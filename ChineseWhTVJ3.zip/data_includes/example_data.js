//this expt. adds a separate sentence after the last one in the first TVJ experiment.
//the items are adapted from Expt1 turth value judgments, but item 10 and 16 had issues before, corrected here. 
var shuffleSequence = seq("intro","setcounter","practice", "presep", sepWith("sep", rshuffle(startsWith("wh"), "f")), "exit");
var practiceItemTypes = ["practice"];

var progressBarText = "您的进度是"
var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: false
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "请按此键继续。"
    }
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro4.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro5.html" }} ],
["setcounter", "__SetCounter__", { }],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

["sep", Separator, { }],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "下面您会做几个练习的例子。"],
                     
                          ["br",],
                          ["br",],
                          ["p", "请按空格键继续"],
                          ]}],
                             
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小宝的妈妈让他把碗里的胡萝卜吃完了才可以吃甜点。小宝很讨厌吃胡萝卜， 但他还是把大部分都吃了， 只剩了几块硬邦邦的。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(您下面会读到一个句子。您需要判断这个句子描述的意思符不符合您以上读到的这个场景。)"],
                          ["p", "(如果您准备好了， 请按空格键)"],
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小宝没有把所有的胡萝卜吃完。",
                              as: ["符合。",
                                   "不符合。"]}],
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "正确答案是 ‘1. 符合’。 您答对了吗？"],
               
                          ["p", "请按空格键继续"],
                          ]}], 
                             
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "元旦汇演的时候丽莎的班上要排一个大合唱， 但学生人数不够。老师把能找来的学生都找来了， 也不管他们会不会唱歌。连小明都被拉进了合唱团。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(您下面会读到一个句子。您需要判断这个句子描述的意思符不符合您以上读到的这个场景。)"],
                          ["p", "(如果您准备好了， 请按空格键)"],
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小明大概很会唱歌。",
                              as: ["符合。",
                                   "不符合。"]}],
                                 
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "正确答案是 ‘2. 不符合’。 您答对了吗？"],
               
                          ["p", "请按空格键继续"],
                          ]}], 
    
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "您知道怎么做了吗？"],
                          ["p", "下面您会再看到几个例子。 您不会再收到任何提示。"],
                          ["br",],
                          ["p", "请按空格键继续"],
                          ]}], 
    
                             
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "春节的时候幼儿园的小朋友想给园长买一个礼物。他们叽叽喳喳讨论半天， 有的说买盆花， 有的说买套书。最后所有的小朋友都同意买副眼镜。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "有一些小朋友想给园长买副眼镜。",
                              as: ["符合。",
                                   "不符合。"]}],
                                 
    
     ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "麦克毕业后自己开了家公司， 每天他的日程都排得很满。这天晚上睡觉之前他忽然觉得自己是不是忘了一件重要的事， 但他想了半天也没想起来是什么事。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "麦克发现自己忘了一件重要的事。",
                              as: ["符合。",
                                   "不符合。"]}],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "练习结束。下面进入正式实验。请按空格键继续。"],
                          ]}],
    
   
    ["presep", Separator, { transfer: 2000, normalMessage: "请准备好， 我们要开始了。请等待。。。" }],

    
[ [ "wh-a", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。 会议之后大会主席发表了一份声明说大会同意对某些国家的制裁将会取消, 而对另一些国家则会继续。 但具体的国家暂时对外界保密。现场的气氛很热烈因为记者们问了很多的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "大会主席宣布了会议决定了联合国应该对哪些国家取消制裁。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。 会议之后大会主席发表了一份声明说大会同意对某些国家的制裁将会取消, 而对另一些国家则会继续。 但具体的国家暂时对外界保密。现场的气氛很热烈因为记者们问了很多的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "大会主席没有宣布会议决定了联合国应该对哪些国家取消制裁。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。 会议之后大会主席发表了一份声明说大会同意对某些国家的制裁将会取消, 而对另一些国家则会继续。 但具体的国家暂时对外界保密。现场的气氛很热烈因为记者们问了很多的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "大会主席宣布了会议否决了联合国应该对哪些国家取消制裁。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。 会议之后大会主席发表了一份声明说大会同意对某些国家的制裁将会取消, 而对另一些国家则会继续。 但具体的国家暂时对外界保密。现场的气氛很热烈因为记者们问了很多的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "大会主席没有宣布会议否决了联合国应该对哪些国家取消制裁。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-a", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都了发言。 王总记得财务部在会议上汇报了今年盈利和亏损的详细情况, 但是他忘记了具体的盈利数额。王总让秘书预定一家餐厅让大家一起年终聚餐。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王总记得财务部报告了公司今年赚了多少钱。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都作了发言。 王总记得财务部在会议上汇报了今年盈利和亏损的详细情况, 但是他忘记了具体的盈利数额。王总让秘书预定一家餐厅让大家一起年终聚餐。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王总不记得财务部报告了公司今年赚了多少钱。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都作了发言。 王总记得财务部在会议上汇报了今年盈利和亏损的详细情况, 但是他忘记了具体的盈利数额。王总让秘书预定一家餐厅让大家一起年终聚餐。。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王总记得财务部相信公司今年赚了多少钱。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都作了发言。 王总记得财务部在会议上汇报了今年盈利和亏损的详细情况, 但是他忘记了具体的盈利数额。王总让秘书预定一家餐厅让大家一起年终聚餐。。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王总不记得财务部相信公司今年赚了多少钱。",
                              as: ["符合.",
                                   "不符合."]}],
[ [ "wh-a", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的。 但目前她对这个城市的名字保密。听众里有一位教授问了艾米丽一些关于历史文献的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "艾米丽公布了她的团队发现了外星人建造了哪座城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的。 但目前她对这个城市的名字保密。听众里有一位教授问了艾米丽一些关于历史文献的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "艾米丽隐瞒了她的团队发现了外星人建造了哪座城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的。 但目前她对这个城市的名字保密。听众里有一位教授问了艾米丽一些关于历史文献的问题。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "艾米丽公布了她的团队相信外星人建造了哪座城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的。 但目前她对这个城市的名字保密。听众里有一位教授问了艾米丽一些关于历史文献的问题。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "艾米丽隐瞒了她的团队相信外星人建造了哪座城市。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-a", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。 他上次旅行回来之后发现朋友们在猜测他去了哪里。 不过他不太清楚朋友们都给出了什么样的答案。妈妈让小王把带回来的礼物分给朋友们让大家高兴高兴。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小王知道他的朋友们在讨论他去了哪些城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。 他上次旅行回来之后发现朋友们在猜测他去了哪里。 不过他不太清楚朋友们都给出了什么样的答案。妈妈让小王把带回来的礼物分给朋友们让大家高兴高兴。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小王不知道他的朋友们在讨论他去了哪些城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。 他上次旅行回来之后发现朋友们在猜测他去了哪里。 不过他不太清楚朋友们都给出了什么样的答案。妈妈让小王把带回来的礼物分给朋友们让大家高兴高兴。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小王知道他的朋友们认为他去了哪些城市。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。 他上次旅行回来之后发现朋友们在猜测他去了哪里。 不过他不太清楚朋友们都给出了什么样的答案。妈妈让小王把带回来的礼物分给朋友们让大家高兴高兴。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小王不知道他的朋友们认为他去了哪些城市。",
                              as: ["符合.",
                                   "不符合."]}],                             

[ [ "wh-a", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。 他们发现嫌疑人在酒后向女朋友丽莎透露过关于下一个抢劫目标的计划。 但是警察对具体的细节包括时间和地点还是毫无头绪, 因为丽莎拒绝把这些重要的信息交给警察。警察局长让助手整理一下最近一年发生的所有抢劫案的具体信息。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "警察知道丽莎打听到犯罪嫌疑人要抢劫哪家银行。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。 他们发现嫌疑人在酒后向女朋友丽莎透露过关于下一个抢劫目标的计划。 但是警察对具体的细节包括时间和地点还是毫无头绪, 因为丽莎拒绝把这些重要的信息交给警察。警察局长让助手整理一下最近一年发生的所有抢劫案的具体信息。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "警察不知道丽莎打听到犯罪嫌疑人要抢劫哪家银行。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。 他们发现嫌疑人在酒后向女朋友丽莎透露过关于下一个抢劫目标的计划。 但是警察对具体的细节包括时间和地点还是毫无头绪, 因为丽莎拒绝把这些重要的信息交给警察。警察局长让助手整理一下最近一年发生的所有抢劫案的具体信息。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "警察知道丽莎相信犯罪嫌疑人要抢劫哪家银行。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。 他们发现嫌疑人在酒后向女朋友丽莎透露过关于下一个抢劫目标的计划。 但是警察对具体的细节包括时间和地点还是毫无头绪, 因为丽莎拒绝把这些重要的信息交给警察。警察局长让助手整理一下最近一年发生的所有抢劫案的具体信息。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "警察不知道丽莎相信犯罪嫌疑人要抢劫哪家银行。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-a", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都非常繁忙。 这天开会的时候他告诉大家, 他已经向董事会提交了辞呈, 辞去现任的职务中的一个。 但辞呈里具体写的要辞掉的工作他现在不方便告诉大家, 要等董事会同意了再说。朋友们都让他好好休个长假放松一下。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "约翰公开了他已经告诉了董事会自己应该辞去哪个职务。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都非常繁忙。 这天开会的时候他告诉大家, 他已经向董事会提交了辞呈, 辞去现任的职务中的一个。 但辞呈里具体写的要辞掉的工作他现在不方便告诉大家, 要等董事会同意了再说。朋友们都让他好好休个长假放松一下。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "约翰没有公开他已经告诉了董事会自己应该辞去哪个职务。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都非常繁忙。 这天开会的时候他告诉大家, 他已经向董事会提交了辞呈, 辞去现任的职务中的一个。 但辞呈里具体写的要辞掉的工作他现在不方便告诉大家, 要等董事会同意了再说。朋友们都让他好好休个长假放松一下。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "约翰公开了他认为自己应该辞去哪个职务。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都非常繁忙。 这天开会的时候他告诉大家, 他已经向董事会提交了辞呈, 辞去现任的职务中的一个。 但辞呈里具体写的要辞掉的工作他现在不方便告诉大家, 要等董事会同意了再说。朋友们都让他好好休个长假放松一下。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "约翰没有公开他认为自己应该辞去哪个职务。",
                              as: ["符合.",
                                   "不符合."]}],
[ [ "wh-a", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理. 他猜测这五个中的一个会升职, 而且老板很快就会通知大家。 他觉得这五个人每个人都有差不多的机会, 都有可能是最后的幸运儿。 周一这天, 老板果然将一个副经理升成了正经理。升职的同事请所有朋友吃了一顿大餐。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "马克预料到了老板很快会揭晓他要提升哪个副经理。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理. 他猜测这五个中的一个会升职, 而且老板很快就会通知大家。 他觉得这五个人每个人都有差不多的机会, 都有可能是最后的幸运儿。 周一这天, 老板果然将一个副经理升成了正经理。升职的同事请所有朋友吃了一顿大餐。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "马克没有预料到老板很快会揭晓他要提升哪个副经理。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理. 他猜测这五个中的一个会升职, 而且老板很快就会通知大家。 他觉得这五个人每个人都有差不多的机会, 都有可能是最后的幸运儿。 周一这天, 老板果然将一个副经理升成了正经理。升职的同事请所有朋友吃了一顿大餐。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "马克预料到了老板心里认为他应该提升哪个副经理。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理. 他猜测这五个中的一个会升职, 而且老板很快就会通知大家。 他觉得这五个人每个人都有差不多的机会, 都有可能是最后的幸运儿。 周一这天, 老板果然将一个副经理升成了正经理。升职的同事请所有朋友吃了一顿大餐。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "马克没有预料到老板心里认为他应该提升哪个副经理。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-a", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。 她写信告诉父母说自己已经上交了志愿表, 而且对新的大学生活充满期待。 但她拒绝告诉父母自己填写的具体内容。玛丽的老师到玛丽家进行了一次家访和玛丽的父母聊了聊。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽告诉了父母她已经决定了自己想去哪所学校。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。 她写信告诉父母说自己已经上交了志愿表, 而且对新的大学生活充满期待。 但她拒绝告诉父母自己填写的具体内容。玛丽的老师到玛丽家进行了一次家访和玛丽的父母聊了聊。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽没告诉父母她已经决定了自己想去哪所学校。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。 她写信告诉父母说自己已经上交了志愿表, 而且对新的大学生活充满期待。 但她拒绝告诉父母自己填写的具体内容。玛丽的老师到玛丽家进行了一次家访和玛丽的父母聊了聊。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽告诉了父母她觉得自己想去哪所学校。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。 她写信告诉父母说自己已经上交了志愿表, 而且对新的大学生活充满期待。 但她拒绝告诉父母自己填写的具体内容。玛丽的老师到玛丽家进行了一次家访和玛丽的父母聊了聊。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽没告诉父母她觉得自己想去去哪所学校。",
                              as: ["符合.",
                                   "不符合."]}],     
   
   
[ [ "wh-a", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在一次记者采访中, 大明星克鲁斯坦承说随着年纪的增长, 他开始发现自己年轻时候做错了一些事, 而且对自己当年的行为非常后悔。 但当记者追问他能不能给出一些具体例子的时候, 他回避了这个问题。这次直率的访谈进行了很长时间双方都很满意。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "克鲁斯告诉了记者他意识到了自己曾经做错了哪些事。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在一次记者采访中, 大明星克鲁斯坦承说随着年纪的增长, 他开始发现自己年轻时候做错了一些事, 而且对自己当年的行为非常后悔。 但当记者追问他能不能给出一些具体例子的时候, 他回避了这个问题。这次直率的访谈进行了很长时间双方都很满意。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "克鲁斯没有告诉记者他意识到了自己曾经做错了哪些事。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在一次记者采访中, 大明星克鲁斯坦承说随着年纪的增长, 他开始发现自己年轻时候做错了一些事, 而且对自己当年的行为非常后悔。 但当记者追问他能不能给出一些具体例子的时候, 他回避了这个问题。这次直率的访谈进行了很长时间双方都很满意。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "克鲁斯告诉了记者他很后悔自己曾经做错了哪些事。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在一次记者采访中, 大明星克鲁斯坦承说随着年纪的增长, 他开始发现自己年轻时候做错了一些事, 而且对自己当年的行为非常后悔。 但当记者追问他能不能给出一些具体例子的时候, 他回避了这个问题。这次直率的访谈进行了很长时间双方都很满意。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "克鲁斯没有告诉记者他很后悔自己曾经做错了哪些事。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-a", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩的时候, 想去那家朋友大力推荐给他,说非常好吃的一家中国餐厅。 但他想不起来餐厅的名字和地址了。小张玩得不错因为宾馆前台的服务生给他介绍了几个好玩的地方。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小张记得他的朋友告诉过他应该去试一试哪一家餐厅。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩的时候, 想去那家朋友大力推荐给他,说非常好吃的一家中国餐厅。 但他想不起来餐厅的名字和地址了。小张玩得不错因为宾馆前台的服务生给他介绍了几个好玩的地方。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小张忘记了他的朋友告诉过他应该去试一试哪一家餐厅。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩的时候, 想去那家朋友大力推荐给他,说非常好吃的一家中国餐厅。 但他想不起来餐厅的名字和地址了。小张玩得不错因为宾馆前台的服务生给他介绍了几个好玩的地方。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小张记得他的朋友认为他应该去试一试哪一家餐厅。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩的时候, 想去那家朋友大力推荐给他,说非常好吃的一家中国餐厅。 但他想不起来餐厅的名字和地址了。小张玩得不错因为宾馆前台的服务生给他介绍了几个好玩的地方。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小张忘记了他的朋友认为他应该去试一试哪一家餐厅。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-a", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。 不过一个在学校里工作的朋友告诉他说这个系的系主任其实已经内定了人选, 公开招聘只是走个形式。 没有人知道这个内定的候选人的具体身份。小李还申请了很多其他学校的工作。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小李打听到了系主任决定了物理系要把工作给哪个候选人。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。 不过一个在学校里工作的朋友告诉他说这个系的系主任其实已经内定了人选, 公开招聘只是走个形式。 没有人知道这个内定的候选人的具体身份。小李还申请了很多其他学校的工作。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小李没打听到系主任决定了物理系要把工作给哪个候选人。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。 不过一个在学校里工作的朋友告诉他说这个系的系主任其实已经内定了人选, 公开招聘只是走个形式。 没有人知道这个内定的候选人的具体身份。小李还申请了很多其他学校的工作。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小李打听到了系主任相信物理系应该把工作给哪个候选人。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。 不过一个在学校里工作的朋友告诉他说这个系的系主任其实已经内定了人选, 公开招聘只是走个形式。 没有人知道这个内定的候选人的具体身份。小李还申请了很多其他学校的工作。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小李没打听到系主任相信物理系应该把工作给哪个候选人。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-a", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件。 他发现有一个员工挪用了巨额的公款。 他在记者会上通报了这一情况, 并且告诉大家所有公款的数额和去向都已经查明。 但由于公款失踪数额惊人, 为避免引发混乱, 他没有在记者会上告诉大家具体的数字。记者们问了他很多问题，保罗累坏了。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "保罗向记者们公布了他查清楚了贪污犯挪用了多少公款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件。 他发现有一个员工挪用了巨额的公款。 他在记者会上通报了这一情况, 并且告诉大家所有公款的数额和去向都已经查明。 但由于公款失踪数额惊人, 为避免引发混乱, 他没有在记者会上告诉大家具体的数字。记者们问了他很多问题，保罗累坏了。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "保罗没有向记者们透露他查清楚了贪污犯挪用了多少公款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件。 他发现有一个员工挪用了巨额的公款。 他在记者会上通报了这一情况, 并且告诉大家所有公款的数额和去向都已经查明。 但由于公款失踪数额惊人, 为避免引发混乱, 他没有在记者会上告诉大家具体的数字。记者们问了他很多问题，保罗累坏了。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "保罗向记者们公布了他认为贪污犯挪用了多少公款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件。 他发现有一个员工挪用了巨额的公款。 他在记者会上通报了这一情况, 并且告诉大家所有公款的数额和去向都已经查明。 但由于公款失踪数额惊人, 为避免引发混乱, 他没有在记者会上告诉大家具体的数字。记者们问了他很多问题，保罗累坏了。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "保罗没有向记者们透露他认为贪污犯挪用了多少公款。",
                              as: ["符合.",
                                   "不符合."]}],                             

[ [ "wh-a", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。 但今天她自己做的时候怎么也想不起来老师说过的糖和面粉的比例。玛丽的老师是一个很有名的甜点师傅，得过很多奖。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽记得老师解释过一份面粉要加多少糖。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。 但今天她自己做的时候怎么也想不起来老师说过的糖和面粉的比例。玛丽的老师是一个很有名的甜点师傅，得过很多奖。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽忘记了老师解释过一份面粉要加多少糖。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。 但今天她自己做的时候怎么也想不起来老师说过的糖和面粉的比例。玛丽的老师是一个很有名的甜点师傅，得过很多奖。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽记得老师认为一份面粉要加多少糖。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。 但今天她自己做的时候怎么也想不起来老师说过的糖和面粉的比例。玛丽的老师是一个很有名的甜点师傅，得过很多奖。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "玛丽忘记了老师认为一份面粉要加多少糖。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-a", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 经过调查核实, 他向学校汇报说他确认了被抄袭的内容的来源, 但是他没有明确指出原文作者的名字和身份。校长决定给这个学生严重处分。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王教授告诉了学校他调查到了这个学生抄袭了哪个作者。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 经过调查核实, 他向学校汇报说他确认了被抄袭的内容的来源, 但是他没有明确指出原文作者的名字和身份。校长决定给这个学生严重处分。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王教授没有告诉学校他调查到了这个学生抄袭了哪个作者。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 经过调查核实, 他向学校汇报说他确认了被抄袭的内容的来源, 但是他没有明确指出原文作者的名字和身份。校长决定给这个学生严重处分。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王教授告诉了学校他认为这个学生抄袭了哪个作者。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 经过调查核实, 他向学校汇报说他确认了被抄袭的内容的来源, 但是他没有明确指出原文作者的名字和身份。校长决定给这个学生严重处分。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "王教授没有告诉学校他认为这个学生抄袭了哪个作者。",
                              as: ["符合.",
                                   "不符合."]}],
[ [ "wh-a", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行通知公司说贷款数额太大, 只可以贷给他们一部分。 银行已经内部讨论决定了具体可贷金额, 但公司还要再等一个星期才可以知道具体的数额。茱莉很喜欢自己的工作，和同事们关系很好。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "茱莉的公司被告知了银行决定了他们能借给公司多少贷款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行通知公司说贷款数额太大, 只可以贷给他们一部分。 银行已经内部讨论决定了具体可贷金额, 但公司还要再等一个星期才可以知道具体的数额。茱莉很喜欢自己的工作，和同事们关系很好。"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "茱莉的公司还没被告知银行决定了他们能借给公司多少贷款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-c", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行通知公司说贷款数额太大, 只可以贷给他们一部分。 银行已经内部讨论决定了具体可贷金额, 但公司还要再等一个星期才可以知道具体的数额。茱莉很喜欢自己的工作，和同事们关系很好。"],
                      
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "茱莉的公司被告知了银行认为他们能借给公司多少贷款。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行通知公司说贷款数额太大, 只可以贷给他们一部分。 银行已经内部讨论决定了具体可贷金额, 但公司还要再等一个星期才可以知道具体的数额。茱莉很喜欢自己的工作，和同事们关系很好。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "茱莉的公司还没被告知银行认为他们能借给公司多少贷款。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-a", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。 她的朋友知道她做了这个梦之后天天向她打听这匹马是什么样的。 但是卡门不愿意告诉自己的朋友关于这匹马的任何细节。卡门已经在计划赢了钱之后要去很多地方旅行。"],
                       
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "卡门的朋友知道她梦到了比赛的冠军属于哪一匹马。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-b", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。 她的朋友知道她做了这个梦之后天天向她打听这匹马是什么样的。 但是卡门不愿意告诉自己的朋友关于这匹马的任何细节。卡门已经在计划赢了钱之后要去很多地方旅行。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "卡门的朋友不知道她梦到了比赛的冠军属于哪一匹马。",
                              as: ["符合.",
                                   "不符合."]}],
    
[ [ "wh-c", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。 她的朋友知道她做了这个梦之后天天向她打听这匹马是什么样的。 但是卡门不愿意告诉自己的朋友关于这匹马的任何细节。卡门已经在计划赢了钱之后要去很多地方旅行。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "卡门的朋友知道她觉得比赛的冠军属于哪一匹马。",
                              as: ["符合.",
                                   "不符合."]}],
                                   
[ [ "wh-d", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。 她的朋友知道她做了这个梦之后天天向她打听这匹马是什么样的。 但是卡门不愿意告诉自己的朋友关于这匹马的任何细节。卡门已经在计划赢了钱之后要去很多地方旅行。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "卡门的朋友不知道她觉得比赛的冠军属于哪一匹马。",
                              as: ["符合.",
                                   "不符合."]}],   
    
    // 10 self-paced-reading filler sentences.
    //


[ [ "f", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在期末考试之后张教授和他的助教苏珊一起批改完了考卷, 发现只有一个学生得了A。 但几天以后张教授在给教务处上报成绩的时候记不清那个得了A的学生的名字, 结果把成绩给报错了。 苏珊把这件事讲给她的几个朋友听, 但是为了保护学生私人信息她隐去了那个得了A的学生的名字。朋友们问她：‘最后学校向学生道歉了没有？’"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "苏珊相信张教授忘记了他给了哪个学生A。",
                              as: ["符合.",
                                   "不符合."]}], 
   
[ [ "f", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "公司最近业务很差。 卡洛斯猜测公司很快会让各个部门裁员。 但因为信息不够, 具体的裁员名单很难猜。 一周之后, 公司果然大裁员。卡洛斯问老板：‘下一轮裁员什么时候会到来？’"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "卡洛斯相信公司很快会宣布各个部门要裁掉哪些员工。",
                              as: ["符合.",
                                   "不符合."]}], 

[ [ "f", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "克丽丝热衷于讨论政治。 最近美国和好几个国家有战争的可能性。 克丽丝预言说总统会在下周的电视演说里告诉大家他要出兵的国家, 但克丽丝并不确定这个国家是哪个。反战的朋友问克丽丝：‘为什么战争被选做解决问题的方法呢？’"],
                       
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "克丽丝认为总统下周会宣布他要出兵哪个国家。",
                              as: ["符合.",
                                   "不符合."]}], 
   
[ [ "f", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "期末考试之后, 历史老师在班上批评小明说他连秦朝的第一个皇帝是谁这么简单的题目都答错了。 不过老师没有提小明给的答案是什么。家长会之后妈妈问小明：‘你准备怎样把成绩赶上去呢？’"],
                         
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "历史老师认为小明弄错了秦朝的第一个皇帝是谁。",
                              as: ["符合.",
                                   "不符合."]}],  
  

[ [ "f", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "哈里叫他的朋友来火车站接自己。 但是他忘了告诉朋友他坐哪趟车了。 他不太确定他的朋友以为自己会什么时候到。更糟糕的是哈里不记得朋友的电话号码是什么了， 只好打电话问妈妈。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "哈里担心自己的朋友不知道自己什么时候到。",
                              as: ["符合.",
                                   "不符合."]}], 
    
    
[ [ "f", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "汤姆买彩票中了大奖! 他告诉朋友们自己已经计划好了怎么用这笔钱, 但具体的计划他没有告诉大家。除了朋友之外没有人知道这个中大奖的幸运儿是谁， 所以大家都在互相打听。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "汤姆否认他已经决定了自己要怎样用赢彩票的钱。",
                              as: ["符合.",
                                   "不符合."]}], 

[ [ "f", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "总统大选快到了。 艾伦告诉朋友们自己很早就决定了要投票给谁。 但他并没有透露具体的候选人, 因为担心朋友之间政治立场不同。他又向朋友们询问怎样在国外投票，因为他旅居国外。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "朋友们不相信艾伦已经确认了他要把票投给哪个候选人。",
                              as: ["符合.",
                                   "不符合."]}], 
   
[ [ "f", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "老王买了一栋很老的房子。 他在地下室找到一份陈旧的房屋图纸, 上面列出了主卧客房的计划。 但这份图纸旧得字迹都模糊了, 老王没看出来到底哪个房间是客房。老王怀疑房屋中介是不是骗了他，他想知道这个房子是不是比房屋中介告诉他的还要老很多。"],
                       
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "老王不认为原先的屋主计划好了哪个房间被用来作客房。",
                              as: ["符合.",
                                   "不符合."]}], 

  
[ [ "f", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授让小李送一本书给另一个老师。 但是小李忘记王教授说的这个老师的名字了。 他在教学楼里转来转去, 怎么也没想起来。另一个老师看见了小李，问他在这里做什么。"],
                        
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小李怀疑王教授明确说过书要交给哪个老师。",
                              as: ["符合.",
                                   "不符合."]}], 
 


[ [ "f", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "今年的电影节有三部影片入围最佳电影奖。 小张听说评委会已经在周一开会决定了最后的获奖名单。 但是具体的名单在颁奖典礼之前对外界完全保密，小张没有打听到任何消息。他想知道自己最喜欢的几个明星会不会出席典礼。"],
                          
                          ]},
                 "Question", {hasCorrect: false, randomOrder: false,
                              q: "小张不相信评委会已经决定了他们要把最佳电影奖颁给哪部电影。",
                              as: ["符合.",
                                   "不符合."]}],  
];
