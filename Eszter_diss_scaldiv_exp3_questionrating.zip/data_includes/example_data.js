define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("v"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: null,
        leftComment: "(very unnatural)", rightComment: "(very natural)"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: false
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],


 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: decide which of two questions you are more likely to ask regarding an individual or topic."] 
],continueMessage:"Click here to start the experiment."}],



  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 ["practice", "MyController", {html: "<p>Compare the following two questions about a wrestler. Which one are you more likely to ask?</p>", q:"", as: ["Is the wrestler weak?", "Is the wrestler strong?"], hasCorrect: 0, randomOrder: true}],
["practice", "MyController", {html: "<p>Compare the following two questions about a spy. Which one are you more likely to ask?</p>", q:"", as: ["Did the spy discover the plan?", "Did the spy memorize the plan?"], hasCorrect: 0, randomOrder: true}],
["practice", "MyController", {html: "<p>Compare the following two questions about a student. Which one are you more likely to ask?</p>", q:"", as: ["Is the student brilliant?", "Is the student intelligent?"], hasCorrect: 0, randomOrder: true}],

                  //Experimental items
 
//strong scalar term always the first option here
[["version1",1], "MyController",       {html: "<p>Compare the following two questions about food. Which one are you more likely to ask?</p>", q:"", as: ["Is the food good?", "Is the food adequate?"], hasCorrect: 0, randomOrder: true}],
[["version3",1], "MyController",       {html: "<p>Compare the following two questions about a salary. Which one are you more likely to ask?</p>", q:"", as: ["Is the salary good?", "Is the salary adequate?"], hasCorrect: 0, randomOrder: true}],
[["version2",1], "MyController",       {html: "<p>Compare the following two questions about a solution. Which one are you more likely to ask?</p>", q:"", as: ["Is the solution good?", "Is the solution adequate?"], hasCorrect: 0, randomOrder: true}],

[["version1",2], "MyController",       {html: "<p>Compare the following two questions about talking. Which one are you more likely to ask?</p>", q:"", as: ["Is talking obligatory?", "Is talking allowed?"], hasCorrect: 0, randomOrder: true}],
[["version3",2], "MyController",       {html: "<p>Compare the following two questions about drinking. Which one are you more likely to ask?</p>", q:"", as: ["Is drinking obligatory?", "Is drinking allowed?"], hasCorrect: 0, randomOrder: true}],
[["version2",2], "MyController",       {html: "<p>Compare the following two questions about copying. Which one are you more likely to ask?</p>", q:"", as: ["Is copying obligatory?", "Is copying allowed?"], hasCorrect: 0, randomOrder: true}],

[["version1",3], "MyController",       {html: "<p>Compare the following two questions about a nurse. Which one are you more likely to ask?</p>", q:"", as: ["Is the nurse stunning?", "Is the nurse attractive?"], hasCorrect: 0, randomOrder: true}],
[["version3",3], "MyController",       {html: "<p>Compare the following two questions about a model. Which one are you more likely to ask?</p>", q:"", as: ["Is the model stunning?", "Is the model attractive?"], hasCorrect: 0, randomOrder: true}],
[["version2",3], "MyController",       {html: "<p>Compare the following two questions about a singer. Which one are you more likely to ask?</p>", q:"", as: ["Is the singer stunning?", "Is the singer attractive?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",4], "MyController",       {html: "<p>Compare the following two questions about a student. Which one are you more likely to ask?</p>", q:"", as: ["Does the student know it will work out?", "Does the student believe it will work out?"], hasCorrect: 0, randomOrder: true}],
[["version3",4], "MyController",       {html: "<p>Compare the following two questions about a mother. Which one are you more likely to ask?</p>", q:"", as: ["Does the mother know it will happen?", "Does the mother believe it will happen?"], hasCorrect: 0, randomOrder: true}],
[["version2",4], "MyController",       {html: "<p>Compare the following two questions about a teacher. Which one are you more likely to ask?</p>", q:"", as: ["Does the teacher know it is true?", "Does the teacher believe it is true?"], hasCorrect: 0, randomOrder: true}],

[["version1",5], "MyController",       {html: "<p>Compare the following two questions about an elephant. Which one are you more likely to ask?</p>", q:"", as: ["Is the elephant enormous?", "Is the elephant big?"], hasCorrect: 0, randomOrder: true}],
[["version3",5], "MyController",       {html: "<p>Compare the following two questions about a house. Which one are you more likely to ask?</p>", q:"", as: ["Is the house enormous?", "Is the house big?"], hasCorrect: 0, randomOrder: true}],
[["version2",5], "MyController",       {html: "<p>Compare the following two questions about a tree. Which one are you more likely to ask?</p>", q:"", as: ["Is the tree enormous?", "Is the tree big?"], hasCorrect: 0, randomOrder: true}],

[["version1",6], "MyController",       {html: "<p>Compare the following two questions about water. Which one are you more likely to ask?</p>", q:"", as: ["Is the water free?", "Is the water cheap?"], hasCorrect: 0, randomOrder: true}],
[["version3",6], "MyController",       {html: "<p>Compare the following two questions about electricity. Which one are you more likely to ask?</p>", q:"", as: ["Is the electricity free?", "Is the electricity cheap?"], hasCorrect: 0, randomOrder: true}],
[["version2",6], "MyController",       {html: "<p>Compare the following two questions about food. Which one are you more likely to ask?</p>", q:"", as: ["Is the food free?", "Is the food cheap?"], hasCorrect: 0, randomOrder: true}],

[["version1",7], "MyController",       {html: "<p>Compare the following two questions about a child. Which one are you more likely to ask?</p>", q:"", as: ["Is the child happy?", "Is the child content?"], hasCorrect: 0, randomOrder: true}],
[["version3",7], "MyController",       {html: "<p>Compare the following two questions about a homemaker. Which one are you more likely to ask?</p>", q:"", as: ["Is the homemaker happy?", "Is the homemaker content?"], hasCorrect: 0, randomOrder: true}],
[["version2",7], "MyController",       {html: "<p>Compare the following two questions about a musician. Which one are you more likely to ask?</p>", q:"", as: ["Is the musician happy?", "Is the musician content?"], hasCorrect: 0, randomOrder: true}],

[["version1",8], "MyController",       {html: "<p>Compare the following two questions about air. Which one are you more likely to ask?</p>", q:"", as: ["Is the air cold?", "Is the air cool?"], hasCorrect: 0, randomOrder: true}],
[["version3",8], "MyController",       {html: "<p>Compare the following two questions about the weather. Which one are you more likely to ask?</p>", q:"", as: ["Is the weather cold?", "Is the weather cool?"], hasCorrect: 0, randomOrder: true}],
[["version2",8], "MyController",       {html: "<p>Compare the following two questions about a room. Which one are you more likely to ask?</p>", q:"", as: ["Is the room cold?", "Is the room cool?"], hasCorrect: 0, randomOrder: true}],

[["version1",9], "MyController",       {html: "<p>Compare the following two questions about a fabric. Which one are you more likely to ask?</p>", q:"", as: ["Is the fabric black?", "Is the fabric dark?"], hasCorrect: 0, randomOrder: true}],
[["version3",9], "MyController",       {html: "<p>Compare the following two questions about the sky. Which one are you more likely to ask?</p>", q:"", as: ["Is the sky black?", "Is the sky dark?"], hasCorrect: 0, randomOrder: true}],
[["version2",9], "MyController",       {html: "<p>Compare the following two questions about a shirt. Which one are you more likely to ask?</p>", q:"", as: ["Is the shirt black?", "Is the shirt dark?"], hasCorrect: 0, randomOrder: true}],

[["version1",10], "MyController",       {html: "<p>Compare the following two questions about a task. Which one are you more likely to ask?</p>", q:"", as: ["Is the task impossible?", "Is the task difficult?"], hasCorrect: 0, randomOrder: true}],
[["version3",10], "MyController",       {html: "<p>Compare the following two questions about a journey. Which one are you more likely to ask?</p>", q:"", as: ["Is the journey impossible?", "Is the journey difficult?"], hasCorrect: 0, randomOrder: true}],
[["version2",10], "MyController",       {html: "<p>Compare the following two questions about a problem. Which one are you more likely to ask?</p>", q:"", as: ["Is the problem impossible?", "Is the problem difficult?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",11], "MyController",       {html: "<p>Compare the following two questions about a boy. Which one are you more likely to ask?</p>", q:"", as: ["Does the boy loathe broccoli?", "Does the boy dislike broccoli?"], hasCorrect: 0, randomOrder: true}],
[["version3",11], "MyController",       {html: "<p>Compare the following two questions about a teacher. Which one are you more likely to ask?</p>", q:"", as: ["Does the teacher loathe fighting?", "Does the teacher dislike fighting?"], hasCorrect: 0, randomOrder: true}],
[["version2",11], "MyController",       {html: "<p>Compare the following two questions about a doctor. Which one are you more likely to ask?</p>", q:"", as: ["Does the doctor loathe coffee?", "Does the doctor dislike coffee?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",12], "MyController",       {html: "<p>Compare the following two questions about a biologist. Which one are you more likely to ask?</p>", q:"", as: ["Did the biologist see none of the birds?", "Did the biologist see few of the birds?"], hasCorrect: 0, randomOrder: true}],
[["version3",12], "MyController",       {html: "<p>Compare the following two questions about a cop. Which one are you more likely to ask?</p>", q:"", as: ["Did the cop see none of the children?", "Did the cop see few of the children?"], hasCorrect: 0, randomOrder: true}],
[["version2",12], "MyController",       {html: "<p>Compare the following two questions about an observer. Which one are you more likely to ask?</p>", q:"", as: ["Did the observer see none of the stars?", "Did the observer see few of the stars?"], hasCorrect: 0, randomOrder: true}],

[["version1",13], "MyController", {html: "<p>Compare the following two questions about a joke. Which one are you more likely to ask?</p>", q:"", as: ["Is the joke hilarious?", "Is the joke funny?"], hasCorrect: 0, randomOrder: true}],
[["version3",13], "MyController", {html: "<p>Compare the following two questions about a play. Which one are you more likely to ask?</p>", q:"", as: ["Is the play hilarious?", "Is the play funny?"], hasCorrect: 0, randomOrder: true}],
[["version2",13], "MyController", {html: "<p>Compare the following two questions about a movie. Which one are you more likely to ask?</p>", q:"", as: ["Is the movie hilarious?", "Is the movie funny?"], hasCorrect: 0, randomOrder: true}],

[["version1",14], "MyController", {html: "<p>Compare the following two questions about food. Which one are you more likely to ask?</p>", q:"", as: ["Is the food excellent?", "Is the food good?"], hasCorrect: 0, randomOrder: true}],
[["version3",14], "MyController", {html: "<p>Compare the following two questions about a movie. Which one are you more likely to ask?</p>", q:"", as: ["Is the movie excellent?", "Is the movie good?"], hasCorrect: 0, randomOrder: true}],
[["version2",14], "MyController", {html: "<p>Compare the following two questions about a sandwich. Which one are you more likely to ask?</p>", q:"", as: ["Is the sandwich excellent?", "Is the sandwich good?"], hasCorrect: 0, randomOrder: true}],

[["version1",15], "MyController", {html: "<p>Compare the following two questions about a layout. Which one are you more likely to ask?</p>", q:"", as: ["Is the layout perfect?", "Is the layout good?"], hasCorrect: 0, randomOrder: true}],
[["version3",15], "MyController", {html: "<p>Compare the following two questions about a solution. Which one are you more likely to ask?</p>", q:"", as: ["Is the solution perfect?", "Is the solution good?"], hasCorrect: 0, randomOrder: true}],
[["version2",15], "MyController", {html: "<p>Compare the following two questions about an answer. Which one are you more likely to ask?</p>", q:"", as: ["Is the answer perfect?", "Is the answer good?"], hasCorrect: 0, randomOrder: true}],

[["version1",16], "MyController", {html: "<p>Compare the following two questions about a problem. Which one are you more likely to ask?</p>", q:"", as: ["Is the problem unsolvable?", "Is the problem hard?"], hasCorrect: 0, randomOrder: true}],
[["version3",16], "MyController", {html: "<p>Compare the following two questions about an issue. Which one are you more likely to ask?</p>", q:"", as: ["Is the issue unsolvable?", "Is the issue hard?"], hasCorrect: 0, randomOrder: true}],
[["version2",16], "MyController", {html: "<p>Compare the following two questions about a puzzle. Which one are you more likely to ask?</p>", q:"", as: ["Is the puzzle unsolvable?", "Is the puzzle hard?"], hasCorrect: 0, randomOrder: true}],

[["version1",17], "MyController", {html: "<p>Compare the following two questions about a boy. Which one are you more likely to ask?</p>", q:"", as: ["Is the boy starving?", "Is the boy hungry?"], hasCorrect: 0, randomOrder: true}],
[["version3",17], "MyController", {html: "<p>Compare the following two questions about a dog. Which one are you more likely to ask?</p>", q:"", as: ["Is the dog starving?", "Is the dog hungry?"], hasCorrect: 0, randomOrder: true}],
[["version2",17], "MyController", {html: "<p>Compare the following two questions about an elephant. Which one are you more likely to ask?</p>", q:"", as: ["Is the elephant starving?", "Is the elephant hungry?"], hasCorrect: 0, randomOrder: true}],

[["version1",18], "MyController", {html: "<p>Compare the following two questions about a dress. Which one are you more likely to ask?</p>", q:"", as: ["Is the dress unique?", "Is the dress special?"], hasCorrect: 0, randomOrder: true}],
[["version3",18], "MyController", {html: "<p>Compare the following two questions about a painting. Which one are you more likely to ask?</p>", q:"", as: ["Is the painting unique?", "Is the painting special?"], hasCorrect: 0, randomOrder: true}],
[["version2",18], "MyController", {html: "<p>Compare the following two questions about a necklace. Which one are you more likely to ask?</p>", q:"", as: ["Is the necklace unique?", "Is the necklace special?"], hasCorrect: 0, randomOrder: true}],

[["version1",19], "MyController", {html: "<p>Compare the following two questions about an assistant. Which one are you more likely to ask?</p>", q:"", as: ["Is the assistant brilliant?", "Is the assistant intelligent?"], hasCorrect: 0, randomOrder: true}],
[["version3",19], "MyController", {html: "<p>Compare the following two questions about a professor. Which one are you more likely to ask?</p>", q:"", as: ["Is the professor brilliant?", "Is the professor intelligent?"], hasCorrect: 0, randomOrder: true}],
[["version2",19], "MyController", {html: "<p>Compare the following two questions about a student. Which one are you more likely to ask?</p>", q:"", as: ["Is the student brilliant?", "Is the student intelligent?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",20], "MyController", {html: "<p>Compare the following two questions about a princess. Which one are you more likely to ask?</p>", q:"", as: ["Does the princess love dancing?", "Does the princess like dancing?"], hasCorrect: 0, randomOrder: true}],
[["version3",20], "MyController", {html: "<p>Compare the following two questions about an actress. Which one are you more likely to ask?</p>", q:"", as: ["Does the actress love the movie?", "Does the actress like the movie?"], hasCorrect: 0, randomOrder: true}],
[["version2",20], "MyController", {html: "<p>Compare the following two questions about a manager. Which one are you more likely to ask?</p>", q:"", as: ["Does the manager love spaghetti?", "Does the manager like spaghetti?"], hasCorrect: 0, randomOrder: true}],

[["version1",21], "MyController", {html: "<p>Compare the following two questions about energy. Which one are you more likely to ask?</p>", q:"", as: ["Is the energy depleted?", "Is the energy low?"], hasCorrect: 0, randomOrder: true}],
[["version3",21], "MyController", {html: "<p>Compare the following two questions about a battery. Which one are you more likely to ask?</p>", q:"", as: ["Is the battery depleted?", "Is the battery low?"], hasCorrect: 0, randomOrder: true}],
[["version2",21], "MyController", {html: "<p>Compare the following two questions about gas. Which one are you more likely to ask?</p>", q:"", as: ["Is the gas depleted?", "Is the gas low?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",22], "MyController", {html: "<p>Compare the following two questions about a child. Which one are you more likely to ask?</p>", q:"", as: ["Does the child have to eat an apple?", "May the child eat an apple?"], hasCorrect: 0, randomOrder: true}],
[["version3",22], "MyController", {html: "<p>Compare the following two questions about a boy. Which one are you more likely to ask?</p>", q:"", as: ["Does the boy have to watch television?", "May the boy watch television?"], hasCorrect: 0, randomOrder: true}],
[["version2",22], "MyController", {html: "<p>Compare the following two questions about a dog. Which one are you more likely to ask?</p>", q:"", as: ["Does the dog have to sleep on the bed?", "May the dog sleep on the bed?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",23], "MyController", {html: "<p>Compare the following two questions about a lawyer. Which one are you more likely to ask?</p>", q:"", as: ["Is it the case that the lawyer will appear in person?", "Is it the case that the lawyer may appear in person?"], hasCorrect: 0, randomOrder: true}],
[["version3",23], "MyController", {html: "<p>Compare the following two questions about a teacher. Which one are you more likely to ask?</p>", q:"", as: ["Is it the case that the teacher will come?", "Is it the case that the teacher may come?"], hasCorrect: 0, randomOrder: true}],
[["version2",23], "MyController", {html: "<p>Compare the following two questions about a student. Which one are you more likely to ask?</p>", q:"", as: ["Is it the case that the student will pass?", "Is it the case that the student may pass?"], hasCorrect: 0, randomOrder: true}],

[["version1",24], "MyController", {html: "<p>Compare the following two questions about a party. Which one are you more likely to ask?</p>", q:"", as: ["Was the party unforgettable?", "Was the party memorable?"], hasCorrect: 0, randomOrder: true}],
[["version3",24], "MyController", {html: "<p>Compare the following two questions about a view. Which one are you more likely to ask?</p>", q:"", as: ["Was the view unforgettable?", "Was the view memorable?"], hasCorrect: 0, randomOrder: true}],
[["version2",24], "MyController", {html: "<p>Compare the following two questions about a movie. Which one are you more likely to ask?</p>", q:"", as: ["Was the movie unforgettable?", "Was the movie memorable?"], hasCorrect: 0, randomOrder: true}],

[["version1",25], "MyController", {html: "<p>Compare the following two questions about a house. Which one are you more likely to ask?</p>", q:"", as: ["Is the house ancient?", "Is the house old?"], hasCorrect: 0, randomOrder: true}],
[["version3",25], "MyController", {html: "<p>Compare the following two questions about a mirror. Which one are you more likely to ask?</p>", q:"", as: ["Is the mirror ancient?", "Is the mirror old?"], hasCorrect: 0, randomOrder: true}],
[["version2",25], "MyController", {html: "<p>Compare the following two questions about a table. Which one are you more likely to ask?</p>", q:"", as: ["Is the table ancient?", "Is the table old?"], hasCorrect: 0, randomOrder: true}],

[["version1",26], "MyController", {html: "<p>Compare the following two questions about food. Which one are you more likely to ask?</p>", q:"", as: ["Is the food delicious?", "Is the food palatable?"], hasCorrect: 0, randomOrder: true}],
[["version3",26], "MyController", {html: "<p>Compare the following two questions about wine. Which one are you more likely to ask?</p>", q:"", as: ["Is the wine delicious?", "Is the wine palatable?"], hasCorrect: 0, randomOrder: true}],
[["version2",26], "MyController", {html: "<p>Compare the following two questions about a dessert. Which one are you more likely to ask?</p>", q:"", as: ["Is the dessert delicious?", "Is the dessert palatable?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here?
[["version1",27], "MyController", {html: "<p>Compare the following two questions about a freshman. Which one are you more likely to ask?</p>", q:"", as: ["Did the freshman win?", "Did the freshman participate?"], hasCorrect: 0, randomOrder: true}],
[["version3",27], "MyController", {html: "<p>Compare the following two questions about a runner. Which one are you more likely to ask?</p>", q:"", as: ["Did the runner win?", "Did the runner participate?"], hasCorrect: 0, randomOrder: true}],
[["version2",27], "MyController", {html: "<p>Compare the following two questions about a skier. Which one are you more likely to ask?</p>", q:"", as: ["Did the skier win?", "Did the skier participate?"], hasCorrect: 0, randomOrder: true}],

//note that I don't use pronouns here
[["version1",28], "MyController", {html: "<p>Compare the following two questions about happiness. Which one are you more likely to ask?</p>", q:"", as: ["Is happiness certain?", "Is happiness possible?"], hasCorrect: 0, randomOrder: true}],
[["version3",28], "MyController", {html: "<p>Compare the following two questions about failing. Which one are you more likely to ask?</p>", q:"", as: ["Is failing certain?", "Is failing possible?"], hasCorrect: 0, randomOrder: true}],
[["version2",28], "MyController", {html: "<p>Compare the following two questions about success. Which one are you more likely to ask?</p>", q:"", as: ["Is success certain?", "Is success possible?"], hasCorrect: 0, randomOrder: true}],

[["version1",29], "MyController", {html: "<p>Compare the following two questions about a model. Which one are you more likely to ask?</p>", q:"", as: ["Is the model beautiful?", "Is the model pretty?"], hasCorrect: 0, randomOrder: true}],
[["version3",29], "MyController", {html: "<p>Compare the following two questions about a lady. Which one are you more likely to ask?</p>", q:"", as: ["Is the lady beautiful?", "Is the lady pretty?"], hasCorrect: 0, randomOrder: true}],
[["version2",29], "MyController", {html: "<p>Compare the following two questions about a girl. Which one are you more likely to ask?</p>", q:"", as: ["Is the girl beautiful?", "Is the girl pretty?"], hasCorrect: 0, randomOrder: true}],

//a fish??
[["version1",30], "MyController", {html: "<p>Compare the following two questions about a plant. Which one are you more likely to ask?</p>", q:"", as: ["Is this plant extinct?", "Is this plant rare?"], hasCorrect: 0, randomOrder: true}],
[["version3",30], "MyController", {html: "<p>Compare the following two questions about a bird. Which one are you more likely to ask?</p>", q:"", as: ["Is this bird extinct?", "Is this bird rare?"], hasCorrect: 0, randomOrder: true}],
[["version2",30], "MyController", {html: "<p>Compare the following two questions about a fish. Which one are you more likely to ask?</p>", q:"", as: ["Is this fish extinct?", "Is this fish rare?"], hasCorrect: 0, randomOrder: true}],

[["version1",31], "MyController", {html: "<p>Compare the following two questions about a recording. Which one are you more likely to ask?</p>", q:"", as: ["Is this recording unavailable?", "Is this recording scarce?"], hasCorrect: 0, randomOrder: true}],
[["version3",31], "MyController", {html: "<p>Compare the following two questions about a resource. Which one are you more likely to ask?</p>", q:"", as: ["Is this resource unavailable?", "Is this resource scarce?"], hasCorrect: 0, randomOrder: true}],
[["version2",31], "MyController", {html: "<p>Compare the following two questions about a mineral. Which one are you more likely to ask?</p>", q:"", as: ["Is this mineral unavailable?", "Is this mineral scarce?"], hasCorrect: 0, randomOrder: true}],

[["version1",32], "MyController", {html: "<p>Compare the following two questions about a song. Which one are you more likely to ask?</p>", q:"", as: ["Is the song ridiculous?", "Is the song silly?"], hasCorrect: 0, randomOrder: true}],
[["version3",32], "MyController", {html: "<p>Compare the following two questions about a joke. Which one are you more likely to ask?</p>", q:"", as: ["Is the joke ridiculous?", "Is the joke silly?"], hasCorrect: 0, randomOrder: true}],
[["version2",32], "MyController", {html: "<p>Compare the following two questions about a question. Which one are you more likely to ask?</p>", q:"", as: ["Is the question ridiculous?", "Is the question silly?"], hasCorrect: 0, randomOrder: true}],

[["version1",33], "MyController", {html: "<p>Compare the following two questions about a room. Which one are you more likely to ask?</p>", q:"", as: ["Is the room tiny?", "Is the room small?"], hasCorrect: 0, randomOrder: true}],
[["version3",33], "MyController", {html: "<p>Compare the following two questions about a car. Which one are you more likely to ask?</p>", q:"", as: ["Is the car tiny?", "Is the car small?"], hasCorrect: 0, randomOrder: true}],
[["version2",33], "MyController", {html: "<p>Compare the following two questions about a fish. Which one are you more likely to ask?</p>", q:"", as: ["Is the fish tiny?", "Is the fish small?"], hasCorrect: 0, randomOrder: true}],

[["version1",34], "MyController", {html: "<p>Compare the following two questions about a shirt. Which one are you more likely to ask?</p>", q:"", as: ["Is the shirt tight?", "Is the shirt snug?"], hasCorrect: 0, randomOrder: true}],
[["version3",34], "MyController", {html: "<p>Compare the following two questions about a dress. Which one are you more likely to ask?</p>", q:"", as: ["Is the dress tight?", "Is the dress snug?"], hasCorrect: 0, randomOrder: true}],
[["version2",34], "MyController", {html: "<p>Compare the following two questions about a glove. Which one are you more likely to ask?</p>", q:"", as: ["Is the glove tight?", "Is the glove snug?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here? object vs subject
[["version1",35], "MyController", {html: "<p>Compare the following two questions about a bartender. Which one are you more likely to ask?</p>", q:"", as: ["Did the bartender see all of the cars?", "Did the bartender see some of the cars?"], hasCorrect: 0, randomOrder: true}],
[["version3",35], "MyController", {html: "<p>Compare the following two questions about a nurse. Which one are you more likely to ask?</p>", q:"", as: ["Did the nurse see all of the signs?", "Did the nurse see some of the signs?"], hasCorrect: 0, randomOrder: true}],
[["version2",35], "MyController", {html: "<p>Compare the following two questions about a mathematician. Which one are you more likely to ask?</p>", q:"", as: ["Did the mathematician see all of the issues?", "Did the mathematician see some of the issues?"], hasCorrect: 0, randomOrder: true}],

//how to phrase the question here? 
[["version1",36], "MyController", {html: "<p>Compare the following two questions about an assistant. Which one are you more likely to ask?</p>", q:"", as: ["Is the assistant always angry?", "Is the assistant sometimes angry?"], hasCorrect: 0, randomOrder: true}],
[["version3",36], "MyController", {html: "<p>Compare the following two questions about a director. Which one are you more likely to ask?</p>", q:"", as: ["Is the director always late?", "Is the director sometimes late?"], hasCorrect: 0, randomOrder: true}],
[["version2",36], "MyController", {html: "<p>Compare the following two questions about a doctor. Which one are you more likely to ask?</p>", q:"", as: ["Is the doctor always irritable?", "Is the doctor sometimes irritable?"], hasCorrect: 0, randomOrder: true}],

[["version1",37], "MyController", {html: "<p>Compare the following two questions about an athlete. Which one are you more likely to ask?</p>", q:"", as: ["Did the athlete finish?", "Did the athlete start?"], hasCorrect: 0, randomOrder: true}],
[["version3",37], "MyController", {html: "<p>Compare the following two questions about a dancer. Which one are you more likely to ask?</p>", q:"", as: ["Did the dancer finish?", "Did the dancer start?"], hasCorrect: 0, randomOrder: true}],
[["version2",37], "MyController", {html: "<p>Compare the following two questions about a runner. Which one are you more likely to ask?</p>", q:"", as: ["Did the runner finish?", "Did the runner start?"], hasCorrect: 0, randomOrder: true}],

[["version1",38], "MyController", {html: "<p>Compare the following two questions about a quarterback. Which one are you more likely to ask?</p>", q:"", as: ["Is the quarterback exhausted?", "Is the quarterback tired?"], hasCorrect: 0, randomOrder: true}],
[["version3",38], "MyController", {html: "<p>Compare the following two questions about a runner. Which one are you more likely to ask?</p>", q:"", as: ["Is the runner exhausted?", "Is the runner tired?"], hasCorrect: 0, randomOrder: true}],
[["version2",38], "MyController", {html: "<p>Compare the following two questions about a worker. Which one are you more likely to ask?</p>", q:"", as: ["Is the worker exhausted?", "Is the worker tired?"], hasCorrect: 0, randomOrder: true}],

[["version1",39], "MyController", {html: "<p>Compare the following two questions about a candidate. Which one are you more likely to ask?</p>", q:"", as: ["Did the candidate succeed?", "Did the candidate try?"], hasCorrect: 0, randomOrder: true}],
[["version3",39], "MyController", {html: "<p>Compare the following two questions about an athlete. Which one are you more likely to ask?</p>", q:"", as: ["Did the athlete succeed?", "Did the athlete try?"], hasCorrect: 0, randomOrder: true}],
[["version2",39], "MyController", {html: "<p>Compare the following two questions about a scientist. Which one are you more likely to ask?</p>", q:"", as: ["Did the scientist succeed?", "Did the scientist try?"], hasCorrect: 0, randomOrder: true}],

[["version1",40], "MyController", {html: "<p>Compare the following two questions about a wallpaper. Which one are you more likely to ask?</p>", q:"", as: ["Is the wallpaper hideous?", "Is the wallpaper ugly?"], hasCorrect: 0, randomOrder: true}],
[["version3",40], "MyController", {html: "<p>Compare the following two questions about a sweater. Which one are you more likely to ask?</p>", q:"", as: ["Is the sweater hideous?", "Is the sweater ugly?"], hasCorrect: 0, randomOrder: true}],
[["version2",40], "MyController", {html: "<p>Compare the following two questions about a painting. Which one are you more likely to ask?</p>", q:"", as: ["Is the painting hideous?", "Is the painting ugly?"], hasCorrect: 0, randomOrder: true}],

[["version1",41], "MyController", {html: "<p>Compare the following two questions about a movie. Which one are you more likely to ask?</p>", q:"", as: ["Is the movie horrific?", "Is the movie unsettling?"], hasCorrect: 0, randomOrder: true}],
[["version3",41], "MyController", {html: "<p>Compare the following two questions about a picture. Which one are you more likely to ask?</p>", q:"", as: ["Is the picture horrific?", "Is the picture unsettling?"], hasCorrect: 0, randomOrder: true}],
[["version2",41], "MyController", {html: "<p>Compare the following two questions about some news. Which one are you more likely to ask?</p>", q:"", as: ["Is the news horrific?", "Is the news unsettling?"], hasCorrect: 0, randomOrder: true}],

[["version1",42], "MyController", {html: "<p>Compare the following two questions about the weather. Which one are you more likely to ask?</p>", q:"", as: ["Is the weather hot?", "Is the weather warm?"], hasCorrect: 0, randomOrder: true}],
[["version3",42], "MyController", {html: "<p>Compare the following two questions about sand. Which one are you more likely to ask?</p>", q:"", as: ["Is the sand hot?", "Is the sand warm?"], hasCorrect: 0, randomOrder: true}],
[["version2",42], "MyController", {html: "<p>Compare the following two questions about a soup. Which one are you more likely to ask?</p>", q:"", as: ["Is the soup hot?", "Is the soup warm?"], hasCorrect: 0, randomOrder: true}],

[["version1",43], "MyController", {html: "<p>Compare the following two questions about a dog. Which one are you more likely to ask?</p>", q:"", as: ["Is the dog scared?", "Is the dog wary?"], hasCorrect: 0, randomOrder: true}],
[["version3",43], "MyController", {html: "<p>Compare the following two questions about a victim. Which one are you more likely to ask?</p>", q:"", as: ["Is the victim scared?", "Is the victim wary?"], hasCorrect: 0, randomOrder: true}],
[["version2",43], "MyController", {html: "<p>Compare the following two questions about a rabbit. Which one are you more likely to ask?</p>", q:"", as: ["Is the rabbit scared?", "Is the rabbit wary?"], hasCorrect: 0, randomOrder: true}],

//Filler items: 4,5,6 are catch trials
["filler1", "MyController", {html: "<p>Compare the following two questions about a table. Which one are you more likely to ask?</p>", q:"", as: ["Is the table dirty?", "Is the table clean?"], hasCorrect: 0, randomOrder: true}],
["filler2", "MyController", {html: "<p>Compare the following two questions about a soldier. Which one are you more likely to ask?</p>", q:"", as: ["Is the soldier harmless?", "Is the soldier dangerous?"], hasCorrect: 0, randomOrder: true}],
["filler3", "MyController", {html: "<p>Compare the following two questions about a man. Which one are you more likely to ask?</p>", q:"", as: ["Is the man sober?", "Is the man drunk?"], hasCorrect: 0, randomOrder: true}],
["filler4", "MyController", {html: "<p>Compare the following two questions about a neighbor. Which one are you more likely to ask?</p>", q:"", as: ["Is the neighbor rich?", "Is the neighbor purple?"], hasCorrect: 0, randomOrder: true}],
["filler5", "MyController", {html: "<p>Compare the following two questions about a gymnast. Which one are you more likely to ask?</p>", q:"", as: ["Is the gymnast tall?", "Is the gymnast rectangular?"], hasCorrect: 0, randomOrder: true}],
["filler6", "MyController", {html: "<p>Compare the following two questions about a doll. Which one are you more likely to ask?</p>", q:"", as: ["Is the doll old?", "Is the doll wavy?"], hasCorrect: 0, randomOrder: true}],
["filler7", "MyController", {html: "<p>Compare the following two questions about a street. Which one are you more likely to ask?</p>", q:"", as: ["Is the street narrow?", "Is the street wide?"], hasCorrect: 0, randomOrder: true}]// NOTE NO COMMA

];
