





var shuffleSequence = seq("setcounter", "Intro", "Demog", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: false,
        instructions: "Use number keys or click choice to answer.",
        randomOrder: true,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/







var items = [


    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],
    
  




["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a buffet</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_6.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was for the child to <b>take less food</b>, which of the following would you be most likely to say?", as: ["Don\'t.","Don\'t do that.","Don\'t take so much of that."]}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, all three choices seem to make some sense in the scenario, but many people find that the choice \"Don\'t take so much of that.\" communicates the father\'s preferred outcome most clearly."],
["p", "Press any key to continue."]
]}],

["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_2.png" height="90%"</center> <p></p><p><big><b><i> Host: </i>Do you want a big piece of cake?</b></big></p><p></p>'}, q: "If you were <b>the guest</b> in the scenario above and you thought the correct outcome was to <b>have a small piece of cake</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t have a big piece of cake."]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, you might not have had a strong preference about which choice did the best job of communicating the preferred outcome. In cases like this, it's OK to go with your first instinct, or just guess."],
["p", "Press any key to continue."]
]}],



["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    
      






/*

Condition letter crosswalk

a exo unav sca
b unm sal sca
c mod avail sca
d unm unav pol
e mod sal pol
f exo avail pol
g unm unav sca
h mod sal sca
i exo avail sca
j mod unav pol
k exo sal pol
l unm avail pol
m mod unav sca
n exo sal sca
o unm avail sca
p exo unav pol
q unm sal pol
r mod avail pol


*/    
    
    











[["q1a", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1b", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1c", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1d", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1e", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1g", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1g", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1h", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1i", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would 1you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1j", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1k", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1l", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1m", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1n", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1o", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy zero candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy candy bars."]}],
[["q1p", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1q", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],
[["q1r", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "If you were <b>the father</b> in the scenario above and you thought the correct outcome was to <b>buy three candy bars</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy five candy bars."]}],













[["q2a", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2b", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2c", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2d", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2e", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2f", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2g", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2h", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2i", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2j", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2k", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2l", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2m", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2n", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2o", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take zero candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take candies."]}],
[["q2p", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2q", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],
[["q2r", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "If you were <b>the sitting worker</b> in the scenario above and you thought the correct outcome was for the standing worker to <b>take two candies</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t take four candies."]}],








[["q3a", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3b", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3c", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3d", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3e", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3f", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3g", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3h", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3i", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3j", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3k", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3l", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3m", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3n", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3o", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add zero peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add peppers."]}],
[["q3p", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3q", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],
[["q3r", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "If you were <b>the instructor</b> in the scenario above and you thought the correct outcome was for the student to <b>add two peppers</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t add four peppers."]}],












[["q4a", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4b", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4c", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4d", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4e", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4f", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4g", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4h", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4i", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4j", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4k", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4l", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4m", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4n", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4o", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy zero charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy charms."]}],
[["q4p", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4q", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
[["q4r", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p><p></p>'}, q: "If you were <b>the husband</b> in the scenario above and you thought the correct outcome was for the wife to <b>buy three charms</b>, which of the following would you be most likely to say?", as: ["You shouldn\'t.","You shouldn\'t do that.","You shouldn\'t buy four charms."]}],
















[["q5a", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5b", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5c", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5d", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5e", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5f", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5g", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5h", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5i", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5j", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5k", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5l", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5m", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5n", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5o", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy zero shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy shirts."]}],
[["q5p", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5q", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],
[["q5r", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy two shirts</b>, which of the following would you be most likely to say?", as: ["I shouldn\'t.","I shouldn\'t do that.","I shouldn\'t buy three shirts."]}],














[["q6a", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6b", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6c", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6d", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6e", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6f", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6g", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6h", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6i", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6j", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6k", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6l", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6m", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6n", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6o", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy zero dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy dresses."]}],
[["q6p", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_neutral.png" height="90%"</center><p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6q", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],
[["q6r", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "If you were <b>the mother</b> in the scenario above and you thought the correct outcome was to <b>buy two dresses</b>, which of the following would you be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy three dresses."]}],





















/* moved two fillers to be practice */











[["q7z", 7], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_1.png" height="90%"</center> <p></p><p><big><b><i> Host: </i>Do you want another drink?</b></big></p>'}, q: "If you were <b>the guest</b> in the scenario above and you thought the correct outcome was to <b>have zero drinks</b>, which of the following would you be most likely to say?", as: ["I can\'t.","I can\'t do that.","I can\'t have a drink."]}],

[["q9z", 9], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a liquor store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_5.png" height="90%"</center><p></p><p><big><b><i> Man: </i>Should we buy the expensive wine?</b></big></p><p></p>'}, q: "If you were <b>the woman</b> in the scenario above and you thought the correct outcome was to <b>buy a cheaper wine</b>, which of the following would you be most likely to say?", as: ["We shouldn\'t.","We shouldn\'t do that.","We shouldn\'t buy the expensive wine."]}],

[["q10z", 10], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a car dealership</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_3.png" height="90%"</center><p></p><p><big><b><i> Salesperson: </i>I see you\'re looking at the fast car.</b></big></p><p></p>'}, q: "If you were <b>the woman</b> in the scenario above and you thought the correct outcome was <b>not to buy a car</b>, which of the following would be most likely to say?", as: ["We can\'t.","We can\'t do that.","We can\'t buy a car."]}],

[["q11z", 11], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_4.png" height="90%"</center><p></p><p><big><b><i> Salesperson: </i>Were you looking to buy a ring today?</b></big></p><p></p>'}, q: "If you were <b>the customer</b> in the scenario above and you thought the correct outcome was to <b>buy a cheap ring</b>, which of the following would you be most likely to say?", as: ["I can\'t.","I can\'t do that.","I can\'t buy an expensive ring."]}],

[["q13z", 13], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Turning a screw</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_9.png" height="90%"</center><p></p>'}, q: "If you were <b>the standing person</b> in the scenario above and you thought the correct outcome was for the sitting person to <b>stop turning the screw</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t unscrew that."]}],

[["q14z", 14], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a bake sale</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_7.png" height="90%"</center> <p></p><p><big><b><i> Woman: </i>I\'m going to buy a whole pie.</b></big></p><p></p>'}, q: "If you were <b>the man</b> in the scenario above and you thought the correct outcome was for the woman to <b>buy one slice of pie</b>, which of the following would you be most likely to say?", as: ["Don\'t.","Don\'t do that.","Don\'t buy a whole pie."]}],

[["q15z", 15], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Writing</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_10.png" height="90%"</center> <p></p><p><big><b><i> Person on right: </i>Can you hand me another pencil?</b></big></p><p></p>'}, q: "If you were <b>the person on the left</b> in the scenario above and you thought the correct outcome was to <b>keep your pencil</b>, which of the following would you be most likely to say?", as: ["I can\'t.","I can\'t do that.","I can\'t spare a pencil."]}],

[["q16z", 16], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Opening a lock</font></center></b></h> <p></p> <center><img src = "http://jeffreypgeiger.com/images/VPE/filler_8.png" height="90%"</center><p></p>'}, q: "If you were <b>the standing person</b> in this scenario and you thought the correct outcome was for the sitting person to <b>try a different key</b>, which of the following would you be most likely to say?", as: ["You can\'t.","You can\'t do that.","You can\'t open the lock with that key."]}]












/*comma*/


    
    




];