define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a dialogue, and decide whether you can conclude something from the answer in that dialogue."] 
],continueMessage:"Click here to start the experiment."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 ["practice", "MyController", {html: "<p>Sue: <i>Is the wrestler weak?</i><br>Mary: <i>He is strong.</i></p><p> Would you conclude from this that Mary thinks the wrestler is not weak?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Sue: <i>Did the spy discover the plan?</i><br>Mary: <i>She memorized it.</i></p><p> Would you conclude from this that Mary thinks the spy did not discover the plan?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//Experimental items
[["Eweak",1], "MyController",       {html: "<p>Sue: <i>Is drinking allowed?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that Mary thinks drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",1], "MyController",       {html: "<p>Sue: <i>Is drinking obligatory?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that Mary thinks drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",2], "MyController",       {html: "<p>Sue: <i>Is the model attractive?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that Mary thinks the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",2], "MyController",       {html: "<p>Sue: <i>Is the model stunning?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that Mary thinks the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",3], "MyController",       {html: "<p>Sue: <i>Did John begin the race?</i><br>Mary: <i>He began the race.</i></p><p> Would you conclude from this that Mary thinks John did not complete the race?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",3], "MyController",       {html: "<p>Sue: <i>Did John complete the race?</i><br>Mary: <i>He began the race.</i></p><p> Would you conclude from this that Mary thinks John did not complete the race?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",4], "MyController",       {html: "<p>Sue: <i>Does the teacher believe it is true?</i><br>Mary: <i>She believes it is true.</i></p><p> Would you conclude from this that Mary thinks the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",4], "MyController",       {html: "<p>Sue: <i>Does the teacher know it is true?</i><br>Mary: <i>She believes it is true.</i></p><p> Would you conclude from this that Mary thinks the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",5], "MyController",       {html: "<p>Sue: <i>Is the elephant big?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that Mary thinks the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",5], "MyController",       {html: "<p>Sue: <i>Is the elephant enormous?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that Mary thinks the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",6], "MyController",       {html: "<p>Sue: <i>Is the weather cool?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that Mary thinks the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",6], "MyController",       {html: "<p>Sue: <i>Is the weather cold?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that Mary thinks the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",7], "MyController",       {html: "<p>Sue: <i>Did the machine damage itself?</i><br>Mary: <i>It damaged itself.</i></p><p> Would you conclude from this that Mary thinks the machine did not destroy itself?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",7], "MyController",       {html: "<p>Sue: <i>Did the machine destroy itself?</i><br>Mary: <i>It damaged itself.</i></p><p> Would you conclude from this that Mary thinks the machine did not destroy itself?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",8], "MyController",       {html: "<p>Sue: <i>Is the sky dark?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that Mary thinks the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",8], "MyController",       {html: "<p>Sue: <i>Is the sky black?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that Mary thinks the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",9], "MyController",       {html: "<p>Sue: <i>Is the task difficult?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that Mary thinks the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",9], "MyController",       {html: "<p>Sue: <i>Is the task impossible?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that Mary thinks the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",10], "MyController",       {html: "<p>Sue: <i>Was Zack's carpet dirty?</i><br>Mary: <i>It was dirty.</i></p><p> Would you conclude from this that Mary thinks Zack's carpet was not filthy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",10], "MyController",       {html: "<p>Sue: <i>Was Zack's carpet filthy?</i><br>Mary: <i>It was dirty.</i></p><p> Would you conclude from this that Mary thinks Zack's carpet was not filthy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",11], "MyController",       {html: "<p>Sue: <i>Does the doctor dislike coffee?</i><br>Mary: <i>She dislikes it.</i></p><p> Would you conclude from this that Mary thinks the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",11], "MyController",       {html: "<p>Sue: <i>Does the doctor loathe coffee?</i><br>Mary: <i>She dislikes it.</i></p><p> Would you conclude from this that Mary thinks the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",12], "MyController", {html: "<p>Sue: <i>Will the sales double?</i><br>Mary: <i>They will double. </i></p><p> Would you conclude from this that Mary thinks the sales will not triple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",12], "MyController", {html: "<p>Sue: <i>Will the sales triple?</i><br>Mary: <i>They will double. </i></p><p> Would you conclude from this that Mary thinks the sales will not triple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",13], "MyController", {html: "<p>Sue: <i>Is the candidate equally skilled?</i><br>Mary: <i>He is equally skilled.</i></p><p> Would you conclude from this that Mary thinks the candidate is not more skilled?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",13], "MyController", {html: "<p>Sue: <i>Is the candidate more skilled?</i><br>Mary: <i>He is equally skilled.</i></p><p> Would you conclude from this that Mary thinks the candidate is not more skilled?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",14], "MyController", {html: "<p>Sue: <i>Is the movie funny?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that Mary thinks the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",14], "MyController", {html: "<p>Sue: <i>Is the movie hilarious?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that Mary thinks the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",15], "MyController", {html: "<p>Sue: <i>Is the movie good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that Mary thinks the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",15], "MyController", {html: "<p>Sue: <i>Is the movie excellent?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that Mary thinks the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",16], "MyController", {html: "<p>Sue: <i>Was the winner happy?</i><br>Mary: <i>She was happy.</i></p><p> Would you conclude from this that Mary thinks the winner was not ecstatic?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",16], "MyController", {html: "<p>Sue: <i>Was the winner ecstatic?</i><br>Mary: <i>She was happy.</i></p><p> Would you conclude from this that Mary thinks the winner was not ecstatic?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",17], "MyController", {html: "<p>Sue: <i>Is the problem hard?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that Mary thinks the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",17], "MyController", {html: "<p>Sue: <i>Is the problem unsolvable?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that Mary thinks the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",18], "MyController", {html: "<p>Sue: <i>Is the toxin harmful?</i><br>Mary: <i>It is harmful.</i></p><p> Would you conclude from this that Mary thinks the toxin is not deadly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",18], "MyController", {html: "<p>Sue: <i>Is the toxin deadly?</i><br>Mary: <i>It is harmful.</i></p><p> Would you conclude from this that Mary thinks the toxin is not deadly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",19], "MyController", {html: "<p>Sue: <i>Is there water here?</i><br>Mary: <i>There is water here.</i></p><p> Would you conclude from this that Mary thinks there isn't water everywhere?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",19], "MyController", {html: "<p>Sue: <i>Is there water everywhere?</i><br>Mary: <i>There is water here.</i></p><p> Would you conclude from this that Mary thinks there isn't water everywhere?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",20], "MyController", {html: "<p>Sue: <i>Is the boy hungry?</i><br>Mary: <i>He is hungry.</i></p><p> Would you conclude from this that Mary thinks the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",20], "MyController", {html: "<p>Sue: <i>Is the boy starving?</i><br>Mary: <i>He is hungry.</i></p><p> Would you conclude from this that Mary thinks the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",21], "MyController", {html: "<p>Sue: <i>Is the student intelligent?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that Mary thinks the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",21], "MyController", {html: "<p>Sue: <i>Is the student brilliant?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that Mary thinks the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",22], "MyController", {html: "<p>Sue: <i>Was Chris's opponent intimidating?</i><br>Mary: <i>He was intimidating.</i></p><p> Would you conclude from this that Mary thinks Chris's opponent was not terrifying?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",22], "MyController", {html: "<p>Sue: <i>Was Chris's opponent terrifying?</i><br>Mary: <i>He was intimidating.</i></p><p> Would you conclude from this that Mary thinks Chris's opponent was not terrifying?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",23], "MyController", {html: "<p>Sue: <i>Was the coast largely flooded?</i><br>Mary: <i>It was largely flooded.</i></p><p> Would you conclude from this that Mary thinks the coast was not totally flooded?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",23], "MyController", {html: "<p>Sue: <i>Was the coast totally flooded?</i><br>Mary: <i>It was largely flooded.</i></p><p> Would you conclude from this that Mary thinks the coast was not totally flooded?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",24], "MyController", {html: "<p>Sue: <i>Does the princess like dancing?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that Mary thinks the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",24], "MyController", {html: "<p>Sue: <i>Does the princess love dancing?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that Mary thinks the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",25], "MyController", {html: "<p>Sue: <i>Does Bill's score match Al's?</i><br>Mary: <i>It matches it.</i></p><p> Would you conclude from this that Mary thinks Bill's score does not exceed Al's?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",25], "MyController", {html: "<p>Sue: <i>Does Bill's score exceed Al's?</i><br>Mary: <i>It matches it.</i></p><p> Would you conclude from this that Mary thinks Bill's score does not exceed Al's?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",26], "MyController", {html: "<p>Sue: <i>Were Peter's answers mostly wrong?</i><br>Mary: <i>They were mostly wrong.</i></p><p> Would you conclude from this that Mary thinks Peter's answers were not entirely wrong?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",26], "MyController", {html: "<p>Sue: <i>Were Peter's answers entirely wrong?</i><br>Mary: <i>They were mostly wrong.</i></p><p> Would you conclude from this that Mary thinks Peter's answers were not entirely wrong?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",27], "MyController", {html: "<p>Sue: <i>Is the house old?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that Mary thinks the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",27], "MyController", {html: "<p>Sue: <i>Is the house ancient?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that Mary thinks the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",28], "MyController", {html: "<p>Sue: <i>Did mistakes happen once?</i><br>Mary: <i>They happened once.</i></p><p> Would you conclude from this that Mary thinks mistakes did not happen twice?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",28], "MyController", {html: "<p>Sue: <i>Did mistakes happen twice?</i><br>Mary: <i>They happened once.</i></p><p> Would you conclude from this that Mary thinks mistakes did not happen twice?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",29], "MyController", {html: "<p>Sue: <i>Did everyone see Wonder Woman or Batman?</i><br>Mary: <i>Everyone saw Wonder Woman or Batman.</i></p><p> Would you conclude from this that Mary thinks it's not the case that everyone saw Wonder Woman and Batman?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",29], "MyController", {html: "<p>Sue: <i>Did everyone see Wonder Woman and Batman?</i><br>Mary: <i>Everyone saw Wonder Woman or Batman.</i></p><p> Would you conclude from this that Mary thinks it's not the case that everyone saw Wonder Woman and Batman?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",30], "MyController", {html: "<p>Sue: <i>Is the teenager overweight?</i><br>Mary: <i>He is overweight.</i></p><p> Would you conclude from this that Mary thinks the teenager is not obese?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",30], "MyController", {html: "<p>Sue: <i>Is the teenager obese?</i><br>Mary: <i>He is overweight.</i></p><p> Would you conclude from this that Mary thinks the teenager is not obese?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",31], "MyController", {html: "<p>Sue: <i>Was the measure supported overwhelmingly?</i><br>Mary: <i>It was supported overwhelmingly.</i></p><p> Would you conclude from this that Mary thinks the measure was not supported unanimously?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",31], "MyController", {html: "<p>Sue: <i>Was the measure supported unanimously?</i><br>Mary: <i>It was supported overwhelmingly.</i></p><p> Would you conclude from this that Mary thinks the measure was not supported unanimously?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",32], "MyController", {html: "<p>Sue: <i>Is the wine palatable?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that Mary thinks the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",32], "MyController", {html: "<p>Sue: <i>Is the wine delicious?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that Mary thinks the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",33], "MyController", {html: "<p>Sue: <i>Is the tank partially full?</i><br>Mary: <i>It is partially full.</i></p><p> Would you conclude from this that Mary thinks the tank is not completely full?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",33], "MyController", {html: "<p>Sue: <i>Is the tank completely full?</i><br>Mary: <i>It is partially full.</i></p><p> Would you conclude from this that Mary thinks the tank is not completely full?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",34], "MyController", {html: "<p>Sue: <i>Does the club permit dancing?</i><br>Mary: <i>It permits it.</i></p><p> Would you conclude from this that Mary thinks the club doesn't require dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",34], "MyController", {html: "<p>Sue: <i>Does the club require dancing?</i><br>Mary: <i>It permits it.</i></p><p> Would you conclude from this that Mary thinks the club doesn't require dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",35], "MyController", {html: "<p>Sue: <i>Was Ann's speech polished?</i><br>Mary: <i>It was polished.</i></p><p> Would you conclude from this that Mary thinks Ann's speech was not impeccable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",35], "MyController", {html: "<p>Sue: <i>Was Ann's speech impeccable?</i><br>Mary: <i>It was polished.</i></p><p> Would you conclude from this that Mary thinks Ann's speech was not impeccable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",36], "MyController", {html: "<p>Sue: <i>Is success possible?</i><br>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that Mary thinks success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",36], "MyController", {html: "<p>Sue: <i>Is success certain?</i><br>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that Mary thinks success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",37], "MyController", {html: "<p>Sue: <i>Is the girl pretty?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that Mary thinks the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",37], "MyController", {html: "<p>Sue: <i>Is the girl beautiful?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that Mary thinks the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",38], "MyController", {html: "<p>Sue: <i>Are the residents primarily Greek?</i><br>Mary: <i>They are primarily Greek.</i></p><p> Would you conclude from this that Mary thinks the resident are not exclusively Greek?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",38], "MyController", {html: "<p>Sue: <i>Are the residents exclusively Greek?</i><br>Mary: <i>They are primarily Greek.</i></p><p> Would you conclude from this that Mary thinks the resident are not exclusively Greek?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",39], "MyController", {html: "<p>Sue: <i>Will a delay probably occur?</i><br>Mary: <i>It will probably occur.</i></p><p> Would you conclude from this that Mary thinks a delay won't necessarily occur?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",39], "MyController", {html: "<p>Sue: <i>Will a delay necessarily occur?</i><br>Mary: <i>It will probably occur.</i></p><p> Would you conclude from this that Mary thinks a delay won't necessarily occur?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",40], "MyController", {html: "<p>Sue: <i>Did the city reduce waste?</i><br>Mary: <i>It reduced waste.</i></p><p> Would you conclude from this that Mary thinks the city did not eliminate waste?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",40], "MyController", {html: "<p>Sue: <i>Did the city eliminate waste?</i><br>Mary: <i>It reduced waste.</i></p><p> Would you conclude from this that Mary thinks the city did not eliminate waste?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",41], "MyController", {html: "<p>Sue: <i>Was Stu's daughter scared?</i><br>Mary: <i>She was scared.</i></p><p> Would you conclude from this that Mary thinks Stu's daughter was not petrified?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",41], "MyController", {html: "<p>Sue: <i>Was Stu's daughter petrified?</i><br>Mary: <i>She was scared.</i></p><p> Would you conclude from this that Mary thinks Stu's daughter was not petrified?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",42], "MyController", {html: "<p>Sue: <i>Was Kaye's illness serious?</i><br>Mary: <i>It was serious.</i></p><p> Would you conclude from this that Mary thinks Kaye's illness was not life-threatening?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",42], "MyController", {html: "<p>Sue: <i>Was Kaye's illness life-threatening?</i><br>Mary: <i>It was serious.</i></p><p> Would you conclude from this that Mary thinks Kaye's illness was not life-threatening?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",43], "MyController", {html: "<p>Sue: <i>Are the two paintings similar?</i><br>Mary: <i>They are similar.</i></p><p> Would you conclude from this that Mary thinks the two paintings are not identical?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",43], "MyController", {html: "<p>Sue: <i>Are the two paintings identical?</i><br>Mary: <i>They are similar.</i></p><p> Would you conclude from this that Mary thinks the two paintings are not identical?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",44], "MyController", {html: "<p>Sue: <i>Did the train slow?</i><br>Mary: <i>It slowed.</i></p><p> Would you conclude from this that Mary thinks the train did not stop?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",44], "MyController", {html: "<p>Sue: <i>Did the train stop?</i><br>Mary: <i>It slowed.</i></p><p> Would you conclude from this that Mary thinks the train did not stop?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",45], "MyController", {html: "<p>Sue: <i>Is the fish small?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that Mary thinks the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",45], "MyController", {html: "<p>Sue: <i>Is the fish tiny?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that Mary thinks the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",46], "MyController", {html: "<p>Sue: <i>Is the shirt snug?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that Mary thinks the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",46], "MyController", {html: "<p>Sue: <i>Is the shirt tight?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that Mary thinks the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

 [["Eweak",47], "MyController", {html: "<p>Sue: <i>Does Cecilia trust some politicians?</i><br>Mary: <i>She trusts some politicians.</i></p><p> Would you conclude from this that Mary thinks Cecilia doesn't trust all politicians?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",47], "MyController", {html: "<p>Sue: <i>Does Cecilia trust all politicians?</i><br>Mary: <i>She trusts some politicians.</i></p><p> Would you conclude from this that Mary thinks Cecilia doesn't trust all politicians?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",48], "MyController", {html: "<p>Sue: <i>Did the runner start?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that Mary thinks the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",48], "MyController", {html: "<p>Sue: <i>Did the runner finish?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that Mary thinks the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",49], "MyController", {html: "<p>Sue: <i>Did the plant survive?</i><br>Mary: <i>It survived.</i></p><p> Would you conclude from this that Mary thinks the plant did not thrive?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",49], "MyController", {html: "<p>Sue: <i>Did the plant thrive?</i><br>Mary: <i>It survived.</i></p><p> Would you conclude from this that Mary thinks the plant did not thrive?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",50], "MyController", {html: "<p>Sue: <i>Is the worker tired?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that Mary thinks the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",50], "MyController", {html: "<p>Sue: <i>Is the worker exhausted?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that Mary thinks the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",51], "MyController", {html: "<p>Sue: <i>Do Joey's parents tolerate dating?</i><br>Mary: <i>They tolerate it.</i></p><p> Would you conclude from this that Mary thinks the Joey's parents do not encourage dating?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",51], "MyController", {html: "<p>Sue: <i>Do Joey's parents encourage dating?</i><br>Mary: <i>They tolerate it.</i></p><p> Would you conclude from this that Mary thinks the Joey's parents do not encourage dating?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",52], "MyController", {html: "<p>Sue: <i>Did the candidate try?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that Mary thinks the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",52], "MyController", {html: "<p>Sue: <i>Did the candidate succeed?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that Mary thinks the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",53], "MyController", {html: "<p>Sue: <i>Is the wallpaper ugly?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that Mary thinks the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",53], "MyController", {html: "<p>Sue: <i>Is the wallpaper hideous?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that Mary thinks the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",54], "MyController", {html: "<p>Sue: <i>Was Tom's interview understandable?</i><br>Mary: <i>It was understandable.</i></p><p> Would you conclude from this that Mary thinks Tom's interview was not articulate?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",54], "MyController", {html: "<p>Sue: <i>Was Tom's interview articulate?</i><br>Mary: <i>It was understandable.</i></p><p> Would you conclude from this that Mary thinks Tom's interview was not articulate?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",55], "MyController", {html: "<p>Sue: <i>Was Tim's bathroom unpleasant?</i><br>Mary: <i>It was unpleasant.</i></p><p> Would you conclude from this that Mary thinks Tim's bathroom is not disgusting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",55], "MyController", {html: "<p>Sue: <i>Was Tim's bathroom disgusting?</i><br>Mary: <i>It was unpleasant.</i></p><p> Would you conclude from this that Mary thinks Tim's bathroom is not disgusting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",56], "MyController", {html: "<p>Sue: <i>Is the lawyer usually early?</i><br>Mary: <i>She is usually early.</i></p><p> Would you conclude from this that Mary thinks the lawyer is not always early?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",56], "MyController", {html: "<p>Sue: <i>Is the lawyer always early?</i><br>Mary: <i>She is usually early.</i></p><p> Would you conclude from this that Mary thinks the lawyer is not always early?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",57], "MyController", {html: "<p>Sue: <i>Does Phoebe want a car?</i><br>Mary: <i>She wants one.</i></p><p> Would you conclude from this that Mary thinks Phoebe doesn't need a car?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",57], "MyController", {html: "<p>Sue: <i>Does Phoebe need a car?</i><br>Mary: <i>She wants one.</i></p><p> Would you conclude from this that Mary thinks Phoebe doesn't need a car?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",58], "MyController", {html: "<p>Sue: <i>Is the weather warm?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that Mary thinks the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",58], "MyController", {html: "<p>Sue: <i>Is the weather hot?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that Mary thinks the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",59], "MyController", {html: "<p>Sue: <i>Did the rehearsal go well?</i><br>Mary: <i>It went well.</i></p><p> Would you conclude from this that Mary thinks the rehearsal didn't go superbly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",59], "MyController", {html: "<p>Sue: <i>Did the rehearsal go superbly?</i><br>Mary: <i>It went well.</i></p><p> Would you conclude from this that Mary thinks the rehearsal didn't go superbly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["Eweak",60], "MyController", {html: "<p>Sue: <i>Is the waiter willing?</i><br>Mary: <i>He is willing.</i></p><p> Would you conclude from this that Mary thinks the waiter is not eager?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["Estrong",60], "MyController", {html: "<p>Sue: <i>Is the waiter eager?</i><br>Mary: <i>He is willing.</i></p><p> Would you conclude from this that Mary thinks the waiter is not eager?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],



//Filler items: 1,2,3,7 are catch trials
["filler1", "MyController", {html: "<p>Sue: <i>Is the table dirty?</i><br>Mary: <i>It is clean.</i></p><p> Would you conclude from this that Mary thinks the table is not dirty?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler2", "MyController", {html: "<p>Sue: <i>Is the soldier harmless?</i><br>Mary: <i>He is dangerous.</i></p><p> Would you conclude from this that Mary thinks the soldier is not harmless?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler3", "MyController", {html: "<p>Sue: <i>Is the man sober?</i><br>Mary: <i>He is drunk.</i></p><p> Would you conclude from this that Mary thinks the man is not sober?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler4", "MyController", {html: "<p>Sue: <i>Is the neighbor rich?</i><br>Mary: <i>She is sleepy.</i></p><p> Would you conclude from this that Mary thinks the neighbor is not rich?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler5", "MyController", {html: "<p>Sue: <i>Is the gymnast single?</i><br>Mary: <i>She is tall.</i></p><p> Would you conclude from this that Mary thinks the gymnast is not single?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler6", "MyController", {html: "<p>Sue: <i>Is the doll old?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that Mary thinks the doll is not old?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler7", "MyController", {html: "<p>Sue: <i>Is the street narrow?</i><br>Mary: <i>It is wide.</i></p><p> Would you conclude from this that Mary thinks the street is not narrow?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}]// NOTE NO COMMA

];
