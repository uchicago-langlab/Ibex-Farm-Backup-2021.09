/*
--Toronto-Psycholinguistics-Experiments--

Template that gives examples of everything Ibex can do for experiments
*/

var shuffleSequence = seq(anyType);
var practiceItemTypes = ["practice"];
var centerItems = true;


var defaults = [
    
    "MyController", {
        randomOrder: true 
        //setting default order for pictures to be random 
        //you can check this is true by simply trying experiment multiple times
     },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [


    /*
    ===================
    INTRODUCTION
    Can include files for Questionnaires, consent forms etc...
    ===================
    */

    //name of controller
    ["intro",
      //type
      "Form",
      //obligatory option that includes a HTML file that is a questionnaire
      {html: { include: "example_intro.html" },
      //fields that need to have the right format when taking input from user
      validators: {
        //age has to be a number
        age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],



    /*
    ===================
    IMAGE
    Controllers that work with Images and Questions
    ===================
    */
    ["s2", "MyController", { s: "On a scale of 1-10, how ____ is the following picture??", /*question you want to ask*/
                             as: /*Image to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://www.premierecreative.com/wp-content/uploads/2014/11/1NumberOneInCircle.png"]}]


];