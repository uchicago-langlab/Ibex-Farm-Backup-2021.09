var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("e"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Kérjük, várjon a következő mondatra.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Kattintson ide a folytatáshoz."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Kattintson ide a folytatáshoz."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Kattintson ide a gyakorláshoz."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "Vége a gyakorlásnak."],
                          ["p", "Most fog elkezdődni a valódi kísérlet, ahol ugyanaz lesz a feladata, mint eddig: egy párbeszédet fog látni, és azt a választ kell kiválasztania, amelyik az elfogadhatóbb/jobb válasz az A által feltett kérdésre."] 
],continueMessage:"Kattintson ide a kísérlet elkezdéséhez."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 
["practice", "Question",       {q: "A: Úgy szeretem az állatokat! Láttad az elefántot az állatkertben?", as: ["B: Igen, láttam.", "B: Nem voltam moziban."], hasCorrect: 0, randomOrder: true}],
["practice", "Question",       {q: "A: Én magyar vagyok. Te honnan származol?", as: ["B: Nem igazán szeretem a csokitortát.", "B: Budapestről."], hasCorrect: 0, randomOrder: true}],
["practice", "Question",       {q: "A: Tegnap koncerten voltam. Te milyen fajta zenét szeretsz?", as: ["B: Ó, nagyon szeretem a zenét!", "B: Leginkább a rockot."], hasCorrect: 0, randomOrder: true}],

//Experimental items
 
//["e1", "Question",       {q: "Mary: This student is intelligent. Would you conclude from this that, according to John, she is not brilliant?", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

["e1", "Question",       {q: {html: "<p>Mary: This student is intelligent. </p><p><i>Would you conclude from this that, according to John, she is not brilliant?</i></p>"}, as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],


//Filler items
["f.M.10", "Question", {q: "A nővéred hívott tegnap. Akarod tudni, miért?", as: ["B: Anyukám volt az, aki hívott.", "B: Én hívtam a nővéremet."], hasCorrect: 0, randomOrder: true}]// NOTE NO COMMA

];
