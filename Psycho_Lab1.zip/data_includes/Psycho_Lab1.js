var shuffleSequence = seq("Demog", "bear_instr", rshuffle(startsWith("q")), rshuffle(startsWith("r")), "sin_instr", rshuffle(startsWith("t")), rshuffle(startsWith("u")));

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: " ",
        randomOrder: false,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

    
["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
["bear_instr", "Form", {consentRequired: true, html: {include: "bear_instr.html" }} ],
["sin_instr", "Form", {consentRequired: true, html: {include: "sin_instr.html" }} ],

    
  














    
    
    
    
    



[["q1", 1], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q2", 2], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q3", 3], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q4", 4], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q5", 5], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q6", 6], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q7", 7], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q8", 8], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["q9", 9], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],



[["r1", 11], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r2", 12], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r3", 13], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r4", 14], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r5", 15], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r6", 16], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r7", 17], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r8", 18], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],

[["r9", 19], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/bear9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: bear","J: pear"]}],






[["t1", 101], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t2", 102], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t3", 103], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t4", 104], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t5", 105], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t6", 106], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t7", 107], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t8", 108], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t9", 109], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t10", 110], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin10.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["t11", 111], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin11.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],





[["u1", 121], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin1.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u2", 122], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin2.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u3", 123], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin3.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u4", 124], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin4.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u5", 125], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin5.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u6", 126], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin6.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u7", 127], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin7.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u8", 128], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin8.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u9", 129], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin9.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u10", 130], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin10.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}],

[["u11", 131], "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/sin11.wav" autoplay="autoplay"></audio>'}, q: " ", as: ["F: sin","J: shin"]}]





/*comma*/


    
    




];