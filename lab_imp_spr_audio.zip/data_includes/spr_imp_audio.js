
var shuffleSequence = seq("intro","Practice", rshuffle(startsWith("imp"), startsWith("f")));


var centerItems = true;
//var counterOverride = 3;


var defaults = [

    "Message", {
        //"html" option is obligatory
        consentRequired: false,
        hideProgressBar: false,
        transfer: "keypress"
    },

    "DashedSentence", {
        //"s" option is obligatory
        mode: "self-paced reading"
          //other option: "speeded acceptability"
    },

    "Question", {
        //"as" option is obligatory
        as: ["Yes", "No"],
        hasCorrect: true
          //if a question has a correct answer,
            //keep it as the first element of the "as" option
    },


    //These settings are needed for audio Type 1
    "AcceptabilityJudgment", {
        //"s" option is obligatory
        //"q" option is obligatory
        //"as" option is obligatory
        as: ["OK"],
        //writing the "as" option here means that this is the default for
        //all AcceptabilityJudgment items
        presentAsScale: true, //presents the "as" option as a scale
        instructions: "Use number keys or click boxes to answer.",
        // leftComment: "(Bad)", //displayed on the left side of the scale
        // rightComment: "(Good)", //displayed on the right side of the scale
        //only two audio options available so far
        audioMessage: { html: "<u>Click here to play audio</u>" },
        audioTrigger: "click"
        //do not change this
        //click, we do have another option at this point of time
    },

    "DashedAcceptabilityJudgment", {
        //combination of AcceptabilityJudgment and DashedSentence
        //"s" option is obligatory
        //"q" option is obligatory
        //"as" option is obligatory
        hasCorrect: false
    },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];


var items = [

    
//   ["intro",
      //type
  //    "Form",
      //obligatory option that includes a HTML file that is a questionnaire
  //    {html: { include: "example_intro.html" },
      //fields that need to have the right format when taking input from user
  //    validators: {
        //age has to be a number
  //      age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
  //      }
  //  } ],
    
    

["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],

    
   [ "Practice",
      "DoubleMessage", {html: {include: "Practice1.html"}, html2: "<p>Chris and Patt had been tirelessly rehearsing for their Broadway musical audition all week.</p>"},
      "DashedSentence", { s:  "After so many rehearsals, Patt sang herself hoarse."} ,  
      "Question", {q: "What were Chris and Patt rehearsing for? ", as: ["An audition","An opera", "A recital"] }],

[ "Practice", 
      "DoubleMessage", {html: {include: "Practice2.html"}, html2: "<p>Upon receiving a job offer from a company based in New york, Mandy was debating whether she was willing to relocate to such a big city.</p>"},
      "DashedSentence", { s:  "Her friend Lucy told her that she had loved living in New York."} ,  
      "Question", {q: "Why is Mandy considering moving to New York?", as: ["Work","Family","Friends"] }],
      
[ "Practice",
      "DoubleMessage", {html: {include: "Practice3.html"}, html2: "<p>In preparation for his trip to Myanmar, Preston went to the bookstore to buy a couple of travel guides.</p>"},
      "DashedSentence", { s:  "Preston went back home with more guides than he would be able to read before his trip."} ,  
      "Question", {q: "Where is Preston travelling?", as: ["Myanmar","Laos", "Cambodia"] }],
      
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. REMEMBER: it will last approximately 30 minutes, and will require your full attention throughout that period. Thank you for your help!"]
                           ]}],
                           
    [ [ "imp_a", 1],
      "DoubleMessage", {html: {include: "item1_none.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 10 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],

    [ [ "imp_b", 1], 
      "DoubleMessage", {html: {include: "item1_ex.html"},html2: "<p>When the doctor arrived that morning she asked the nurse exactly how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 10 patients were currently waitlisted."} , 
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
    
    [ [ "imp_c", 1],
      "DoubleMessage", {html: {include: "item1_apx.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse approximately how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 10 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],
      
    [ [ "imp_d", 1],
      "DoubleMessage", {html: {include: "item1_none.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 100 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],

    [ [ "imp_e", 1],
      "DoubleMessage", {html: {include: "item1_ex.html"},html2: "<p>When the doctor arrived that morning she asked the nurse exactly how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 100 patients were currently waitlisted."} , 
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
    
    [ [ "imp_f", 1],
      "DoubleMessage", {html: {include: "item1_apx.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse approximately how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 100 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],
    
    [ [ "imp_g", 1],
      "DoubleMessage", {html: {include: "item1_none.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 1,000 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],

    [ [ "imp_h", 1], 
      "DoubleMessage", {html: {include: "item1_ex.html"},html2: "<p>When the doctor arrived that morning she asked the nurse exactly how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 1,000 patients were currently waitlisted."} , 
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
    
    [ [ "imp_i", 1],
      "DoubleMessage", {html: {include: "item1_apx.html"}, html2: "<p>When the doctor arrived that morning she asked the nurse approximately how many patients were waitlisted for the new clinical study.</p>"},
      "DashedSentence", { s:  "The nurse replied that 1,000 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],  
      
    [ [ "imp_a", 2],
      "DoubleMessage", {html: {include: "item2_none.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 200 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

    [ [ "imp_b", 2], 
      "DoubleMessage", {html: {include: "item2_ex.html"},html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out exactly what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 200 dollars less per year."} , 
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],
    
    [ [ "imp_c", 2],
      "DoubleMessage", {html: {include: "item2_apx.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out approximately what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 200 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

     [ [ "imp_d", 2],
      "DoubleMessage", {html: {include: "item2_none.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 2,000 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

    [ [ "imp_e", 2], 
      "DoubleMessage", {html: {include: "item2_ex.html"},html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out exactly what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 2,000 dollars less per year."} , 
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],
    
    [ [ "imp_f", 2],
      "DoubleMessage", {html: {include: "item2_apx.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out approximately what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 2,000 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

     [ [ "imp_g", 2],
      "DoubleMessage", {html: {include: "item2_none.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 20,000 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

    [ [ "imp_h", 2], 
      "DoubleMessage", {html: {include: "item2_ex.html"},html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out exactly what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 20,000 dollars less per year."} , 
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],
    
    [ [ "imp_i", 2],
      "DoubleMessage", {html: {include: "item2_apx.html"}, html2: "<p>After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out approximately what his salary reduction would be.</p>"},
      "DashedSentence", { s:  "His boss said that Peet would earn 20,000 dollars less per year."} ,  
      "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],
  
      [ [ "imp_a", 3],
      "DoubleMessage", {html: {include: "item3_none.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} ,  
     "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

    [ [ "imp_b", 3], 
      "DoubleMessage", {html: {include: "item3_ex.html"},html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy exactly how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} , 
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
    
    [ [ "imp_c", 3],
      "DoubleMessage", {html: {include: "item3_apx.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy approximately how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} ,  
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
      
    [ [ "imp_d", 3],
      "DoubleMessage", {html: {include: "item3_none.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} ,  
     "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

    [ [ "imp_e", 3], 
      "DoubleMessage", {html: {include: "item3_ex.html"},html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy exactly how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} , 
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
    
    [ [ "imp_f", 3],
      "DoubleMessage", {html: {include: "item3_apx.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy approximately how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} ,  
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
      
    [ [ "imp_g", 3],
      "DoubleMessage", {html: {include: "item3_none.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} ,  
     "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

    [ [ "imp_h", 3], 
      "DoubleMessage", {html: {include: "item3_ex.html"},html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy exactly how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} , 
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
    
    [ [ "imp_i", 3],
      "DoubleMessage", {html: {include: "item3_apx.html"}, html2: "<p>Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy approximately how many points the toaster cost.</p>"},
      "DashedSentence", { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} ,  
      "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

    [ [ "imp_a", 4],
      "DoubleMessage", {html: {include: "item4_none.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} ,  
     "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

    [ [ "imp_b", 4], 
      "DoubleMessage", {html: {include: "item4_ex.html"},html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner exactly how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} , 
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
    
    [ [ "imp_c", 4],
      "DoubleMessage", {html: {include: "item4_apx.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner approximately how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} ,  
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
      
    [ [ "imp_d", 4],
      "DoubleMessage", {html: {include: "item4_none.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 500 gallons on a daily basis."} ,  
     "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

    [ [ "imp_e", 4], 
      "DoubleMessage", {html: {include: "item4_ex.html"},html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner exactly how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 500 gallons on a daily basis."} , 
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
    
    [ [ "imp_f", 4],
      "DoubleMessage", {html: {include: "item4_apx.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner approximately how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 500 gallons on a daily basis."} ,  
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
      
    [ [ "imp_g", 4],
      "DoubleMessage", {html: {include: "item4_none.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} ,  
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

    [ [ "imp_h", 4], 
      "DoubleMessage", {html: {include: "item4_ex.html"},html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner exactly how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} , 
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
    
    [ [ "imp_i", 4],
      "DoubleMessage", {html: {include: "item4_apx.html"}, html2: "<p>Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner approximately how many gallons of milk the farm was currently selling.</p>"},
      "DashedSentence", { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} ,  
      "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],
      
    [ [ "imp_a", 5],
      "DoubleMessage", {html: {include: "item5_none.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

    [ [ "imp_b", 5], 
      "DoubleMessage", {html: {include: "item5_ex.html"},html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, exactly how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} , 
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
      
    [ [ "imp_c", 5],
      "DoubleMessage", {html: {include: "item5_apx.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, approximately how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
        
    [ [ "imp_d", 5],
      "DoubleMessage", {html: {include: "item5_none.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

    [ [ "imp_e", 5], 
      "DoubleMessage", {html: {include: "item5_ex.html"},html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, exactly how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} , 
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
      
    [ [ "imp_f", 5],
      "DoubleMessage", {html: {include: "item5_apx.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, approximately how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
    
    [ [ "imp_g", 5],
      "DoubleMessage", {html: {include: "item5_none.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

    [ [ "imp_h", 5], 
      "DoubleMessage", {html: {include: "item5_ex.html"},html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, exactly how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} , 
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
      
    [ [ "imp_i", 5],
      "DoubleMessage", {html: {include: "item5_apx.html"}, html2: "<p>As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, approximately how many subscribers they had to their monthly newsletter.</p>"},
      "DashedSentence", { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} ,  
      "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],
      
    [ [ "imp_a", 6],
      "DoubleMessage", {html: {include: "item6_none.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

    [ [ "imp_b", 6], 
      "DoubleMessage", {html: {include: "item6_ex.html"},html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask exactly how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."} , 
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_c", 6],
      "DoubleMessage", {html: {include: "item6_apx.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask approximately how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_d", 6],
      "DoubleMessage", {html: {include: "item6_none.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

    [ [ "imp_e", 6], 
      "DoubleMessage", {html: {include: "item6_ex.html"},html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask exactly how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."} , 
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_f", 6],
      "DoubleMessage", {html: {include: "item6_apx.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask approximately how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_g", 6],
      "DoubleMessage", {html: {include: "item6_none.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

    [ [ "imp_h", 6],
      "DoubleMessage", {html: {include: "item6_ex.html"},html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask exactly how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."} , 
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_i", 6],
      "DoubleMessage", {html: {include: "item6_apx.html"}, html2: "<p>Due to a mistake in filing her taxes, Erika had to call the IRS to ask approximately how much money she owed.</p>"},
      "DashedSentence", { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."} ,  
      "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],
      
    [ [ "imp_a", 7],
      "DoubleMessage", {html: {include: "item7_none.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 900 people had submitted their answers."} ,  
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

    [ [ "imp_b", 7], 
      "DoubleMessage", {html: {include: "item7_ex.html"},html2: "<p>Ryan was directing a presidential poll and needed to know exactly how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 900 people had submitted their answers."} , 
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],
      
    [ [ "imp_c", 7],
      "DoubleMessage", {html: {include: "item7_apx.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know approximately how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 900 people had submitted their answers."} ,  
     "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],
    
    [ [ "imp_d", 7],
      "DoubleMessage", {html: {include: "item7_none.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 9,000 people had submitted their answers."} ,  
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

    [ [ "imp_e", 7], 
      "DoubleMessage", {html: {include: "item7_ex.html"},html2: "<p>Ryan was directing a presidential poll and needed to know exactly how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 9,000 people had submitted their answers."} , 
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],
      
    [ [ "imp_f", 7],
      "DoubleMessage", {html: {include: "item7_apx.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know approximately how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 9,000 people had submitted their answers."} ,  
     "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

    [ [ "imp_g", 7],
      "DoubleMessage", {html: {include: "item7_none.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 90,000 people had submitted their answers."} ,  
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

    [ [ "imp_h", 7], 
      "DoubleMessage", {html: {include: "item7_ex.html"},html2: "<p>Ryan was directing a presidential poll and needed to know exactly how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 90,000 people had submitted their answers."} , 
      "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],
      
    [ [ "imp_i", 7],
      "DoubleMessage", {html: {include: "item7_apx.html"}, html2: "<p>Ryan was directing a presidential poll and needed to know approximately how many people had participated.</p>"},
      "DashedSentence", { s:  "His chief researcher told him that 90,000 people had submitted their answers."} ,  
    "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
     
     [ [ "imp_a", 8],
      "DoubleMessage", {html: {include: "item8_none.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 60 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

    [ [ "imp_b", 8], 
      "DoubleMessage", {html: {include: "item8_ex.html"},html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked exactly how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 60 dollars the last time she played."} , 
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
    [ [ "imp_c", 8],
      "DoubleMessage", {html: {include: "item8_apx.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked approximately how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 60 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
    [ [ "imp_d", 8],
      "DoubleMessage", {html: {include: "item8_none.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 600 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

    [ [ "imp_e", 8], 
      "DoubleMessage", {html: {include: "item8_ex.html"},html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked exactly how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 600 dollars the last time she played."} , 
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
    [ [ "imp_f", 8],
      "DoubleMessage", {html: {include: "item8_apx.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked approximately how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 600 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
    [ [ "imp_g", 8],
      "DoubleMessage", {html: {include: "item8_none.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 6,000 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

    [ [ "imp_h", 8], 
      "DoubleMessage", {html: {include: "item8_ex.html"},html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked exactly how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 6,000 dollars the last time she played."} , 
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
    [ [ "imp_i", 8],
      "DoubleMessage", {html: {include: "item8_apx.html"}, html2: "<p>When Connor met Abigayle, a retired Jeopardy champion, he asked approximately how large her margin of victory had been in her final championship.</p>"},
      "DashedSentence", { s:  "Abigayle said that she had won by 6,000 dollars the last time she played."} ,  
      "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],
      
     [ [ "imp_a", 9],
      "DoubleMessage", {html: {include: "item9_none.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 70 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],

    [ [ "imp_b", 9], 
      "DoubleMessage", {html: {include: "item9_ex.html"},html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain exactly how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 70 people had voted there that day."} , 
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
      
    [ [ "imp_c", 9],
      "DoubleMessage", {html: {include: "item9_apx.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain approximately how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 70 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
      
     [ [ "imp_d", 9],
      "DoubleMessage", {html: {include: "item9_none.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 700 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],

    [ [ "imp_e", 9], 
      "DoubleMessage", {html: {include: "item9_ex.html"},html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain exactly how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 700 people had voted there that day."} , 
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
      
    [ [ "imp_f", 9],
      "DoubleMessage", {html: {include: "item9_apx.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain approximately how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 700 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
      
    [ [ "imp_g", 9],
      "DoubleMessage", {html: {include: "item9_none.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 7,000 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],

    [ [ "imp_h", 9], 
      "DoubleMessage", {html: {include: "item9_ex.html"},html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain exactly how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 7,000 people had voted there that day."} , 
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
      
    [ [ "imp_i", 9],
      "DoubleMessage", {html: {include: "item9_apx.html"}, html2: "<p>When Elsa arrived to tabulate the votes, she asked the precinct captain approximately how many people had cast votes in the caucus in that precinct.</p>"},
      "DashedSentence", { s:  "The precinct captain said that 7,000 people had voted there that day."} ,  
      "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
  
  
 [ [ "imp_a", 10],
      "DoubleMessage", {html: {include: "item10_none.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 10 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],

    [ [ "imp_b", 10], 
      "DoubleMessage", {html: {include: "item10_ex.html"},html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter exactly how much cocaine the neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 10 pounds at the time."} , 
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
      
    [ [ "imp_c", 10],
      "DoubleMessage", {html: {include: "item10_apx.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter approximately how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 10 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
      
     [ [ "imp_d", 10],
      "DoubleMessage", {html: {include: "item10_none.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 100 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],

    [ [ "imp_e", 10], 
      "DoubleMessage", {html: {include: "item10_ex.html"},html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter exactly how much cocaine the neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 100 pounds at the time."} , 
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
      
    [ [ "imp_f", 10],
      "DoubleMessage", {html: {include: "item10_apx.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter approximately how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 100 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
            
     [ [ "imp_g", 10],
      "DoubleMessage", {html: {include: "item10_none.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 1,000 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],

    [ [ "imp_h", 10], 
      "DoubleMessage", {html: {include: "item10_ex.html"},html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter exactly how much cocaine the neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 1,000 pounds at the time."} , 
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
      
    [ [ "imp_i", 10],
      "DoubleMessage", {html: {include: "item10_apx.html"}, html2: "<p>The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter approximately how much cocaine his neighbor had.</p>"},
      "DashedSentence", { s:  "Carter said that his neighbor had 1,000 pounds at the time."} ,  
      "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}],
            
     [ [ "imp_a", 11],
      "DoubleMessage", {html: {include: "item11_none.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

    [ [ "imp_b", 11], 
      "DoubleMessage", {html: {include: "item11_ex.html"},html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her exactly how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."} , 
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],
      
    [ [ "imp_c", 11],
      "DoubleMessage", {html: {include: "item11_apx.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her approximately how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],
      
    [ [ "imp_d", 11],
      "DoubleMessage", {html: {include: "item11_none.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

    [ [ "imp_e", 11], 
      "DoubleMessage", {html: {include: "item11_ex.html"},html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her exactly how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."} , 
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],
      
    [ [ "imp_f", 11],
      "DoubleMessage", {html: {include: "item11_apx.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her approximately how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],  
           
    [ [ "imp_g", 11],
      "DoubleMessage", {html: {include: "item11_none.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

    [ [ "imp_h", 11], 
      "DoubleMessage", {html: {include: "item11_ex.html"},html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her exactly how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."} , 
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],
      
    [ [ "imp_i", 11],
      "DoubleMessage", {html: {include: "item11_apx.html"}, html2: "<p>Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her approximately how high her rocket had flown.</p>"},
      "DashedSentence", { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."} ,  
      "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}], 
      
    [ [ "imp_a", 12],
      "DoubleMessage", {html: {include: "item12_none.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 900 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],

    [ [ "imp_b", 12], 
      "DoubleMessage", {html: {include: "item12_ex.html"},html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him exactly how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 900 gallons had been spilled."} , 
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
      
    [ [ "imp_c", 12],
      "DoubleMessage", {html: {include: "item12_apx.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him approximately how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 900 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],   
            
    [ [ "imp_d", 12],
      "DoubleMessage", {html: {include: "item12_none.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 9,000 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],

    [ [ "imp_e", 12], 
      "DoubleMessage", {html: {include: "item12_ex.html"},html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him exactly how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 9,000 gallons had been spilled."} , 
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
      
    [ [ "imp_f", 12],
      "DoubleMessage", {html: {include: "item12_apx.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him approximately how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 9,000 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],        
      
    [ [ "imp_g", 12],
      "DoubleMessage", {html: {include: "item12_none.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 90,000 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],

    [ [ "imp_h", 12], 
      "DoubleMessage", {html: {include: "item12_ex.html"},html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him exactly how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 90,000 gallons had been spilled."} , 
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
      
    [ [ "imp_i", 12],
      "DoubleMessage", {html: {include: "item12_apx.html"}, html2: "<p>The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him approximately how many gallons of oil had been lost.</p>"},
      "DashedSentence", { s:  "The engineer said that 90,000 gallons had been spilled."} ,  
      "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
               
    [ [ "imp_a", 13],
      "DoubleMessage", {html: {include: "item13_none.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 500 rows not including headers."} ,  
      "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],

    [ [ "imp_b", 13], 
      "DoubleMessage", {html: {include: "item13_ex.html"},html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor exactly how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 500 rows not including headers."} , 
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
      
    [ [ "imp_c", 13],
      "DoubleMessage", {html: {include: "item13_apx.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor approximately how long the input files that had been assigned for data processing were.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 500 rows not including headers."} ,  
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
                    
    [ [ "imp_d", 13],
      "DoubleMessage", {html: {include: "item13_none.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 5,000 rows not including headers."} ,  
      "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],

    [ [ "imp_e", 13], 
      "DoubleMessage", {html: {include: "item13_ex.html"},html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor exactly how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 5,000 rows not including headers."} , 
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
      
    [ [ "imp_f", 13],
      "DoubleMessage", {html: {include: "item13_apx.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor approximately how long the input files that had been assigned for data processing were.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 5,000 rows not including headers."} ,  
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],               
               
    [ [ "imp_g", 13],
      "DoubleMessage", {html: {include: "item13_none.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 50,000 rows not including headers."} ,  
      "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],

    [ [ "imp_h", 13], 
      "DoubleMessage", {html: {include: "item13_ex.html"},html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor exactly how long the input files were that had been assigned for data processing.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 50,000 rows not including headers."} , 
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
      
    [ [ "imp_i", 13],
      "DoubleMessage", {html: {include: "item13_apx.html"}, html2: "<p>Erin was ready to start working on her computational linguistics final project, so she asked her professor approximately how long the input files that had been assigned for data processing were.</p>"},
      "DashedSentence", { s:  "The professor answered that the files contained 50,000 rows not including headers."} ,  
     "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}], 
               
    [ [ "imp_a", 14],
      "DoubleMessage", {html: {include: "item14_none.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 200 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],

    [ [ "imp_b", 14],
      "DoubleMessage", {html: {include: "item14_ex.html"},html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask exactly how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 200 years was the age of the artifact."} , 
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
      
    [ [ "imp_c", 14],
      "DoubleMessage", {html: {include: "item14_apx.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask approximately how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 200 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}], 
                 
    [ [ "imp_d", 14],
      "DoubleMessage", {html: {include: "item14_none.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 2,000 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],

    [ [ "imp_e", 14], 
      "DoubleMessage", {html: {include: "item14_ex.html"},html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask exactly how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 2,000 years was the age of the artifact."} , 
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
      
    [ [ "imp_f", 14],
      "DoubleMessage", {html: {include: "item14_apx.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask approximately how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 2,000 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}], 
                 
    [ [ "imp_g", 14],
      "DoubleMessage", {html: {include: "item14_none.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 20,000 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],

    [ [ "imp_h", 14], 
      "DoubleMessage", {html: {include: "item14_ex.html"},html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask exactly how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 20,000 years was the age of the artifact."} , 
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
      
    [ [ "imp_i", 14],
      "DoubleMessage", {html: {include: "item14_apx.html"}, html2: "<p>Noah found a curious artifact in a cave and took it to some paleontologists to ask approximately how old it was.</p>"},
      "DashedSentence", { s:  "The scientists determined that 20,000 years was the age of the artifact."} ,  
      "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}], 
      
    [ [ "imp_a", 15],
      "DoubleMessage", {html: {include: "item15_none.html"}, html2: "<p>Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 800 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_b", 15],
      "DoubleMessage", {html: {include: "item15_ex.html"}, html2: "<p>Before taking off, the pilot asked the engineer exactly how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 800 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_c", 15],
      "DoubleMessage", {html: {include: "item15_apx.html"}, html2: "<p>Before taking off, the pilot asked the engineer approximately how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 800 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],
      
    [ [ "imp_d", 15],
      "DoubleMessage", {html: {include: "item15_none.html"}, html2: "<p>Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 8,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_e", 15],
      "DoubleMessage", {html: {include: "item15_ex.html"}, html2: "<p>Before taking off, the pilot asked the engineer exactly how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 8,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_f", 15],
      "DoubleMessage", {html: {include: "item15_apx.html"}, html2: "<p>Before taking off, the pilot asked the engineer approximately how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 8,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

      [ [ "imp_g", 15],
      "DoubleMessage", {html: {include: "item15_none.html"}, html2: "<p>Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 80,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_h", 15],
      "DoubleMessage", {html: {include: "item15_ex.html"}, html2: "<p>Before taking off, the pilot asked the engineer exactly how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 80,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

     [ [ "imp_i", 15],
      "DoubleMessage", {html: {include: "item15_apx.html"}, html2: "<p>Before taking off, the pilot asked the engineer approximately how many miles the plane had travelled in the last week.</p>"},
      "DashedSentence", { s:  "The engineer replied that the plane had travelled 80,000 miles with no major incidents."} ,  
      "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],
      
      [ [ "imp_a", 16],
      "DoubleMessage", {html: {include: "item16_none.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 30 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_b", 16],
      "DoubleMessage", {html: {include: "item16_ex.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor exactly how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 30 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_c", 16],
      "DoubleMessage", {html: {include: "item16_apx.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor approximately how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 30 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
            
    [ [ "imp_d", 16],
      "DoubleMessage", {html: {include: "item16_none.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 300 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_e", 16],
      "DoubleMessage", {html: {include: "item16_ex.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor exactly how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 300 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_f", 16],
      "DoubleMessage", {html: {include: "item16_apx.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor approximately how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 300 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
            
    [ [ "imp_g", 16],
      "DoubleMessage", {html: {include: "item16_none.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 3,000 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_h", 16],
      "DoubleMessage", {html: {include: "item16_ex.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor exactly how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 3,000 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],
      
    [ [ "imp_i", 16],
      "DoubleMessage", {html: {include: "item16_apx.html"}, html2: "<p>On Julie's first day in the lab, she asked her supervisor approximately how much she needed to heat the sample that she was experimenting with.</p>"},
      "DashedSentence", { s:  "Her supervisor said that 3,000 degrees was the target temperature."} ,  
      "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

      [ [ "imp_a", 17],
      "DoubleMessage", {html: {include: "item17_none.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 100 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
    [ [ "imp_b", 17],
      "DoubleMessage", {html: {include: "item17_ex.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian exactly how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 100 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
      [ [ "imp_c", 17],
      "DoubleMessage", {html: {include: "item17_apx.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian approximately how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 100 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
    [ [ "imp_d", 17],
      "DoubleMessage", {html: {include: "item17_none.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 1,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
    [ [ "imp_e", 17],
      "DoubleMessage", {html: {include: "item17_ex.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian exactly how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 1,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
      [ [ "imp_f", 17],
      "DoubleMessage", {html: {include: "item17_apx.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian approximately how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 1,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
    [ [ "imp_g", 17],
      "DoubleMessage", {html: {include: "item17_none.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 10,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
    [ [ "imp_h", 17],
      "DoubleMessage", {html: {include: "item17_ex.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian exactly how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 10,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
     
      [ [ "imp_i", 17],
      "DoubleMessage", {html: {include: "item17_apx.html"}, html2: "<p>While visiting the local reserve, Sandy asked the onsite veterinarian approximately how many flamingos lived there.</p>"},
      "DashedSentence", { s:  "The veterinarian told her that they had 10,000 flamingos at the moment."} ,  
     "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],

    [ [ "imp_a", 18],
      "DoubleMessage", {html: {include: "item18_none.html"}, html2: "<p>The printer called the newspaper's editor to ask how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 700 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
     [ [ "imp_b", 18],
      "DoubleMessage", {html: {include: "item18_ex.html"}, html2: "<p>The printer called the newspaper's editor to ask exactly how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 700 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],

    [ [ "imp_c", 18],
      "DoubleMessage", {html: {include: "item18_apx.html"}, html2: "<p>The printer called the newspaper's editor to ask approximately how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 700 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
    [ [ "imp_d", 18],
      "DoubleMessage", {html: {include: "item18_none.html"}, html2: "<p>The printer called the newspaper's editor to ask how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 7,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
     [ [ "imp_e", 18],
      "DoubleMessage", {html: {include: "item18_ex.html"}, html2: "<p>The printer called the newspaper's editor to ask exactly how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 7,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],

    [ [ "imp_f", 18],
      "DoubleMessage", {html: {include: "item18_apx.html"}, html2: "<p>The printer called the newspaper's editor to ask approximately how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 7,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
    [ [ "imp_g", 18],
      "DoubleMessage", {html: {include: "item18_none.html"}, html2: "<p>The printer called the newspaper's editor to ask how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 70,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
     [ [ "imp_h", 18],
      "DoubleMessage", {html: {include: "item18_ex.html"}, html2: "<p>The printer called the newspaper's editor to ask exactly how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 70,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],

    [ [ "imp_i", 18],
      "DoubleMessage", {html: {include: "item18_apx.html"}, html2: "<p>The printer called the newspaper's editor to ask approximately how many copies needed to be printed.</p>"},
      "DashedSentence", { s:  "The editor told him that they needed 70,000 copies by the end of the day."} ,  
     "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
     
     [ [ "imp_a", 19],
      "DoubleMessage", {html: {include: "item19_none.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 700 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_b", 19],
      "DoubleMessage", {html: {include: "item19_ex.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 700 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
   [ [ "imp_c", 19],
      "DoubleMessage", {html: {include: "item19_apx.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask approximately how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 700 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_d", 19],
      "DoubleMessage", {html: {include: "item19_none.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_e", 19],
      "DoubleMessage", {html: {include: "item19_ex.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
   [ [ "imp_f", 19],
      "DoubleMessage", {html: {include: "item19_apx.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask approximately how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_g", 19],
      "DoubleMessage", {html: {include: "item19_none.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_h", 19],
      "DoubleMessage", {html: {include: "item19_ex.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
   [ [ "imp_i", 19],
      "DoubleMessage", {html: {include: "item19_apx.html"}, html2: "<p>Susan called Andrea at the Data Analysis department to ask approximately how many clicks their new website publicity banner had received in the last week.</p>"},
      "DashedSentence", { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States."} ,  
     "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
     
    [ [ "imp_a", 20],
      "DoubleMessage", {html: {include: "item20_none.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 20 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_b", 20],
      "DoubleMessage", {html: {include: "item20_ex.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel exactly how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 20 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_c", 20],
      "DoubleMessage", {html: {include: "item20_apx.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel approximately how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 20 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
          
    [ [ "imp_d", 20],
      "DoubleMessage", {html: {include: "item20_none.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 200 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_e", 20],
      "DoubleMessage", {html: {include: "item20_ex.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel exactly how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 200 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_f", 20],
      "DoubleMessage", {html: {include: "item20_apx.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel approximately how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 200 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
          
    [ [ "imp_g", 20],
      "DoubleMessage", {html: {include: "item20_none.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."} ,  
     "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_h", 20],
      "DoubleMessage", {html: {include: "item20_ex.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel exactly how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."} ,  
      "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
    [ [ "imp_i", 20],
      "DoubleMessage", {html: {include: "item20_apx.html"}, html2: "<p>While setting up for the concert that night, Jordan asked Rachel approximately how many chairs they needed to unfold.</p>"},
      "DashedSentence", { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."} ,  
      "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
     
     [ [ "imp_a", 21],
      "DoubleMessage", {html: {include: "item21_none.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
     
     [ [ "imp_b", 21],
      "DoubleMessage", {html: {include: "item21_ex.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton exactly how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
           
     [ [ "imp_c", 21],
      "DoubleMessage", {html: {include: "item21_apx.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton approximately how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
           
     [ [ "imp_d", 21],
      "DoubleMessage", {html: {include: "item21_none.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
     
     [ [ "imp_e", 21],
      "DoubleMessage", {html: {include: "item21_ex.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton exactly how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
           
     [ [ "imp_f", 21],
      "DoubleMessage", {html: {include: "item21_apx.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton approximately how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
                 
     [ [ "imp_g", 21],
      "DoubleMessage", {html: {include: "item21_none.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
     
     [ [ "imp_h", 21],
      "DoubleMessage", {html: {include: "item21_ex.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton exactly how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
           
     [ [ "imp_i", 21],
      "DoubleMessage", {html: {include: "item21_apx.html"}, html2: "<p>While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton approximately how many rooms he wanted the new hotel to have.</p>"},
      "DashedSentence", { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} ,  
      "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],
      
     [ [ "imp_a", 22],
      "DoubleMessage", {html: {include: "item22_none.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 80 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_b", 22],
      "DoubleMessage", {html: {include: "item22_ex.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator exactly how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 80 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_c", 22],
      "DoubleMessage", {html: {include: "item22_apx.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator approximately how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 80 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_d", 22],
      "DoubleMessage", {html: {include: "item22_none.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 800 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_e", 22],
      "DoubleMessage", {html: {include: "item22_ex.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator exactly how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 800 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_f", 22],
      "DoubleMessage", {html: {include: "item22_apx.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator approximately how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 800 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_g", 22],
      "DoubleMessage", {html: {include: "item22_none.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 8,000 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_h", 22],
      "DoubleMessage", {html: {include: "item22_ex.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator exactly how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 8,000 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_i", 22],
      "DoubleMessage", {html: {include: "item22_apx.html"}, html2: "<p>Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator approximately how many Democrats were expected that evening.</p>"},
      "DashedSentence", { s:  "The coordinator said that 8,000 Democrats would attend the event."} ,  
      "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],
            
     [ [ "imp_a", 23],
      "DoubleMessage", {html: {include: "item23_none.html"}, html2: "<p>Rowan asked Peet how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 60 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
    [ [ "imp_b", 23],
      "DoubleMessage", {html: {include: "item23_ex.html"}, html2: "<p>Rowan asked Peet exactly how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 60 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
    [ [ "imp_c", 23],
      "DoubleMessage", {html: {include: "item23_apx.html"}, html2: "<p>Rowan asked Peet approximately how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 60 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
    [ [ "imp_d", 23],
      "DoubleMessage", {html: {include: "item23_none.html"}, html2: "<p>Rowan asked Peet how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 600 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
    [ [ "imp_e", 23],
      "DoubleMessage", {html: {include: "item23_ex.html"}, html2: "<p>Rowan asked Peet exactly how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 600 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
   [ [ "imp_f", 23],
      "DoubleMessage", {html: {include: "item23_apx.html"}, html2: "<p>Rowan asked Peet approximately how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 600 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
  
  [ [ "imp_g", 23],
      "DoubleMessage", {html: {include: "item23_none.html"}, html2: "<p>Rowan asked Peet how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 6,000 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
    [ [ "imp_h", 23],
      "DoubleMessage", {html: {include: "item23_ex.html"}, html2: "<p>Rowan asked Peet exactly how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 6,000 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
      
   [ [ "imp_i", 23],
      "DoubleMessage", {html: {include: "item23_apx.html"}, html2: "<p>Rowan asked Peet approximately how many stamps he added to his collection after attending the stamp fair.</p>"},
      "DashedSentence", { s:  "Peet said that he acquired 6,000 stamps at a very good price."} ,  
      "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],
           
    [ [ "imp_a", 24],
      "DoubleMessage", {html: {include: "item24_none.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 90 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_b", 24],
      "DoubleMessage", {html: {include: "item24_ex.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director exactly how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 90 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                       
    [ [ "imp_c", 24],
      "DoubleMessage", {html: {include: "item24_apx.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director approximately how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 90 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_d", 24],
      "DoubleMessage", {html: {include: "item24_none.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 900 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_e", 24],
      "DoubleMessage", {html: {include: "item24_ex.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director exactly how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 900 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                       
    [ [ "imp_f", 24],
      "DoubleMessage", {html: {include: "item24_apx.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director approximately how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 900 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_g", 24],
      "DoubleMessage", {html: {include: "item24_none.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 9,000 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_h", 24],
      "DoubleMessage", {html: {include: "item24_ex.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director exactly how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 9,000 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                       
    [ [ "imp_i", 24],
      "DoubleMessage", {html: {include: "item24_apx.html"}, html2: "<p>After the flood, the head of the hospital asked the blood bank director approximately how many units of blood had been lost.</p>"},
      "DashedSentence", { s:  "The blood bank director said that 9,000 units had been contaminated."} ,  
      "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],
                 
    [ [ "imp_a", 25],
      "DoubleMessage", {html: {include: "item25_none.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 60 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_b", 25],
      "DoubleMessage", {html: {include: "item25_ex.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager exactly how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 60 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_c", 25],
      "DoubleMessage", {html: {include: "item25_apx.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager approximately how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 60 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_d", 25],
      "DoubleMessage", {html: {include: "item25_none.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 600 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_e", 25],
      "DoubleMessage", {html: {include: "item25_ex.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager exactly how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 600 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_f", 25],
      "DoubleMessage", {html: {include: "item25_apx.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager approximately how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 600 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_g", 25],
      "DoubleMessage", {html: {include: "item25_none.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 6,000 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_h", 25],
      "DoubleMessage", {html: {include: "item25_ex.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager exactly how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 6,000 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_i", 25],
      "DoubleMessage", {html: {include: "item25_apx.html"}, html2: "<p>After learning that her company's website had been hacked, Joana called the IT department to ask the manager approximately how many accounts had been accessed by the hackers.</p>"},
      "DashedSentence", { s:  "The manager said that information from 6,000 accounts had been stolen."} ,  
      "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
                       
    [ [ "imp_a", 26],
      "DoubleMessage", {html: {include: "item26_none.html"}, html2: "<p>The Dean called his secretary to find out how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 50 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                            
    [ [ "imp_b", 26],
      "DoubleMessage", {html: {include: "item26_ex.html"}, html2: "<p>The Dean called his secretary to find out exactly how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 50 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],                  
                         
    [ [ "imp_c", 26],
      "DoubleMessage", {html: {include: "item26_apx.html"}, html2: "<p>The Dean called his secretary to find out approximately how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 50 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                             
    [ [ "imp_d", 26],
      "DoubleMessage", {html: {include: "item26_none.html"}, html2: "<p>The Dean called his secretary to find out how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 500 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                            
    [ [ "imp_e", 26],
      "DoubleMessage", {html: {include: "item26_ex.html"}, html2: "<p>The Dean called his secretary to find out exactly how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 500 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],                  
                         
    [ [ "imp_f", 26],
      "DoubleMessage", {html: {include: "item26_apx.html"}, html2: "<p>The Dean called his secretary to find out approximately how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 500 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                             
    [ [ "imp_g", 26],
      "DoubleMessage", {html: {include: "item26_none.html"}, html2: "<p>The Dean called his secretary to find out how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 5,000 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                            
    [ [ "imp_h", 26],
      "DoubleMessage", {html: {include: "item26_ex.html"}, html2: "<p>The Dean called his secretary to find out exactly how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 5,000 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],                  
                         
    [ [ "imp_i", 26],
      "DoubleMessage", {html: {include: "item26_apx.html"}, html2: "<p>The Dean called his secretary to find out approximately how many graduate students had received his email about the new grading policies.</p>"},
      "DashedSentence", { s:  "The secretary replied that 5,000 students had gotten the message."} ,  
      "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],
                             
    [ [ "imp_a", 27],
      "DoubleMessage", {html: {include: "Item27_none.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 40 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                               
    [ [ "imp_b", 27],
      "DoubleMessage", {html: {include: "item27_ex.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her exactly how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 40 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "imp_c", 27],
      "DoubleMessage", {html: {include: "item27_apx.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her approximately how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 40 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "imp_d", 27],
      "DoubleMessage", {html: {include: "Item27_none.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 400 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                               
    [ [ "imp_e", 27],
      "DoubleMessage", {html: {include: "item27_ex.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her exactly how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 400 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "imp_f", 27],
      "DoubleMessage", {html: {include: "item27_apx.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her approximately how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 400 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "imp_g", 27],
      "DoubleMessage", {html: {include: "Item27_none.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 4,000 views from several countries."},  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                               
    [ [ "imp_h", 27],
      "DoubleMessage", {html: {include: "item27_ex.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her exactly how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 4,000 views from several countries."} ,  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "imp_i", 27],
      "DoubleMessage", {html: {include: "item27_apx.html"}, html2: "<p>After learning Pamela finally uploaded the video of her latest song to YouTube, Matt asked her approximately how many views the video had in the last week.</p>"},
      "DashedSentence", { s:  "Pamela replied that her video had 4,000 views from several countries."} ,  
      "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],
                                   
    [ [ "f_1", 28],
      "DoubleMessage", {html: {include: "Filler28.html"}, html2: "<p>While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was.</p>"},
      "DashedSentence", { s:  "The map showed that the nearest lodge was still several miles away."} ,  
      "Question", {q: "What was several miles way?", as: ["Lodge", "Hostel", "Cabin"]}],
                                         
    [ [ "f_1", 29],
      "DoubleMessage", {html: {include: "Filler29.html"}, html2: "<p>While marathoning her favorite TV show, Avatar, Jhanelle checked the list to see how many episodes were left.</p>"},
      "DashedSentence", { s:  "The list showed that she still had a few episodes left."} ,  
      "Question", {q: "What show was Jhanelle watching?", as: ["Avatar", "Breaking Bad", "Spongebob"]}],
                                                 
    [ [ "f_1", 30],
      "DoubleMessage", {html: {include: "Filler30.html"}, html2: "<p>After the disappointing loss, Akash asked the basketball coach approximately how many turnovers he had committed.</p>"},
      "DashedSentence", { s:  "The coach said Akash had committed far too many turnovers."} ,  
      "Question", {q: "What was the couch's opinion about the amount of turnovers Akash committed?", as: ["Bad", "Good", "Indifferent"]}],
                                                       
    [ [ "f_1", 31],
      "DoubleMessage", {html: {include: "Filler31.html"}, html2: "<p>Iz tested herself to see exactly how many airplane noises she could identify.</p>"},
      "DashedSentence", { s:  "She found that she could identify every airplane noise."} ,  
      "Question", {q: "What type of sound is Iz identifying?", as: ["Airplane noises", "Car horns", "Train whistles"]}],
                                                       
    [ [ "f_1", 32],
      "DoubleMessage", {html: {include: "Filler32.html"}, html2: "<p>The spectators were amazed by David's skill and asked him approximately how many knives he could juggle at once.</p>"},
      "DashedSentence", { s:  "David answered that he could juggle quite a few knives at one time."} ,  
      "Question", {q: "How many knives could David juggle at once?", as: ["Lots", "Few", "Not more than two"]}],      
                                                             
    [ [ "f_1", 33],
      "DoubleMessage", {html: {include: "Filler33.html"}, html2: "<p>Isabella was collecting flight statistics and asked the air traffic controller exactly how many planes would be flying through O'Hare that day.</p>"},
      "DashedSentence", { s:  "The air traffic controller replied that the airports would see an average number of flights that day."} ,  
      "Question", {q: "At what airport are statistics being collected?", as: ["O'Hare", "JFK", "Midway"]}],
                                                                   
    [ [ "f_1", 34],
      "DoubleMessage", {html: {include: "Filler34.html"}, html2: "<p>Bardia was bored and decided to count exactly how many tiles were on the floor of the lecture hall.</p>"},
      "DashedSentence", { s:  "He found that there were more tiles than he cared to count."} ,  
      "Question", {q: "Where was Bardia?", as: ["Lecture hall", "Kitchen", "Bathroom"]}],
                                                                         
    [ [ "f_1", 35],
      "DoubleMessage", {html: {include: "Filler35.html"}, html2: "<p>Kevin wanted to know exactly how many successful coups d'état there had been in American history.</p>"},
      "DashedSentence", { s:  "He learned that there had been none."} ,  
      "Question", {q: "How many coups d'état have there been in American history?", as: ["Zero", "One", "Two"]}],    
                                                                               
    [ [ "f_1", 36],
      "DoubleMessage", {html: {include: "Filler36.html"}, html2: "<p>Pat went out knocking on doors while campaigning for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day.</p>"},
      "DashedSentence", { s:  "Pat answered that he had knocked on an enormous number of doors."} ,  
      "Question", {q: "Who is Pat campaigning for?", as: ["Jim Gilmore", "Lincoln Chafee", "Lawrence Lessig"]}],
                                                                                     
    [ [ "f_1", 37],
      "DoubleMessage", {html: {include: "Filler37.html"}, html2: "<p>Brian decided that he would count approximately how many spoons there were in the South Campus dining hall.</p>"},
      "DashedSentence", { s:  "He counted many, many spoons."} ,  
      "Question", {q: "Which dining hall did Brian investigate?", as: ["South", "Bartlett", "Pierce"]}],
                                                                                      
    [ [ "f_1", 38],
      "DoubleMessage", {html: {include: "Filler38.html"}, html2: "<p>Nancy, a salesperson, had to count up exactly how many pieces of cereal were in each box.</p>"},
      "DashedSentence", { s:  "Not surprisingly, she found that each box contained a lot of pieces of cereal."} ,  
      "Question", {q: "What is Nancy?", as: ["Salesperson", "Janitor", "Chef"]}],
                                                                                            
    [ [ "f_2", 39],
      "DoubleMessage", {html: {include: "Filler39.html"}, html2: "<p>Dylan asked his boss how many people definitely would show up to the meeting.</p>"},
      "DashedSentence", { s:  "His boss said that exactly 20 people would come."} ,  
      "Question", {q: "What is the event?", as: ["Meeting", "Funeral", "Wedding"]}],
                                                                                                
    [ [ "f_2", 40],
      "DoubleMessage", {html: {include: "Filler40.html"}, html2: "<p>Gerri asked the Goldman-Sachs executive nervously how many other candidates there were for the position.</p>"},
      "DashedSentence", { s:  "He told her that approximately 50 other candidates were being interviewed."} ,  
      "Question", {q: "What company has Gerri applied to?", as: ["Goldman Sachs", "JP Morgan", "US Bank"]}], 
                                                                                                      
    [ [ "f_2", 41],
      "DoubleMessage", {html: {include: "Filler41.html"}, html2: "<p>A perplexed Jay wondered constantly how many of his classmates had failed the economics midterm.</p>"},
      "DashedSentence", { s:  "It turned out that exactly 20 of Jay's classmates had failed the exam."} ,  
      "Question", {q: "What subject was Jay studying?", as: ["Economics", "Chemistry", "Physics"]}],
                                                                                                            
    [ [ "f_2", 42],
      "DoubleMessage", {html: {include: "Filler42.html"}, html2: "<p>Nora wondered exasperatedly how many hours she would have to spend dancing that weekend.</p>"},
      "DashedSentence", { s:  "According to her schedule, she would dance for approximately 20 hours."} ,  
      "Question", {q: "What did Nora check?", as: ["Her schedule", "Her phone", "Her agenda"]}],
                                                                                                                  
    [ [ "f_2", 43],
      "DoubleMessage", {html: {include: "Filler43.html"}, html2: "<p>During the theology exam, Ryan racked his brain, asking himself frustratedly how many commandments there were.</p>"},
      "DashedSentence", { s:  "He then recalled that there were exactly 10 commandments."} ,  
      "Question", {q: "What subject is Ryan studying?", as: ["Theology", "History", "Arabic"]}],
                                                                                                                        
    [ [ "f_2", 44],
      "DoubleMessage", {html: {include: "Filler44.html"}, html2: "<p>Curious acquaintances often wondered fervently how many languages Nina spoke.</p>"},
      "DashedSentence", { s:  "She revealed one day that she spoke exactly 10 languages."} ,  
      "Question", {q: "What is the polyglot's name?", as: ["Nina", "Bill", "Ted"]}],
                                                                                                                              
    [ [ "f_2", 45],
      "DoubleMessage", {html: {include: "Filler45.html"}, html2: "<p>On her visit to the alpaca farm, Shannon asked excitedly how many alpacas there were.</p>"},
      "DashedSentence", { s:  "She was informed that there were approximately 40 alpacas."} ,  
      "Question", {q: "What animal is Shannon seeing?", as: ["Alpacas", "Llamas", "Dromedaries"]}],
                                                                                                                                    
    [ [ "f_2", 46],
      "DoubleMessage", {html: {include: "Filler46.html"}, html2: "<p>Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating.</p>"},
      "DashedSentence", { s:  "She found that the average student procrastinates for approximately 20 hours per week."} ,  
      "Question", {q: "What did Angela study?", as: ["Procrastination", "Sleeping", "Eating"]}],
                                                                                                                                          
    [ [ "f_2", 47],
      "DoubleMessage", {html: {include: "Filler47.html"}, html2: "<p>Elaina was lost and asked a pedestrian desperately how many blocks away the University of Chicago's campus was.</p>"},
      "DashedSentence", { s:  "The pedestrian said that the campus was approximately 10 blocks away."} ,  
      "Question", {q: "What campus is Elaina looking for?", as: ["University of Chicago", "Northwestern", "Harvard"]}],
                                                                                                                                                
    [ [ "f_2", 48],
      "DoubleMessage", {html: {include: "Filler48.html"}, html2: "<p>After the accident, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop.</p>"},
      "DashedSentence", { s:  "The agent told him that it would cost exactly 500 dollars."} ,  
      "Question", {q: "What does Zach need repaired?", as: ["Laptop", "Refrigerator", "Car"]}],
                                                                                                                                                      
    [ [ "f_2", 49],
      "DoubleMessage", {html: {include: "Filler49.html"}, html2: "<p>William was interested in famous train heists and looked up curiously how many dollars Jesse James had stolen in his robbery.</p>"},
      "DashedSentence", { s:  "He learned that approximately 3,000 dollars had been taken."} ,  
      "Question", {q: "Who is William studying?", as: ["Jesse James", "Walter White", "Al Capone"]}],
                                                                                                                                                            
    [ [ "f_3", 50],
      "DoubleMessage", {html: {include: "Filler50.html"}, html2: "<p>James and Karnika asked the organizer how many people certainly would come to their wedding.</p>"},
      "DashedSentence", { s:  "The organizer replied that a large handful of people would come."} ,  
      "Question", {q: "How many people were invited to the wedding?", as: ["A lot", "Not a lot", "Ten"]}],
                                                                                                                                                            
    [ [ "f_3", 51],
      "DoubleMessage", {html: {include: "Filler51.html"}, html2: "<p>Claire pondered carefully how many new strings she needed for her violin.</p>"},
      "DashedSentence", { s:  "She determined she needed several new strings."} ,  
      "Question", {q: "What does Claire play?", as: ["Violin", "Guitar", "Viola"]}],
                                                                                                                                                                  
    [ [ "f_3", 52],
      "DoubleMessage", {html: {include: "Filler52.html"}, html2: "<p>Remy asked his friends persistently how many of them would be participating in the scavenger hunt in the spring.</p>"},
      "DashedSentence", { s:  "He learned that few of his friends would participate."} ,  
      "Question", {q: "When does the scavenger hunt take place?", as: ["Spring", "Fall", "Winter"]}],
                                                                                                                                                                        
    [ [ "f_3", 53],
      "DoubleMessage", {html: {include: "Filler53.html"}, html2: "<p>Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday.</p>"},
      "DashedSentence", { s:  "They said they would be willing to make calls for a few hours."} ,  
      "Question", {q: "What kind of volunteer work were Rebecca's friends going to do?", as: ["Phone calls", "Tutoring", "Coaching"]}],
                                                                                                                                                                              
    [ [ "f_3", 54],
      "DoubleMessage", {html: {include: "Filler54.html"}, html2: "<p>In the course of preparing for move-in, Louis asked the housing officials curiously how many new residents there would be that year.</p>"},
      "DashedSentence", { s:  "The officials told him there would be many new residents."} ,  
      "Question", {q: "Who asked this question?", as: ["Louis", "Dustin", "Helen"]}],
                                                                                                                                                                                    
    [ [ "f_3", 55],
      "DoubleMessage", {html: {include: "Filler55.html"}, html2: "<p>Before leaving on her vacation, Julie asked her friends how many gallons of gas probably would be needed to get her to Pasadena.</p>"},
      "DashedSentence", { s:  "They told her that only a few gallons would be necessary."} ,  
      "Question", {q: "How many gallons were necessary to make the trip?", as: ["A few", "A couple", "A full tank"]}],
                                                                                                                                                                                          
    [ [ "f_3", 56],
      "DoubleMessage", {html: {include: "Filler56.html"}, html2: "<p>Caleb went to the doughnut shop and asked the salesperson hungrily how many doughnuts there were left.</p>"},
      "DashedSentence", { s:  "The salesperson answered that there was a donut shortage and that they had only a few doughnuts left."} ,  
      "Question", {q: "What was the problem?", as: ["Doughnut shortage", "No doughnuts had not been delivered that day", "All doughnuts were sold out"]}], 
                                                                                                                                                                                                
    [ [ "f_3", 57],
      "DoubleMessage", {html: {include: "Filler57.html"}, html2: "<p>Erin, an avid reader, wondered intently how many words there were in the book 'War and Peace.'</p>"},
      "DashedSentence", { s:  "She quickly discovered that it contained more words than she could count."} ,  
      "Question", {q: "For how long did Erin inspect the book?", as: ["Not for long", "She was not inspecting a book", "A year"]}],
                                                                                                                                                                                                      
    [ [ "f_3", 58],
      "DoubleMessage", {html: {include: "Filler58.html"}, html2: "<p>Ulysses was in a bad mood and demanded to know immediately how many minutes his pizza would need to cook.</p>"},
      "DashedSentence", { s:  "The waiter responded that the food would be ready in a few minutes."} ,  
      "Question", {q: "When was the pizza going to be ready?", as: ["In a few minutes", "In an hour", "In an hour and a half"]}],  
                                                                                                                                                                                                          
    [ [ "f_3", 59],
      "DoubleMessage", {html: {include: "Filler59.html"}, html2: "<p>Elaine asked her classmates nosily how many siblings they each had.</p>"},
      "DashedSentence", { s:  "She was informed that most of them had a few siblings."} ,  
     "Question", {q: "Whom did Elaine ask?", as: ["Classmates", "Neighbors", "Teachers"]}],  
                                                                                                                                                                                                               
    [ [ "f_3", 60],
      "DoubleMessage", {html: {include: "Filler60.html"}, html2: "<p>When a notification of delay came in, Frederick asked the gate attendant despondently how many hours his flight to Columbus would be delayed.</p>"},
      "DashedSentence", { s:  "The attendant reassured him that the delay was only a few minutes."} ,  
      "Question", {q: "How confident was the attendant about the length of the delay?", as: ["Very confident", "Not very confident", "Neutral"]}]

    ]; 
      
    