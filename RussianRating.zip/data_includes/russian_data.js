var shuffleSequence = seq("setcounter","intro","practice", "presep", sepWith("sep", rshuffle(startsWith("Russian"))), "exit");
var practiceItemTypes = ["Практика"];

var progressBarText = "Прогресс"
//var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
    },
    
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5"],
        presentAsScale: true,
       //How acceptable is this senteence
        instructions: "Насколько приемлемо это предложение? Используйте цифровые клавиши или галочки чтобы ответить.",
        leftComment: "(Плохо)", rightComment: "(Хорошо)"
    },
   
    "Message", {
        hideProgressBar: true,
        continueMessage: "Пожалуйста, нажмите сюда, чтобы продолжить"
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        //press here to continue
        continueMessage: "Пожалуйста, нажмите сюда, чтобы продолжить"
    }
];

var aj = "AcceptabilityJudgment";
var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],


["setcounter", "__SetCounter__", { }],


["sep", Separator, { }],
   ["practice", aj, {s: "Часто Маша любит пить чай с печеньями."}],
 
    ["practice", aj, {s: "Студенты ушли на прогулку."}],
    
    ["practice", aj, {s: "Саша услышал собака."}],
 
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "Конец тренировочной части. Сейчас начнется эксперимент."],
                          ]}],
    
   
    ["presep", Separator, { transfer: 2000, normalMessage: "Внимание, скоро начнем. Подождите, пожалуйста..." }],


[["Russian",1], aj, {s: "Испугала кроликов молния."}],
[["Russian",2], aj, {s: "Мальчики в саду кусты сажают."}],
[["Russian",3], aj, {s: "Женщина мажет на хлеб варенье."}],
[["Russian",4], aj, {s: "Маму любят дети."}],    
[["Russian",5], aj, {s: "Строят мост рабочие."}],
[["Russian",6], aj, {s: "Любят маму дети."}],
[["Russian",7], aj, {s: "Девочка письмо пишет ручкой."}],   
[["Russian",8], aj, {s: "Мужчина вечер своим поведением испортил."}],
[["Russian",9], aj, {s: "Бабушка внуку показала игрушку."}],
[["Russian",10], aj, {s: "Девочка цветы собирает."}],
 
[["Russian",11], aj, {s: "Девочка котёнка подарила сестре."}],
[["Russian",12], aj, {s: "Кроликов молния испугала."}],    
[["Russian",13], aj, {s: "Мужчина испортил вечер своим поведением."}],
[["Russian",14], aj, {s: "Город накрыла волна."}],
[["Russian",15], aj, {s: "Охотник кормит мясом собаку."}],
[["Russian",16], aj, {s: "Мальчики в саду сажают кусты."}],    
[["Russian",17], aj, {s: "Корабль тонет."}],
[["Russian",18], aj, {s: "Мост рабочие строят."}],
[["Russian",19], aj, {s: "Шум тревожит мужчину."}],
[["Russian",20], aj, {s: "Шум мужчину тревожит."}],
 
[["Russian",21], aj, {s: "Маму дети любят."}],
[["Russian",22], aj, {s: "Юноша другу ключи кинул."}],
[["Russian",23], aj, {s: "Девушка шьёт платье подружке."}],
[["Russian",24], aj, {s: "Юноша кинул ключи другу."}],    
[["Russian",25], aj, {s: "Девочка сестре подарила котёнка."}],
[["Russian",26], aj, {s: "Мать знакомит с коллегами дочь."}],   
[["Russian",27], aj, {s: "Девушка подружке платье шьёт."}],
[["Russian",28], aj, {s: "Женщина мажет хлеб вареньем."}],
[["Russian",29], aj, {s: "Юноша кинул другу ключи."}],
[["Russian",30], aj, {s: "Девочка ручкой письмо пишет."}],
 
[["Russian",31], aj, {s: "Тревожит шум мужчину."}],       
[["Russian",32], aj, {s: "Охотник кормит собаке мясо."}],
[["Russian",33], aj, {s: "Город волна накрыла."}],
[["Russian",34], aj, {s: "Мать знакомит дочь с коллегами."}],
[["Russian",35], aj, {s: "Девочка сестре котёнка подарила."}],    
[["Russian",36], aj, {s: "Встретил мужчина родственника."}],
[["Russian",37], aj, {s: "Бабушка игрушку внуку показала."}],
[["Russian",38], aj, {s: "Собирает девочка цветы."}],   
[["Russian",39], aj, {s: "Девочка собирает цветы."}],
[["Russian",40], aj, {s: "Мастер девочку научил играть на скрипке."}],
 
[["Russian",41], aj, {s: "Несёт ветер запах."}],
[["Russian",42], aj, {s: "Мастер играть на скрипке девочку научил."}],
[["Russian",43], aj, {s: "Мужчина встретил родственника."}],    
[["Russian",44], aj, {s: "Спит мужчина."}],
[["Russian",45], aj, {s: "Упал мальчик."}],   
[["Russian",46], aj, {s: "Плавают дети."}],   
[["Russian",47], aj, {s: "Женщина мажет вареньем хлеб."}],
[["Russian",48], aj, {s: "Девочка ручкой пишет письмо."}],
[["Russian",49], aj, {s: "Женщина мажет варенье на хлеб."}],
[["Russian",50], aj, {s: "Охотник бежит."}],    
 
[["Russian",51], aj, {s: "Парень танцует."}],
[["Russian",52], aj, {s: "Накрыла город волна."}],   
[["Russian",53], aj, {s: "Мальчик увидел оленя в лесу."}],   
[["Russian",54], aj, {s: "Мастер играть на скрипке научил девочку."}],
[["Russian",55], aj, {s: "Ветер несёт запах."}],
[["Russian",56], aj, {s: "Бабушка игрушку показала внуку."}],
[["Russian",57], aj, {s: "девушка шьёт подружке платье."}],   
[["Russian",58], aj, {s: "Мужчина испортил своим поведением вечер."}],
[["Russian",59], aj, {s: "Мост строят рабочие."}],   
 
[["Russian",60], aj, {s: "Мать дочь с коллегами знакомит."}],   
[["Russian",61], aj, {s: "Охотник кормит мясо собаке."}],
[["Russian",62], aj, {s: "Охотник кормит собаку мясом."}],
    
    
[["Russian",63], aj, {s: "Мальчик оленя в лесу увидел."}],   
[["Russian",64], aj, {s: "Мужчина родственника встретил."}],   
[["Russian",65], aj, {s: "Кроликов испугала молния."}],
[["Russian",66], aj, {s: "Мальчики кусты сажают в саду."}],
[["Russian",67], aj, {s: "Мальчик увидел в лесу оленя."}],
[["Russian",68], aj, {s: "Ветер запах несёт."}],
    
    
];




