var shuffleSequence = seq("setcounter","consent", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("e"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Kérjük, várjon a következő mondatra.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
    ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Kattintson ide az eredmények elküldéséhez."} ],
    ["consent", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Kattintson ide a folytatáshoz."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],

//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "Vége a gyakorlásnak."],
                          ["p", "Most fog elkezdődni a valódi kísérlet, ahol ugyanaz lesz a feladata, mint eddig: mondatokat kell majd elolvasnia, és az utánuk következő kérdést megválaszolnia."] 
],continueMessage:"Kattintson ide a kísérlet elkezdéséhez."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


["intro", "Message", {html: ["div",
                          ["p", "Ebben a kísérletben mondatokat fog olvasni, melyek egymást követő szavanként/kifejezésenként lesznek a képernyőre kiírva. A kísérlet egyszerre csak a mondat egy részét fogja megmutatni. Minden mondat egy üres vonallal kezdődik - üsse le a space gombot ahhoz, hogy az első szó feltűnjön."],
                          ["p", "A space gomb ismételt leütéseivel kell majd mindig egy új szót felfednie. Mikor egy új szó megjelenik, az az előzőnek a helyére kerül, és az előző eltűnik. Folytassa a space gomb leütését egészen addig, amíg el nem ér a mondat végére."],
                          ["p", "Kérjük, a megszokott sebességével olvasson, ne olvasson se túl lassan, se túl gyorsan. A mondatokat némán olvassa, ne olvassa fel őket hangosan."],
                          ["p", "A kísérlet minden mondat (vagyis a . utáni space leütés) után egy kérdést tesz fel, azt ellenőrizendő, hogy Ön megértette-e a mondatot. Kérjük, kattinson az Ön által helyesnek tartott válaszra, majd várjon a következő mondat elkezdésére."],
                          ["p", "A valódi kísérlet előtt két próbamondatot (és kérdést) kell most elolvasnia, amik segítségével begyakorolhatja a feladatot."] 
],continueMessage:"Kattintson ide a gyakorláshoz."}],

    //
    // 2 practice items for self-paced reading ( with a comprehension question).
    //
    ["practice", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "az időjárás", "jelentés", "ellenére", "idén", "karácsonykor", "sem", "fog", "esni", "a hó."]},
                  "Question", {q: "Az időjárás jelentés szerint fog esni a hó?", as: ["igen", "nem"], hasCorrect: 0, randomOrder: true}],
    ["practice", "DashedSentence", {s: ["Az,", "hogy", "a főpolgármester", "meglátogatta", "az új", "képviselőt,", "senkit", "nem", "lepett", "meg."]},
    "Question", {q: "Ki látogatott meg kit?", as: ["a főpolgármester a képviselőt", "a képviselő a főpolgármestert"], hasCorrect: 0, randomOrder: true}],

    //
    // 32 "real" (i.e. non-filler) self-paced reading items with corresponding acceptability judgment items.
    // There are eight conditions.
    //

    [["e.SRC.A",1], "DashedSentence", {s: ["A nővére", "azt", "válaszolta:", "A szakadárt,", "megutáló", "diktátor", "beszédet", "mondott", "az", "ülésen."]},
               "Question",       {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt", "a szakadár a diktátort"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",1], "DashedSentence", {s: ["A nővére", "azt", "válaszolta:", "A szakadár,", "által", "megutált", "diktátor", "beszédet", "mondott", "az", "ülésen."]},
               "Question",       {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt", "a szakadár a diktátort"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",1], "DashedSentence", {s: ["A nővére", "azt", "válaszolta:", "A diktátort,", "megutáló", "szakadár", "beszédet", "mondott", "az", "ülésen."]},
               "Question",       {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt", "a szakadár a diktátort"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",1], "DashedSentence", {s: ["A nővére", "azt", "válaszolta:", "A diktátor,", "által", "megutált", "szakadár", "beszédet", "mondott", "az", "ülésen."]},
               "Question",       {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt", "a szakadár a diktátort"], hasCorrect: 0, randomOrder: true}],

    
    [["e.SRC.A",2], "DashedSentence", {s: ["A főorvos", "azt", "mondta:", "A kardiológust", "megvádoló", "terapeuta", "leellenőrizte", "az", "iratokat", "az", "irodában."]},
               "Question",       {q: "Ki vádolt meg kit?", as: ["a terapeuta a kardiológust", "a kardiológus a terapeutát"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",2], "DashedSentence", {s: ["A főorvos", "azt", "mondta:", "A kardiológus", "által", "megvádolt", "terapeuta", "leellenőrizte", "az", "iratokat", "az", "irodában."]},
               "Question",       {q: "Ki vádolt meg kit?", as: ["a terapeuta a kardiológust", "a kardiológus a terapeutát"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",2], "DashedSentence", {s: ["A főorvos", "azt", "mondta:", "A terapeutát", "megvádoló", "kardiológus", "leellenőrizte", "az", "iratokat", "az", "irodában."]},
               "Question",       {q: "Ki vádolt meg kit?", as: ["a terapeuta a kardiológust", "a kardiológus a terapeutát"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",2], "DashedSentence", {s: ["A főorvos", "azt", "mondta:", "A terapeuta", "által", "megvádolt", "kardiológus", "leellenőrizte", "az", "iratokat", "az", "irodában."]},
               "Question",       {q: "Ki vádolt meg kit?", as: ["a terapeuta a kardiológust", "a kardiológus a terapeutát"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",3], "DashedSentence", {s: ["A partnere", "így", "válaszolt:", "A taxist", "megelőző", "motoros", "befordult", "a", "kereszteződésénél."]},
                          "Question",       {q: "Ki előzött meg kit?", as: ["a motoros a taxist", "a taxis a motorost"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",3], "DashedSentence", {s: ["A partnere", "így", "válaszolt:", "A taxis", "által", "megelőzött", "motoros", "befordult", "a", "kereszteződésénél."]},
                          "Question",       {q: "Ki előzött meg kit?", as: ["a motoros a taxist", "a taxis a motorost"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",3], "DashedSentence", {s: ["A partnere", "így", "válaszolt:", "A motorost", "megelőző", "taxis", "befordult", "a", "kereszteződésénél."]},
                          "Question",       {q: "Ki előzött meg kit?", as: ["a motoros a taxist", "a taxis a motorost"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",3], "DashedSentence", {s: ["A partnere", "így", "válaszolt:", "A motoros", "által", "megelőzött", "taxis", "befordult", "a", "kereszteződésénél."]},
                          "Question",       {q: "Ki előzött meg kit?", as: ["a motoros a taxist", "a taxis a motorost"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",4], "DashedSentence", {s: ["A titkárnő", "azt", "válaszolta:", "Az elemzőt", "idegesítő", "mérnök", "beszámolót", "írt", "a projektről."]},
                          "Question",       {q: "Ki idegesített kit?", as: ["a mérnök az elemzőt", "az elemző a mérnököt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",4], "DashedSentence", {s: ["A titkárnő", "azt", "válaszolta:", "Az elemző", "által", "idegesített", "mérnök", "beszámolót", "írt", "a projektről."]},
                          "Question",       {q: "Ki idegesített kit?", as: ["a mérnök az elemzőt", "az elemző a mérnököt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",4], "DashedSentence", {s: ["A titkárnő", "azt", "válaszolta:", "A mérnököt", "idegesítő", "elemző", "beszámolót", "írt", "a projektről."]},
                          "Question",       {q: "Ki idegesített kit?", as: ["a mérnök az elemzőt", "az elemző a mérnököt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",4], "DashedSentence", {s: ["A titkárnő", "azt", "válaszolta:", "A mérnök", "által", "idegesített", "elemző", "beszámolót", "írt", "a projektről."]},
                          "Question",       {q: "Ki idegesített kit?", as: ["a mérnök az elemzőt", "az elemző a mérnököt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",5], "DashedSentence", {s: ["A rendezvényszervező", "azt", "válaszolta:", "A fuvolást", "felbosszantó", "hegedűs", "lemondta", "a pénteki", "koncertet."]},
                          "Question",       {q: "Ki boszantott fel kit?", as: ["a hegedűs a fuvolást", "a fuvolás a hegedűst"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",5], "DashedSentence", {s: ["A rendezvényszervező", "azt", "válaszolta:", "A fuvolás", "által", "felbosszantott", "hegedűs", "lemondta", "a pénteki", "koncertet."]},
                          "Question",       {q: "Ki boszantott fel kit?", as: ["a hegedűs a fuvolást", "a fuvolás a hegedűst"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",5], "DashedSentence", {s: ["A rendezvényszervező", "azt", "válaszolta:", "A hegedűst", "felbosszantó", "fuvolás", "lemondta", "a pénteki", "koncertet."]},
                          "Question",       {q: "Ki boszantott fel kit?", as: ["a hegedűs a fuvolást", "a fuvolás a hegedűst"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",5], "DashedSentence", {s: ["A rendezvényszervező", "azt", "válaszolta:", "A hegedűs", "által", "felbosszantott", "fuvolás", "lemondta", "a pénteki", "koncertet."]},
                          "Question",       {q: "Ki boszantott fel kit?", as: ["a hegedűs a fuvolást", "a fuvolás a hegedűst"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",6], "DashedSentence", {s: ["A szemtanú", "azt", "mondta:", "A gyanúsítottat", "észrevevő", "nyomozó", "a szemébe", "húzta", "a sapkáját."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a nyomozó a gyanúsítottat", "a gyanúsított a nyomozót"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",6], "DashedSentence", {s: ["A szemtanú", "azt", "mondta:", "A gyanúsított", "által", "észrevett", "nyomozó", "a szemébe", "húzta", "a sapkáját."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a nyomozó a gyanúsítottat", "a gyanúsított a nyomozót"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",6], "DashedSentence", {s: ["A szemtanú", "azt", "mondta:", "A nyomozót", "észrevevő", "gyanúsított", "a szemébe", "húzta", "a sapkáját."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a nyomozó a gyanúsítottat", "a gyanúsított a nyomozót"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",6], "DashedSentence", {s: ["A szemtanú", "azt", "mondta:", "A nyomozó", "által", "észrevett", "gyanúsított", "a szemébe", "húzta", "a sapkáját."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a nyomozó a gyanúsítottat", "a gyanúsított a nyomozót"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",7], "DashedSentence", {s: ["A portás", "azt", "felelte:", "A műgyűjtőt", "lefárasztó", "művész", "feltekerte", "a portrét", "tartalmazó", "vásznat."]},
                          "Question",       {q: "Ki fárasztott le kit?", as: ["a művész a műgyűjtőt", "a műgyűjtő a művészt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",7], "DashedSentence", {s: ["A portás", "azt", "felelte:", "A műgyűjtő", "által", "lefárasztott", "művész", "feltekerte", "a portrét", "tartalmazó", "vásznat."]},
                          "Question",       {q: "Ki fárasztott le kit?", as: ["a művész a műgyűjtőt", "a műgyűjtő a művészt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",7], "DashedSentence", {s: ["A portás", "azt", "felelte:", "A művészt", "lefárasztó", "műgyűjtő", "feltekerte", "a portrét", "tartalmazó", "vásznat."]},
                          "Question",       {q: "Ki fárasztott le kit?", as: ["a művész a műgyűjtőt", "a műgyűjtő a művészt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",7], "DashedSentence", {s: ["A portás", "azt", "felelte:", "A művész", "által", "lefárasztott", "műgyűjtő", "feltekerte", "a portrét", "tartalmazó", "vásznat."]},
                          "Question",       {q: "Ki fárasztott le kit?", as: ["a művész a műgyűjtőt", "a műgyűjtő a művészt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",8], "DashedSentence", {s: ["A helyette", "így", "válaszolt:", "A statisztikust", "figyelmeztető", "könyvelő", "sietve", "foglalta", "össze", "az", "eredményeket."]},
                          "Question",       {q: "Ki figyelmeztetett kit?", as: ["a könyvelő a statisztikust", "a statisztikus a könyvelőt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",8], "DashedSentence", {s: ["A helyette", "így", "válaszolt:", "A statisztikus", "által", "figyelmeztetett", "könyvelő", "sietve", "foglalta", "össze", "az", "eredményeket."]},
                          "Question",       {q: "Ki figyelmeztetett kit?", as: ["a könyvelő a statisztikust", "a statisztikus a könyvelőt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",8], "DashedSentence", {s: ["A helyette", "így", "válaszolt:", "A könyvelőt", "figyelmeztető", "statisztikus", "sietve", "foglalta", "össze", "az", "eredményeket."]},
                          "Question",       {q: "Ki figyelmeztetett kit?", as: ["a könyvelő a statisztikust", "a statisztikus a könyvelőt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",8], "DashedSentence", {s: ["A helyette", "így", "válaszolt:", "A könyvelő", "által", "figyelmeztetett", "statisztikus", "sietve", "foglalta", "össze", "az", "eredményeket."]},
                          "Question",       {q: "Ki figyelmeztetett kit?", as: ["a könyvelő a statisztikust", "a statisztikus a könyvelőt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",9], "DashedSentence", {s: ["A tábornok", "azt", "válaszolta:", "A tisztet", "utáló", "katona", "kitüntetést", "kapott", "bátorságáért."]},
                          "Question",       {q: "Ki utált kit?", as: ["a katona a tisztet", "a tiszt a katonát"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",9], "DashedSentence", {s: ["A tábornok", "azt", "válaszolta:", "A tiszt", "által", "utált", "katona", "kitüntetést", "kapott", "bátorságáért."]},
                          "Question",       {q: "Ki utált kit?", as: ["a katona a tisztet", "a tiszt a katonát"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",9], "DashedSentence", {s: ["A tábornok", "azt", "válaszolta:", "A katonát", "utáló", "tiszt", "kitüntetést", "kapott", "bátorságáért."]},
                          "Question",       {q: "Ki utált kit?", as: ["a katona a tisztet", "a tiszt a katonát"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",9], "DashedSentence", {s: ["A tábornok", "azt", "válaszolta:", "A katona", "által", "utált", "tiszt", "kitüntetést", "kapott", "bátorságáért."]},
                          "Question",       {q: "Ki utált kit?", as: ["a katona a tisztet", "a tiszt a katonát"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",10], "DashedSentence", {s: ["Egyik", "kollégája", "azt", "válaszolta:", "A pácienst", "meglátogató", "orvos", "egy", "jegyzettömbbe", "írta", "le", "a javaslatait."]},
                          "Question",       {q: "Ki látogatott meg kit?", as: ["az orvos a pácienst", "a páciens az orvost"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",10], "DashedSentence", {s: ["Egyik", "kollégája", "azt", "válaszolta:", "A páciens", "által", "meglátogatott", "orvos", "egy", "jegyzettömbbe", "írta", "le", "a javaslatait."]},
                          "Question",       {q: "Ki látogatott meg kit?", as: ["az orvos a pácienst", "a páciens az orvost"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",10], "DashedSentence", {s: ["Egyik", "kollégája", "azt", "válaszolta:", "A orvost", "meglátogató", "páciens", "egy", "jegyzettömbbe", "írta", "le", "a javaslatait."]},
                          "Question",       {q: "Ki látogatott meg kit?", as: ["az orvos a pácienst", "a páciens az orvost"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",10], "DashedSentence", {s: ["Egyik", "kollégája", "azt", "válaszolta:", "A orvos", "által", "meglátogatott", "páciens", "egy", "jegyzettömbbe", "írta", "le", "a javaslatait."]},
                          "Question",       {q: "Ki látogatott meg kit?", as: ["az orvos a pácienst", "a páciens az orvost"], hasCorrect: 0, randomOrder: true}],
    
    [["e.SRC.A",11], "DashedSentence", {s: ["A menedzser", "azt", "mondta:", "A vendéget", "meglökő", "csapos", "elejtett", "egy", "vízzel", "teli", "poharat."]},
                          "Question",       {q: "Ki lökött meg kit?", as: ["a csapos a vendéget", "a vendég a csapost"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",11], "DashedSentence", {s: ["A menedzser", "azt", "mondta:", "A vendég", "által", "meglökött", "csapos", "elejtett", "egy", "vízzel", "teli", "poharat."]},
                          "Question",       {q: "Ki lökött meg kit?", as: ["a csapos a vendéget", "a vendég a csapost"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",11], "DashedSentence", {s: ["A menedzser", "azt", "mondta:", "A csapost", "meglökő", "vendég", "elejtett", "egy", "vízzel", "teli", "poharat."]},
                          "Question",       {q: "Ki lökött meg kit?", as: ["a csapos a vendéget", "a vendég a csapost"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",11], "DashedSentence", {s: ["A menedzser", "azt", "mondta:", "A csapost", "által", "meglökött", "vendég", "elejtett", "egy", "vízzel", "teli", "poharat."]},
                          "Question",       {q: "Ki lökött meg kit?", as: ["a csapos a vendéget", "a vendég a csapost"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",12], "DashedSentence", {s: ["A vezérigazgató", "azt", "válaszolta:", "A befektetőt", "lenyűgöző", "vállalkozó", "megfontolta", "az együttműködési", "ajánlatot."]},
                          "Question",       {q: "Ki nyűgözött meg kit?", as: ["a vállalkozó a befektetőt", "a befektető a vállalkozót"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",12], "DashedSentence", {s: ["A vezérigazgató", "azt", "válaszolta:", "A befektető", "által", "lenyűgözött", "vállalkozó", "megfontolta", "az együttműködési", "ajánlatot."]},
                          "Question",       {q: "Ki nyűgözött meg kit?", as: ["a vállalkozó a befektetőt", "a befektető a vállalkozót"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",12], "DashedSentence", {s: ["A vezérigazgató", "azt", "válaszolta:", "A vállalkozót", "lenyűgöző", "befektető", "megfontolta", "az együttműködési", "ajánlatot."]},
                          "Question",       {q: "Ki nyűgözött meg kit?", as: ["a vállalkozó a befektetőt", "a befektető a vállalkozót"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",12], "DashedSentence", {s: ["A vezérigazgató", "azt", "válaszolta:", "A vállalkozó", "által", "lenyűgözött", "befektető", "megfontolta", "az együttműködési", "ajánlatot."]},
                          "Question",       {q: "Ki nyűgözött meg kit?", as: ["a vállalkozó a befektetőt", "a befektető a vállalkozót"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",13], "DashedSentence", {s: ["Andi", "azt", "mondta:", "Az unokát", "megölelő", "nagypapa", "kitalált", "egy", "mesét", "egy", "elefántról."]},
                          "Question",       {q: "Ki ölelt meg kit?", as: ["a nagypapa az unokát", "az unoka a nagypapát"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",13], "DashedSentence", {s: ["Andi", "azt", "mondta:", "Az unoka", "által", "megölelt", "nagypapa", "kitalált", "egy", "mesét", "egy", "elefántról."]},
                          "Question",       {q: "Ki ölelt meg kit?", as: ["a nagypapa az unokát", "az unoka a nagypapát"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",13], "DashedSentence", {s: ["Andi", "azt", "mondta:", "A nagypapát", "megölelő", "unoka", "kitalált", "egy", "mesét", "egy", "elefántról."]},
                          "Question",       {q: "Ki ölelt meg kit?", as: ["a nagypapa az unokát", "az unoka a nagypapát"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",13], "DashedSentence", {s: ["Andi", "azt", "mondta:", "A nagypapa", "által", "megölelt", "unoka", "kitalált", "egy", "mesét", "egy", "elefántról."]},
                          "Question",       {q: "Ki ölelt meg kit?", as: ["a nagypapa az unokát", "az unoka a nagypapát"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",14], "DashedSentence", {s: ["Azt", "mondta:", "A kormányzót", "megdicsérő", "polgármester", "választási", "sikerre", "számított."]},
                          "Question",       {q: "Ki dicsért meg kit?", as: ["a polgármester a kormányzót", "a kormányzó a polgármestert"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",14], "DashedSentence", {s: ["Azt", "mondta:", "A kormányzó", "által", "megdicsért", "polgármester", "választási", "sikerre", "számított."]},
                          "Question",       {q: "Ki dicsért meg kit?", as: ["a polgármester a kormányzót", "a kormányzó a polgármestert"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",14], "DashedSentence", {s: ["Azt", "mondta:", "A polgármestert", "megdicsérő", "kormányzó", "választási", "sikerre", "számított."]},
                          "Question",       {q: "Ki dicsért meg kit?", as: ["a polgármester a kormányzót", "a kormányzó a polgármestert"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",14], "DashedSentence", {s: ["Azt", "mondta:", "A polgármester", "által", "megdicsért", "kormányzó", "választási", "sikerre", "számított."]},
                          "Question",       {q: "Ki dicsért meg kit?", as: ["a polgármester a kormányzót", "a kormányzó a polgármestert"], hasCorrect: 0, randomOrder: true}],
   
    [["e.SRC.A",15], "DashedSentence", {s: ["A segéd", "azt", "mondta:", "A franciát", "legyőző", "svéd", "elejtette", "az", "ütőjét", "a pályán."]},
                          "Question",       {q: "Ki győzött le kit?", as: ["a svéd a franciát", "a francia a svédet"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",15], "DashedSentence", {s: ["A segéd", "azt", "mondta:", "A francia", "által", "legyőzött", "svéd", "elejtette", "az", "ütőjét", "a pályán."]},
                          "Question",       {q: "Ki győzött le kit?", as: ["a svéd a franciát", "a francia a svédet"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",15], "DashedSentence", {s: ["A segéd", "azt", "mondta:", "A svédet", "legyőző", "francia", "elejtette", "az", "ütőjét", "a pályán."]},
                          "Question",       {q: "Ki győzött le kit?", as: ["a svéd a franciát", "a francia a svédet"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",15], "DashedSentence", {s: ["A segéd", "azt", "mondta:", "A svéd", "által", "legyőzött", "francia", "elejtette", "az", "ütőjét", "a pályán."]},
                          "Question",       {q: "Ki győzött le kit?", as: ["a svéd a franciát", "a francia a svédet"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",16], "DashedSentence", {s: ["Az adminisztrátor", "azt", "válaszolta:", "A biológust", "méltató", "kémikus", "díjat", "kapott", "a kutatásáért."]},
                          "Question",       {q: "Ki méltatott kit?", as: ["a kémikus a biológust", "a biológus a kémikust"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",16], "DashedSentence", {s: ["Az adminisztrátor", "azt", "válaszolta:", "A biológus", "által", "méltatott", "kémikus", "díjat", "kapott", "a kutatásáért."]},
                          "Question",       {q: "Ki méltatott kit?", as: ["a kémikus a biológust", "a biológus a kémikust"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",16], "DashedSentence", {s: ["Az adminisztrátor", "azt", "válaszolta:", "A kémikust", "méltató", "biológus", "díjat", "kapott", "a kutatásáért."]},
                          "Question",       {q: "Ki méltatott kit?", as: ["a kémikus a biológust", "a biológus a kémikust"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",16], "DashedSentence", {s: ["Az adminisztrátor", "azt", "válaszolta:", "A kémikus", "által", "méltatott", "biológus", "díjat", "kapott", "a kutatásáért."]},
                          "Question",       {q: "Ki méltatott kit?", as: ["a kémikus a biológust", "a biológus a kémikust"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",17], "DashedSentence", {s: ["A tortanár", "azt", "válaszolta:", "Az osztályelsőt", "provokáló", "szájhős", "kimagyarázta", "a helyzetet", "a veszekedést", "követően."]},
                          "Question",       {q: "Ki provokált kit?", as: ["a szájhős az osztályelsőt", "az osztályelső a szájhőst"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",17], "DashedSentence", {s: ["A tortanár", "azt", "válaszolta:", "Az osztályelső", "által", "provokált", "szájhős", "kimagyarázta", "a helyzetet", "a veszekedést", "követően."]},
                          "Question",       {q: "Ki provokált kit?", as: ["a szájhős az osztályelsőt", "az osztályelső a szájhőst"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",17], "DashedSentence", {s: ["A tortanár", "azt", "válaszolta:", "A szájhőst", "provokáló", "osztályelső", "kimagyarázta", "a helyzetet", "a veszekedést", "követően."]},
                          "Question",       {q: "Ki provokált kit?", as: ["a szájhős az osztályelsőt", "az osztályelső a szájhőst"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",17], "DashedSentence", {s: ["A tortanár", "azt", "válaszolta:", "A szájhős", "által", "provokált", "osztályelső", "kimagyarázta", "a helyzetet", "a veszekedést", "követően."]},
                          "Question",       {q: "Ki provokált kit?", as: ["a szájhős az osztályelsőt", "az osztályelső a szájhőst"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",18], "DashedSentence", {s: ["A HR-es", "azt", "mondta:", "A menedzsert", "kiábrándító", "szakértő", "megszakította", "a kapcsolatot", "a céggel."]},
                          "Question",       {q: "Ki ábrándított ki kit?", as: ["a szakértő a menedzsert", "a menedzser a szakértőt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",18], "DashedSentence", {s: ["A HR-es", "azt", "mondta:", "A menedzser", "által", "kiábrándított", "szakértő", "megszakította", "a kapcsolatot", "a céggel."]},
                          "Question",       {q: "Ki ábrándított ki kit?", as: ["a szakértő a menedzsert", "a menedzser a szakértőt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",18], "DashedSentence", {s: ["A HR-es", "azt", "mondta:", "A szakértőt", "kiábrándító", "menedzser", "megszakította", "a kapcsolatot", "a céggel."]},
                          "Question",       {q: "Ki ábrándított ki kit?", as: ["a szakértő a menedzsert", "a menedzser a szakértőt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",18], "DashedSentence", {s: ["A HR-es", "azt", "mondta:", "A szakértő", "által", "kiábrándított", "menedzser", "megszakította", "a kapcsolatot", "a céggel."]},
                          "Question",       {q: "Ki ábrándított ki kit?", as: ["a szakértő a menedzsert", "a menedzser a szakértőt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",19], "DashedSentence", {s: ["Zita", "így", "válaszolt:", "A könyvtárost", "leszidó", "adminisztrátor", "dühösen", "panaszlevelet", "írt."]},
                          "Question",       {q: "Ki szidott le kit?", as: ["az adminisztrátor a könyvtárost", "a könyvtáros az adminisztrátort"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",19], "DashedSentence", {s: ["Zita", "így", "válaszolt:", "A könyvtáros", "által", "leszidott", "adminisztrátor", "dühösen", "panaszlevelet", "írt."]},
                          "Question",       {q: "Ki szidott le kit?", as: ["az adminisztrátor a könyvtárost", "a könyvtáros az adminisztrátort"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",19], "DashedSentence", {s: ["Zita", "így", "válaszolt:", "Az adminisztrátort", "leszidó", "könyvtáros", "dühösen", "panaszlevelet", "írt."]},
                          "Question",       {q: "Ki szidott le kit?", as: ["az adminisztrátor a könyvtárost", "a könyvtáros az adminisztrátort"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",19], "DashedSentence", {s: ["Zita", "így", "válaszolt:", "Az adminisztrátor", "által", "leszidott", "könyvtáros", "dühösen", "panaszlevelet", "írt."]},
                          "Question",       {q: "Ki szidott le kit?", as: ["az adminisztrátor a könyvtárost", "a könyvtáros az adminisztrátort"], hasCorrect: 0, randomOrder: true}],  


    [["e.SRC.A",20], "DashedSentence", {s: ["A beosztott", "azt", "mondta:", "A mentőst", "észrevevő", "tűzoltó", "rádión", "kért", "segítséget."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a tűzoltó a mentőst", "a mentős a tűzoltót"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",20], "DashedSentence", {s: ["A beosztott", "azt", "mondta:", "A mentős", "által", "észrevett", "tűzoltó", "rádión", "kért", "segítséget."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a tűzoltó a mentőst", "a mentős a tűzoltót"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",20], "DashedSentence", {s: ["A beosztott", "azt", "mondta:", "A tűzoltót", "észrevevő", "mentős", "rádión", "kért", "segítséget."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a tűzoltó a mentőst", "a mentős a tűzoltót"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",20], "DashedSentence", {s: ["A beosztott", "azt", "mondta:", "A tűzoltó", "által", "észrevett", "mentős", "rádión", "kért", "segítséget."]},
                          "Question",       {q: "Ki vett észre kit?", as: ["a tűzoltó a mentőst", "a mentős a tűzoltót"], hasCorrect: 0, randomOrder: true}],


    [["e.SRC.A",21], "DashedSentence", {s: ["A társa", "azt", "válaszolta:", "A játékost", "megzavaró", "rendező", "egy", "kérdéssel", "válaszolta", "meg", "a kérdést."]},
                          "Question",       {q: "Ki zavart meg kit?", as: ["a rendező a játékost", "a játékos a rendezőt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",21], "DashedSentence", {s: ["A társa", "azt", "válaszolta:", "A játékos", "által", "megzavart", "rendező", "egy", "kérdéssel", "válaszolta", "meg", "a kérdést."]},
                          "Question",       {q: "Ki zavart meg kit?", as: ["a rendező a játékost", "a játékos a rendezőt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",21], "DashedSentence", {s: ["A társa", "azt", "válaszolta:", "A rendezőt", "megzavaró", "játékos", "egy", "kérdéssel", "válaszolta", "meg", "a kérdést."]},
                          "Question",       {q: "Ki zavart meg kit?", as: ["a rendező a játékost", "a játékos a rendezőt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",21], "DashedSentence", {s: ["A társa", "azt", "válaszolta:", "A rendező", "által", "megzavart", "játékos", "egy", "kérdéssel", "válaszolta", "meg", "a kérdést."]},
                          "Question",       {q: "Ki zavart meg kit?", as: ["a rendező a játékost", "a játékos a rendezőt"], hasCorrect: 0, randomOrder: true}],
   
    [["e.SRC.A",22], "DashedSentence", {s: ["A barátnő", "azt", "mondta:", "A könyvelőt", "ajánló", "ügyvéd", "keddre", "szervezte", "meg", "a találkozót."]},
                          "Question",       {q: "Ki ajánlott kit?", as: ["az ügyvéd a könyvelőt", "a könyvelő az ügyvédet"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",22], "DashedSentence", {s: ["A barátnő", "azt", "mondta:", "A könyvelő", "által", "ajánlott", "ügyvéd", "keddre", "szervezte", "meg", "a találkozót."]},
                          "Question",       {q: "Ki ajánlott kit?", as: ["az ügyvéd a könyvelőt", "a könyvelő az ügyvédet"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",22], "DashedSentence", {s: ["A barátnő", "azt", "mondta:", "Az ügyvédet", "ajánló", "könyvelő", "keddre", "szervezte", "meg", "a találkozót."]},
                          "Question",       {q: "Ki ajánlott kit?", as: ["az ügyvéd a könyvelőt", "a könyvelő az ügyvédet"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",22], "DashedSentence", {s: ["A barátnő", "azt", "mondta:", "Az ügyvéd", "által", "ajánlott", "könyvelő", "keddre", "szervezte", "meg", "a találkozót."]},
                          "Question",       {q: "Ki ajánlott kit?", as: ["az ügyvéd a könyvelőt", "a könyvelő az ügyvédet"], hasCorrect: 0, randomOrder: true}],
   
    [["e.SRC.A",23], "DashedSentence", {s: ["Ádám", "azt", "mondta:", "Az elnököt", "háborgató", "szenátor", "írt", "egy", "levelet", "a kongresszusnak."]},
                          "Question",       {q: "Ki háborgatott kit?", as: ["a szenátor az elnököt", "az elnök a szenátort"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",23], "DashedSentence", {s: ["Ádám", "azt", "mondta:", "Az elnök", "által", "háborgatott", "szenátor", "írt", "egy", "levelet", "a kongresszusnak."]},
                          "Question",       {q: "Ki háborgatott kit?", as: ["a szenátor az elnököt", "az elnök a szenátort"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",23], "DashedSentence", {s: ["Ádám", "azt", "mondta:", "A szenátort", "háborgató", "elnök", "írt", "egy", "levelet", "a kongresszusnak."]},
                          "Question",       {q: "Ki háborgatott kit?", as: ["a szenátor az elnököt", "az elnök a szenátort"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",23], "DashedSentence", {s: ["Ádám", "azt", "mondta:", "A szenátor", "által", "háborgatott", "elnök", "írt", "egy", "levelet", "a kongresszusnak."]},
                          "Question",       {q: "Ki háborgatott kit?", as: ["a szenátor az elnököt", "az elnök a szenátort"], hasCorrect: 0, randomOrder: true}],


    [["e.SRC.A",24], "DashedSentence", {s: ["Katalin", "azt", "mondta:", "A nyomozót", "értesítő", "riporter", "részletesen", "leírta", "a bűncselekményt."]},
                          "Question",       {q: "Ki értesített kit?", as: ["a riporter a nyomozót", "a nyomozó a riportert"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",24], "DashedSentence", {s: ["Katalin", "azt", "mondta:", "A nyomozó", "által", "értesített", "riporter", "részletesen", "leírta", "a bűncselekményt."]},
                          "Question",       {q: "Ki értesített kit?", as: ["a riporter a nyomozót", "a nyomozó a riportert"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",24], "DashedSentence", {s: ["Katalin", "azt", "mondta:", "A riportert", "értesítő", "nyomozó", "részletesen", "leírta", "a bűncselekményt."]},
                          "Question",       {q: "Ki értesített kit?", as: ["a riporter a nyomozót", "a nyomozó a riportert"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",24], "DashedSentence", {s: ["Katalin", "azt", "mondta:", "A riporter", "által", "értesített", "nyomozó", "részletesen", "leírta", "a bűncselekményt."]},
                          "Question",       {q: "Ki értesített kit?", as: ["a riporter a nyomozót", "a nyomozó a riportert"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",25], "DashedSentence", {s: ["A helyettes", "azt", "válaszolta:", "A hadnagyot", "megalázó", "tábornok", "hibát", "követett", "el", "a csatában."]},
                          "Question",       {q: "Ki alázott meg kit?", as: ["a tábornok a hadnagyot", "a hadnagy a tábornokot"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",25], "DashedSentence", {s: ["A helyettes", "azt", "válaszolta:", "A hadnagy", "által", "megalázott", "tábornok", "hibát", "követett", "el", "a csatában."]},
                          "Question",       {q: "Ki alázott meg kit?", as: ["a tábornok a hadnagyot", "a hadnagy a tábornokot"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",25], "DashedSentence", {s: ["A helyettes", "azt", "válaszolta:", "A tábornokot", "megalázó", "hadnagy", "hibát", "követett", "el", "a csatában."]},
                          "Question",       {q: "Ki alázott meg kit?", as: ["a tábornok a hadnagyot", "a hadnagy a tábornokot"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",25], "DashedSentence", {s: ["A helyettes", "azt", "válaszolta:", "A tábornok", "által", "megalázott", "hadnagy", "hibát", "követett", "el", "a csatában."]},
                          "Question",       {q: "Ki alázott meg kit?", as: ["a tábornok a hadnagyot", "a hadnagy a tábornokot"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",26], "DashedSentence", {s: ["Charlie", "azt", "mondta:", "A nyelvészt", "idéző", "filozófus", "tanított", "egy", "kurzust", "Cambridge-ben."]},
                          "Question",       {q: "Ki idézett kit?", as: ["a filozófus a nyelvészt", "a nyelvész a filozófust"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",26], "DashedSentence", {s: ["Charlie", "azt", "mondta:", "A nyelvész", "által", "idézett", "filozófus", "tanított", "egy", "kurzust", "Cambridge-ben."]},
                          "Question",       {q: "Ki idézett kit?", as: ["a filozófus a nyelvészt", "a nyelvész a filozófust"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",26], "DashedSentence", {s: ["Charlie", "azt", "mondta:", "A filozófust", "idéző", "nyelvész", "tanított", "egy", "kurzust", "Cambridge-ben."]},
                          "Question",       {q: "Ki idézett kit?", as: ["a filozófus a nyelvészt", "a nyelvész a filozófust"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",26], "DashedSentence", {s: ["Charlie", "azt", "mondta:", "A filozófus", "által", "idézett", "nyelvész", "tanított", "egy", "kurzust", "Cambridge-ben."]},
                          "Question",       {q: "Ki idézett kit?", as: ["a filozófus a nyelvészt", "a nyelvész a filozófust"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",27], "DashedSentence", {s: ["András", "így", "tippelt:", "A dobost", "szerető", "szólógitáros", "1988-ban", "alapította", "meg", "az együttest."]},
                          "Question",       {q: "Ki szeretett kit?", as: ["a szólógitáros a dobost", "a dobos a szólógitárost"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",27], "DashedSentence", {s: ["András", "így", "tippelt:", "A dobos", "által", "szeretett", "szólógitáros", "1988-ban", "alapította", "meg", "az együttest."]},
                          "Question",       {q: "Ki szeretett kit?", as: ["a szólógitáros a dobost", "a dobos a szólógitárost"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",27], "DashedSentence", {s: ["András", "így", "tippelt:", "A szólógitárost", "szerető", "dobos", "1988-ban", "alapította", "meg", "az együttest."]},
                          "Question",       {q: "Ki szeretett kit?", as: ["a szólógitáros a dobost", "a dobos a szólógitárost"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",27], "DashedSentence", {s: ["András", "így", "tippelt:", "A szólógitáros", "által", "szeretett", "dobos", "1988-ban", "alapította", "meg", "az együttest."]},
                          "Question",       {q: "Ki szeretett kit?", as: ["a szólógitáros a dobost", "a dobos a szólógitárost"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",28], "DashedSentence", {s: ["Ők", "azt", "válaszolták:", "Az úszót", "megijesztő", "búvár", "félrehúzódott", "az egyik", "oldalra."]},
                          "Question",       {q: "Ki ijesztett meg kit?", as: ["a búvár az úszót", "az úszó a búvárt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",28], "DashedSentence", {s: ["Ők", "azt", "válaszolták:", "Az úszó", "által", "megijesztett", "búvár", "félrehúzódott", "az egyik", "oldalra."]},
                          "Question",       {q: "Ki ijesztett meg kit?", as: ["a búvár az úszót", "az úszó a búvárt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",28], "DashedSentence", {s: ["Ők", "azt", "válaszolták:", "A búvárt", "megijesztő", "úszó", "félrehúzódott", "az egyik", "oldalra."]},
                          "Question",       {q: "Ki ijesztett meg kit?", as: ["a búvár az úszót", "az úszó a búvárt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",28], "DashedSentence", {s: ["Ők", "azt", "válaszolták:", "A búvár", "által", "megijesztett", "úszó", "félrehúzódott", "az egyik", "oldalra."]},
                          "Question",       {q: "Ki ijesztett meg kit?", as: ["a búvár az úszót", "az úszó a búvárt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",29], "DashedSentence", {s: ["Gyuri", "azt", "mondta:", "A villanyszerelőt", "megütő", "gépész", "egy", "monoklival", "a szeme", "alatt", "ment", "haza."]},
                          "Question",       {q: "Ki ütött meg kit?", as: ["a gépész a villanyszerelőt", "a villanyszerelő a gépészt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",29], "DashedSentence", {s: ["Gyuri", "azt", "mondta:", "A villanyszerelő", "által", "megütött", "gépész", "egy", "monoklival", "a szeme", "alatt", "ment", "haza."]},
                          "Question",       {q: "Ki ütött meg kit?", as: ["a gépész a villanyszerelőt", "a villanyszerelő a gépészt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",29], "DashedSentence", {s: ["Gyuri", "azt", "mondta:", "A gépészt", "megütő", "villanyszerelő", "egy", "monoklival", "a szeme", "alatt", "ment", "haza."]},
                          "Question",       {q: "Ki ütött meg kit?", as: ["a gépész a villanyszerelőt", "a villanyszerelő a gépészt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",29], "DashedSentence", {s: ["Gyuri", "azt", "mondta:", "A gépész", "által", "megütött", "villanyszerelő", "egy", "monoklival", "a szeme", "alatt", "ment", "haza."]},
                          "Question",       {q: "Ki ütött meg kit?", as: ["a gépész a villanyszerelőt", "a villanyszerelő a gépészt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",30], "DashedSentence", {s: ["A tanú", "azt", "mondta:", "A bűnözőt", "megsebesítő", "rendőr", "az üldözés", "során", "elejtette", "a revolverét."]},
                          "Question",       {q: "Ki sebesített meg kit?", as: ["a rendőr a bűnözőt", "a bűnöző a rendőrt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",30], "DashedSentence", {s: ["A tanú", "azt", "mondta:", "A bűnöző", "által", "megsebesített", "rendőr", "az üldözés", "során", "elejtette", "a revolverét."]},
                          "Question",       {q: "Ki sebesített meg kit?", as: ["a rendőr a bűnözőt", "a bűnöző a rendőrt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",30], "DashedSentence", {s: ["A tanú", "azt", "mondta:", "A rendőrt", "megsebesítő", "bűnöző", "az üldözés", "során", "elejtette", "a revolverét."]},
                          "Question",       {q: "Ki sebesített meg kit?", as: ["a rendőr a bűnözőt", "a bűnöző a rendőrt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",30], "DashedSentence", {s: ["A tanú", "azt", "mondta:", "A rendőr", "által", "megsebesített", "bűnöző", "az üldözés", "során", "elejtette", "a revolverét."]},
                          "Question",       {q: "Ki sebesített meg kit?", as: ["a rendőr a bűnözőt", "a bűnöző a rendőrt"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",31], "DashedSentence", {s: ["Réka", "így", "foglalta", "össze:", "A vevőt", "összezavaró", "patikus", "újraolvasta", "a receptet."]},
                          "Question",       {q: "Ki zavart össze kit?", as: ["a patikus a vevőt", "a vevő a patikust"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",31], "DashedSentence", {s: ["Réka", "így", "foglalta", "össze:", "A vevő", "által", "összezavart", "patikus", "újraolvasta", "a receptet."]},
                          "Question",       {q: "Ki zavart össze kit?", as: ["a patikus a vevőt", "a vevő a patikust"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",31], "DashedSentence", {s: ["Réka", "így", "foglalta", "össze:", "A patikust", "összezavaró", "vevő", "újraolvasta", "a receptet."]},
                          "Question",       {q: "Ki zavart össze kit?", as: ["a patikus a vevőt", "a vevő a patikust"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",31], "DashedSentence", {s: ["Réka", "így", "foglalta", "össze:", "A patikus", "által", "összezavart", "vevő", "újraolvasta", "a receptet."]},
                          "Question",       {q: "Ki zavart össze kit?", as: ["a patikus a vevőt", "a vevő a patikust"], hasCorrect: 0, randomOrder: true}],

    [["e.SRC.A",32], "DashedSentence", {s: ["Robi", "azt", "válaszolta:", "A gengsztert", "bemártó", "tolvaj", "a széfben", "rejtette", "el", "a zsákmányt."]},
                          "Question",       {q: "Ki mártott be kit?", as: ["a tolvaj a gengsztert", "a gengszter a tolvajt"], hasCorrect: 0, randomOrder: true}],
    [["e.ORC.A",32], "DashedSentence", {s: ["Robi", "azt", "válaszolta:", "A gengszter", "által", "bemártott", "tolvaj", "a széfben", "rejtette", "el", "a zsákmányt."]},
                          "Question",       {q: "Ki mártott be kit?", as: ["a tolvaj a gengsztert", "a gengszter a tolvajt"], hasCorrect: 1, randomOrder: true}],
    [["e.SRC.B",32], "DashedSentence", {s: ["Robi", "azt", "válaszolta:", "A tolvajt", "bemártó", "gengszter", "a széfben", "rejtette", "el", "a zsákmányt."]},
                          "Question",       {q: "Ki mártott be kit?", as: ["a tolvaj a gengsztert", "a gengszter a tolvajt"], hasCorrect: 1, randomOrder: true}],
    [["e.ORC.B",32], "DashedSentence", {s: ["Robi", "azt", "válaszolta:", "A tolvaj", "által", "bemártott", "gengszter", "a széfben", "rejtette", "el", "a zsákmányt."]},
                          "Question",       {q: "Ki mártott be kit?", as: ["a tolvaj a gengsztert", "a gengszter a tolvajt"], hasCorrect: 0, randomOrder: true}],


  
         //
    // 38 self-paced-reading filler sentences with question.
    //

    ["f.A.1", "DashedSentence", {s: ["Az,", "hogy", "a dékán", "kinevezte", "az adjunktust", "tanszékvezetővé,", "meglepett", "mindenkit."]},
          "Question",       {q: "Ki nevezett ki kit tanszékvezetővé?", as: ["a dékán az adjunktust", "az adjunktus a dékánt"], hasCorrect: 0, randomOrder: true}],

    ["f.A.2", "DashedSentence", {s: ["Az,", "hogy", "a főorvos", "megkérdőjelezte", "a gyermekgyógyászt,", "mindenkit", "elszomorított."]},
          "Question",       {q: "Ki kérdőjelezett meg kit?", as: ["a főorvos a gyermekgyógyászt", "a gyermekgyógyász a főorvost"], hasCorrect: 0, randomOrder: true}],

    ["f.A.3", "DashedSentence", {s: ["Az,", "hogy", "a postás", "időben", "átadta", "a fontos", "csomagot", "a nagykövetnek,", "megkönnyebbülés", "volt."]},
          "Question",       {q: "Kinek adta át a postás a csomagot?", as: ["a nagykövetnek", "a diplomatának"], hasCorrect: 0, randomOrder: true}],

    ["f.A.4", "DashedSentence", {s: ["Az,", "hogy", "a kisfiúnak", "megvette", "az anyukája", "a lézerkardot,", "féltékennyé", "tette", "a testvéreit."]},
          "Question",       {q: "Ki volt féltékeny?", as: ["a testvérek", "a kisfiú"], hasCorrect: 0, randomOrder: true}],

    ["f.A.5", "DashedSentence", {s: ["Az,", "hogy", "a nagymama", "karácsonykor", "sonkát", "szolgált", "fel,", "a teljes", "családnak", "örömet", "szerzett."]},
          "Question",       {q: "Mit szolgált fel a nagymama karácsonykor?", as: ["sonkát", "pulykát"], hasCorrect: 0, randomOrder: true}],

    ["f.A.6", "DashedSentence", {s: ["Az,", "hogy", "a parancsnok", "két fotót is", "behozott", "az irodába", "az ismeretlen", "tettesről,", "bizalomra", "adott", "okot."]},
          "Question",       {q: "Ki hozta be a fotókat?", as: ["a parancsnok", "a főhadnagy"], hasCorrect: 0, randomOrder: true}],

    ["f.A.7", "DashedSentence", {s: ["Az,", "hogy", "Rita", "a leárazáson", "csak", "márkás", "ruhákat", "vett,", "teljes", "mértékben", "kiszámítható", "volt."]},
          "Question",       {q: "Meglepő volt Rita márkás ruha vásárlása?", as: ["nem", "igen"], hasCorrect: 0, randomOrder: true}],

    ["f.B.1", "DashedSentence", {s: ["Az", "a hír,", "hogy", "a kéményseprő", "előreengedte", "a takarítónőt,", "hamar", "elterjedt", "a lakók", "között."]},
          "Question",       {q: "Ki engedett előre kit?", as: ["a kéményseprő a takarítónőt", "a takarítónő a kéményseprőt"], hasCorrect: 0, randomOrder: true}],

    ["f.B.2", "DashedSentence", {s: ["Az", "az állítás,", "hogy", "az újságíró", "lefizette", "a politikust,", "alaptalannak", "bizonyult."]},
          "Question",       {q: "Lefizette az újságíró a politikust?", as: ["nem", "igen"], hasCorrect: 0, randomOrder: true}],

    ["f.B.3", "DashedSentence", {s: ["Az", "a téveszme,", "hogy", "a nőgyógyász", "megvetette", "a bábát,", "sok", "beteget", "ijesztett", "el."]},
          "Question",       {q: "Igaz, hogy a nőgyógyász megvetette a bábát?", as: ["nem", "igen"], hasCorrect: 0, randomOrder: true}],

    ["f.B.4", "DashedSentence", {s: ["Az", "az állítás,", "hogy", "az iskolaigazgató", "elütötte", "a portást,", "nagy", "vihart", "kavart."]},
          "Question",       {q: "Ki ütött el kit?", as: ["az iskolaigazgató a portást", "a portás az iskolaigazgatót"], hasCorrect: 0, randomOrder: true}],

    ["f.B.5", "DashedSentence", {s: ["Az", "a rágalom,", "hogy", "a professzor", "pénzért", "jobb", "jegyet", "ad,", "alaptalannak", "bizonyult."]},
          "Question",       {q: "Kit rágalmaztak meg?", as: ["a professzort", "a minisztert"], hasCorrect: 0, randomOrder: true}],

    ["f.B.6", "DashedSentence", {s: ["Az", "a hír,", "hogy", "a légiutaskísérő", "eltérítette", "a Marokkóba", "tartó", "gépet,", "mindenkit", "elborzasztott."]},
          "Question",       {q: "Hova tartott az eltérített gép?", as: ["Marokkóba", "Milánóba"], hasCorrect: 0, randomOrder: true}],

    ["f.B.7", "DashedSentence", {s: ["Az", "a gyanú,", "hogy", "a házigazda", "rohadt", "gyümölcsöt", "tálalt", "fel,", "hamar", "elterjedt", "a környéken."]},
          "Question",       {q: "Mi volt rohadt?", as: ["a gyümölcs", "a zöldség"], hasCorrect: 0, randomOrder: true}],

    ["f.B.8", "DashedSentence", {s: ["Az", "az állítás,", "hogy", "az egyetemi", "felvételi", "egy sikeres", "karrier", "első", "állomása,", "a miniszter", "szájából", "hangzott", "el."]},
          "Question",       {q: "Milyen felvételiről beszélt a miniszter?", as: ["egyetemi", "középiskolai"], hasCorrect: 0, randomOrder: true}],

    ["f.C.1", "DashedSentence", {s: ["Annak", "a valószínűsége,", "hogy", "a séf", "feleségül", "veszi", "a pincérnőt,", "elég", "alacsony."]},
          "Question",       {q: "Ki nem fogja feleségül venni a pincérnőt?", as: ["a séf", "a kukta"], hasCorrect: 0, randomOrder: true}],

    ["f.C.2", "DashedSentence", {s: ["Annak", "a valószínűsége,", "hogy", "az óvónő", "elaltatná", "a nagycsoportost,", "nem", "túl", "nagy."]},
          "Question",       {q: "Kit próbál elaltatni az óvónő?", as: ["a nagycsoportost", "a kiscsoportost"], hasCorrect: 0, randomOrder: true}],

    ["f.C.3", "DashedSentence", {s: ["Annak", "a lehetősége,", "hogy", "az amerikai", "miniszter", "felhívja", "az orosz", "minisztert,", "mindenkit", "megrémített."]},
          "Question",       {q: "Milyen minisztert rémisztő, ha felhív az amerikai?", as: ["orosz", "spanyol"], hasCorrect: 0, randomOrder: true}],

    ["f.C.4", "DashedSentence", {s: ["Annak", "a lehetősége,", "hogy", "a zsoldos", "megbocsátana", "a terroristának,", "felkeltette", "a parancsnok", "figyelmét."]},
          "Question",       {q: "Ki figyelt fel a lehetőségre?", as: ["a parancsnok", "az ezredes"], hasCorrect: 0, randomOrder: true}],


    ["f.C.5", "DashedSentence", {s: ["Annak", "a valószínűsége,", "hogy", "az almatorta", "még", "a vendégek", "érkezése", "előtt", "elkészüljön,", "percről", "percre", "csökkent."]},
          "Question",       {q: "Mi nem fog elkészülni a vendégek érkezésére?", as: ["az almatorta", "az almáspite"], hasCorrect: 0, randomOrder: true}],

    ["f.C.6", "DashedSentence", {s: ["Annak", "a valószínűsége,", "hogy", "a titkárnő", "a fontos", "emailt", "még", "ebédszünet", "előtt", "kiküldje,", "rohamosan", "csökkent."]},
          "Question",       {q: "Mit kéne a titkárnőnek kiküldenie?", as: ["emailt", "közleményt"], hasCorrect: 0, randomOrder: true}],

    ["f.C.7", "DashedSentence", {s: ["Annak", "a lehetősége,", "hogy", "a varrónő", "az új", "ruhához", "az anyagot", "külföldről", "rendelje,", "sajnos", "nem", "garantált."]},
          "Question",       {q: "Mihez kell a varrónőnek anyag?", as: ["az új ruhához", "az báli ruhához"], hasCorrect: 0, randomOrder: true}],

    ["f.C.8", "DashedSentence", {s: ["Annak", "a lehetősége,", "hogy", "a színésznő", "a darab", "után", "autogramokat", "fog", "osztani,", "felvillanyozta", "a rajongót."]},
          "Question",       {q: "Mikor fog a színésznő autogramokat osztani?", as: ["a darab után", "a fogadáson"], hasCorrect: 0, randomOrder: true}],

    ["f.D.1", "DashedSentence", {s: ["A tanársegéd", "azt", "kérdezte,", "hogy", "az egyetemi", "nyílt", "nap", "szombaton", "lesz-e,", "megtartva."]},
          "Question",       {q: "Ki kérdezett az egyetemi nyílt napról?", as: ["a tanársegéd", "az asszisztens"], hasCorrect: 0, randomOrder: true}],

    ["f.D.2", "DashedSentence", {s: ["A látogató", "az", "iránt", "érdeklődött,", "hogy", "a múzeum", "vasárnaponként", "is", "nyitva,", "tart-e."]},
          "Question",       {q: "Milyen nap iránt érdeklődött a látogató?", as: ["vasárnap", "szombat"], hasCorrect: 0, randomOrder: true}],

    ["f.D.3", "DashedSentence", {s: ["Azt", "hittem,", "hogy", "a barátnőm", "művészettörténet", "fog", "tanulni", "az egyetemen."]},
          "Question",       {q: "Kiről hittem, hogy művészettörténet fog tanulni?", as: ["a barátnőmről", "a húgomról"], hasCorrect: 0, randomOrder: true}],

    ["f.D.4", "DashedSentence", {s: ["A nagymamám", "azt", "mondta,", "hogy", "a lakatos", "nem", "végzett", "jó", "munkát."]},
          "Question",       {q: "Ki nem volt elégedett a lakatossal?", as: ["a nagymamám", "a nagynéném"], hasCorrect: 0, randomOrder: true}],

    ["f.D.5", "DashedSentence", {s: ["Azt", "kérdeztük,", "hogy", "a tilosban", "parkolásért", "kiszabott", "büntetést", "be", "lehet-e", "csekken", "fizetni."]},
          "Question",       {q: "Mit akarunk csekken befizetni?", as: ["büntetést", "villanyszámlát"], hasCorrect: 0, randomOrder: true}],

    ["f.D.6", "DashedSentence", {s: ["A napközis", "tanítóm", "azt", "gondolta,", "hogy", "hiba", "lenne", "a nehéz", "matekleckéről", "az énektanárt", "megkérdezni."]},
          "Question",       {q: "Milyen lecke nehéz?", as: ["matek", "ének"], hasCorrect: 0, randomOrder: true}],

    ["f.D.7", "DashedSentence", {s: ["A festő", "azt", "mondta,", "hogy", "legszívesebben", "leköpte", "volna", "a szobrászt", "a legutóbbi", "közös", "kiállításukon."]},
          "Question",       {q: "Ki akarta leköpni a szobrászt?", as: ["a festő", "a művész"], hasCorrect: 0, randomOrder: true}],

    ["f.D.8", "DashedSentence", {s: ["A karmester", "azt", "hitte,", "hogy", "a főpróbát", "követően", "a teljes", "zenekar", "együtt", "fogja", "a koncertterem", "padlóját", "felmosni."]},
          "Question",       {q: "Minek a padlóját kellett felmosni?", as: ["koncertterem", "operaház"], hasCorrect: 0, randomOrder: true}],


    ["f.E.1", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "az iskolavezetés", "komoly", "problémákkal", "küzd."]},
          "Question",       {q: "Ki küzd problémákkal?", as: ["az iskolavezetés", "az iskolaigazgató"], hasCorrect: 0, randomOrder: true}],

    ["f.E.2", "DashedSentence", {s: ["Kétséges", "volt,", "hogy", "a fodrász", "megértette-e,", "hogy", "mi", "volt", "a frizurámmal", "a probléma."]},
          "Question",       {q: "Kinek volt problémája a firzurájával?", as: ["nekem", "a fodrásznak"], hasCorrect: 0, randomOrder: true}],

    ["f.E.3", "DashedSentence", {s: ["Kérdéses", "volt,", "hogy", "kitudódik-e,", "hogy", "a bankár", "megvesztegette", "a bírót."]},
          "Question",       {q: "Ki vesztegetett meg kit?", as: ["a bankár a bírót", "a bíró a bankárt"], hasCorrect: 0, randomOrder: true}],

    ["f.E.4", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "a hivatalnok", "hősies", "tetteinek", "köszönhetően", "fog", "érdemérmet", "kapni", "jövő", "tavasszal."]},
          "Question",       {q: "Ki fog érdemérmet kapni?", as: ["a hivatalnok", "a tiszt"], hasCorrect: 0, randomOrder: true}],

    ["f.E.5", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "a kalauz", "hirtelen", "kivett", "betegszabadságának", "hátterében", "családi", "problémák", "állnak."]},
          "Question",       {q: "Ki vett ki hirtelen betegszabadságot?", as: ["a kalauz", "a buszvezető"], hasCorrect: 0, randomOrder: true}],

    ["f.E.6", "DashedSentence", {s: ["Kétséges", "volt,", "hogy", "az éjszakai", "műszakos", "nyomdász", "elkészül-e", "a hétfőre", "ígért", "újság", "tördelésével."]},
          "Question",       {q: "Mikorra volt ígérve az újság?", as: ["hétfőre", "holnapra"], hasCorrect: 0, randomOrder: true}],

    ["f.E.7", "DashedSentence", {s: ["Kétséges", "volt,", "hogy", "a varázslótanonc", "legyőzte-e", "az ellenségét,", "vagy", "csak", "egy pillanatra", "tűnt", "úgy,", "hogy", "sikert", "fog", "aratni."]},
          "Question",       {q: "Kit kétséges, hogy legyőzött a varázslótanonc?", as: ["az ellenségét", "a gonoszt"], hasCorrect: 0, randomOrder: true}]


];
