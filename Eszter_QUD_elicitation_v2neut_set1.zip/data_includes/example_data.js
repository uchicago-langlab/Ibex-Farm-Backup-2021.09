define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});

var shuffleSequence = seq("setcounter","consent", "intro1","intro2",
                      sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit"  );

var completionMessage = "Thank you for your participation!"

var defaults = [
    "Separator", {
          transfer: 200,
          hideProgressBar: true,
        normalMessage: ""
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        leftComment: "very unnatural", rightComment: "very natural"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];



var items = [

    ["sep", "Separator", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html"}}],
    
    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],

     ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: guess what Mary's question was, given the rest of the dialogue."] 
],continueMessage:"Click here to start the experiment."}],
 
  ["setcounter", "__SetCounter__", { }],
    
// items

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The bus driver is angry.</i></p>"}],

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The soldier is dangerous.</i></p>"}], 

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wrestler is strong.</i></p>"}], 

[["Eliteral",1], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Drinking is allowed.</i></p>"}],

[["Eliteral",2], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br> Sue: <i>The model is attractive.</i></p>"}],
  
    [["Eliteral",3], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>John began the race.</i></p>"}],
 
    [["Eliteral",4], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teacher believes it is true.</i></p>"}], 

[["Eliteral",5], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The elephant is big.</i></p>"}], 

[["Eliteral",6], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is cool.</i></p>"}], 

[["Eliteral",7], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The machine damaged itself.</i></p>"}], 

[["Eliteral",8], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sky is dark.</i></p>"}],

[["Eliteral",9], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The task is difficult.</i></p>"}], 

[["Eliteral",10], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Zack's carpet was dirty.</i></p>"}], 

[["Eliteral",11], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The doctor dislikes coffee.</i></p>"}],  

[["Eliteral",12], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sales will double. </i></p>"}],

[["Eliteral",13], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>That candidate is equally skilled.</i></p>"}], 

[["Eliteral",14], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is funny.</i></p>"}], 

[["Eliteral",15], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is good.</i></p>"}], 

[["Eliteral",16], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The winner was happy.</i></p>"}], 

[["Eliteral",17], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The problem is hard.</i></p>"}], 

[["Eliteral",18], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The toxin is harmful.</i></p>"}], 

[["Eliteral",19], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>There is water here.</i></p>"}], 

[["Eliteral",20], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The boy is hungry.</i></p>"}], 

[["Eliteral",21], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The student is intelligent.</i></p>"}], 

[["Eliteral",22], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Chris's opponent was intimidating.</i></p>"}], 

[["Eliteral",23], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The coast was largely flooded.</i></p>"}],  

[["Eliteral",24], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The princess likes dancing.</i></p>"}],

[["Eliteral",25], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Bill's score matches Al's.</i></p>"}], 

[["Eliteral",26], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Peter's answers were mostly wrong.</i></p>"}], 

[["Eliteral",27], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The house is old.</i></p>"}], 

[["Eliteral",28], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Mistakes happened once.</i></p>"}], 

[["Eliteral",29], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Jimmy writes books or plays.</i></p>"}], 

[["Eliteral",30], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teenager is overweight.</i></p>"}], 

// [["Eliteral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i></p>"}],  
// [["Eimplicature",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i></p>"}], 
// [["Eneutral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i></p>"}], 
// [["Eimplicature",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i></p>"}],  
// [["Eneutral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i></p>"}], 
// [["Eimplicature",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i></p>"}], 
// [["Eneutral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i></p>"}], 
// [["Eimplicature",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i></p>"}], 
// [["Eneutral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i></p>"}], 
// [["Eimplicature",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i></p>"}],  
// [["Eneutral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i></p>"}],  
// [["Eimplicature",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i></p>"}], 
// [["Eneutral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i></p>"}],  
// [["Eimplicature",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i></p>"}],  
// [["Eneutral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i></p>"}], 
// [["Eimplicature",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i></p>"}],  
// [["Eneutral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i></p>"}], 
// [["Eimplicature",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i></p>"}], 
// [["Eneutral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i></p>"}],
// [["Eimplicature",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i></p>"}],
// [["Eneutral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i></p>"}], 
// [["Eimplicature",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i></p>"}],  
// [["Eneutral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i></p>"}],  
// [["Eimplicature",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i></p>"}],  
// [["Eneutral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i></p>"}],
// [["Eimplicature",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i></p>"}],  
// [["Eneutral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i></p>"}], 
// [["Eimplicature",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i></p>"}], 
// [["Eneutral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i></p>"}], 
// [["Eimplicature",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i></p>"}], 
// [["Eneutral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i></p>"}],
// [["Eimplicature",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i></p>"}],
// [["Eneutral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br>Mary: <i>Oh, I see.</i></p>"}],

//  [["Eliteral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i></p>"}],  
// [["Eimplicature",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i></p>"}], 
// [["Eneutral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i></p>"}],  
// [["Eimplicature",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i></p>"}], 
// [["Eneutral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i></p>"}],  
// [["Eimplicature",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i></p>"}], 
// [["Eneutral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i></p>"}], 
// [["Eimplicature",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i></p>"}],  
// [["Eneutral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i></p>"}],  
// [["Eimplicature",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i></p>"}],  
// [["Eneutral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i></p>"}],  
// [["Eimplicature",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i></p>"}], 
// [["Eneutral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i></p>"}],  
// [["Eimplicature",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i></p>"}],  
// [["Eneutral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i></p>"}], 
// [["Eimplicature",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i></p>"}],  
// [["Eneutral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i></p>"}],  
// [["Eimplicature",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i></p>"}],  
// [["Eneutral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i></p>"}], 
// [["Eimplicature",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i></p>"}], 
// [["Eneutral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i></p>"}], 
// [["Eimplicature",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i></p>"}], 
// [["Eneutral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i></p>"}],  
// [["Eimplicature",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i></p>"}],  
// [["Eneutral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i></p>"}],  
// [["Eimplicature",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i></p>"}],  
// [["Eneutral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i></p>"}],  
// [["Eimplicature",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i></p>"}],  
// [["Eneutral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

["filler1", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The table is clean.</i></p>"}], 
["filler2", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The man is drunk.</i></p>"}],  
["filler3", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The neighbor is sleepy.</i></p>"}],  
["filler4", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The gymnast is tall.</i></p>"}], 
["filler5", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The street is wide.</i></p>"}]// NOTE NO COMMA


    
    ];