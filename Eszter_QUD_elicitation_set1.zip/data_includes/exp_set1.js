define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});

var shuffleSequence = seq("setcounter","consent", "intro1","intro2",
                      sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit"  );

var completionMessage = "Thank you for your participation!"

var defaults = [
    "Separator", {
          transfer: 200,
          hideProgressBar: true,
        normalMessage: ""
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        leftComment: "very unnatural", rightComment: "very natural"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];



var items = [

    ["sep", "Separator", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html"}}],
    
    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],

     ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: guess what Mary's question was, making sure that it makes sense in the context of the entire dialogue."] 
],continueMessage:"Click here to start the experiment."}],
 
  ["setcounter", "__SetCounter__", { }],
    
// items

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The bus driver is angry.</i><br>Mary: <i>Can I take that to mean he could be furious?</i><br>Sue: <i>Yes, that's right.</i></p>"}],

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The soldier is dangerous.</i><br>Mary: <i>Can I take that to mean he is not harmless?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wrestler is strong.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",1], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Drinking is allowed.</i><br>Mary: <i>Can I take that to mean it is not obligatory?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eimplicature",1], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Drinking is allowed.</i><br>Mary: <i>Can I take that to mean it might be obligatory?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",1], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Drinking is allowed.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",2], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br> Sue: <i>The model is attractive.</i><br>Mary: <i>Can I take that to mean she is not stunning?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
    [["Eimplicature",2], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The model is attractive.</i><br>Mary: <i>Can I take that to mean she might be stunning?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
    [["Eneutral",2], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The model is attractive.</i><br>Mary: <i>Oh, I see.</i></p>"}],

    [["Eliteral",3], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>John began the race.</i><br>Mary: <i>Can I take that to mean he did not finish it?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
    [["Eimplicature",3], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>John began the race.</i><br>Mary: <i>Can I take that to mean he might have finished it?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
    [["Eneutral",3], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>John began the race.</i><br>Mary: <i>Oh, I see.</i></p>"}],

    [["Eliteral",4], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teacher believes it is true.</i><br>Mary: <i>Can I take that to mean she doesn't know it is true?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",4], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teacher believes it is true.</i><br>Mary: <i>Can I take that to mean she might know it is true?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eneutral",4], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teacher believes it is true.</i><br>Mary: <i>Oh, I see.</i></p>"}],

[["Eliteral",5], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The elephant is big.</i><br>Mary: <i>Can I take that to mean it is not enormous?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",5], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The elephant is big.</i><br>Mary: <i>Can I take that to mean it might be enormous?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",5], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The elephant is big.</i><br>Mary: <i>Oh, I see.</i></p>"}],

[["Eliteral",6], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is cool.</i><br>Mary: <i>Can I take that to mean it is not cold?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",6], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is cool.</i><br>Mary: <i>Can I take that to mean it might be cold?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",6], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is cool.</i><br>Mary: <i>Oh, I see.</i></p>"}],

[["Eliteral",7], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The machine damaged itself.</i><br>Mary: <i>Can I take that to mean it didn't destroy itself?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",7], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The machine damaged itself.</i><br>Mary: <i>Can I take that to mean it might have destroyed itself?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",7], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The machine damaged itself.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",8], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sky is dark.</i><br>Mary: <i>Can I take that to mean it is not black?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eimplicature",8], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sky is dark.</i><br>Mary: <i>Can I take that to mean it might be black?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",8], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sky is dark.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",9], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The task is difficult.</i><br>Mary: <i>Can I take that to mean it is not impossible?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",9], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The task is difficult.</i><br>Mary: <i>Can I take that to mean it might be impossible?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",9], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The task is difficult.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",10], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Zack's carpet was dirty.</i><br>Mary: <i>Can I take that to mean it was not filthy?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",10], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Zack's carpet was dirty.</i><br>Mary: <i>Can I take that to mean it might have been filthy?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eneutral",10], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Zack's carpet was dirty.</i><br>Mary: <i>Oh, I see.</i></p>"}],

[["Eliteral",11], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The doctor dislikes coffee.</i><br>Mary: <i>Can I take that to mean she doesn't loathe coffee?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
[["Eimplicature",11], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The doctor dislikes coffee.</i><br>Mary: <i>Can I take that to mean she might loathe coffee?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
[["Eneutral",11], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The doctor dislikes coffee.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

[["Eliteral",12], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sales will double. </i><br>Mary: <i>Can I take that to mean they won't triple?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eimplicature",12], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sales will double. </i><br>Mary: <i>Can I take that to mean they might triple?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",12], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sales will double. </i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",13], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>That candidate is equally skilled.</i><br>Mary: <i>Can I take that to mean he's not more skilled?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",13], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>That candidate is equally skilled.</i><br>Mary: <i>Can I take that to mean he might be more skilled?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eneutral",13], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>That candidate is equally skilled.</i><br>Mary: <i>Oh, I see.</i></p>"}],

[["Eliteral",14], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is funny.</i><br>Mary: <i>Can I take that to mean it was not hilarious?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",14], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is funny.</i><br>Mary: <i>Can I take that to mean it might be hilarious?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eneutral",14], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is funny.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

[["Eliteral",15], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is good.</i><br>Mary: <i>Can I take that to mean it is not excellent?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
[["Eimplicature",15], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is good.</i><br>Mary: <i>Can I take that to mean it might be excellent?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
[["Eneutral",15], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is good.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",16], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The winner was happy.</i><br>Mary: <i>Can I take that to mean she was not ecstatic?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",16], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The winner was happy.</i><br>Mary: <i>Can I take that to mean she might have been ecstatic?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",16], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The winner was happy.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",17], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The problem is hard.</i><br>Mary: <i>Can I take that to mean it is not unsolvable?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",17], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The problem is hard.</i><br>Mary: <i>Can I take that to mean it might be unsolvable?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",17], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The problem is hard.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",18], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The toxin is harmful.</i><br>Mary: <i>Can I take that to mean it is not deadly?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",18], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The toxin is harmful.</i><br>Mary: <i>Can I take that to mean it might be deadly?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",18], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The toxin is harmful.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",19], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>There is water here.</i><br>Mary: <i>Can I take that to mean there isn't water everywhere?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",19], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>There is water here.</i><br>Mary: <i>Can I take that to mean there might be water everywhere?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",19], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>There is water here.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",20], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The boy is hungry.</i><br>Mary: <i>Can I take that to mean he is not starving?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",20], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The boy is hungry.</i><br>Mary: <i>Can I take that to mean he might be starving?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",20], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The boy is hungry.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",21], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The student is intelligent.</i><br>Mary: <i>Can I take that to mean she is not brilliant?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",21], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The student is intelligent.</i><br>Mary: <i>Can I take that to mean she might be brilliant?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",21], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The student is intelligent.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",22], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Chris's opponent was intimidating.</i><br>Mary: <i>Can I take that to mean he was not terrifying?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",22], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Chris's opponent was intimidating.</i><br>Mary: <i>Can I take that to mean he might have been terrifying?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",22], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Chris's opponent was intimidating.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",23], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The coast was largely flooded.</i><br>Mary: <i>Can I take that to mean it was not totally flooded?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",23], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The coast was largely flooded.</i><br>Mary: <i>Can I take that to mean it might have been totally flooded?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",23], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The coast was largely flooded.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",24], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The princess likes dancing.</i><br>Mary: <i>Can I take that to mean she doesn't love dancing?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eimplicature",24], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The princess likes dancing.</i><br>Mary: <i>Can I take that to mean she might love dancing?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",24], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The princess likes dancing.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",25], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Bill's score matches Al's.</i><br>Mary: <i>Can I take that to mean it doesn't exceed Al's?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",25], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Bill's score matches Al's.</i><br>Mary: <i>Can I take that to mean it might exceed Al's?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",25], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Bill's score matches Al's.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",26], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Peter's answers were mostly wrong.</i><br>Mary: <i>Can I take that to mean they were not entirely wrong?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",26], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Peter's answers were mostly wrong.</i><br>Mary: <i>Can I take that to mean they might have been entirely wrong?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",26], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Peter's answers were mostly wrong.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",27], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The house is old.</i><br>Mary: <i>Can I take that to mean it is not ancient?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",27], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The house is old.</i><br>Mary: <i>Can I take that to mean it might be ancient?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",27], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The house is old.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",28], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Mistakes happened once.</i><br>Mary: <i>Can I take that to mean they didn't happen twice?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",28], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Mistakes happened once.</i><br>Mary: <i>Can I take that to mean they might have happened twice?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",28], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Mistakes happened once.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",29], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Jimmy writes books or plays.</i><br>Mary: <i>Can I take that to mean he doesn't wrote books and plays?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",29], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Jimmy writes books or plays.</i><br>Mary: <i>Can I take that to mean he might write books and plays?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",29], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Jimmy writes books or plays.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",30], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teenager is overweight.</i><br>Mary: <i>Can I take that to mean he is not obese?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",30], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teenager is overweight.</i><br>Mary: <i>Can I take that to mean he might be obese?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",30], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teenager is overweight.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>Can I take that to mean it was not supported unanimously?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>Can I take that to mean it might have been supported unanimously?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br>Mary: <i>Can I take that to mean it is not delicious?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br>Mary: <i>Can I take that to mean it might be delicious?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br>Mary: <i>Can I take that to mean it is not completely fully?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br>Mary: <i>Can I take that to mean it might be completely full?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br>Mary: <i>Can I take that to mean it doesn't require dancing?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br>Mary: <i>Can I take that to mean it might require dancing?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>Can I take that to mean it wasn't impeccable?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>Can I take that to mean it might have been impeccable?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br>Mary: <i>Can I take that to mean it isn't certain?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br>Mary: <i>Can I take that to mean it might be certain?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br>Mary: <i>Can I take that to mean she's not beautiful?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br>Mary: <i>Can I take that to mean she might be beautiful?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>Can I take that to mean they're not exclusively Greek?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>Can I take that to mean they might be exclusively Greek?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br>Mary: <i>Can I take that to mean a delay won't necessarily ocucr?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br>Mary: <i>Can I take that to mean it might be the case that a delay will necessarily occur?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br>Mary: <i>Can I take that to mean it didn't eliminate waste?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eimplicature",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br>Mary: <i>Can I take that to mean it might have eliminated waste?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>Can I take that to mean she was not petrified?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>Can I take that to mean she might have been petrified?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>Can I take that to mean it wasn't life-threatening?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>Can I take that to mean it might have been life-threatening?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br>Mary: <i>Can I take that to mean they are not identical?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eimplicature",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br>Mary: <i>Can I take that to mean they might be identical?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br>Mary: <i>Can I take that to mean it didn't stop?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br>Mary: <i>Can I take that to mean it might have stopped?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br>Mary: <i>Can I take that to mean it is not tiny?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br>Mary: <i>Can I take that to mean it might be tiny?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br>Mary: <i>Can I take that to mean it is not tight?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eimplicature",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br>Mary: <i>Can I take that to mean it might be tight?</i><br>Sue: <i>Yes, that's right.</i></p>"}],
// [["Eneutral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br>Mary: <i>Oh, I see.</i></p>"}],

//  [["Eliteral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>Can I take that to mean she doesn't trust all politicians?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>Can I take that to mean she might trust all politicians?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br>Mary: <i>Can I take that to mean he didn't finish?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br>Mary: <i>Can I take that to mean he might have finished?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br>Mary: <i>Can I take that to mean it didn't thrive?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br>Mary: <i>Can I take that to mean it might have thrived?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br>Mary: <i>Can I take that to mean she's not exhausted?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br>Mary: <i>Can I take that to mean she might be exhausted?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>Can I take that to mean they don't encourage dating?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>Can I take that to mean they might encourage dating?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br>Mary: <i>Can I take that to mean she didn't succeed?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br>Mary: <i>Can I take that to mean she might have succeeded?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>Can I take that to mean it is not hideous?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>Can I take that to mean it might be hideous?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>Can I take that to mean it was not articulate?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>Can I take that to mean it might have been articulate?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>Can I take that to mean it was not disgusting?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>Can I take that to mean it might have been disgusting?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>Can I take that to mean she's not always early?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>Can I take that to mean she might always be early?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>Can I take that to mean she doesn't need a car?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eimplicature",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>Can I take that to mean she might need a car?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
// [["Eneutral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br>Mary: <i>Can I take that to mean it is not hot?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br>Mary: <i>Can I take that to mean it might be hot?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br>Mary: <i>Can I take that to mean it didn't go superbly?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br>Mary: <i>Can I take that to mean it might have gone superbly?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br>Mary: <i>Can I take that to mean he is not eager?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eimplicature",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br>Mary: <i>Can I take that to mean he might be eager?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
// [["Eneutral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

["filler1", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The table is clean.</i><br>Mary: <i>Can I take that to mean it is not dirty?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
["filler2", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The man is drunk.</i><br>Mary: <i>Can I take that to mean the he is not sober?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
["filler3", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The neighbor is sleepy.</i><br>Mary: <i>Can I take that to mean she is not alert?</i><br>Sue: <i>Yes, that's right.</i></p>"}],  
["filler4", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The gymnast is tall.</i><br>Mary: <i>Can I take that to mean he is not short?</i><br>Sue: <i>Yes, that's right.</i></p>"}], 
["filler5", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The street is wide.</i><br>Mary: <i>Can I take that to mean it is not narrow?</i><br>Sue: <i>Yes, that's right.</i></p>"}]// NOTE NO COMMA


    
    ];