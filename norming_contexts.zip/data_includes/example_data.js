var shuffleSequence = seq("Intro0", "setcounter", "Intro", "practice", "check1", "xep", rshuffle(startsWith("norm"), startsWith("f")), "Exit");
var practiceItemTypes = ["practice"];


var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Click boxes to answer.",
        leftComment: "(Highly Unlikely)", rightComment: "(Highly Likely)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

  ["Intro0", "Form", {consentRequired: true, html: {include: "intro1_norm.html" }} ],  

//["setcounter", "__SetCounter__", { }],
["Intro", "Form", {consentRequired: true, html: {include: "intro_norm.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "intro2_norm.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "intro4_norm.html" }} ],  
["check1", "Form", {consentRequired: true, html: {include: "intro3_norm.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],


 ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Mike told Stacey that he felt like going out for dinner that night. Stacey replied that she had had a big lunch that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Stacey will go out to dinner with Mike?"}}],                          
  
  ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Not today, thanks'', it means that you think it is unlikely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."], 
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Sure, but let's get something light like a salad'', it means that you think it is likely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                           ["p", "If on the other hand you were not sure how Myke should have interpreted Stacey's answer, you should have clicked on button 4."],
   
                           ["p", "Press any key to move on to the next example."]
                           ]}],                      
                          
 
   ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Cecilia asked his boss if she could get a raise. Her boss replied that the company had just acquired expensive new equipment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Cecilia's boss will give her a raise?"}}],                          
    
                          
    ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sorry, we just spent a lot of money and we cannot afford to give you a raise right now'', it means that you think it's very unlikely that she will receive a raise. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."],
                            
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sure, we now have a lot of money to invest in the company'', it means that you think it's very likely that she will receive a raise. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                            
                           ["p", "If on the other hand you were not sure how Cecilia should have interpreted her boss' answer, you should have clicked on button 4."],
                           ["p", "Press any key to move on to the next example."]
                           ]}],                                          
  

   ["xep", Separator, {transfer: 2000, normalMessage: "Now you are ready to begin!" }],
    
     
[["norm_a",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing. The farmer replied that he was selling 50 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 50 gallons of milk, no more and no fewer?"}}], 

[["norm_b",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing. The farmer replied that he was selling 500 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 500 gallons of milk, no more and no fewer?"}}],
    
[["norm_c",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing. The farmer replied that he was selling 5,000 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 5,000 gallons of milk, no more and no fewer?"}}],
    
[["norm_d",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm’s sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing. The farmer replied that he was selling 50 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 50 gallons of milk, no more and no fewer?"}}],
    
[["norm_e",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm’s sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing. The farmer replied that he was selling 500 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 500 gallons of milk, no more and no fewer?"}}],
    
[["norm_f",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm’s sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing. The farmer replied that he was selling 5,000 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 5,000 gallons of milk, no more and no fewer?"}}],

[["norm_a",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay. The IRS representative said that Erika owed 400 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 400 dollars, not more and not fewer?"}}],
    
[["norm_b",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay. The IRS representative said that Erika owed 4,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 4,000 dollars, not more and not fewer?"}}], 
    
[["norm_c",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay. The IRS representative said that Erika owed 40,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 40,000 dollars, not more and not fewer?"}}], 
    
[["norm_d",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay. The IRS representative said that Erika owed 400 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 400 dollars, not more and not fewer?"}}], 
    
[["norm_e",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay. The IRS representative said that Erika owed 4,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 4,000 dollars, not more and not fewer?"}}], 
    
[["norm_f",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay. The IRS representative said that Erika owed 40,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 40,000 dollars, not more and not fewer?"}}],  
    
[["norm_a",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received. His chief researcher told him that 900 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 900 people had participated, not more and not fewer?"}}],
    
[["norm_b",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received. His chief researcher told him that 9,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 9,000 people had participated, not more and not fewer?"}}],
  
[["norm_c",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received. His chief researcher told him that 90,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 90,000 people had participated, not more and not fewer?"}}],
 
[["norm_d",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received. His chief researcher told him that 900 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 900 people had participated, not more and not fewer?"}}],

[["norm_e",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received. His chief researcher told him that 9,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 9,000 people had participated, not more and not fewer?"}}],
 
[["norm_f",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received. His chief researcher told him that 90,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 90,000 people had participated, not more and not fewer?"}}],
 
[["norm_a",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water. The engineer said that 900 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 900 gallons had been spilled, not more and not fewer?"}}],
    
[["norm_b",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water. The engineer said that 9,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 9,000 gallons had been spilled, not more and not fewer?"}}],                                  
    
[["norm_c",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water. The engineer said that 90,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 90,000 gallons had been spilled, not more and not fewer?"}}],                               
    
[["norm_d",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water. The engineer said that 900 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 900 gallons had been spilled, not more and not fewer?"}}],                                    
    
[["norm_e",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water. The engineer said that 9,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 9,000 gallons had been spilled, not more and not fewer?"}}],                                    
    
[["norm_f",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water. The engineer said that 90,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 90,000 gallons had been spilled, not more and not fewer?"}}],

[["norm_a",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy, a zoologist, was preparing to head down to the Galapagos Islands to do research on the local flamingo population. She was planning to attach a GPS tracker to each flamingo in the reserve in order to keep track of the colony’s migration patterns around the islands. Sandy told the on-site veterinarian that she had already spent a lot of her grant money on other supplies and she didn't want to order too many trackers, so she asked the veterinarian how many flamingoes lived there. The veterinarian told her that they had 100 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 100 flamingos, no more and no less?"}}],
    
[["norm_b",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy, a zoologist, was preparing to head down to the Galapagos Islands to do research on the local flamingo population. She was planning to attach a GPS tracker to each flamingo in the reserve in order to keep track of the colony’s migration patterns around the islands. Sandy told the on-site veterinarian that she had already spent a lot of her grant money on other supplies and she didn't want to order too many trackers, so she asked the veterinarian how many flamingoes lived there. The veterinarian told her that they had 1,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 1,000 flamingos, no more and no less?"}}],
    
[["norm_c",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy, a zoologist, was preparing to head down to the Galapagos Islands to do research on the local flamingo population. She was planning to attach a GPS tracker to each flamingo in the reserve in order to keep track of the colony’s migration patterns around the islands. Sandy told the on-site veterinarian that she had already spent a lot of her grant money on other supplies and she didn't want to order too many trackers, so she asked the veterinarian how many flamingoes lived there. The veterinarian told her that they had 10,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 10,000 flamingos, no more and no less?"}}],
    
[["norm_d",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy was on a trip to the Galapagos Islands with her 6th grade class and was touring the local wildlife reserve with her students. Some of her students saw a flock of flamingoes being fed by the on-site veterinarian. Sandy was a little bit embarrassed when Mandy, one of her students, yelled out to the on-site veterinarian to ask him how many flamingoes lived there. The veterinarian told her that they had 100 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 100 flamingos, no more and no less?"}}],
        
[["norm_e",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy was on a trip to the Galapagos Islands with her 6th grade class and was touring the local wildlife reserve with her students. Some of her students saw a flock of flamingoes being fed by the on-site veterinarian. Sandy was a little bit embarrassed when Mandy, one of her students, yelled out to the on-site veterinarian to ask him how many flamingoes lived there. The veterinarian told her that they had 1,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 1,000 flamingos, no more and no less?"}}],
        
[["norm_f",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Sandy was on a trip to the Galapagos Islands with her 6th grade class and was touring the local wildlife reserve with her students. Some of her students saw a flock of flamingoes being fed by the on-site veterinarian. Sandy was a little bit embarrassed when Mandy, one of her students, yelled out to the on-site veterinarian to ask him how many flamingoes lived there. The veterinarian told her that they had 10,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 10,000 flamingos, no more and no less?"}}],
    
[["norm_a",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was working with very limited supplies this month after an unexpected large order. He wanted to make sure they would have enough black ink for the journal they printed every month, so he called the journal editor to tell him about his concerns and to ask him to confirm the amount of copies he wanted him to print. The editor told him that they needed 700 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 700 copies, no more and no less?"}}],
    
[["norm_b",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was working with very limited supplies this month after an unexpected large order. He wanted to make sure they would have enough black ink for the journal they printed every month, so he called the journal editor to tell him about his concerns and to ask him to confirm the amount of copies he wanted him to print. The editor told him that they needed 7,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 7,000 copies, no more and no less?"}}],
    
[["norm_c",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was working with very limited supplies this month after an unexpected large order. He wanted to make sure they would have enough black ink for the journal they printed every month, so he called the journal editor to tell him about his concerns and to ask him to confirm the amount of copies he wanted him to print. The editor told him that they needed 70,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 70,000 copies, no more and no less?"}}],
                     
[["norm_d",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was chatting with one of the editors of a journal they printed once a month. The editor had hinted that readership was down, so the printer wondered whether the editor was considering downsizing, so he asked the editor ideally how many copies he’d like him to print. The editor told him that they needed 700 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 700 copies, no more and no less?"}}],
                     
[["norm_e",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was chatting with one of the editors of a journal they printed once a month. The editor had hinted that readership was down, so the printer wondered whether the editor was considering downsizing, so he asked the editor ideally how many copies he’d like him to print. The editor told him that they needed 7,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 7,000 copies, no more and no less?"}}],
                     
[["norm_f",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer was chatting with one of the editors of a journal they printed once a month. The editor had hinted that readership was down, so the printer wondered whether the editor was considering downsizing, so he asked the editor ideally how many copies he’d like him to print. The editor told him that they needed 70,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 70,000 copies, no more and no less?"}}],

[["norm_a",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", " A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email. The secretary replied that 50 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 50 students had gotten the message, no more and no less? "}}],
     
[["norm_b",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", " A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email. The secretary replied that 500 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 500 students had gotten the message, no more and no less? "}}],
                         
[["norm_c",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", " A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email. The secretary replied that 5,000 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 5,000 students had gotten the message, no more and no less? "}}],
    
[["norm_d",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email. The secretary replied that 50 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 50 students had gotten the message, no more and no less? "}}],
     
[["norm_e",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email. The secretary replied that 500 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 500 students had gotten the message, no more and no less? "}}],
                         
[["norm_f",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email. The secretary replied that 5,000 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 5,000 students had gotten the message, no more and no less? "}}],
    
[["norm_a",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest’s website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten. Pamela replied that her video had 40 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
    
[["norm_b",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest’s website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten. Pamela replied that her video had 400 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 400 views, no more and no less?"}}],
                                 
[["norm_c",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest’s website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten. Pamela replied that her video had 4,000 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 4,000 views, no more and no less?"}}],
    
[["norm_d",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten. Pamela replied that her video had 40 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
    
[["norm_e",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten. Pamela replied that her video had 400 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 400 views, no more and no less?"}}],
                                 
[["norm_f",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten. Pamela replied that her video had 4,000 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 4,000 views, no more and no less?"}}],    
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
[["f_1",28], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was. The map showed that the nearest lodge was still several miles away."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the lodge is more than 10 miles away?"}}],                          
 
 [["f_1",29], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While marathoning her favorite TV show, Avatar, Jhanelle checked the list to see exactly how many episodes were left. The list showed that she still had a few episodes left."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there are less than 5 episodes left?"}}],                          
    
 [["f_1",30], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the disappointing loss, Akash asked the basketball coach approximately how many turnovers he had committed. The coach said Akash had committed far too many turnovers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Akash committed more turnovers than anyone else on the team?"}}],                          
    
 [["f_1", 31], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Iz tested herself to see exactly how many airplane noises she could identify. She found that she could identify every airplane noise."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were a lot of airplanes in the air that day?"}}],                          
    
 [["f_1", 32], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The spectators were amazed by David's skill and asked him approximately how many knives he could juggle at once. David answered that he could juggle quite a few knives at one time."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that David exaggerated when he told the crowd the number of knives he could juggle to impress them?"}}],                          
    
 [["f_1", 33], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Isabella was collecting flight statistics and asked the air traffic controller exactly how many planes would be flying through O'Hare that day. The air traffic controller replied that the airports would see an average number of flights that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that exactly 2,500 airplanes will fly through O'Hare, no more and no less? "}}],                          
    
 [["f_1", 34], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Bardia was bored and decided to count exactly how many tiles were on the floor of the lecture hall. He found that there were more tiles than he cared to count."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were over 100 tiles on the floor of the lecture hall?"}}],                          
    
 [["f_1", 35], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Kevin wanted to know exactly how many successful coups d'état there had been in American history. He learned that there had been none."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Kevin thought that there was at least one coups d'état before he checked?"}}],                          
    
 [["f_1", 36], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Pat went out knocking on doors while campaigning for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day. Pat answered that he had knocked on an enormous number of doors."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pat knocked on exactly 50 doors, no more and no less?"}}],                          
    
 [["f_1", 37], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Brian decided that he would count approximately how many spoons there were in the South Campus dining hall. He counted many, many spoons."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were over 100 spoons in the dining hall?"}}],                          
    
 [["f_1", 38], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Nancy, a salesperson, had to count up exactly how many pieces of cereal were in each box. Not surprisingly, she found that each box contained a lot of pieces of cereal."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that each box contained the exact same amount of pieces?"}}],                          
    
 [["f_2", 39], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Dylan asked his boss how many people definitely would show up to the meeting. His boss said that exactly 20 people would come."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Dylan was expecting exactly 20 people to come to the meeting when he asked his boss, no more and no less?"}}],                          
    
 [["f_2", 40], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Gerri asked the Goldman-Sachs executive nervously how many other candidates there were for the position. He told her that approximately 50 other candidates were being interviewed."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Gerri was expecting exactly 50 other people were being interviewed for the position, no more and no less? "}}],                          
    
 [["f_2", 41], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "A perplexed Jay wondered constantly how many of his classmates had failed the economics midterm. It turned out that exactly 20 of Jay's classmates had failed the exam."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jay expected more than 20 people to fail the exam?"}}],                          
    
 [["f_2", 42], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Nora wondered exasperatedly how many hours she would have to spend dancing that weekend. According to her schedule, she would dance for approximately 20 hours."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Nora was expecting to work more than 20 hours that weekend?"}}],                          
    
 [["f_2", 43], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "During the theology exam, Ryan racked his brain, asking himself frustratedly how many commandments there were. He then recalled that there were exactly 10 commandments."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Ryan recalled what those 10 commandments were?"}}],                          
    
 [["f_2", 44], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Curious acquaintances often wondered fervently how many languages Nina spoke. She revealed one day that she spoke exactly 10 languages."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Nina's acquaintances were surprised when she told them she spoke 10 languages? "}}],                          
    
 [["f_2", 45], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "On her visit to the alpaca farm, Shannon asked excitedly how many alpacas there were. She was informed that there were approximately 40 alpacas."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farm contained exactly 40 alpacas, no more and no less?"}}],                          
    
 [["f_2", 46], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating. She found that the average student procrastinates for approximately 20 hours per week."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Angela expected the average student to procrastinate more than 20 hours per week?"}}],                          
    
 [["f_2", 47], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Elaina was lost and asked a pedestrian desperately how many blocks away the University of Chicago's campus was. The pedestrian said that the campus was approximately 10 blocks away."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Elania expected campus to be more than 10 blocks away?"}}],                          
    
 [["f_2", 48], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the accident, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop. The agent told him that it would cost exactly 500 dollars."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Zach expected the repairs to cost exactly 500 dollars, no more and no less?"}}],                          
    
 [["f_2", 49], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "William was interested in famous train heists and looked up curiously how many dollars Jesse James had stolen in his robbery. He learned that approximately 3,000 dollars had been taken."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that William expected the total amount of money taken by Jesse James to be around 3,000 dollars?"}}],                          
    
 [["f_3", 50], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "James and Karnika asked the organizer how many people certainly would come to their wedding. The organizer replied that a large handful of people would come."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that James and Karnika expected more people to come than what the organizer told them?"}}],                          
    
 [["f_3", 51], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Claire pondered carefully how many new strings she needed for her violin. She determined she needed several new strings."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Claire initially expected her violin to need more than 2 strings replaced?"}}],                          
    
 [["f_3", 52], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Remy asked his friends persistently how many of them would be participating in the scavenger hunt in the spring. He learned that few of his friends would participate."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that exactly 5 of Remy's friends would participate, no more and no less?"}}],                          
    
 [["f_3", 53], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday. They said they would be willing to make calls for a few hours."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rebecca's friends volunteered in the phone bank on Friday for over 3 hours?"}}],                          
    
 [["f_3", 54], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "In the course of preparing for move-in, Louis asked the housing officials curiously how many new residents there would be that year. The officials told him there would be many new residents."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were at least over 10 new residents that year?"}}],                          
    
 [["f_3", 55], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Before leaving on her vacation, Julie asked her friends how many gallons of gas probably would be needed to get her to Pasadena. They told her that only a few gallons would be necessary."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie needed exactly 3 gallons of gas to get to Pasadena, no more and no less?"}}],                          
    
 [["f_3", 56], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Caleb went to the doughnut shop and asked the salesperson hungrily how many doughnuts there were left. The salesperson answered that there was a donut shortage and that they had only a few doughnuts left."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Caleb bought the rest of the doughnuts in the shop?"}}],                          
    
 [["f_3",57], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erin, an avid reader, wondered intently how many words were in the book 'War and Peace.' She quickly discovered that it contained more words than she could count."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Erin counted over 100 words before she stopped counting?"}}],                          
    
 [["f_3", 58], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ulysses was in a bad mood and demanded to know immediately how many minutes his pizza would need to cook. The waiter responded that the food would be ready in a few minutes."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the pizza came in exactly 5 minutes, no more and no less?"}}],                          
    
 [["f_3", 59], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Elaine asked her classmates nosily how many siblings they each had. She was informed that most of them had a few siblings."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the average student in Elaine's class had approximately 3 siblings?"}}],                          
    
 [["f_3", 60], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When a notification of delay came in, Frederick asked the gate attendant despondently how many hours his flight to Columbus would be delayed. The attendant reassured him that the delay was only a few minutes."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the plane came in less than an hour late?"}}]                          
       
];