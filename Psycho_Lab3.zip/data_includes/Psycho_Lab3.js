var shuffleSequence = seq("setcounter", "Demog", "instr", rshuffle(startsWith("item")));

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: " ",
        randomOrder: false,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "DashedSentence", {
    hideUnderscores: true
    },
    "Question", {
    hasCorrect: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [


["setcounter", "__SetCounter__", { }],

    
["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
["instr", "Form", {consentRequired: true, html: {include: "instr.html" }} ],








[["itemA1amb", 1], "DashedSentence", {s:
"When the tiger appeared the lion roared very loudly."
},"Question", {q:
"Did the tiger roar?"
, as: ["Yes","No"],
hasCorrect: 1}],


[["itemA2amb",2], "DashedSentence", {s:
"Although the bear disappeared the deer leapt away quickly."
},"Question", {q:
"Did the deer leap away?"
, as: ["Yes","No"],
hasCorrect: 0}],


[["itemA3amb", 3],
"DashedSentence", {s:
"While the students listened the teacher sang them a song."
},"Question", {q:
"Did the students sing?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA4amb", 4],
"DashedSentence", {s:
"When the boy sneezed the girl walked to the door."
},"Question", {q:
"Did the boy sneeze?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA5amb", 5],
"DashedSentence", {s:
"After the man came the woman had some pie."
},"Question", {q:
"Did the man have pie?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA6amb", 6],
"DashedSentence", {s:
"After the man talked the woman told a story."
},"Question", {q:
"Did the woman tell a story?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA7amb", 7],
"DashedSentence", {s:
"When the girl screamed the boy ran away from the dog."
},"Question", {q:
"Did the boy scream?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA8amb", 8],
"DashedSentence", {s:
"While the girl skipped the dog chased a cat."
},"Question", {q:
"Did the girl skip?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA9amb", 9],
"DashedSentence", {s:
"As the boy hopped the girl played with a ball."
},"Question", {q:
"Did the girl hop?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA10amb", 10],
"DashedSentence", {s:
"As the horse leapt the cow ate some grass."
},"Question", {q:
"Did the cow leap?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA11amb", 11],
"DashedSentence", {s:
"When the woman fell the policeman stoppped and helped her up."
},"Question", {q:
"Did the woman fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA12amb", 12],
"DashedSentence", {s:
"While the girl danced her mother took some pictures."
},"Question", {q:
"Did the mother dance?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA13amb", 13],
"DashedSentence", {s:
"When the baby smiled the nurse clapped her hands."
},"Question", {q:
"Did the nurse clap?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA14una", 14],
"DashedSentence", {s:
"After the doctor laughed, the woman jumped to her feet."
},"Question", {q:
"Did the woman laugh?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA15una", 15],
"DashedSentence", {s:
"Before the girl coughed, the doctor read his notes."
},"Question", {q:
"Did the girl cough?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA16una", 16],
"DashedSentence", {s:
"Because the girl sobbed, the man gave her some ice cream."
},"Question", {q:
"Did the man sob?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA17una", 17],
"DashedSentence", {s:
"While the cat purred, the dog sat near the fireplace."
},"Question", {q:
"Did the dog sit?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA18una", 18],
"DashedSentence", {s:
"While the dog slept, the cat drank some milk."
},"Question", {q:
"Did the cat sleep?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA19una", 19],
"DashedSentence", {s:
"Because the man snored, the woman plugged her ears."
},"Question", {q:
"Did the man snore?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA20una", 20],
"DashedSentence", {s:
"As the dog growled, the owner talked on the telephone."
},"Question", {q:
"Did the owner growl?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA21una", 21],
"DashedSentence", {s:
"While the girl prayed, the woman prepared to go to bed."
},"Question", {q:
"Did the girl pray?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA22una", 22],
"DashedSentence", {s:
"When the customer complained, the salesman called the boss."
},"Question", {q:
"Did the salesman complain?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA23una", 23],
"DashedSentence", {s:
"While the balloon rose, the child shouted and ran."
},"Question", {q:
"Did the child shout?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA24una", 24],
"DashedSentence", {s:
"While the girl giggled, the man watched a movie."
},"Question", {q:
"Did the man giggle?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA25una", 25],
"DashedSentence", {s:
"As the crowd clapped, the actor bowed and smiled."
},"Question", {q:
"Did the crowd clap?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA26una", 26],
"DashedSentence", {s:
"While the dancer bowed, the crowd shouted and clapped."
},"Question", {q:
"Did the dancer clap?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB1amb", 27],
"DashedSentence", {s:
"While the boy drank the girl ate some ham."
},"Question", {q:
"Did the boy drink?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB2amb", 28],
"DashedSentence", {s:
"While the girl ate the boy had some milk."
},"Question", {q:
"Did the girl have milk?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB3amb", 29],
"DashedSentence", {s:
"While the man sang the drummer banged on a bass drum."
},"Question", {q:
"Did the drummer sing?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB4amb", 30],
"DashedSentence", {s:
"As the fireman hummed the truck came into the station."
},"Question", {q:
"Did the fireman hum?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB5amb", 31],
"DashedSentence", {s:
"As the woman cleaned the doctor walked into the room."
},"Question", {q:
"Did the doctor clean?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB6amb", 32],
"DashedSentence", {s:
"As the child climbed the woman pushed the stroller."
},"Question", {q:
"Did the child climb?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB7amb", 33],
"DashedSentence", {s:
"Before the plane landed the pilot saw a jet."
},"Question", {q:
"Did the pilot see a jet?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB8amb", 34],
"DashedSentence", {s:
"While the girl ran the teacher helped the boy."
},"Question", {q:
"Did the teacher help the girl?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB9amb", 35],
"DashedSentence", {s:
"While the captain sailed the truck crossed over the bridge."
},"Question", {q:
"Did the captain cross the bridge?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB10amb", 36],
"DashedSentence", {s:
"When the woman tripped the table fell and the vase broke."
},"Question", {q:
"Did the woman trip?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB11amb", 37],
"DashedSentence", {s:
"As the man walked the workers painted the house."
},"Question", {q:
"Did the man paint?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB12amb", 38],
"DashedSentence", {s:
"When the girl called the phone rang six times."
},"Question", {q:
"Did the phone ring?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB13amb", 39],
"DashedSentence", {s:
"When the boy raced the street was full of people."
},"Question", {q:
"Was the street deserted?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB14una", 40],
"DashedSentence", {s:
"While the boy fought, the newspaper landed on the porch."
},"Question", {q:
"Did the boy fight?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB15una", 41],
"DashedSentence", {s:
"As the player hit, the crowd made loud noises."
},"Question", {q:
"Was the crowd quiet?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB16una", 42],
"DashedSentence", {s:
"While the man parked, the horn sounded and scared the dog."
},"Question", {q:
"Did the man park?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB17una", 43],
"DashedSentence", {s:
"When the boy played, the dog found a bone in the garden."
},"Question", {q:
"Did the dog play?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB18una", 44],
"DashedSentence", {s:
"While the chef baked, the stove was very hot."
},"Question", {q:
"Was the stove hot?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB19una", 45],
"DashedSentence", {s:
"As the woman drove, the brush fell out of her purse."
},"Question", {q:
"Did the woman fall?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB20una", 46],
"DashedSentence", {s:
"As the man dealt, the hamburger sat on the tray."
},"Question", {q:
"Did the man eat the hamburger?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB21una", 47],
"DashedSentence", {s:
"As the girl dressed, the mirror fell onto the floor."
},"Question", {q:
"Did the mirror fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB22una", 48],
"DashedSentence", {s:
"While the boy hid, the air chilled a little bit."
},"Question", {q:
"Did the boy hide?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB23una", 49],
"DashedSentence", {s:
"When the child asked, the dog got the bone."
},"Question", {q:
"Did the child find the bone?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB24una", 50],
"DashedSentence", {s:
"While the fisherman cast, the boat floated down the river."
},"Question", {q:
"Was the boat floating?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB25una", 51],
"DashedSentence", {s:
"As the woman spun, the fire died down and dimmed."
},"Question", {q:
"Was the fire raging?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB26una", 52],
"DashedSentence", {s:
"While the children read, the cook made some lunch."
},"Question", {q:
"Did the children cook?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC1amb", 53],
"DashedSentence", {s:
"While the boy drank the milk got warm and spoiled."
},"Question", {q:
"Was the milk cold?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC2amb", 54],
"DashedSentence", {s:
"While the girl ate the ice cream melted and started running."
},"Question", {q:
"Did the ice cream melt?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC3amb", 55],
"DashedSentence", {s:
"While the man sang the song played on the radio."
},"Question", {q:
"Did the man sing?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC4amb", 56],
"DashedSentence", {s:
"As the fireman hummed the tune played near the station."
},"Question", {q:
"Did the tune play?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC5amb", 57],
"DashedSentence", {s:
"As the woman cleaned the stove began to heat up."
},"Question", {q:
"Was the stove cool?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC6amb", 58],
"DashedSentence", {s:
"As the child climbed the ladder fell with a crash."
},"Question", {q:
"Did the ladder fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC7amb", 59],
"DashedSentence", {s:
"Before the pilot landed the plane flew through a cloud."
},"Question", {q:
"Did the plane fly?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC8amb", 60],
"DashedSentence", {s:
"While the girl ran the race played on television."
},"Question", {q:
"Did the girl listen to the race on the radio?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC9amb", 61],
"DashedSentence", {s:
"When the captain sailed the ship passed by the bridge."
},"Question", {q:
"Was the captain flying?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC10amb", 62],
"DashedSentence", {s:
"When the woman tripped the girl fell down and broke a vase."
},"Question", {q:
"Did the vase break?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC11amb", 63],
"DashedSentence", {s:
"As the man walked the dog barked and jumped."
},"Question", {q:
"Did the man jump?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC12amb", 64],
"DashedSentence", {s:
"When the girl called the dog came close and barked."
},"Question", {q:
"Did the dog bark?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC13amb", 65],
"DashedSentence", {s:
"When the boy raced the bike fell over and crashed."
},"Question", {q:
"Did the boy fall over?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC14una", 66],
"DashedSentence", {s:
"While the boy fought, the bully snuck off and hid."
},"Question", {q:
"Did the boy fight?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC15una", 67],
"DashedSentence", {s:
"As the player hit, the ball came back from the outfield."
},"Question", {q:
"Did the player run?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC16una", 68],
"DashedSentence", {s:
"While the man parked, the car bumped the green truck."
},"Question", {q:
"Was the truck red?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC17una", 69],
"DashedSentence", {s:
"When the boy played, the trumpet screeched and squeaked."
},"Question", {q:
"Did the boy screech?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC18una", 70],
"DashedSentence", {s:
"While the chef baked, the cookies cooled on the counter."
},"Question", {q:
"Were the cookies on the counter?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC19una", 71],
"DashedSentence", {s:
"As the man drove, the truck hit the fire hydrant."
},"Question", {q:
"Did the truck hit the hydrant?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC20una", 72],
"DashedSentence", {s:
"When the man dealt, the cards landed all over the place."
},"Question", {q:
"Did the man deal?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC21una", 73],
"DashedSentence", {s:
"As the girl dressed, the doll fell to the floor."
},"Question", {q:
"Did the girl fall?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC22una", 74],
"DashedSentence", {s:
"While the boy hid, the toy vanished for a while."
},"Question", {q:
"Did the boy hide?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC23una", 75],
"DashedSentence", {s:
"When the child asked, the teacher answered right away."
},"Question", {q:
"Did the teacher ask?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC24una", 76],
"DashedSentence", {s:
"While the fisherman cast, the net trailed in the water."
},"Question", {q:
"Did the net rip?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC25una", 77],
"DashedSentence", {s:
"As the woman spun, the yarn twisted and tangled."
},"Question", {q:
"Did the yarn tangle?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC26una", 78],
"DashedSentence", {s:
"While the children read, the books arrived from the library."
},"Question", {q:
"Did the books arrive?"
, as: ["Yes","No"],
hasCorrect: 0}],






















[["itemA1una", 1], "DashedSentence", {s:
"When the tiger appeared, the lion roared very loudly."
},"Question", {q:
"Did the tiger roar?"
, as: ["Yes","No"],
hasCorrect: 1}],


[["itemA2una",2], "DashedSentence", {s:
"Although the bear disappeared, the deer leapt away quickly."
},"Question", {q:
"Did the deer leap away?"
, as: ["Yes","No"],
hasCorrect: 0}],


[["itemA3una", 3],
"DashedSentence", {s:
"While the students listened, the teacher sang them a song."
},"Question", {q:
"Did the students sing?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA4una", 4],
"DashedSentence", {s:
"When the boy sneezed, the girl walked to the door."
},"Question", {q:
"Did the boy sneeze?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA5una", 5],
"DashedSentence", {s:
"After the man came, the woman had some pie."
},"Question", {q:
"Did the man have pie?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA6una", 6],
"DashedSentence", {s:
"After the man talked, the woman told a story."
},"Question", {q:
"Did the woman tell a story?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA7una", 7],
"DashedSentence", {s:
"When the girl screamed, the boy ran away from the dog."
},"Question", {q:
"Did the boy scream?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA8una", 8],
"DashedSentence", {s:
"While the girl skipped, the dog chased a cat."
},"Question", {q:
"Did the girl skip?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA9una", 9],
"DashedSentence", {s:
"As the boy hopped, the girl played with a ball."
},"Question", {q:
"Did the girl hop?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA10una", 10],
"DashedSentence", {s:
"As the horse leapt, the cow ate some grass."
},"Question", {q:
"Did the cow leap?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA11una", 11],
"DashedSentence", {s:
"When the woman fell, the policeman stoppped and helped her up."
},"Question", {q:
"Did the woman fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA12una", 12],
"DashedSentence", {s:
"While the girl danced, her mother took some pictures."
},"Question", {q:
"Did the mother dance?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA13una", 13],
"DashedSentence", {s:
"When the baby smiled, the nurse clapped her hands."
},"Question", {q:
"Did the nurse clap?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA14amb", 14],
"DashedSentence", {s:
"After the doctor laughed the woman jumped to her feet."
},"Question", {q:
"Did the woman laugh?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA15amb", 15],
"DashedSentence", {s:
"Before the girl coughed the doctor read his notes."
},"Question", {q:
"Did the girl cough?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA16amb", 16],
"DashedSentence", {s:
"Because the girl sobbed the man gave her some ice cream."
},"Question", {q:
"Did the man sob?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA17amb", 17],
"DashedSentence", {s:
"While the cat purred the dog sat near the fireplace."
},"Question", {q:
"Did the dog sit?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA18amb", 18],
"DashedSentence", {s:
"While the dog slept the cat drank some milk."
},"Question", {q:
"Did the cat sleep?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA19amb", 19],
"DashedSentence", {s:
"Because the man snored the woman plugged her ears."
},"Question", {q:
"Did the man snore?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA20amb", 20],
"DashedSentence", {s:
"As the dog growled the owner talked on the telephone."
},"Question", {q:
"Did the owner growl?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA21amb", 21],
"DashedSentence", {s:
"While the girl prayed the woman prepared to go to bed."
},"Question", {q:
"Did the girl pray?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA22amb", 22],
"DashedSentence", {s:
"When the customer complained the salesman called the boss."
},"Question", {q:
"Did the salesman complain?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA23amb", 23],
"DashedSentence", {s:
"While the balloon rose the child shouted and ran."
},"Question", {q:
"Did the child shout?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA24amb", 24],
"DashedSentence", {s:
"While the girl giggled the man watched a movie."
},"Question", {q:
"Did the man giggle?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemA25amb", 25],
"DashedSentence", {s:
"As the crowd clapped the actor bowed and smiled."
},"Question", {q:
"Did the crowd clap?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemA26amb", 26],
"DashedSentence", {s:
"While the dancer bowed the crowd shouted and clapped."
},"Question", {q:
"Did the dancer clap?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB1una", 27],
"DashedSentence", {s:
"While the boy drank, the girl ate some ham."
},"Question", {q:
"Did the boy drink?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB2una", 28],
"DashedSentence", {s:
"While the girl ate, the boy had some milk."
},"Question", {q:
"Did the girl have milk?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB3una", 29],
"DashedSentence", {s:
"While the man sang, the drummer banged on a bass drum."
},"Question", {q:
"Did the drummer sing?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB4una", 30],
"DashedSentence", {s:
"As the fireman hummed, the truck came into the station."
},"Question", {q:
"Did the fireman hum?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB5una", 31],
"DashedSentence", {s:
"As the woman cleaned, the doctor walked into the room."
},"Question", {q:
"Did the doctor clean?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB6una", 32],
"DashedSentence", {s:
"As the child climbed, the woman pushed the stroller."
},"Question", {q:
"Did the child climb?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB7una", 33],
"DashedSentence", {s:
"Before the plane landed, the pilot saw a jet."
},"Question", {q:
"Did the pilot see a jet?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB8una", 34],
"DashedSentence", {s:
"While the girl ran, the teacher helped the boy."
},"Question", {q:
"Did the teacher help the girl?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB9una", 35],
"DashedSentence", {s:
"While the captain sailed, the truck crossed over the bridge."
},"Question", {q:
"Did the captain cross the bridge?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB10una", 36],
"DashedSentence", {s:
"When the woman tripped, the table fell and the vase broke."
},"Question", {q:
"Did the woman trip?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB11una", 37],
"DashedSentence", {s:
"As the man walked, the workers painted the house."
},"Question", {q:
"Did the man paint?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB12una", 38],
"DashedSentence", {s:
"When the girl called, the phone rang six times."
},"Question", {q:
"Did the phone ring?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB13una", 39],
"DashedSentence", {s:
"When the boy raced, the street was full of people."
},"Question", {q:
"Was the street deserted?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB14amb", 40],
"DashedSentence", {s:
"While the boy fought the newspaper landed on the porch."
},"Question", {q:
"Did the boy fight?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB15amb", 41],
"DashedSentence", {s:
"As the player hit the crowd made loud noises."
},"Question", {q:
"Was the crowd quiet?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB16amb", 42],
"DashedSentence", {s:
"While the man parked the horn sounded and scared the dog."
},"Question", {q:
"Did the man park?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB17amb", 43],
"DashedSentence", {s:
"When the boy played the dog found a bone in the garden."
},"Question", {q:
"Did the dog play?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB18amb", 44],
"DashedSentence", {s:
"While the chef baked the stove was very hot."
},"Question", {q:
"Was the stove hot?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB19amb", 45],
"DashedSentence", {s:
"As the woman drove the brush fell out of her purse."
},"Question", {q:
"Did the woman fall?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB20amb", 46],
"DashedSentence", {s:
"As the man dealt the hamburger sat on the tray."
},"Question", {q:
"Did the man eat the hamburger?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB21amb", 47],
"DashedSentence", {s:
"As the girl dressed the mirror fell onto the floor."
},"Question", {q:
"Did the mirror fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB22amb", 48],
"DashedSentence", {s:
"While the boy hid the air chilled a little bit."
},"Question", {q:
"Did the boy hide?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB23amb", 49],
"DashedSentence", {s:
"When the child asked the dog got the bone."
},"Question", {q:
"Did the child find the bone?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB24amb", 50],
"DashedSentence", {s:
"While the fisherman cast the boat floated down the river."
},"Question", {q:
"Was the boat floating?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemB25amb", 51],
"DashedSentence", {s:
"As the woman spun the fire died down and dimmed."
},"Question", {q:
"Was the fire raging?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemB26amb", 52],
"DashedSentence", {s:
"While the children read the cook made some lunch."
},"Question", {q:
"Did the children cook?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC1una", 53],
"DashedSentence", {s:
"While the boy drank, the milk got warm and spoiled."
},"Question", {q:
"Was the milk cold?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC2una", 54],
"DashedSentence", {s:
"While the girl ate, the ice cream melted and started running."
},"Question", {q:
"Did the ice cream melt?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC3una", 55],
"DashedSentence", {s:
"While the man sang, the song played on the radio."
},"Question", {q:
"Did the man sing?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC4una", 56],
"DashedSentence", {s:
"As the fireman hummed, the tune played near the station."
},"Question", {q:
"Did the tune play?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC5una", 57],
"DashedSentence", {s:
"As the woman cleaned, the stove began to heat up."
},"Question", {q:
"Was the stove cool?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC6una", 58],
"DashedSentence", {s:
"As the child climbed, the ladder fell with a crash."
},"Question", {q:
"Did the ladder fall?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC7una", 59],
"DashedSentence", {s:
"Before the pilot landed, the plane flew through a cloud."
},"Question", {q:
"Did the plane fly?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC8una", 60],
"DashedSentence", {s:
"While the girl ran, the race played on television."
},"Question", {q:
"Did the girl listen to the race on the radio?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC9una", 61],
"DashedSentence", {s:
"When the captain sailed, the ship passed by the bridge."
},"Question", {q:
"Was the captain flying?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC10una", 62],
"DashedSentence", {s:
"When the woman tripped, the girl fell down and broke a vase."
},"Question", {q:
"Did the vase break?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC11una", 63],
"DashedSentence", {s:
"As the man walked, the dog barked and jumped."
},"Question", {q:
"Did the man jump?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC12una", 64],
"DashedSentence", {s:
"When the girl called, the dog came close and barked."
},"Question", {q:
"Did the dog bark?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC13una", 65],
"DashedSentence", {s:
"When the boy raced, the bike fell over and crashed."
},"Question", {q:
"Did the boy fall over?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC14amb", 66],
"DashedSentence", {s:
"While the boy fought the bully snuck off and hid."
},"Question", {q:
"Did the boy fight?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC15amb", 67],
"DashedSentence", {s:
"As the player hit the ball came back from the outfield."
},"Question", {q:
"Did the player run?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC16amb", 68],
"DashedSentence", {s:
"While the man parked the car bumped the green truck."
},"Question", {q:
"Was the truck red?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC17amb", 69],
"DashedSentence", {s:
"When the boy played the trumpet screeched and squeaked."
},"Question", {q:
"Did the boy screech?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC18amb", 70],
"DashedSentence", {s:
"While the chef baked the cookies cooled on the counter."
},"Question", {q:
"Were the cookies on the counter?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC19amb", 71],
"DashedSentence", {s:
"As the man drove the truck hit the fire hydrant."
},"Question", {q:
"Did the truck hit the hydrant?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC20amb", 72],
"DashedSentence", {s:
"When the man dealt the cards landed all over the place."
},"Question", {q:
"Did the man deal?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC21amb", 73],
"DashedSentence", {s:
"As the girl dressed the doll fell to the floor."
},"Question", {q:
"Did the girl fall?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC22amb", 74],
"DashedSentence", {s:
"While the boy hid the toy vanished for a while."
},"Question", {q:
"Did the boy hide?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC23amb", 75],
"DashedSentence", {s:
"When the child asked the teacher answered right away."
},"Question", {q:
"Did the teacher ask?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC24amb", 76],
"DashedSentence", {s:
"While the fisherman cast the net trailed in the water."
},"Question", {q:
"Did the net rip?"
, as: ["Yes","No"],
hasCorrect: 1}],

[["itemC25amb", 77],
"DashedSentence", {s:
"As the woman spun the yarn twisted and tangled."
},"Question", {q:
"Did the yarn tangle?"
, as: ["Yes","No"],
hasCorrect: 0}],

[["itemC26amb", 78],
"DashedSentence", {s:
"While the children read the books arrived from the library."
},"Question", {q:
"Did the books arrive?"
, as: ["Yes","No"],
hasCorrect: 0}]




/*comma*/


    
    




];