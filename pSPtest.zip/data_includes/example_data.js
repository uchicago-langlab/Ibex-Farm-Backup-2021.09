var shuffleSequence = seq("intro", "example_intro", "intro1", shuffle(
 randomize("G001")
,randomize("G002")
,randomize("G003")
,randomize("G004")
,randomize("G005")
,randomize("G006")
,randomize("G007")
,randomize("G008")
,randomize("G009")
,randomize("G010")
,randomize("G011")
,randomize("G012")
,randomize("G013")
,randomize("G014")
,randomize("G015")
,randomize("G016")
,randomize("G017")
,randomize("G018")
,randomize("G019")
,randomize("G020")
,randomize("G021")
,randomize("G022")
,randomize("G023")
,randomize("G024")
,randomize("G025")
,randomize("G026")
,randomize("G027")
,randomize("G028")
,randomize("G029")
,randomize("G030")
,randomize("G031")
,randomize("G032")
,randomize("G033")
,randomize("G034")
,randomize("G035")
,randomize("G036")
,randomize("G037")
,randomize("G038")
,randomize("G039")
,randomize("G040")
,randomize("G041")
,randomize("G042")
,randomize("G043")
,randomize("G044")
,randomize("G045")
,randomize("G046")
,randomize("G047")
,randomize("G048")
,randomize("G049")
,randomize("G050")
,randomize("G051")
,randomize("G052")
,randomize("G053")
,randomize("G054")
,randomize("G055")
,randomize("G056")
,randomize("G057")
,randomize("G058")
,randomize("G059")
,randomize("G060")
,randomize("G061")
,randomize("G062")
,randomize("G063")
,randomize("G064")
,randomize("G065")
,randomize("G066")
,randomize("G067")
,randomize("G068")
,randomize("G069")
,randomize("G070")
,randomize("G071")
,randomize("G072")
,randomize("G073")
,randomize("G074")
,randomize("G075")
,randomize("G076")
,randomize("G077")
,randomize("G078")
,randomize("G079")
,randomize("G080")
,randomize("G081")
,randomize("G082")
,randomize("G083")
,randomize("G084")
,randomize("G085")
,randomize("G086")
,randomize("G087")
,randomize("G088")
,randomize("G089")
,randomize("G090")
,randomize("G091")
,randomize("G092")
,randomize("G093")
,randomize("G094")
,randomize("G095")
,randomize("G096")
,randomize("G097")
,randomize("G098")
,randomize("G099")
,randomize("G100")
,randomize("G101")
,randomize("G102")
,randomize("G103")
,randomize("G104")
,randomize("G105")
,randomize("G106")
,randomize("G107")
,randomize("G108")
,randomize("G109")
,randomize("G110")
,randomize("G111")
,randomize("G112")
,randomize("G113")
,randomize("G114")
,randomize("G115")
,randomize("G116")
,randomize("G117")
,randomize("G118")
,randomize("G119")
,randomize("G120")
,randomize("G121")
,randomize("G122")
,randomize("G123")
,randomize("G124")
,randomize("G125")
,randomize("G126")
,randomize("G127")
,randomize("G128")
,randomize("G129")
,randomize("G130")
,randomize("G131")
,randomize("G132")
));

var defaults = ["Question", {as: ["1", "2", "3", "4", "5", "6", "7"], presentAsScale: true, leftComment: "Not related", rightComment: "Very Related"}]

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],

["intro", "Form", {

html: { include: "example_intro.html" },

validators: {

age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }

}

} ],

["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],

[["G001", 001], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball player mentioned the bat and the ball during the game.</td></tr>" }],
[["G001", 001], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cave explorer mentioned the bat on the ceiling and a few insects.</td></tr>" }],
[["G001", 001], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball player mentioned the bat on the ceiling and a few insects.</td></tr>" }],
[["G001", 001], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cave explorer mentioned the bat and the ball during the game.</td></tr>" }],

[["G002", 002], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer discussed the calf and the cow for the sale.</td></tr>" }],
[["G002", 002], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner discussed the calf of his leg in the stretches.</td></tr>" }],
[["G002", 002], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer discussed the calf of his leg in the stretches.</td></tr>" }],
[["G002", 002], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner discussed the calf and the cow for the sale.</td></tr>" }],

[["G003", 003], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction worker saw the crane and other machinery at the work site.</td></tr>" }],
[["G003", 003], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The birdwatcher saw the crane on the lake at the break of dawn.</td></tr>" }],
[["G003", 003], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction worker saw the crane on the lake at the break of dawn.</td></tr>" }],
[["G003", 003], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The birdwatcher saw the crane and other machinery at the work site.</td></tr>" }],

[["G004", 004], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The government official brought up the seal on the envelope of the official document.</td></tr>" }],
[["G004", 004], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surfer brought up the seal on the beach of his favorite surf spot.</td></tr>" }],
[["G004", 004], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The government official brought up the seal on the beach of his favorite surf spot.</td></tr>" }],
[["G004", 004], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surfer brought up the seal on the envelope of the official document.</td></tr>" }],

[["G005", 005], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jeweler considered the charm on the bracelet with silver and gold details.</td></tr>" }],
[["G005", 005], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The villager considered the charm and the appeal of the cottage.</td></tr>" }],
[["G005", 005], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jeweler considered the charm and the appeal of the cottage.</td></tr>" }],
[["G005", 005], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The villager considered the charm on the bracelet with silver and gold details.</td></tr>" }],

[["G006", 006], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The woodworker approached the board of solid maple for the construction of his house.</td></tr>" }],
[["G006", 006], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chairman approached the board and the committee members for help during the crisis.</td></tr>" }],
[["G006", 006], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The woodworker approached the board and the committee members for help during the crisis.</td></tr>" }],
[["G006", 006], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chairman approached the board of solid maple for the construction of his house.</td></tr>" }],

[["G007", 007], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The child talked about the block and other toys at the daycare.</td></tr>" }],
[["G007", 007], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The policeman talked about the block in the neighborhood and other places.</td></tr>" }],
[["G007", 007], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The child talked about the block in the neighborhood and other places.</td></tr>" }],
[["G007", 007], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The policeman talked about the block and other toys at the daycare.</td></tr>" }],

[["G008", 008], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman mentioned the degree of the temperaturein Farenheit on the television.</td></tr>" }],
[["G008", 008], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor mentioned the degree at the graduation ceremony of the new doctors.</td></tr>" }],
[["G008", 008], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman mentioned the degree at the graduation ceremony of the new doctors.</td></tr>" }],
[["G008", 008], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor mentioned the degree of the temperaturein Farenheit on the television.</td></tr>" }],

[["G009", 009], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction worker inquired about the foundation of the house and its stability.</td></tr>" }],
[["G009", 009], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The philanthropist inquired about the foundation and its outreach to the local community.</td></tr>" }],
[["G009", 009], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction worker inquired about the foundation and its outreach to the local community.</td></tr>" }],
[["G009", 009], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The philanthropist inquired about the foundation of the house and its stability.</td></tr>" }],

[["G010", 010], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jeweler pointed out the ring and its diamond to his clients.</td></tr>" }],
[["G010", 010], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fire chief pointed out the ring of the alarm during the fire drill.</td></tr>" }],
[["G010", 010], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jeweler pointed out the ring of the alarm during the fire drill.</td></tr>" }],
[["G010", 010], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fire chief pointed out the ring and its diamond to his clients.</td></tr>" }],

[["G011", 011], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The director called attention to the cast in the play of Romeo and Juliet.</td></tr>" }],
[["G011", 011], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The doctor called attention to the cast on the arm of the sad boy.</td></tr>" }],
[["G011", 011], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The director called attention to the cast on the arm of the sad boy.</td></tr>" }],
[["G011", 011], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The doctor called attention to the cast in the play of Romeo and Juliet.</td></tr>" }],

[["G012", 012], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mattress salesman discovered the spring in the mattress through the hole.</td></tr>" }],
[["G012", 012], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker discovered the spring of clean water in the middle of the forest.</td></tr>" }],
[["G012", 012], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mattress salesman discovered the spring of clean water in the middle of the forest.</td></tr>" }],
[["G012", 012], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker discovered the spring in the mattress through the hole.</td></tr>" }],

[["G013", 013], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military chief introduced the drill and other training to the new soldiers.</td></tr>" }],
[["G013", 013], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic introduced the drill in the toolbox to the other volunteers.</td></tr>" }],
[["G013", 013], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military chief introduced the drill in the toolbox to the other volunteers.</td></tr>" }],
[["G013", 013], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic introduced the drill and other training to the new soldiers.</td></tr>" }],

[["G014", 014], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The babysitter referred to the story with the dragon and princess to the sleepy children.</td></tr>" }],
[["G014", 014], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect referred to the story above the terrace of the building scheduled for demolition.</td></tr>" }],
[["G014", 014], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The babysitter referred to the story above the terrace of the building scheduled for demolition.</td></tr>" }],
[["G014", 014], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect referred to the story with the dragon and princess to the sleepy children.</td></tr>" }],

[["G015", 015], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The priest explained the mass at the church on Sunday.</td></tr>" }],
[["G015", 015], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The potter explained the mass of red clay at the potter's wheel.</td></tr>" }],
[["G015", 015], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The priest explained the mass of red clay at the potter's wheel.</td></tr>" }],
[["G015", 015], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The potter explained the mass at the church on Sunday.</td></tr>" }],

[["G016", 016], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tennis player talked about the match and his win against last year's champion.</td></tr>" }],
[["G016", 016], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candlemaker talked about the match and the fire in his workshop.</td></tr>" }],
[["G016", 016], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tennis player talked about the match and the fire in his workshop.</td></tr>" }],
[["G016", 016], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candlemaker talked about the match and his win against last year's champion.</td></tr>" }],

[["G017", 017], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball umpire evaluated the pitcher with sloppy throws to the baseball batter</td></tr>" }],
[["G017", 017], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The party hostess evaluated the pitcher of cold lemonade on the picnic table outside.</td></tr>" }],
[["G017", 017], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball umpire evaluated the pitcher of cold lemonade on the picnic table outside.</td></tr>" }],
[["G017", 017], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The party hostess evaluated the pitcher with sloppy throws to the baseball batter</td></tr>" }],

[["G018", 018], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The veterinarian noticed the tick on the dog in the clinic.</td></tr>" }],
[["G018", 018], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The politician noticed the tick on the ballet on the podium.</td></tr>" }],
[["G018", 018], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The veterinarian noticed the tick on the ballet on the podium.</td></tr>" }],
[["G018", 018], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The politician noticed the tick on the dog in the clinic.</td></tr>" }],

[["G019", 019], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The employee questioned the march of next year and work hours with the boss.</td></tr>" }],
[["G019", 019], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military commander questioned the march of the soldiers in the snow.</td></tr>" }],
[["G019", 019], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The employee questioned the march of the soldiers in the snow.</td></tr>" }],
[["G019", 019], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military commander questioned the march of next year and work hours with the boss.</td></tr>" }],

[["G020", 020], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sports commentator reported on the race and the winners and losers.</td></tr>" }],
[["G020", 020], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The census reported on the race and the ethnicity of all of the country's people.</td></tr>" }],
[["G020", 020], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sports commentator reported on the race and the ethnicity of all of the country's people.</td></tr>" }],
[["G020", 020], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The census reported on the race and the winners and losers.</td></tr>" }],

[["G021", 021], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist alluded to the file for the nails of her favorite client.</td></tr>" }],
[["G021", 021], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The IT specialist alluded to the file on the computer with the virus.</td></tr>" }],
[["G021", 021], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist alluded to the file on the computer with the virus.</td></tr>" }],
[["G021", 021], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The IT specialist alluded to the file for the nails of her favorite client.</td></tr>" }],

[["G022", 022], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The biologist talked of the scales on the fish and its colorful fins.</td></tr>" }],
[["G022", 022], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The workout trainer talked of the scales in the gym for tracking weightloss.</td></tr>" }],
[["G022", 022], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The biologist talked of the scales in the gym for tracking weightloss.</td></tr>" }],
[["G022", 022], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The workout trainer talked of the scales on the fish and its colorful fins.</td></tr>" }],

[["G023", 023], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The basketball players recognized the coach on the team in the yearbook.</td></tr>" }],
[["G023", 023], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carriage driver recognized the coach on the road in the countryside.</td></tr>" }],
[["G023", 023], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The basketball players recognized the coach on the road in the countryside.</td></tr>" }],
[["G023", 023], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carriage driver recognized the coach on the team in the yearbook.</td></tr>" }],

[["G024", 024], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tennis player noticed the racket and the balls on the court.</td></tr>" }],
[["G024", 024], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The old woman noticed the racket and other disturbances by the teenagers on her lawn.</td></tr>" }],
[["G024", 024], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tennis player noticed the racket and other disturbances by the teenagers on her lawn.</td></tr>" }],
[["G024", 024], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The old woman noticed the racket and the balls on the court.</td></tr>" }],

[["G025", 025], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bird lover remarked on the perch with the bird sitting on it.</td></tr>" }],
[["G025", 025], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman remarked on the perch and the tuna in the boats.</td></tr>" }],
[["G025", 025], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bird lover remarked on the perch and the tuna in the boats.</td></tr>" }],
[["G025", 025], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman remarked on the perch with the bird sitting on it.</td></tr>" }],

[["G026", 026], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The movie star reported the fan and the paparazzi in the theater.</td></tr>" }],
[["G026", 026], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The custodian reported the fan in the room and the leak in the ceiling.</td></tr>" }],
[["G026", 026], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The movie star reported the fan in the room and the leak in the ceiling.</td></tr>" }],
[["G026", 026], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The custodian reported the fan and the paparazzi in the theater.</td></tr>" }],

[["G027", 027], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic spoke about the bolt and the screw in the toolbox by the bench.</td></tr>" }],
[["G027", 027], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman spoke about the bolt of bright lightening and some thunder during the news.</td></tr>" }],
[["G027", 027], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic spoke about the bolt of bright lightening and some thunder during the news.</td></tr>" }],
[["G027", 027], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman spoke about the bolt and the screw in the toolbox by the bench.</td></tr>" }],

[["G028", 028], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The football player spoke of the ball during the game and the many penalties.</td></tr>" }],
[["G028", 028], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The debutante spoke of the ball and the dinner for New York's richest families.</td></tr>" }],
[["G028", 028], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The football player spoke of the ball and the dinner for New York's richest families.</td></tr>" }],
[["G028", 028], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The debutante spoke of the ball during the game and the many penalties.</td></tr>" }],

[["G029", 029], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid observed the iron for the clothes in the hamper.</td></tr>" }],
[["G029", 029], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The nutritionist observed the iron in the vitamins of the athlete.</td></tr>" }],
[["G029", 029], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid observed the iron in the vitamins of the athlete.</td></tr>" }],
[["G029", 029], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The nutritionist observed the iron for the clothes in the hamper.</td></tr>" }],

[["G030", 030], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The child asked about the party and the balloons in the house.</td></tr>" }],
[["G030", 030], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The politician asked about the party and its views on immigration law.</td></tr>" }],
[["G030", 030], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The child asked about the party and its views on immigration law.</td></tr>" }],
[["G030", 030], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The politician asked about the party and the balloons in the house.</td></tr>" }],

[["G031", 031], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The police looked into the fall down the stairs by the old man.</td></tr>" }],
[["G031", 031], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveler looked into the fall and the winter seasons for opportunities to travel.</td></tr>" }],
[["G031", 031], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The police looked into the fall and the winter seasons for opportunities to travel.</td></tr>" }],
[["G031", 031], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveler looked into the fall down the stairs by the old man.</td></tr>" }],

[["G032", 032], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The monarch remembered the count and his castle in Bavaria.</td></tr>" }],
[["G032", 032], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candidate remembered the count of the votes in the election.</td></tr>" }],
[["G032", 032], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The monarch remembered the count of the votes in the election.</td></tr>" }],
[["G032", 032], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candidate remembered the count and his castle in Bavaria.</td></tr>" }],

[["G033", 033], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith hinted at the key in the door to the home owner.</td></tr>" }],
[["G033", 033], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The typist hinted at the key on the keyboard of the broken computer.</td></tr>" }],
[["G033", 033], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith hinted at the key on the keyboard of the broken computer.</td></tr>" }],
[["G033", 033], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The typist hinted at the key in the door to the home owner.</td></tr>" }],

[["G034", 034], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The book editor saw the period of the sentence on the final page.</td></tr>" }],
[["G034", 034], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The historian saw the period of time during the Middle Ages.</td></tr>" }],
[["G034", 034], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The book editor saw the period of time during the Middle Ages.</td></tr>" }],
[["G034", 034], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The historian saw the period of the sentence on the final page.</td></tr>" }],

[["G035", 035], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter commented on the nail in the toolbox next to the hammer.</td></tr>" }],
[["G035", 035], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The beautician commented on the nail with red polish and silver glitter.</td></tr>" }],
[["G035", 035], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter commented on the nail with red polish and silver glitter.</td></tr>" }],
[["G035", 035], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The beautician commented on the nail in the toolbox next to the hammer.</td></tr>" }],

[["G036", 036], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The groomer acknowledged the bark of the dog in the kennel.</td></tr>" }],
[["G036", 036], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener acknowledged the bark on the tree in the forest.</td></tr>" }],
[["G036", 036], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The groomer acknowledged the bark on the tree in the forest.</td></tr>" }],
[["G036", 036], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener acknowledged the bark of the dog in the kennel.</td></tr>" }],

[["G037", 037], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The anatomy student pointed to the colon in the cadaver on the examination room table.</td></tr>" }],
[["G037", 037], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The writer pointed to the colon in the sentence of the last line of the page.</td></tr>" }],
[["G037", 037], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The anatomy student pointed to the colon in the sentence of the last line of the page.</td></tr>" }],
[["G037", 037], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The writer pointed to the colon in the cadaver on the examination room table.</td></tr>" }],

[["G038", 038], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tailor revealed the suit and the tuxedo to be worn by the men.</td></tr>" }],
[["G038", 038], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The poker player revealed the suit of the card in his hand.</td></tr>" }],
[["G038", 038], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tailor revealed the suit of the card in his hand.</td></tr>" }],
[["G038", 038], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The poker player revealed the suit and the tuxedo to be worn by the men.</td></tr>" }],

[["G039", 039], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sales woman called attention to the dress on the mannequin by the door.</td></tr>" }],
[["G039", 039], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The historian called attention to the dress and manner of style of the youth in that era.</td></tr>" }],
[["G039", 039], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sales woman called attention to the dress and manner of style of the youth in that era.</td></tr>" }],
[["G039", 039], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The historian called attention to the dress on the mannequin by the door.</td></tr>" }],

[["G040", 040], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener alluded to the fig on the tree in the backyard.</td></tr>" }],
[["G040", 040], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef alluded to the fig in the cake for the customers.</td></tr>" }],
[["G040", 040], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener alluded to the fig in the cake for the customers.</td></tr>" }],
[["G040", 040], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef alluded to the fig on the tree in the backyard.</td></tr>" }],

[["G041", 041], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener inquired about the lemon on the table from the tree in the greenhouse.</td></tr>" }],
[["G041", 041], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food critic inquired about the lemon in the soup at the new restaurant.</td></tr>" }],
[["G041", 041], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener inquired about the lemon in the soup at the new restaurant.</td></tr>" }],
[["G041", 041], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food critic inquired about the lemon on the table from the tree in the greenhouse.</td></tr>" }],

[["G042", 042], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker mentioned the fox in the woods at the riverside.</td></tr>" }],
[["G042", 042], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teenager mentioned the fox and other models on the magazine cover  to her friend.</td></tr>" }],
[["G042", 042], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker mentioned the fox and other models on the magazine cover  to her friend.</td></tr>" }],
[["G042", 042], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teenager mentioned the fox in the woods at the riverside.</td></tr>" }],

[["G043", 043], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fastfood cook addressed the oil in the fryer used to cook the fries.</td></tr>" }],
[["G043", 043], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic addressed the oil in the car and other repairs.</td></tr>" }],
[["G043", 043], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fastfood cook addressed the oil in the car and other repairs.</td></tr>" }],
[["G043", 043], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic addressed the oil in the fryer used to cook the fries.</td></tr>" }],

[["G044", 044], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reporter talked about the paper and its headlines on the news.</td></tr>" }],
[["G044", 044], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor talked about the paper on the floors of the cafeteria.</td></tr>" }],
[["G044", 044], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reporter talked about the paper on the floors of the cafeteria.</td></tr>" }],
[["G044", 044], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor talked about the paper and its headlines on the news.</td></tr>" }],

[["G045", 045], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic asked about the wheels on the car at the garage.</td></tr>" }],
[["G045", 045], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teenage boy asked about the wheels at the dealership for his 18th birthday present.</td></tr>" }],
[["G045", 045], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic asked about the wheels at the dealership for his 18th birthday present.</td></tr>" }],
[["G045", 045], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teenage boy asked about the wheels on the car at the garage.</td></tr>" }],

[["G046", 046], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman spoke about the shower on the forecast for that Monday.</td></tr>" }],
[["G046", 046], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The spa assistant spoke about the shower and the steam in the bathroom.</td></tr>" }],
[["G046", 046], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman spoke about the shower and the steam in the bathroom.</td></tr>" }],
[["G046", 046], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The spa assistant spoke about the shower on the forecast for that Monday.</td></tr>" }],

[["G047", 047], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid noticed the corner of the room with all of the dust and dirt.</td></tr>" }],
[["G047", 047], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tourist noticed the corner of the street and its lack of people.</td></tr>" }],
[["G047", 047], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid noticed the corner of the street and its lack of people.</td></tr>" }],
[["G047", 047], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tourist noticed the corner of the room with all of the dust and dirt.</td></tr>" }],

[["G048", 048], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The anatomy student discussed the ear and its structure of delicate bones and canals.</td></tr>" }],
[["G048", 048], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tattoo artist discussed the ear and its multiple piercings at his parlor.</td></tr>" }],
[["G048", 048], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The anatomy student discussed the ear and its multiple piercings at his parlor.</td></tr>" }],
[["G048", 048], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tattoo artist discussed the ear and its structure of delicate bones and canals.</td></tr>" }],

[["G049", 049], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor observed the handle of the broom while sweeping.</td></tr>" }],
[["G049", 049], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The furniture maker observed the handle of the cabinet while building it.</td></tr>" }],
[["G049", 049], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor observed the handle of the cabinet while building it.</td></tr>" }],
[["G049", 049], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The furniture maker observed the handle of the broom while sweeping.</td></tr>" }],

[["G050", 050], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The soccer player pointed to the foot and its injury to the sports doctor.</td></tr>" }],
[["G050", 050], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter pointed to the foot of the chair and its intricate detail.</td></tr>" }],
[["G050", 050], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The soccer player pointed to the foot of the chair and its intricate detail.</td></tr>" }],
[["G050", 050], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter pointed to the foot and its injury to the sports doctor.</td></tr>" }],

[["G051", 051], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith talked of the key to the door that was always closed.</td></tr>" }],
[["G051", 051], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The computer hacker talked of the key to the code on the encryption network.</td></tr>" }],
[["G051", 051], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith talked of the key to the code on the encryption network.</td></tr>" }],
[["G051", 051], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The computer hacker talked of the key to the door that was always closed.</td></tr>" }],

[["G052", 052], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman acknowledged the fog over the lake in the early hours of the morning.</td></tr>" }],
[["G052", 052], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mental patient acknowledged the fog of his mind over the last few years.</td></tr>" }],
[["G052", 052], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman acknowledged the fog of his mind over the last few years.</td></tr>" }],
[["G052", 052], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mental patient acknowledged the fog over the lake in the early hours of the morning.</td></tr>" }],

[["G053", 053], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The biologist broached the shell of the snail and its protective qualities.</td></tr>" }],
[["G053", 053], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The allergy specialist broached the shell of the peanut to the kids at school.</td></tr>" }],
[["G053", 053], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The biologist broached the shell of the peanut to the kids at school.</td></tr>" }],
[["G053", 053], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The allergy specialist broached the shell of the snail and its protective qualities.</td></tr>" }],

[["G054", 054], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The prisoner explained the taste of freedom to his fellow prisoners.</td></tr>" }],
[["G054", 054], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food tester explained the taste of the soup with the lemon.</td></tr>" }],
[["G054", 054], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The prisoner explained the taste of the soup with the lemon.</td></tr>" }],
[["G054", 054], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food tester explained the taste of freedom to his fellow prisoners.</td></tr>" }],

[["G055", 055], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The detective revealed the glass on the ground by the window.</td></tr>" }],
[["G055", 055], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The waitress revealed the glass on the table for the diners.</td></tr>" }],
[["G055", 055], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The detective revealed the glass on the table for the diners.</td></tr>" }],
[["G055", 055], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The waitress revealed the glass on the ground by the window.</td></tr>" }],

[["G056", 056], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The geologist named the rock on the ground of the dark cave.</td></tr>" }],
[["G056", 056], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The preacher named the rock of a pope that makes the foundation of the church.</td></tr>" }],
[["G056", 056], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The geologist named the rock of a pope that makes the foundation of the church.</td></tr>" }],
[["G056", 056], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The preacher named the rock on the ground of the dark cave.</td></tr>" }],

[["G057", 057], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer evaluated the chicken in the coop with the other chickens.</td></tr>" }],
[["G057", 057], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The taunting kids evaluated the chicken of a friend in the haunted house.</td></tr>" }],
[["G057", 057], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer evaluated the chicken of a friend in the haunted house.</td></tr>" }],
[["G057", 057], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The taunting kids evaluated the chicken in the coop with the other chickens.</td></tr>" }],

[["G058", 058], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The painter hinted at the lavendar and other colors in the artwork.</td></tr>" }],
[["G058", 058], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener hinted at the lavendar by the oregano and other herbs.</td></tr>" }],
[["G058", 058], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The painter hinted at the lavendar by the oregano and other herbs.</td></tr>" }],
[["G058", 058], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener hinted at the lavendar and other colors in the artwork.</td></tr>" }],

[["G059", 059], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cyclist commented on the lock on his bike when it was stolen.</td></tr>" }],
[["G059", 059], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith commented on the lock on the door of the old abandoned house.</td></tr>" }],
[["G059", 059], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cyclist commented on the lock on the door of the old abandoned house.</td></tr>" }],
[["G059", 059], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The locksmith commented on the lock on his bike when it was stolen.</td></tr>" }],

[["G060", 060], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman looked into the catch of the salmon for that day.</td></tr>" }],
[["G060", 060], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball umpire looked into the catch in the game by the player.</td></tr>" }],
[["G060", 060], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman looked into the catch in the game by the player.</td></tr>" }],
[["G060", 060], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The baseball umpire looked into the catch of the salmon for that day.</td></tr>" }],

[["G061", 061], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The eye doctor brought up the bridge of her glasses with the dent.</td></tr>" }],
[["G061", 061], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction crew brought up the bridge over the river to the civil engineer.</td></tr>" }],
[["G061", 061], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The eye doctor brought up the bridge over the river to the civil engineer.</td></tr>" }],
[["G061", 061], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The construction crew brought up the bridge of her glasses with the dent.</td></tr>" }],

[["G062", 062], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The personal shopper remembered the collar of the shirt and its color.</td></tr>" }],
[["G062", 062], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dog walker remembered the collar of the puppy and its color.</td></tr>" }],
[["G062", 062], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The personal shopper remembered the collar of the puppy and its color.</td></tr>" }],
[["G062", 062], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dog walker remembered the collar of the shirt and its color.</td></tr>" }],

[["G063", 063], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The psychiatrist brought up the state of mind of the distraught patient</td></tr>" }],
[["G063", 063], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The map maker brought up the state and the cities of the old settlement.</td></tr>" }],
[["G063", 063], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The psychiatrist brought up the state and the cities of the old settlement.</td></tr>" }],
[["G063", 063], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The map maker brought up the state of mind of the distraught patient</td></tr>" }],

[["G064", 064], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect introduced the passage between the buildings to the owners of the property.</td></tr>" }],
[["G064", 064], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reader introduced the passage from the book to his friends.</td></tr>" }],
[["G064", 064], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect introduced the passage from the book to his friends.</td></tr>" }],
[["G064", 064], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reader introduced the passage between the buildings to the owners of the property.</td></tr>" }],

[["G065", 065], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor pointed out the course and other classes to his students.</td></tr>" }],
[["G065", 065], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The explorer pointed out the course of the river to the other hikers.</td></tr>" }],
[["G065", 065], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor pointed out the course of the river to the other hikers.</td></tr>" }],
[["G065", 065], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The explorer pointed out the course and other classes to his students.</td></tr>" }],

[["G066", 066], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The judge refered to the admission of guilt by the prisoner.</td></tr>" }],
[["G066", 066], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The amusement park refered to the admission for children under ten years.</td></tr>" }],
[["G066", 066], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The judge refered to the admission for children under ten years.</td></tr>" }],
[["G066", 066], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The amusement park refered to the admission of guilt by the prisoner.</td></tr>" }],

[["G067", 067], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The house wife mentioned the company at her home in the country.</td></tr>" }],
[["G067", 067], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The business owner mentioned the company and its struggles with the economy.</td></tr>" }],
[["G067", 067], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The house wife mentioned the company and its struggles with the economy.</td></tr>" }],
[["G067", 067], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The business owner mentioned the company at her home in the country.</td></tr>" }],

[["G068", 068], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The musician inquired about the organ in the church and its history.</td></tr>" }],
[["G068", 068], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surgeon inquired about the organ in the patient during the operation.</td></tr>" }],
[["G068", 068], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The musician inquired about the organ in the patient during the operation.</td></tr>" }],
[["G068", 068], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surgeon inquired about the organ in the church and its history.</td></tr>" }],

[["G069", 069], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The Native American spoke about the reservation and its land with buffalo as far reaching as Nevada.</td></tr>" }],
[["G069", 069], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hotel desk worker spoke about the reservation at the hotel for the family of four.</td></tr>" }],
[["G069", 069], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The Native American spoke about the reservation at the hotel for the family of four.</td></tr>" }],
[["G069", 069], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hotel desk worker spoke about the reservation and its land with buffalo as far reaching as Nevada.</td></tr>" }],

[["G070", 070], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surgeon talked of the operation at the hospital for the patient with the tumor.</td></tr>" }],
[["G070", 070], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mathematician talked of the operation of subtraction to his advanced students.</td></tr>" }],
[["G070", 070], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surgeon talked of the operation of subtraction to his advanced students.</td></tr>" }],
[["G070", 070], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mathematician talked of the operation at the hospital for the patient with the tumor.</td></tr>" }],

[["G071", 071], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The musician remembered the band at the concert for the newspaper.</td></tr>" }],
[["G071", 071], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gift wrapper remembered the band around the package filled with toys.</td></tr>" }],
[["G071", 071], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The musician remembered the band around the package filled with toys.</td></tr>" }],
[["G071", 071], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gift wrapper remembered the band at the concert for the newspaper.</td></tr>" }],

[["G072", 072], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The economist evaluated the pound in Great Britain and its stockmarkets.</td></tr>" }],
[["G072", 072], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The butcher evaluated the pound of tenderized beef on the scale.</td></tr>" }],
[["G072", 072], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The economist evaluated the pound of tenderized beef on the scale.</td></tr>" }],
[["G072", 072], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The butcher evaluated the pound in Great Britain and its stockmarkets.</td></tr>" }],

[["G073", 073], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect remarked on the scale on the blueprint from centimeters to meters.</td></tr>" }],
[["G073", 073], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The singer remarked on the scale and music notes on the music sheet.</td></tr>" }],
[["G073", 073], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The architect remarked on the scale and music notes on the music sheet.</td></tr>" }],
[["G073", 073], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The singer remarked on the scale on the blueprint from centimeters to meters.</td></tr>" }],

[["G074", 074], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The coal worker reported on the mine and its minerals deep inside.</td></tr>" }],
[["G074", 074], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military specialist reported on the mine and its explosions from the enemy territory.</td></tr>" }],
[["G074", 074], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The coal worker reported on the mine and its explosions from the enemy territory.</td></tr>" }],
[["G074", 074], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The military specialist reported on the mine and its minerals deep inside.</td></tr>" }],

[["G075", 075], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The violinist discussed the note in the music with the conductor.</td></tr>" }],
[["G075", 075], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The husband discussed the note on the table concerning the grocery list.</td></tr>" }],
[["G075", 075], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The violinist discussed the note on the table concerning the grocery list.</td></tr>" }],
[["G075", 075], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The husband discussed the note in the music with the conductor.</td></tr>" }],

[["G076", 076], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fortune teller described the present and the past and the future.</td></tr>" }],
[["G076", 076], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The birthday boy described the present and the balloons outside.</td></tr>" }],
[["G076", 076], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fortune teller described the present and the balloons outside.</td></tr>" }],
[["G076", 076], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The birthday boy described the present and the past and the future.</td></tr>" }],

[["G077", 077], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The time keeper acknowledged the second in the hour when the disaster occurred.</td></tr>" }],
[["G077", 077], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner acknowledged the second in the race and other competitors.</td></tr>" }],
[["G077", 077], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The time keeper acknowledged the second in the race and other competitors.</td></tr>" }],
[["G077", 077], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner acknowledged the second in the hour when the disaster occurred.</td></tr>" }],

[["G078", 078], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The ship captain noticed the channel and its waters down below.</td></tr>" }],
[["G078", 078], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The talk show host noticed the channel on the television and its popularity.</td></tr>" }],
[["G078", 078], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The ship captain noticed the channel on the television and its popularity.</td></tr>" }],
[["G078", 078], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The talk show host noticed the channel and its waters down below.</td></tr>" }],

[["G079", 079], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fortune teller asked about the palm of his hand and other personal details.</td></tr>" }],
[["G079", 079], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surfer asked about the palm and its coconuts along the beach.</td></tr>" }],
[["G079", 079], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fortune teller asked about the palm and its coconuts along the beach.</td></tr>" }],
[["G079", 079], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The surfer asked about the palm of his hand and other personal details.</td></tr>" }],

[["G080", 080], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid named the solution of dish soap and water in the sink.</td></tr>" }],
[["G080", 080], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The genius named the solution for the problem on the chalkboard.</td></tr>" }],
[["G080", 080], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid named the solution for the problem on the chalkboard.</td></tr>" }],
[["G080", 080], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The genius named the solution of dish soap and water in the sink.</td></tr>" }],

[["G081", 081], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sports fan observed the point from the player during the critical part of the game.</td></tr>" }],
[["G081", 081], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveler observed the point on the map by the mountain.</td></tr>" }],
[["G081", 081], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sports fan observed the point on the map by the mountain.</td></tr>" }],
[["G081", 081], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveler observed the point from the player during the critical part of the game.</td></tr>" }],

[["G082", 082], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The campers alluded to the bank along the river with many pebbles.</td></tr>" }],
[["G082", 082], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The accountant alluded to the bank and the money gained through investment.</td></tr>" }],
[["G082", 082], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The campers alluded to the bank and the money gained through investment.</td></tr>" }],
[["G082", 082], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The accountant alluded to the bank along the river with many pebbles.</td></tr>" }],

[["G083", 083], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer talked about the cotton in the fields and the drought that year.</td></tr>" }],
[["G083", 083], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fashion designer talked about the cotton in the fabric of the pants.</td></tr>" }],
[["G083", 083], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer talked about the cotton in the fabric of the pants.</td></tr>" }],
[["G083", 083], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fashion designer talked about the cotton in the fields and the drought that year.</td></tr>" }],

[["G084", 084], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dishwasher mentioned the bowl and the cup on the table.</td></tr>" }],
[["G084", 084], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hungry child mentioned the bowl of cereal was eaten for breakfast.</td></tr>" }],
[["G084", 084], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dishwasher mentioned the bowl of cereal was eaten for breakfast.</td></tr>" }],
[["G084", 084], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hungry child mentioned the bowl and the cup on the table.</td></tr>" }],

[["G085", 085], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman pointed out the anchovy in the net of the boat.</td></tr>" }],
[["G085", 085], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The pizza maker pointed out the anchovy on the pizza to the customer.</td></tr>" }],
[["G085", 085], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fisherman pointed out the anchovy on the pizza to the customer.</td></tr>" }],
[["G085", 085], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The pizza maker pointed out the anchovy in the net of the boat.</td></tr>" }],

[["G086", 086], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The novelist referred to the book and its characters to the class.</td></tr>" }],
[["G086", 086], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid referred to the book on the table next to the fireplace.</td></tr>" }],
[["G086", 086], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The novelist referred to the book on the table next to the fireplace.</td></tr>" }],
[["G086", 086], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid referred to the book and its characters to the class.</td></tr>" }],

[["G087", 087], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer asked about the chicken in the yard with the geese.</td></tr>" }],
[["G087", 087], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef asked about the chicken in the oven of the restaurant.</td></tr>" }],
[["G087", 087], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The farmer asked about the chicken in the oven of the restaurant.</td></tr>" }],
[["G087", 087], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef asked about the chicken in the yard with the geese.</td></tr>" }],

[["G088", 088], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bus driver spoke about the class of noisy kids at the front of the bus.</td></tr>" }],
[["G088", 088], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor spoke about the class and its homework and rules to the students.</td></tr>" }],
[["G088", 088], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bus driver spoke about the class and its homework and rules to the students.</td></tr>" }],
[["G088", 088], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor spoke about the class of noisy kids at the front of the bus.</td></tr>" }],

[["G089", 089], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sheep herder observed the lamb in the meadow with its family.</td></tr>" }],
[["G089", 089], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The restaurant server observed the lamb on the plate of the wealthy man.</td></tr>" }],
[["G089", 089], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sheep herder observed the lamb on the plate of the wealthy man.</td></tr>" }],
[["G089", 089], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The restaurant server observed the lamb in the meadow with its family.</td></tr>" }],

[["G090", 090], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sailor pointed to the lobster in the ocean by the ship.</td></tr>" }],
[["G090", 090], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food critic pointed to the lobster for the dinner that night.</td></tr>" }],
[["G090", 090], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sailor pointed to the lobster for the dinner that night.</td></tr>" }],
[["G090", 090], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The food critic pointed to the lobster in the ocean by the ship.</td></tr>" }],

[["G091", 091], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The editor spoke of the magazine and its future direction to the audience.</td></tr>" }],
[["G091", 091], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The garbage man spoke of the magazine on the ground of the playground.</td></tr>" }],
[["G091", 091], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The editor spoke of the magazine on the ground of the playground.</td></tr>" }],
[["G091", 091], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The garbage man spoke of the magazine and its future direction to the audience.</td></tr>" }],

[["G092", 092], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The journalist considered the newspaper an interesting work with a political slant.</td></tr>" }],
[["G092", 092], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The recycling man considered the newspaper and the cans on the curb for pickup.</td></tr>" }],
[["G092", 092], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The journalist considered the newspaper and the cans on the curb for pickup.</td></tr>" }],
[["G092", 092], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The recycling man considered the newspaper an interesting work with a political slant.</td></tr>" }],

[["G093", 093], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The lumberman described the oak in the forest to other workers.</td></tr>" }],
[["G093", 093], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter described the oak in the cabinet as a luxury.</td></tr>" }],
[["G093", 093], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The lumberman described the oak in the cabinet as a luxury.</td></tr>" }],
[["G093", 093], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The carpenter described the oak in the forest to other workers.</td></tr>" }],

[["G094", 094], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The vegetable seller remembered the onion from the garden of the house.</td></tr>" }],
[["G094", 094], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook's helper remembered the onion in the soup of the customer.</td></tr>" }],
[["G094", 094], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The vegetable seller remembered the onion in the soup of the customer.</td></tr>" }],
[["G094", 094], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook's helper remembered the onion from the garden of the house.</td></tr>" }],

[["G095", 095], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The animal breeder alluded to the rabbit in the cage by the house.</td></tr>" }],
[["G095", 095], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef alluded to the rabbit on the plate with the mashed potatos.</td></tr>" }],
[["G095", 095], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The animal breeder alluded to the rabbit on the plate with the mashed potatos.</td></tr>" }],
[["G095", 095], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The chef alluded to the rabbit in the cage by the house.</td></tr>" }],

[["G096", 096], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The king acknowledged the blood of royal anscestors in his lineage.</td></tr>" }],
[["G096", 096], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The nurse acknowledged the blood of the victim on the floor of the hospital.</td></tr>" }],
[["G096", 096], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The king acknowledged the blood of the victim on the floor of the hospital.</td></tr>" }],
[["G096", 096], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The nurse acknowledged the blood of royal anscestors in his lineage.</td></tr>" }],

[["G097", 097], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener addressed the mint in the pot next to the oregano.</td></tr>" }],
[["G097", 097], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candyman addressed the mint in the icecream and the chocolate chips.</td></tr>" }],
[["G097", 097], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener addressed the mint in the icecream and the chocolate chips.</td></tr>" }],
[["G097", 097], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The candyman addressed the mint in the pot next to the oregano.</td></tr>" }],

[["G098", 098], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mother remarked on the doll of a girl in the daycare.</td></tr>" }],
[["G098", 098], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The little girl remarked on the doll at the toy store in the pink box.</td></tr>" }],
[["G098", 098], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mother remarked on the doll at the toy store in the pink box.</td></tr>" }],
[["G098", 098], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The little girl remarked on the doll of a girl in the daycare.</td></tr>" }],

[["G099", 099], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jungle tribe made known the parrot in the tree with colorful feathers.</td></tr>" }],
[["G099", 099], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teacher made known the parrot of a boy in the classroom.</td></tr>" }],
[["G099", 099], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jungle tribe made known the parrot of a boy in the classroom.</td></tr>" }],
[["G099", 099], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The teacher made known the parrot in the tree with colorful feathers.</td></tr>" }],

[["G100", 100], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dentist commented on the root of the tooth of the ailing patient.</td></tr>" }],
[["G100", 100], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tree specialist commented on the root of the pine tree as it lay on the forest floor.</td></tr>" }],
[["G100", 100], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The dentist commented on the root of the pine tree as it lay on the forest floor.</td></tr>" }],
[["G100", 100], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The tree specialist commented on the root of the tooth of the ailing patient.</td></tr>" }],

[["G101", 101], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The patient reported on the skin of his knee to the doctor.</td></tr>" }],
[["G101", 101], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fruit farmer reported on the skin of the peaches and of the oranges.</td></tr>" }],
[["G101", 101], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The patient reported on the skin of the peaches and of the oranges.</td></tr>" }],
[["G101", 101], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fruit farmer reported on the skin of his knee to the doctor.</td></tr>" }],

[["G102", 102], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fashion designer introduced the skirt and the blouse for women with refined taste.</td></tr>" }],
[["G102", 102], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker introduced the slope of the mountain to the other hikers.</td></tr>" }],
[["G102", 102], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fashion designer introduced the skirt of the mountain to the other hikers.</td></tr>" }],
[["G102", 102], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The hiker introduced the slope and the blouse for women with refined taste.</td></tr>" }],

[["G103", 103], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist brought up the tip of the finger of her client.</td></tr>" }],
[["G103", 103], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook brought up the yolk of the egg and other details for making cake.</td></tr>" }],
[["G103", 103], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist brought up the tip of the egg and other details for making cake.</td></tr>" }],
[["G103", 103], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook brought up the yolk of the finger of her client.</td></tr>" }],

[["G104", 104], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid pointed out the iron and wrinkled clothing to the other maids.</td></tr>" }],
[["G104", 104], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook pointed out the griddle with the bacon and eggs to the other cooks.</td></tr>" }],
[["G104", 104], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid pointed out the iron with the bacon and eggs to the other cooks.</td></tr>" }],
[["G104", 104], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The cook pointed out the griddle and wrinkled clothing to the other maids.</td></tr>" }],

[["G105", 105], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bus driver refered to the station by the stoplight to the pedestrian.</td></tr>" }],
[["G105", 105], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman refered to the season and the sunshine to be expected.</td></tr>" }],
[["G105", 105], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The bus driver refered to the station and the sunshine to be expected.</td></tr>" }],
[["G105", 105], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The weatherman refered to the season by the stoplight to the pedestrian.</td></tr>" }],

[["G106", 106], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The wax worker mentioned the candle and the fire it had caused.</td></tr>" }],
[["G106", 106], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sailor mentioned the sail to the captain of the ship.</td></tr>" }],
[["G106", 106], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The wax worker mentioned the candle to the captain of the ship.</td></tr>" }],
[["G106", 106], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sailor mentioned the sail and the fire it had caused.</td></tr>" }],

[["G107", 107], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The little girl inquired about the doll in the toystore of the mall.</td></tr>" }],
[["G107", 107], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The doctor inquired about the wrist in the cast of his patient.</td></tr>" }],
[["G107", 107], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The little girl inquired about the doll in the cast of his patient.</td></tr>" }],
[["G107", 107], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The doctor inquired about the wrist in the toystore of the mall.</td></tr>" }],

[["G108", 108], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The grocery shopper spoke about the line and the registers that were closed.</td></tr>" }],
[["G108", 108], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The veterinarian spoke about the tail of the horse that he was riding.</td></tr>" }],
[["G108", 108], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The grocery shopper spoke about the line of the horse that he was riding.</td></tr>" }],
[["G108", 108], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The veterinarian spoke about the tail and the registers that were closed.</td></tr>" }],

[["G109", 109], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The police talked of the handcuffs on the criminal in the cop car.</td></tr>" }],
[["G109", 109], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The husbands talked of the wives and their mothers' influence on them.</td></tr>" }],
[["G109", 109], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The police talked of the handcuffs and their mothers' influence on them.</td></tr>" }],
[["G109", 109], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The husbands talked of the wives on the criminal in the cop car.</td></tr>" }],

[["G110", 110], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The brothers remembered the twins from a party of a close friend.</td></tr>" }],
[["G110", 110], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The groom remembered the cufflinks for the suit and tie event.</td></tr>" }],
[["G110", 110], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The brothers remembered the twins for the suit and tie event.</td></tr>" }],
[["G110", 110], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The groom remembered the cufflinks from a party of a close friend.</td></tr>" }],

[["G111", 111], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The author evaluated the title of the new book out in bookstore nationwide.</td></tr>" }],
[["G111", 111], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor evaluated the degree of the scientist working in the lab.</td></tr>" }],
[["G111", 111], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The author evaluated the title of the scientist working in the lab.</td></tr>" }],
[["G111", 111], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor evaluated the degree of the new book out in bookstore nationwide.</td></tr>" }],

[["G112", 112], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The botonist remarked on the plant in the garden with the strange flowers.</td></tr>" }],
[["G112", 112], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor remarked on the floor of the building with all of the offices.</td></tr>" }],
[["G112", 112], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The botonist remarked on the plant of the building with all of the offices.</td></tr>" }],
[["G112", 112], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The janitor remarked on the floor in the garden with the strange flowers.</td></tr>" }],

[["G113", 113], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The scientist reported on the cure for the disease in elderly patients.</td></tr>" }],
[["G113", 113], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The pope reported on the priest and his Church to the devoted followers.</td></tr>" }],
[["G113", 113], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The scientist reported on the cure and his Church to the devoted followers.</td></tr>" }],
[["G113", 113], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The pope reported on the priest for the disease in elderly patients.</td></tr>" }],

[["G114", 114], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The store attendant pointed out the battery in the toy car and replaced it with a new one.</td></tr>" }],
[["G114", 114], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid pointed out the heap of books on the floor of the mansion.</td></tr>" }],
[["G114", 114], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The store attendant pointed out the battery of books on the floor of the mansion.</td></tr>" }],
[["G114", 114], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The maid pointed out the heap in the toy car and replaced it with a new one.</td></tr>" }],

[["G115", 115], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The kids talked about the game of basketball with their friends.</td></tr>" }],
[["G115", 115], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The potter talked about the set of cups and plates.</td></tr>" }],
[["G115", 115], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The kids talked about the game of cups and plates.</td></tr>" }],
[["G115", 115], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The potter talked about the set of basketball with their friends.</td></tr>" }],

[["G116", 116], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The animal rescue referred to the cat in the cage and fed her food.</td></tr>" }],
[["G116", 116], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic referred to the jack under the car and the spare wheel.</td></tr>" }],
[["G116", 116], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The animal rescue referred to the cat under the car and the spare wheel.</td></tr>" }],
[["G116", 116], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The mechanic referred to the jack in the cage and fed her food.</td></tr>" }],

[["G117", 117], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gas station attendant examined the pump for the gas next to the broken vehicle.</td></tr>" }],
[["G117", 117], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The criminal examined the bomb in his suitcase before boarding the train.</td></tr>" }],
[["G117", 117], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gas station attendant examined the pump in his suitcase before boarding the train.</td></tr>" }],
[["G117", 117], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The criminal examined the bomb for the gas next to the broken vehicle.</td></tr>" }],

[["G118", 118], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner mentioned the clock and the time that he had to beat.</td></tr>" }],
[["G118", 118], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jewelry salesman mentioned the watch on the wrist of the man in the suit.</td></tr>" }],
[["G118", 118], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The runner mentioned the clock on the wrist of the man in the suit.</td></tr>" }],
[["G118", 118], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The jewelry salesman mentioned the watch and the time that he had to beat.</td></tr>" }],

[["G119", 119], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The daydreamer remarked on the memory of his past and happier times.</td></tr>" }],
[["G119", 119], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveller remarked on the souvenir from the trip to the Bahamas.</td></tr>" }],
[["G119", 119], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The daydreamer remarked on the memory from the trip to the Bahamas.</td></tr>" }],
[["G119", 119], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The traveller remarked on the souvenir of his past and happier times.</td></tr>" }],

[["G120", 120], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The psychologist reported on the dream of the patient with disturbing issues.</td></tr>" }],
[["G120", 120], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The insomniac reported on the sleep and the medication to help.</td></tr>" }],
[["G120", 120], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The psychologist reported on the dream and the medication to help.</td></tr>" }],
[["G120", 120], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The insomniac reported on the sleep of the patient with disturbing issues.</td></tr>" }],

[["G121", 121], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The firefighter discussed the ring of the alarm to the chief.</td></tr>" }],
[["G121", 121], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The homeowner discussed the bell of the door to his new two-story home.</td></tr>" }],
[["G121", 121], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The firefighter discussed the ring of the door to his new two-story home.</td></tr>" }],
[["G121", 121], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The homeowner discussed the bell of the alarm to the chief.</td></tr>" }],

[["G122", 122], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The show host described the audience and their clapping for the guest star.</td></tr>" }],
[["G122", 122], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reporter described the public and their reaction to the news.</td></tr>" }],
[["G122", 122], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The show host described the audience and their reaction to the news.</td></tr>" }],
[["G122", 122], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The reporter described the public and their clapping for the guest star.</td></tr>" }],

[["G123", 123], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist commented on the finger on the hand of the woman with the diamond ring.</td></tr>" }],
[["G123", 123], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The foot doctor commented on the toe on the foot of the man with the fungus.</td></tr>" }],
[["G123", 123], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The manicurist commented on the finger on the foot of the man with the fungus.</td></tr>" }],
[["G123", 123], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The foot doctor commented on the toe on the hand of the woman with the diamond ring.</td></tr>" }],

[["G124", 124], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The taxi driver looked into the address of the house in the center of the big city.</td></tr>" }],
[["G124", 124], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The explorer looked into the direction on the map of the winding river.</td></tr>" }],
[["G124", 124], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The taxi driver looked into the address on the map of the winding river.</td></tr>" }],
[["G124", 124], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The explorer looked into the direction of the house in the center of the big city.</td></tr>" }],

[["G125", 125], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The children brought up the cartoon on the television to their babysitter.</td></tr>" }],
[["G125", 125], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The street artist brought up the charicature of the woman with the large nose.</td></tr>" }],
[["G125", 125], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The children brought up the cartoon of the woman with the large nose.</td></tr>" }],
[["G125", 125], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The street artist brought up the charicature on the television to their babysitter.</td></tr>" }],

[["G126", 126], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener asked about the thorn on the rose in her garden.</td></tr>" }],
[["G126", 126], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sous chef asked about the spine of the fish that she was cooking.</td></tr>" }],
[["G126", 126], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The gardener asked about the thorn of the fish that she was cooking.</td></tr>" }],
[["G126", 126], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The sous chef asked about the spine on the rose in her garden.</td></tr>" }],

[["G127", 127], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The actor called attention to the spotlight on the stage to the director.</td></tr>" }],
[["G127", 127], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The writer called attention to the focus of the book to the readers.</td></tr>" }],
[["G127", 127], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The actor called attention to the spotlight of the book to the readers.</td></tr>" }],
[["G127", 127], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The writer called attention to the focus on the stage to the director.</td></tr>" }],

[["G128", 128], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fruit seller saw the pomegranate in the basket of the old woman.</td></tr>" }],
[["G128", 128], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The soldier saw the grenade by the guns in the back of the old jeep.</td></tr>" }],
[["G128", 128], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The fruit seller saw the pomegranate by the guns in the back of the old jeep.</td></tr>" }],
[["G128", 128], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The soldier saw the grenade in the basket of the old woman.</td></tr>" }],

[["G129", 129], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professional organizer noticed the section of the box with the yarn and knitting needles.</td></tr>" }],
[["G129", 129], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor noticed the department of the university and the lack of funding it had.</td></tr>" }],
[["G129", 129], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professional organizer noticed the section of the university and the lack of funding it had.</td></tr>" }],
[["G129", 129], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The professor noticed the department of the box with the yarn and knitting needles.</td></tr>" }],

[["G130", 130], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The store attendant pointed out the battery in the toy car and replaced it with a new one.</td></tr>" }],
[["G130", 130], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The babysitter pointed out the energy in the kids at the park.</td></tr>" }],
[["G130", 130], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The store attendant pointed out the battery in the kids at the park.</td></tr>" }],
[["G130", 130], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The babysitter pointed out the energy in the toy car and replaced it with a new one.</td></tr>" }],

[["G131", 131], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The horseback rider watched the tail of the horse next to the fence.</td></tr>" }],
[["G131", 131], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The customer watched the line at the store and decided to come back later.</td></tr>" }],
[["G131", 131], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The horseback rider watched the tail at the store and decided to come back later.</td></tr>" }],
[["G131", 131], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The customer watched the line of the horse next to the fence.</td></tr>" }],

[["G132", 132], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The barista mentioned the coffee in the pot and in the cup.</td></tr>" }],
[["G132", 132], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The painter mentioned the brown in the painting of the old man with a beard.</td></tr>" }],
[["G132", 132], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The barista mentioned the coffee in the painting of the old man with a beard.</td></tr>" }],
[["G132", 132], "SimilaritySentence", { html: "<center><table class='tbl'> <tr> <td>The painter mentioned the brown in the pot and in the cup.</td></tr>" }],
];
