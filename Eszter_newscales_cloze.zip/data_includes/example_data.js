define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", "GuidedPractice1", "Feedback1", "GuidedPractice2", "Feedback2","practiceover", rshuffle(startsWith("E"),startsWith("f")), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
          transfer: "keypress",
        normalMessage: "Press any key to continue"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        leftComment: "very unnatural", rightComment: "very natural"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro3", "Form", {consentRequired: true, html: { include: "intro3.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue.</i></p>"}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: fill in the blank in each conversation with a single word."] 
],continueMessage:"Click here to start the experiment."}],


      ["Feedback1", "Message", {html: ["p", "Some possible answers are: strong or muscular."]}],  
       ["Feedback2", "Message", {html: ["p", "Some possible answers are: taken, free or occupied."]}],    

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //

    ["setcounter", "__SetCounter__", { }],

["GuidedPractice1", "Form", {html: "<p>Sue: <i>The wrestler is weak.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
 
 ["GuidedPractice2", "Form", {html: "<p>Sue: <i>There's nowhere to sit at the restaurant.</i><br>Mary: <i>So you mean all the tables are <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],   
//Experimental items

[["ESI",1], "Form",       {html: "<p>Sue: <i>Drinking is allowed.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",1], "Form",       {html: "<p>Sue: <i>Drinking is optional.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",1], "Form",       {html: "<p>Sue: <i>Drinking is only allowed.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",2], "Form",       {html: "<p>Sue: <i>The model is attractive.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",2], "Form",       {html: "<p>Sue: <i>The model is average.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",2], "Form",       {html: "<p>Sue: <i>The model is only attractive.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",3], "Form",       {html: "<p>Sue: <i>John began the race.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["EX",3], "Form",       {html: "<p>Sue: <i>John quit the race.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["Eonly",3], "Form",       {html: "<p>Sue: <i>John only began the race.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],

[["ESI",4], "Form",       {html: "<p>Sue: <i>The teacher believes it is true.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it is true.</i></p>"}],
[["EX",4], "Form",       {html: "<p>Sue: <i>The teacher assumes it is true.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it is true.</i></p>"}],
[["Eonly",4], "Form",       {html: "<p>Sue: <i>The teacher only believes it is true.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it is true.</i></p>"}],

[["ESI",5], "Form",       {html: "<p>Sue: <i>The elephant is big.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",5], "Form",       {html: "<p>Sue: <i>The elephant is small.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",5], "Form",       {html: "<p>Sue: <i>The elephant is only big.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",6], "Form",       {html: "<p>Sue: <i>The weather is cool.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",6], "Form",       {html: "<p>Sue: <i>The weather is warm.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",6], "Form",       {html: "<p>Sue: <i>The weather is only cool.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",7], "Form",       {html: "<p>Sue: <i>The machine damaged itself.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> itself.</i></p>"}],
[["EX",7], "Form",       {html: "<p>Sue: <i>The machine fixed itself.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> itself.</i></p>"}],
[["Eonly",7], "Form",       {html: "<p>Sue: <i>The machine only damaged itself.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> itself.</i></p>"}],

[["ESI",8], "Form",       {html: "<p>Sue: <i>The sky is dark.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",8], "Form",       {html: "<p>Sue: <i>The sky is blue.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",8], "Form",       {html: "<p>Sue: <i>The sky is only dark.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",9], "Form",       {html: "<p>Sue: <i>The task is difficult.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",9], "Form",       {html: "<p>Sue: <i>The task is easy.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",9], "Form",       {html: "<p>Sue: <i>The task is only difficult.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",10], "Form",       {html: "<p>Sue: <i>Zack's carpet was dirty.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",10], "Form",       {html: "<p>Sue: <i>Zack's carpet was clean.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",10], "Form",       {html: "<p>Sue: <i>Zack's carpet was only dirty.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",11], "Form",       {html: "<p>Sue: <i>The doctor dislikes coffee.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> coffee.</i></p>"}],
[["EX",11], "Form",       {html: "<p>Sue: <i>The doctor loves coffee.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> coffee.</i></p>"}],
[["Eonly",11], "Form",       {html: "<p>Sue: <i>The doctor only dislikes coffee.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> coffee.</i></p>"}],

[["ESI",12], "Form", {html: "<p>Sue: <i>The sales will double.</i><br>Mary: <i>So you mean they will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",12], "Form", {html: "<p>Sue: <i>The sales will fall.</i><br>Mary: <i>So you mean they will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",12], "Form", {html: "<p>Sue: <i>The sales will only double.</i><br>Mary: <i>So you mean they will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",13], "Form", {html: "<p>Sue: <i>That candidate is equally skilled.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> skilled.</i></p>"}],
[["EX",13], "Form", {html: "<p>Sue: <i>That candidate is less skilled.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> skilled.</i></p>"}],
[["Eonly",13], "Form", {html: "<p>Sue: <i>That candidate is only equally skilled.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> skilled.</i></p>"}],

[["ESI",14], "Form", {html: "<p>Sue: <i>The movie is funny.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",14], "Form", {html: "<p>Sue: <i>The movie is sad.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",14], "Form", {html: "<p>Sue: <i>The movie is only funny.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",15], "Form", {html: "<p>Sue: <i>The movie is good.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",15], "Form", {html: "<p>Sue: <i>The movie is bad.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",15], "Form", {html: "<p>Sue: <i>The movie is only good.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",16], "Form", {html: "<p>Sue: <i>The winner was happy.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",16], "Form", {html: "<p>Sue: <i>The winner was sad.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",16], "Form", {html: "<p>Sue: <i>The winner was only happy.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",17], "Form", {html: "<p>Sue: <i>The problem is hard.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",17], "Form", {html: "<p>Sue: <i>The problem is easy.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",17], "Form", {html: "<p>Sue: <i>The problem is only hard.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",18], "Form", {html: "<p>Sue: <i>The toxin is harmful.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",18], "Form", {html: "<p>Sue: <i>The toxin is safe.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",18], "Form", {html: "<p>Sue: <i>The toxin is only harmful.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",19], "Form", {html: "<p>Sue: <i>There is water here.</i><br>Mary: <i>So you mean there isn't water <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",19], "Form", {html: "<p>Sue: <i>There is water periodically.</i><br>Mary: <i>So you mean there isn't water <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",19], "Form", {html: "<p>Sue: <i>There is water only here.</i><br>Mary: <i>So you mean there isn't water <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",20], "Form", {html: "<p>Sue: <i>The boy is hungry.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",20], "Form", {html: "<p>Sue: <i>The boy is full.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",20], "Form", {html: "<p>Sue: <i>The boy is only hungry.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",21], "Form", {html: "<p>Sue: <i>The student is intelligent.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",21], "Form", {html: "<p>Sue: <i>The student is dumb.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",21], "Form", {html: "<p>Sue: <i>The student is only intelligent.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",22], "Form", {html: "<p>Sue: <i>Chris's opponent was intimidating.</i><br>Mary: <i>So you mean he was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",22], "Form", {html: "<p>Sue: <i>Chris's opponent was weak.</i><br>Mary: <i>So you mean he was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",22], "Form", {html: "<p>Sue: <i>Chris's opponent was only intimidating.</i><br>Mary: <i>So you mean he was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",23], "Form", {html: "<p>Sue: <i>The coast was largely flooded.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> flooded.</i></p>"}],
[["EX",23], "Form", {html: "<p>Sue: <i>The coast was heavily flooded.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> flooded.</i></p>"}],
[["Eonly",23], "Form", {html: "<p>Sue: <i>The coast was only largely flooded.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> flooded.</i></p>"}],

[["ESI",24], "Form", {html: "<p>Sue: <i>The princess likes dancing.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],
[["EX",24], "Form", {html: "<p>Sue: <i>The princess hates dancing.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],
[["Eonly",24], "Form", {html: "<p>Sue: <i>The princess only likes dancing.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],

[["ESI",25], "Form", {html: "<p>Sue: <i>Bill's score matches Al's.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["EX",25], "Form", {html: "<p>Sue: <i>Bill's score approaches Al's.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["Eonly",25], "Form", {html: "<p>Sue: <i>Bill's score only matches Al's.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],

[["ESI",26], "Form", {html: "<p>Sue: <i>Peter's answers were mostly wrong.</i><br>Mary: <i>So you mean they were not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> wrong.</i></p>"}],
[["EX",26], "Form", {html: "<p>Sue: <i>Peter's answers were technically wrong.</i><br>Mary: <i>So you mean they were not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> wrong.</i></p>"}],
[["Eonly",26], "Form", {html: "<p>Sue: <i>Peter's answers were only mostly wrong.</i><br>Mary: <i>So you mean they were not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> wrong.</i></p>"}],

[["ESI",27], "Form", {html: "<p>Sue: <i>The house is old.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",27], "Form", {html: "<p>Sue: <i>The house is new.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",27], "Form", {html: "<p>Sue: <i>The house is only old.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",28], "Form", {html: "<p>Sue: <i>Mistakes happened once.</i><br>Mary: <i>So you mean they did not happen <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",28], "Form", {html: "<p>Sue: <i>Mistakes happened rarely.</i><br>Mary: <i>So you mean they did not happen <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",28], "Form", {html: "<p>Sue: <i>Mistakes happened only once.</i><br>Mary: <i>So you mean they did not happen <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

//figure out only!!!
//[["ESI",29], "Form", {html: "<p>Sue: <i>Jimmy writes books or plays.</i><br>Mary: <i>So you mean not books <input name='blank' size='30' class='obligatory' type='text' autofocus></input> plays.</i></p>"}],
//[["EX",29], "Form", {html: "<p>Sue: <i>Jimmy writes books not plays.</i><br>Mary: <i>So you mean not books <input name='blank' size='30' class='obligatory' type='text' autofocus></input> plays.</i></p>"}],
//[["Eonly",29], "Form", {html: "<p>Sue: <i>Jimmy writes books or plays.</i><br>Mary: <i>So you mean not books <input name='blank' size='30' class='obligatory' type='text' autofocus></input> plays.</i></p>"}],

//EX is weird?
[["ESI",29], "Form", {html: "<p>Sue: <i>Everyone saw Wonder Woman or Batman.</i><br>Mary: <i>So you mean they did not see Wonder Woman <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Batman.</i></p>"}],
[["EX",29], "Form", {html: "<p>Sue: <i>Everyone saw Wonderwoman not Batman.</i><br>Mary: <i>So you mean they did not see Wonder Woman <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Batman.</i></p>"}],
[["Eonly",29], "Form", {html: "<p>Sue: <i>Everyone saw only Wonder Woman or Batman.</i><br>Mary: <i>So you mean they did not see Wonder Woman <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Batman.</i></p>"}],

[["ESI",30], "Form", {html: "<p>Sue: <i>The teenager is overweight.</i><br>Mary: <i>So you mean he is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",30], "Form", {html: "<p>Sue: <i>The teenager is thin.</i><br>Mary: <i>So you mean he is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",30], "Form", {html: "<p>Sue: <i>The teenager is only overweight.</i><br>Mary: <i>So you mean he is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",31], "Form", {html: "<p>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>So you mean it was not supported <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",31], "Form", {html: "<p>Sue: <i>The measure was supported weakly.</i><br>Mary: <i>So you mean it was not supported <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",31], "Form", {html: "<p>Sue: <i>The measure was supported only overwhelmingly.</i><br>Mary: <i>So you mean it was not supported <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",32], "Form", {html: "<p>Sue: <i>The wine is palatable.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",32], "Form", {html: "<p>Sue: <i>The wine is bitter.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",32], "Form", {html: "<p>Sue: <i>The wine is only palatable.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",33], "Form", {html: "<p>Sue: <i>The tank is partially full.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> full.</i></p>"}],
[["EX",33], "Form", {html: "<p>Sue: <i>The tank is almost full.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> full.</i></p>"}],
[["Eonly",33], "Form", {html: "<p>Sue: <i>The tank is only partially full.</i><br>Mary: <i>So you mean it is not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> full.</i></p>"}],

[["ESI",34], "Form", {html: "<p>Sue: <i>The club permits dancing.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],
[["EX",34], "Form", {html: "<p>Sue: <i>The club banned dancing.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],
[["Eonly",34], "Form", {html: "<p>Sue: <i>The club only permits dancing.</i><br>Mary: <i>So you mean it does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing.</i></p>"}],

[["ESI",35], "Form", {html: "<p>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",35], "Form", {html: "<p>Sue: <i>Ann's speech was flawed.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",35], "Form", {html: "<p>Sue: <i>Ann's speech was only polished.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",36], "Form", {html: "<p>Sue: <i>Success is possible.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",36], "Form", {html: "<p>Sue: <i>Success is difficult.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",36], "Form", {html: "<p>Sue: <i>Success is only possible.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",37], "Form", {html: "<p>Sue: <i>The girl is pretty.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",37], "Form", {html: "<p>Sue: <i>The girl is ugly.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",37], "Form", {html: "<p>Sue: <i>The girl is only pretty.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",38], "Form", {html: "<p>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Greek.</i></p>"}],
[["EX",38], "Form", {html: "<p>Sue: <i>The residents are possibly Greek.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Greek.</i></p>"}],
[["Eonly",38], "Form", {html: "<p>Sue: <i>The residents are only primarily Greek.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Greek.</i></p>"}],

[["ESI",39], "Form", {html: "<p>Sue: <i>A delay will probably occur.</i><br>Mary: <i>So you mean it will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> occur.</i></p>"}],
[["EX",39], "Form", {html: "<p>Sue: <i>A delay will sometimes occur.</i><br>Mary: <i>So you mean it will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> occur.</i></p>"}],
[["Eonly",39], "Form", {html: "<p>Sue: <i>A delay will only probably occur.</i><br>Mary: <i>So you mean it will not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> occur.</i></p>"}],

[["ESI",40], "Form", {html: "<p>Sue: <i>The city reduced waste.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["EX",40], "Form", {html: "<p>Sue: <i>The city stored waste.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["Eonly",40], "Form", {html: "<p>Sue: <i>The city only reduced waste.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],

[["ESI",41], "Form", {html: "<p>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",41], "Form", {html: "<p>Sue: <i>Stu's daughter was brave.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",41], "Form", {html: "<p>Sue: <i>Stu's daughter was only scared.</i><br>Mary: <i>So you mean she was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",42], "Form", {html: "<p>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",42], "Form", {html: "<p>Sue: <i>Kaye's illness was minor.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",42], "Form", {html: "<p>Sue: <i>Kaye's illness was only serious.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",43], "Form", {html: "<p>Sue: <i>The two paintings are similar.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",43], "Form", {html: "<p>Sue: <i>The two paintings are different.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",43], "Form", {html: "<p>Sue: <i>The two paintings are only similar.</i><br>Mary: <i>So you mean they're not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",44], "Form", {html: "<p>Sue: <i>The train slowed.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",44], "Form", {html: "<p>Sue: <i>The train continued.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",44], "Form", {html: "<p>Sue: <i>The train only slowed.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",45], "Form", {html: "<p>Sue: <i>The fish is small.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",45], "Form", {html: "<p>Sue: <i>The fish is large.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",45], "Form", {html: "<p>Sue: <i>The fish is only small.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",46], "Form", {html: "<p>Sue: <i>The shirt is snug.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",46], "Form", {html: "<p>Sue: <i>The shirt is loose.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",46], "Form", {html: "<p>Sue: <i>The shirt is only snug.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",47], "Form", {html: "<p>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>So you mean she does not trust <input name='blank' size='30' class='obligatory' type='text' autofocus></input> politicians.</i></p>"}],
[["EX",47], "Form", {html: "<p>Sue: <i>Cecilia trusts few politicians.</i><br>Mary: <i>So you mean she does not trust <input name='blank' size='30' class='obligatory' type='text' autofocus></input> politicians.</i></p>"}],
[["Eonly",47], "Form", {html: "<p>Sue: <i>Cecilia trusts only some politicians.</i><br>Mary: <i>So you mean she does not trust <input name='blank' size='30' class='obligatory' type='text' autofocus></input> politicians.</i></p>"}],

[["ESI",48], "Form", {html: "<p>Sue: <i>The runner started.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",48], "Form", {html: "<p>Sue: <i>The runner quit.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",48], "Form", {html: "<p>Sue: <i>The runner only started.</i><br>Mary: <i>So you mean he did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",49], "Form", {html: "<p>Sue: <i>The plant survived.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",49], "Form", {html: "<p>Sue: <i>The plant died.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",49], "Form", {html: "<p>Sue: <i>The plant only survived.</i><br>Mary: <i>So you mean it did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",50], "Form", {html: "<p>Sue: <i>The worker is tired.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",50], "Form", {html: "<p>Sue: <i>The worker is energized.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",50], "Form", {html: "<p>Sue: <i>The worker is only tired.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",51], "Form", {html: "<p>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>So you mean they do not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["EX",51], "Form", {html: "<p>Sue: <i>Joey's parents hate dating.</i><br>Mary: <i>So you mean they do not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],
[["Eonly",51], "Form", {html: "<p>Sue: <i>Joey's parents only tolerate dating.</i><br>Mary: <i>So you mean they do not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it.</i></p>"}],

[["ESI",52], "Form", {html: "<p>Sue: <i>The candidate tried.</i><br>Mary: <i>So you mean she did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",52], "Form", {html: "<p>Sue: <i>The candidate failed.</i><br>Mary: <i>So you mean she did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",52], "Form", {html: "<p>Sue: <i>The candidate only tried.</i><br>Mary: <i>So you mean she did not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",53], "Form", {html: "<p>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",53], "Form", {html: "<p>Sue: <i>The wallpaper is pretty.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",53], "Form", {html: "<p>Sue: <i>The wallpaper is only ugly.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",54], "Form", {html: "<p>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",54], "Form", {html: "<p>Sue: <i>Tom's interview was rushed.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",54], "Form", {html: "<p>Sue: <i>Tom's interview was only understandable.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",55], "Form", {html: "<p>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",55], "Form", {html: "<p>Sue: <i>Tim's bathroom was clean.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",55], "Form", {html: "<p>Sue: <i>Tim's bathroom was only unpleasant.</i><br>Mary: <i>So you mean it was not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",56], "Form", {html: "<p>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> early.</i></p>"}],
[["EX",56], "Form", {html: "<p>Sue: <i>The lawyer is rarely early.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> early.</i></p>"}],
[["Eonly",56], "Form", {html: "<p>Sue: <i>The lawyer is only usually early.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> early.</i></p>"}],

[["ESI",57], "Form", {html: "<p>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> a car.</i></p>"}],
[["EX",57], "Form", {html: "<p>Sue: <i>Phoebe has a car.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> a car.</i></p>"}],
[["Eonly",57], "Form", {html: "<p>Sue: <i>Phoebe only wants a car.</i><br>Mary: <i>So you mean she does not <input name='blank' size='30' class='obligatory' type='text' autofocus></input> a car.</i></p>"}],

[["ESI",58], "Form", {html: "<p>Sue: <i>The weather is warm.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",58], "Form", {html: "<p>Sue: <i>The weather is cold.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",58], "Form", {html: "<p>Sue: <i>The weather is only warm.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",59], "Form", {html: "<p>Sue: <i>The rehearsal went well.</i><br>Mary: <i>So you mean it did not go <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",59], "Form", {html: "<p>Sue: <i>The rehearsal went poorly.</i><br>Mary: <i>So you mean it did not go <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",59], "Form", {html: "<p>Sue: <i>The rehearsal only went well.</i><br>Mary: <i>So you mean it did not go <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],

[["ESI",60], "Form", {html: "<p>Sue: <i>The waiter is willing.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["EX",60], "Form", {html: "<p>Sue: <i>The waiter is bored.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
[["Eonly",60], "Form", {html: "<p>Sue: <i>The waiter is only willing.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],



//Filler items NEED MORE???
["filler1", "Form", {html: "<p>Sue: <i>The table is clean.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler2", "Form", {html: "<p>Sue: <i>The soldier is dangerous.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler3", "Form", {html: "<p>Sue: <i>The man is drunk.</i><br>Mary: <i>So you mean he's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler4", "Form", {html: "<p>Sue: <i>The neighbor is poor.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler5", "Form", {html: "<p>Sue: <i>The gymnast is married.</i><br>Mary: <i>So you mean she's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler6", "Form", {html: "<p>Sue: <i>The doll is new.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}],
["filler7", "Form", {html: "<p>Sue: <i>The street is wide.</i><br>Mary: <i>So you mean it's not <input name='blank' size='30' class='obligatory' type='text' autofocus></input>.</i></p>"}]// NOTE NO COMMA

];
