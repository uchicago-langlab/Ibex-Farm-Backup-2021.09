var shuffleSequence = seq('consent', 'intro', 'practice1', 'practice2', 'end_practice', rshuffle(startsWith('item-')), 'questionnaire', 'exit');

// rshuffle(rshuffle(startsWith('shape_')), rshuffle(startsWith('artifact_')))

var showProgressBar = false;
var pageTitle = "Mechanical Turk Experiment";
// "The results were successfully sent to the server.
// You can now validate your participation on Mechanical Turk. Thanks!"
var completionMessage = "your results have been submitted -- thank you!";
// "There was an error sending the results to the server.
var completionErrorMessage = "something went wrong";

var defaults = [
    "Separator", {
        transfer: 350,
        normalMessage: "+",
        errorMessage: "+",
        ignoreFailure: true
    },
    "Message", {
        hideProgressBar: false,
        transfer: "keypress"
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true
    },
];


var items = [

    ["sep", "Separator", { }],

    ["consent", "Form", {
        consentRequired: true,
        html: {include: "consent.html"}
    }],

    ["intro", "Form", {
        html: {include: "instructions.html"},
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    }],

    ["questionnaire", "Form", {
        html: {include: "questionnaire.html"},
        continueMessage: "click here to obtain an MTurk validation code"
    }],

    ["exit", "Form", {
        html: {include: "exit.html"},
        continueMessage: "click here to submit your reults!"
    }],
                
    ["practice1", "PictureSelect", {
         html: {include: "practice1.html"},
         prompt: 'Speaker: I saw a diamond. It was colorful.<br/><br/>Make a guess: How colorful was the diamond that the speaker saw? Choose one image from below.'
    }],


    ["end_practice", "Message", {
                consentRequired: false,
                transfer: "click",
                continueMessage: "Click here to begin the experiment.",
                html: "<div><p>You have finished the practice section.</p><p>For the rest of the study, for each sentence you will see, please <b>read the question carefully. </b></p>",
    }],


     // Green cube
    [["item-full",1], "PictureSelect", {html: {include: "item_shape_empty_full_full_greencube.html"}, prompt: 'Speaker: I saw a cube. It was full.<br/><br/>Make a guess: How full was the cube that the speaker saw? Choose one image from below.'}],
    [["item-empty",1], "PictureSelect", {html: {include: "item_shape_empty_full_full_greencube.html"}, prompt: 'Speaker: I saw a cube. It was empty.<br/><br/>Make a guess: How empty was the cube that the speaker saw? Choose one image from below.'}],

     // Yellow cube
    [["item-full",2], "PictureSelect", {html: {include: "item_shape_empty_full_full_yellowcube.html"}, prompt: 'Speaker: I saw a cube. It was full.<br/><br/>Make a guess: How full was the cube that the speaker saw? Choose one image from below.'}],
    [["item-empty", 2],"PictureSelect", {html: {include: "item_shape_empty_full_full_yellowcube.html"}, prompt: 'Speaker: I saw a cube. It was empty.<br/><br/>Make a guess: How empty was the cube that the speaker saw? Choose one image from below.'}],

     // Blue arrow
    [["item-bent", 3],"PictureSelect", {html: {include: "item_shape_straight_bent_bent_bluearrow.html"}, prompt: 'Speaker: I saw an arrow. It was bent.<br/><br/>Make a guess: How bent was the arrow that the speaker saw? Choose one image from below.'}],
    [["item-straight", 3],"PictureSelect", {html: {include: "item_shape_straight_bent_bent_bluearrow.html"}, prompt: 'Speaker: I saw an arrow. It was straight.<br/><br/>Make a guess: How straight was the arrow that the speaker saw? Choose one image from below.'}],

    // Green arrow
    [["item-bent",4], "PictureSelect", {html: {include: "item_shape_straight_bent_bent_greenarrow.html"}, prompt: 'Speaker: I saw an arrow. It was bent.<br/><br/>Make a guess: How bent was the arrow that the speaker saw? Choose one image from below.'}],
    [["item-straight",4], "PictureSelect", {html: {include: "item_shape_straight_bent_bent_greenarrow.html"}, prompt: 'Speaker: I saw an arrow. It was straight.<br/><br/>Make a guess: How straight was the arrow that the speaker saw? Choose one image from below.'}],

    // Red square
    [["item-big", 5],"PictureSelect", {html: {include: "item_shape_small_big_big_redsquare.html"}, prompt: 'Speaker: I saw a square. It was big.<br/><br/>Make a guess: How big was the square that the speaker saw? Choose one image from below.'}],
    [["item-small",5], "PictureSelect", {html: {include: "item_shape_small_big_big_redsquare.html"}, prompt: 'Speaker: I saw a square. It was small.<br/><br/>Make a guess: How small was the square that the speaker saw? Choose one image from below.'}],

    // Yellow circle
    [["item-big", 6],"PictureSelect", {html: {include: "item_shape_small_big_big_yellowcircle.html"}, prompt: 'Speaker: I saw a circle. It was big.<br/><br/>Make a guess: How big was the circle that the speaker saw? Choose one image from below.'}],
    [["item-small",6], "PictureSelect", {html: {include: "item_shape_small_big_big_yellowcircle.html"}, prompt: 'Speaker: I saw a circle. It was small.<br/><br/>Make a guess: How small was the circle that the speaker saw? Choose one image from below.'}],

    // Green oval
    [["item-wide", 7],"PictureSelect", {html: {include: "item_shape_narrow_wide_wide_greenoval.html"}, prompt: 'Speaker: I saw an oval. It was wide.<br/><br/>Make a guess: How wide was the oval that the speaker saw? Choose one image from below.'}],
    [["item-narrow",7], "PictureSelect", {html: {include: "item_shape_narrow_wide_wide_greenoval.html"}, prompt: 'Speaker: I saw an oval. It was narrow.<br/><br/>Make a guess: How narrow was the oval that the speaker saw? Choose one image from below.'}],

    // Red oval
    [["item-wide", 8],"PictureSelect", {html: {include: "item_shape_narrow_wide_wide_redoval.html"}, prompt: 'Speaker: I saw an oval. It was wide.<br/><br/>Make a guess: How wide was the oval that the speaker saw? Choose one image from below.'}],
    [["item-narrow",8], "PictureSelect", {html: {include: "item_shape_narrow_wide_wide_redoval.html"}, prompt: 'Speaker: I saw an oval. It was narrow.<br/><br/>Make a guess: How narrow was the oval that the speaker saw? Choose one image from below.'}],

    // Red circle
    [["item-striped",9],"PictureSelect", {html: {include: "item_shape_plain_striped_stripedd_redcircle.html"}, prompt: 'Speaker: I saw a circle. It was striped.<br/><br/>Make a guess: How striped was the circle that the speaker saw? Choose one image from below.'}],
    [["item-plain",9], "PictureSelect", {html: {include: "item_shape_plain_striped_stripedd_redcircle.html"}, prompt: 'Speaker: I saw a circle. It was plain.<br/><br/>Make a guess: How plain was the circle that the speaker saw? Choose one image from below.'}],

    // Yellow square
    [["item-striped",10], "PictureSelect", {html: {include: "item_shape_plain_striped_stripedd_yellowsquare.html"}, prompt: 'Speaker: I saw a square. It was striped.<br/><br/>Make a guess: How striped was the square that the speaker saw? Choose one image from below.'}],
    [["item-plain",10], "PictureSelect", {html: {include: "item_shape_plain_striped_stripedd_yellowsquare.html"}, prompt: 'Speaker: I saw a square. It was plain.<br/><br/>Make a guess: How plain was the square that the speaker saw? Choose one image from below.'}],

    // Green cylinder
    [["item-tall", 11],"PictureSelect", {html: {include: "item_shape_short_tall_tall_greencylinder.html"}, prompt: 'Speaker: I saw a cylinder. It was tall.<br/><br/>Make a guess: How tall was the cylinder that the speaker saw? Choose one image from below.'}],
    [["item-short", 11],"PictureSelect", {html: {include: "item_shape_short_tall_tall_greencylinder.html"}, prompt: 'Speaker: I saw a cylinder. It was short.<br/><br/>Make a guess: How short was the cylinder that the speaker saw? Choose one image from below.'}],

    // Green spiral
    [["item-tall",12], "PictureSelect", {html: {include: "item_shape_short_tall_tall_greenspiral.html"}, prompt: 'Speaker: I saw a spiral. It was tall.<br/><br/>Make a guess: How tall was the spiral that the speaker saw? Choose one image from below.'}],
    [["item-short",12], "PictureSelect", {html: {include: "item_shape_short_tall_tall_greenspiral.html"}, prompt: 'Speaker: I saw a spiral. It was short.<br/><br/>Make a guess: How short was the spiral that the speaker saw? Choose one image from below.'}],

    // BLue circle
    [["item-open", 13],"PictureSelect", {html: {include: "item_shape_closed_open_open_bluecircle.html"}, prompt: 'Speaker: I saw a circle. It was open.<br/><br/>Make a guess: How open was the circle that the speaker saw? Choose one image from below.'}],
    [["item-closed",13], "PictureSelect", {html: {include: "item_shape_closed_open_open_bluecircle.html"}, prompt: 'Speaker: I saw a circle. It was closed.<br/><br/>Make a guess: How closed was the circle that the speaker saw? Choose one image from below.'}],

    // Red triangle
    [["item-open", 14],"PictureSelect", {html: {include: "item_shape_closed_open_open_redtriangle.html"}, prompt: 'Speaker: I saw a triangle. It was open.<br/><br/>Make a guess: How open was the triangle that the speaker saw? Choose one image from below.'}],
    [["item-closed",14], "PictureSelect", {html: {include: "item_shape_closed_open_open_redtriangle.html"}, prompt: 'Speaker: I saw a triangle. It was closed.<br/><br/>Make a guess: How closed was the triangle that the speaker saw? Choose one image from below.'}],

    // Blue line
    [["item-curved",15], "PictureSelect", {html: {include: "item_shape_straight_curved_curved_blueline.html"}, prompt: 'Speaker: I saw a line. It was curved.<br/><br/>Make a guess: How curved was the line that the speaker saw? Choose one image from below.'}],
    [["item-straight",15], "PictureSelect", {html: {include: "item_shape_straight_curved_curved_blueline.html"}, prompt: 'Speaker: I saw a line. It was straight.<br/><br/>Make a guess: How straight was the line that the speaker saw? Choose one image from below.'}],

    // Palm
    [["item-curved",16], "PictureSelect", {html: {include: "item_shape_straight_curved_curved_greenline.html"}, prompt: 'Speaker: I saw a line. It was curved.<br/><br/>Make a guess: How curved was the line that the speaker saw? Choose one image from below.'}],
    [["item-straight",16], "PictureSelect", {html: {include: "item_shape_straight_curved_curved_greenline.html"}, prompt: 'Speaker: I saw a line. It was straight.<br/><br/>Make a guess: How straight was the line that the speaker saw? Choose one image from below.'}],

    // Yellow circle
    [["item-spotted",17], "PictureSelect", {html: {include: "item_shape_plain_spotted_spotted_yellowcircle.html"}, prompt: 'Speaker: I saw a circle. It was spotted.<br/><br/>Make a guess: How spotted was the circle that the speaker saw? Choose one image from below.'}],
    [["item-plain", 17],"PictureSelect", {html: {include: "item_shape_plain_spotted_spotted_yellowcircle.html"}, prompt: 'Speaker: I saw a circle. It was plain.<br/><br/>Make a guess: How plain was the circle that the speaker saw? Choose one image from below.'}],

    // Yellow square
    [["item-spotted",18], "PictureSelect", {html: {include: "item_shape_plain_spotted_spotted_yellowsquare.html"}, prompt: 'Speaker: I saw a square. It was spotted.<br/><br/>Make a guess: How spotted was the square that the speaker saw? Choose one image from below.'}],
    [["item-plain",18], "PictureSelect", {html: {include: "item_shape_plain_spotted_spotted_yellowsquare.html"}, prompt: 'Speaker: I saw a square. It was plain.<br/><br/>Make a guess: How plain was the square that the speaker saw? Choose one image from below.'}],

    // Blue arrow
    [["item-thick", 19],"PictureSelect", {html: {include: "item_shape_thin_thick_thick_bluearrow.html"}, prompt: 'Speaker: I saw an arrow. It was thick.<br/><br/>Make a guess: How thick was the arrow that the speaker saw? Choose one image from below.'}],
    [["item-thin", 19],"PictureSelect", {html: {include: "item_shape_thin_thick_thick_bluearrow.html"}, prompt: 'Speaker: I saw an arrow. It was thin.<br/><br/>Make a guess: How thin was the arrow that the speaker saw? Choose one image from below.'}],

    // Book
    [["item-thick",20], "PictureSelect", {html: {include: "item_shape_thin_thick_thick_redarrow.html"}, prompt: 'Speaker: I saw an arrow. It was thick.<br/><br/>Make a guess: How thick was the arrow that the speaker saw? Choose one image from below.'}],
    [["item-thin",20], "PictureSelect", {html: {include: "item_shape_thin_thick_thick_redarrow.html"}, prompt: 'Speaker: I saw an arrow. It was thin.<br/><br/>Make a guess: How thin was the arrow that the speaker saw? Choose one image from below.'}],

    // Noodle
    [["item-long", 21],"PictureSelect", {html: {include: "item_shape_short_long_long_greenarrow.html"}, prompt: 'Speaker: I saw an arrow. It was long.<br/><br/>Make a guess: How long was the arrow that the speaker saw? Choose one image from below.'}],
    [["item-short",21], "PictureSelect", {html: {include: "item_shape_short_long_long_greenarrow.html"}, prompt: 'Speaker: I saw an arrow. It was short.<br/><br/>Make a guess: How short was the arrow that the speaker saw? Choose one image from below.'}],

    // Green line
    [["item-long", 22],"PictureSelect", {html: {include: "item_shape_short_long_long_greenline.html"}, prompt: 'Speaker: I saw a line. It was long.<br/><br/>Make a guess: How long was the line that the speaker saw? Choose one image from below.'}],
    [["item-short",22], "PictureSelect", {html: {include: "item_shape_short_long_long_greenline.html"}, prompt: 'Speaker: I saw a line. It was short.<br/><br/>Make a guess: How short was the line that the speaker saw? Choose one image from below.'}],

    // Blue square
    [["item-bumpy",23], "PictureSelect", {html: {include: "item_shape_smooth_bumpy_bumpy_bluesquare.html"}, prompt: 'Speaker: I saw a square. It was bumpy.<br/><br/>Make a guess: How bumpy was the square that the speaker saw? Choose one image from below.'}],
    [["item-smooth",23], "PictureSelect", {html: {include: "item_shape_smooth_bumpy_bumpy_bluesquare.html"}, prompt: 'Speaker: I saw a square. It was smooth.<br/><br/>Make a guess: How smooth was the square that the speaker saw? Choose one image from below.'}],


    // Red square
    [["item-bumpy",24], "PictureSelect", {html: {include: "item_shape_smooth_bumpy_bumpy_redsquare.html"}, prompt: 'Speaker: I saw a square. It was bumpy.<br/><br/>Make a guess: How bumpy was the square that the speaker saw? Choose one image from below.'}],
    [["item-smooth", 24],"PictureSelect", {html: {include: "item_shape_smooth_bumpy_bumpy_redsquare.html"}, prompt: 'Speaker: I saw a square. It was smooth.<br/><br/>Make a guess: How smooth was the square that the speaker saw? Choose one image from below.'}]


 ];
