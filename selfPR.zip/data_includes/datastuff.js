var shuffleSequence = seq("intro","setcounter","practice", "presep", sepWith("sep", rshuffle(startsWith("EP"),startsWith("EH"))), "exit");
var practiceItemTypes = ["practice"];

//var progressBarText = "Your current progress"
//var completionMessage = "Congrats. You finished！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "+",
        ignoreFailure: true
    },
    
    "DashedSentence", {
        mode: "self-paced reading",
        display: "dashed"
    },
   "Question", {as: ["Yes", "No"]},
    
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var DS = "DashedSentence";
var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],


["setcounter", "__SetCounter__", { }],


["sep", Separator, { }],
   ["practice", DS, {s: ["This is", "a practice sentence", "to get you used," "to the method of presentation."]}, "Question", {q: "Do you understand?"}],
 
    ["practice", DS, {s: ["The plumber", "working", "in the bathroom", "found a penny."]}, "Question", {q: "Did she find a dime?"}],
    
    ["practice", DS, {s: ["The pop star", "sang", "the audience", "a song about love", "at the concert", "last night."]}, "Question", {q: "Did she sing about love?"}],
 
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The practice session is over now. You will start the experiment now. Pleae press the spacebar to continue"],
                          ]}],
    
   
    ["presep", Separator, { transfer: 2000, normalMessage: "Please get ready. We will start. Please wait..." }],


[["EH_a", 1], DS, {s: ["The baseball player", "spoke about", "the bat", "with the ball", "during the game."]}, "Question", {q: "Is the person talking about a flying mammal?", hasCorrect : 0}],
[["EH_b", 1], DS, {s: ["The cave explorer", "spoke about", "the bat", "on the ceiling", "and a few insects."]}, "Question", {q: "Is the person talking about a flying mammal?", hasCorrect : 1}],
[["EH_aa", 1], DS, {s: ["Paulina", "spoke about", "the bat", "with the ball", "during the game."]}, "Question", {q: "Is the person talking about a flying mammal?", hasCorrect : 0}],
[["EH_bb", 1], DS, {s: ["Paulina", "spoke about", "the bat", "on the ceiling", "and a few insects."]}, "Question", {q: "Is the person talking about a flying mammal?", hasCorrect : 1}],
[["EH_a", 2], DS, {s: ["The mailman", "brought up", "the seal", "on the envelope", "of the official document."]}, "Question", {q: "Is the person talking about an official stamp on a letter?", hasCorrect : 1}],
[["EH_b", 2], DS, {s: ["The surfer", "brought up", "the seal", "on the beach", "of his favorite surf spot."]}, "Question", {q: "Is the person talking about an official stamp on a letter?", hasCorrect : 0}],
[["EH_aa", 2], DS, {s: ["Kevin", "brought up", "the seal", "on the envelope", "of the official document."]}, "Question", {q: "Is the person talking about an official stamp on a letter?", hasCorrect : 1}],
[["EH_bb", 2], DS, {s: ["Kevin", "brought up", "the seal", "on the beach", "of his favorite surf spot."]}, "Question", {q: "Is the person talking about an official stamp on a letter?", hasCorrect : 0}],

    
    
[["EP_a", 1], DS, {s: ["The sales woman", "called attention to", "the dress", "on the mannequin", "by the door."]}, "Question", {q: "Is the person talking about an article of clothing?", hasCorrect : 1}],
[["EP_b", 1], DS, {s: ["The historian", "called attention to", "the dress", "and style of", "the youth in that era."]}, "Question", {q: "Is the person talking about an article of clothing?", hasCorrect : 0}],
[["EP_aa", 1], DS, {s: ["Gary", "called attention to", "the dress", "on the mannequin", "by the door."]}, "Question", {q: "Is the person talking about an article of clothing?", hasCorrect : 1}],
[["EP_bb", 1], DS, {s: ["Gary", "called attention to", "the dress", "and style of", "the youth in that era."]}, "Question", {q: "Is the person talking about an article of clothing?", hasCorrect : 0}],
[["EP_a", 2], DS, {s: ["The gardener", "alluded to", "the fig", "on the tree", "in the backyard."]}, "Question", {q: "Is the person talking about a whole piece of fruit?", hasCorrect : 1}],
[["EP_b", 2], DS, {s: ["The chef", "alluded to", "the fig", "in the cake", "for the customers."]}, "Question", {q: "Is the person talking about a whole piece of fruit?", hasCorrect : 0}],
[["EP_aa", 2], DS, {s: ["Christina", "alluded to", "the fig", "on the tree", "in the backyard."]}, "Question", {q: "Is the person talking about a whole piece of fruit?", hasCorrect : 1}],
[["EP_bb", 2], DS, {s: ["Christina", "alluded to", "the fig", "in the cake", "for the customers."]}, "Question", {q: "Is the person talking about a whole piece of fruit?", hasCorrect : 0}],
    
    
];

