define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});

var shuffleSequence = seq("setcounter","consent", "intro1","intro2",
                      sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit"  );

var completionMessage = "Thank you for your participation!"

var defaults = [
    "Separator", {
          transfer: 200,
          hideProgressBar: true,
        normalMessage: ""
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        leftComment: "very unnatural", rightComment: "very natural"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];



var items = [

    ["sep", "Separator", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html"}}],
    
    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],

     ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: guess what Mary's question was, given the rest of the dialogue and the conclusion she draw from it."] 
],continueMessage:"Click here to start the experiment."}],
 
  ["setcounter", "__SetCounter__", { }],
    
// items

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The bus driver is angry.</i><br><br>**Mary concludes that<b> the bus driver is not furious.</b>**</p>"}],

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The soldier is dangerous.</i><br><br>**Mary concludes that<b> the soldier is not harmless.</b>**</p>"}], 

["practice", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wrestler is strong.</i><br><br>**Mary concludes that<b> the wrestler is not weak.</b>**</p>"}], 

[["Eliteral",1], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Drinking is allowed.</i><br><br>**Mary concludes that<b> drinking is not obligatory.</b>**</p>"}],

[["Eliteral",2], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br> Sue: <i>The model is attractive.</i><br><br>**Mary concludes that<b> the model is not stunning.</b>**</p>"}],
  
    [["Eliteral",3], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>John began the race.</i><br><br>**Mary concludes that<b> John did not finish the race.</b>**</p>"}],
 
    [["Eliteral",4], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teacher believes it is true.</i><br><br>**Mary concludes that<b> the teacher doesn't know it is true.</b>**</p>"}], 

[["Eliteral",5], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The elephant is big.</i><br><br>**Mary concludes that<b> the elephant is not enormous.</b>**</p>"}], 

[["Eliteral",6], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is cool.</i><br><br>**Mary concludes that<b> the weather is not cold.</b>**</p>"}], 

[["Eliteral",7], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The machine damaged itself.</i><br><br>**Mary concludes that<b> the machine didn't destroy itself.</b>**</p>"}], 

[["Eliteral",8], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sky is dark.</i><br><br>**Mary concludes that<b> the sky is not black.</b>**</p>"}],

[["Eliteral",9], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The task is difficult.</i><br><br>**Mary concludes that<b> the task is not impossible.</b>**</p>"}], 

[["Eliteral",10], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Zack's carpet was dirty.</i><br><br>**Mary concludes that<b> Zack's carpet was not filthy.</b>**</p>"}], 

[["Eliteral",11], "Form",       {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The doctor dislikes coffee.</i><br><br>**Mary concludes that<b> the doctor doesn't loathe coffee.</b>**</p>"}],  

[["Eliteral",12], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The sales will double. </i><br><br>**Mary concludes that<b> the sales won't triple.</b>**</p>"}],

[["Eliteral",13], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>That candidate is equally skilled.</i><br><br>**Mary concludes that<b> the candidate is not more skilled.</b>**</p>"}], 

[["Eliteral",14], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is funny.</i><br><br>**Mary concludes that<b> the movie is not hilarious.</b>**</p>"}], 

[["Eliteral",15], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The movie is good.</i><br><br>**Mary concludes that<b> the movie is not excellent.</b>**</p>"}], 

[["Eliteral",16], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The winner was happy.</i><br><br>**Mary concludes that<b> the winner was not ecstatic.</b>**</p>"}], 

[["Eliteral",17], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The problem is hard.</i><br><br>**Mary concludes that<b> the problem is not unsolvable.</b>**</p>"}], 

[["Eliteral",18], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The toxin is harmful.</i><br><br>**Mary concludes that<b> the toxin is not deadly.</b>**</p>"}], 

[["Eliteral",19], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>There is water here.</i><br><br>**Mary concludes that<b> there isn't water everywhere.</b>**</p>"}], 

[["Eliteral",20], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The boy is hungry.</i><br><br>**Mary concludes that<b> the boy is not starving.</b>**</p>"}], 

[["Eliteral",21], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The student is intelligent.</i><br><br>**Mary concludes that<b> the student is not brilliant.</b>**</p>"}], 

[["Eliteral",22], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Chris's opponent was intimidating.</i><br><br>**Mary concludes that<b> Chris's opponent was not terrifying.</b>**</p>"}], 

[["Eliteral",23], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The coast was largely flooded.</i><br><br>**Mary concludes that<b> the coast was not totally flooded.</b>**</p>"}],  

[["Eliteral",24], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The princess likes dancing.</i><br><br>**Mary concludes that<b> the princess doesn't love dancing.</b>**</p>"}],

[["Eliteral",25], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Bill's score matches Al's.</i><br><br>**Mary concludes that<b> Bill's score doesn't exceed Al's.</b>**</p>"}], 

[["Eliteral",26], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Peter's answers were mostly wrong.</i><br><br>**Mary concludes that<b> Peter's answers were not entirely wrong.</b>**</p>"}], 

[["Eliteral",27], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The house is old.</i><br><br>**Mary concludes that<b> the house is not ancient.</b>**</p>"}], 

[["Eliteral",28], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Mistakes happened once.</i><br><br>**Mary concludes that<b> mistakes didn't happen twice.</b>**</p>"}], 

[["Eliteral",29], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Jimmy writes books or plays.</i><br><br>**Mary concludes that<b> Jimmy doesn't write books and plays.</b>**</p>"}], 

[["Eliteral",30], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The teenager is overweight.</i><br><br>**Mary concludes that<b> the teenager is not obese.</b>**</p>"}], 

// [["Eliteral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br><br>**Mary concludes that<b> it was not supported unanimously.</b>**</p>"}],  
// [["Eimplicature",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br><br>**Mary concludes that<b> it might have been supported unanimously.</b>**</p>"}], 
// [["Eneutral",31], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The measure was supported overwhelmingly.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br><br>**Mary concludes that<b> it is not delicious.</b>**</p>"}], 
// [["Eimplicature",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br><br>**Mary concludes that<b> it might be delicious.</b>**</p>"}],  
// [["Eneutral",32], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wine is palatable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br><br>**Mary concludes that<b> it is not completely fully.</b>**</p>"}], 
// [["Eimplicature",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br><br>**Mary concludes that<b> it might be completely full.</b>**</p>"}], 
// [["Eneutral",33], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The tank is partially full.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br><br>**Mary concludes that<b> it doesn't require dancing.</b>**</p>"}], 
// [["Eimplicature",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br><br>**Mary concludes that<b> it might require dancing.</b>**</p>"}], 
// [["Eneutral",34], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The club permits dancing.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br><br>**Mary concludes that<b> it wasn't impeccable.</b>**</p>"}], 
// [["Eimplicature",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br><br>**Mary concludes that<b> it might have been impeccable.</b>**</p>"}],  
// [["Eneutral",35], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Ann's speech was polished.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br><br>**Mary concludes that<b> it isn't certain.</b>**</p>"}],  
// [["Eimplicature",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br><br>**Mary concludes that<b> it might be certain.</b>**</p>"}], 
// [["Eneutral",36], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Success is possible.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br><br>**Mary concludes that<b> she's not beautiful.</b>**</p>"}],  
// [["Eimplicature",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br><br>**Mary concludes that<b> she might be beautiful.</b>**</p>"}],  
// [["Eneutral",37], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The girl is pretty.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br><br>**Mary concludes that<b> they're not exclusively Greek.</b>**</p>"}], 
// [["Eimplicature",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br><br>**Mary concludes that<b> they might be exclusively Greek.</b>**</p>"}],  
// [["Eneutral",38], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The residents are primarily Greek.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br><br>**Mary concludes that<b> a delay won't necessarily ocucr.</b>**</p>"}], 
// [["Eimplicature",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br><br>**Mary concludes that<b> it might be the case that a delay will necessarily occur.</b>**</p>"}], 
// [["Eneutral",39], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>A delay will probably occur.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br><br>**Mary concludes that<b> it didn't eliminate waste.</b>**</p>"}],
// [["Eimplicature",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br><br>**Mary concludes that<b> it might have eliminated waste.</b>**</p>"}],
// [["Eneutral",40], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The city reduced waste.</i><br>Mary: <i>Oh, I see.</i></p>"}],

// [["Eliteral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br><br>**Mary concludes that<b> she was not petrified.</b>**</p>"}], 
// [["Eimplicature",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br><br>**Mary concludes that<b> she might have been petrified.</b>**</p>"}],  
// [["Eneutral",41], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Stu's daughter was scared.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br><br>**Mary concludes that<b> it wasn't life-threatening.</b>**</p>"}],  
// [["Eimplicature",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br><br>**Mary concludes that<b> it might have been life-threatening.</b>**</p>"}],  
// [["Eneutral",42], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Kaye's illness was serious.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br><br>**Mary concludes that<b> they are not identical.</b>**</p>"}],
// [["Eimplicature",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br><br>**Mary concludes that<b> they might be identical.</b>**</p>"}],  
// [["Eneutral",43], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The two paintings are similar.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br><br>**Mary concludes that<b> it didn't stop.</b>**</p>"}], 
// [["Eimplicature",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br><br>**Mary concludes that<b> it might have stopped.</b>**</p>"}], 
// [["Eneutral",44], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The train slowed.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br><br>**Mary concludes that<b> it is not tiny.</b>**</p>"}], 
// [["Eimplicature",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br><br>**Mary concludes that<b> it might be tiny.</b>**</p>"}], 
// [["Eneutral",45], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The fish is small.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br><br>**Mary concludes that<b> it is not tight.</b>**</p>"}],
// [["Eimplicature",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br><br>**Mary concludes that<b> it might be tight.</b>**</p>"}],
// [["Eneutral",46], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The shirt is snug.</i><br>Mary: <i>Oh, I see.</i></p>"}],

//  [["Eliteral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br><br>**Mary concludes that<b> she doesn't trust all politicians.</b>**</p>"}],  
// [["Eimplicature",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br><br>**Mary concludes that<b> she might trust all politicians.</b>**</p>"}], 
// [["Eneutral",47], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Cecilia trusts some politicians.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br><br>**Mary concludes that<b> he didn't finish.</b>**</p>"}],  
// [["Eimplicature",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br><br>**Mary concludes that<b> he might have finished.</b>**</p>"}], 
// [["Eneutral",48], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The runner started.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br><br>**Mary concludes that<b> it didn't thrive.</b>**</p>"}],  
// [["Eimplicature",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br><br>**Mary concludes that<b> it might have thrived.</b>**</p>"}], 
// [["Eneutral",49], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The plant survived.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br><br>**Mary concludes that<b> she's not exhausted.</b>**</p>"}], 
// [["Eimplicature",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br><br>**Mary concludes that<b> she might be exhausted.</b>**</p>"}],  
// [["Eneutral",50], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The worker is tired.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br><br>**Mary concludes that<b> they don't encourage dating.</b>**</p>"}],  
// [["Eimplicature",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br><br>**Mary concludes that<b> they might encourage dating.</b>**</p>"}],  
// [["Eneutral",51], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Joey's parents tolerate dating.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br><br>**Mary concludes that<b> she didn't succeed.</b>**</p>"}],  
// [["Eimplicature",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br><br>**Mary concludes that<b> she might have succeeded.</b>**</p>"}], 
// [["Eneutral",52], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The candidate tried.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br><br>**Mary concludes that<b> it is not hideous.</b>**</p>"}],  
// [["Eimplicature",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br><br>**Mary concludes that<b> it might be hideous.</b>**</p>"}],  
// [["Eneutral",53], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The wallpaper is ugly.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br><br>**Mary concludes that<b> it was not articulate.</b>**</p>"}], 
// [["Eimplicature",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br><br>**Mary concludes that<b> it might have been articulate.</b>**</p>"}],  
// [["Eneutral",54], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tom's interview was understandable.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br><br>**Mary concludes that<b> it was not disgusting.</b>**</p>"}],  
// [["Eimplicature",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br><br>**Mary concludes that<b> it might have been disgusting.</b>**</p>"}],  
// [["Eneutral",55], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Tim's bathroom was unpleasant.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br><br>**Mary concludes that<b> she's not always early.</b>**</p>"}], 
// [["Eimplicature",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br><br>**Mary concludes that<b> she might always be early.</b>**</p>"}], 
// [["Eneutral",56], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The lawyer is usually early.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br><br>**Mary concludes that<b> she doesn't need a car.</b>**</p>"}], 
// [["Eimplicature",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br><br>**Mary concludes that<b> she might need a car.</b>**</p>"}], 
// [["Eneutral",57], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>Phoebe wants a car.</i><br>Mary: <i>Oh, I see.</i></p>"}], 

// [["Eliteral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br><br>**Mary concludes that<b> it is not hot.</b>**</p>"}],  
// [["Eimplicature",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br><br>**Mary concludes that<b> it might be hot.</b>**</p>"}],  
// [["Eneutral",58], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The weather is warm.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br><br>**Mary concludes that<b> it didn't go superbly.</b>**</p>"}],  
// [["Eimplicature",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br><br>**Mary concludes that<b> it might have gone superbly.</b>**</p>"}],  
// [["Eneutral",59], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The rehearsal went well.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

// [["Eliteral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br><br>**Mary concludes that<b> he is not eager.</b>**</p>"}],  
// [["Eimplicature",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br><br>**Mary concludes that<b> he might be eager.</b>**</p>"}],  
// [["Eneutral",60], "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The waiter is willing.</i><br>Mary: <i>Oh, I see.</i></p>"}],  

["filler1", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The table is clean.</i><br><br>**Mary concludes that<b> the table is not dirty.</b>**</p>"}], 
["filler2", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The man is drunk.</i><br><br>**Mary concludes that<b> the man is not sober.</b>**</p>"}],  
["filler3", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The neighbor is sleepy.</i><br><br>**Mary concludes that<b> the neighbor is not alert.</b>**</p>"}],  
["filler4", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The gymnast is tall.</i><br><br>**Mary concludes that<b> the gymnast is not short.</b>**</p>"}], 
["filler5", "Form", {html: "<p>Mary: <i><input name='blank' size='40' class='obligatory' type='text' autofocus></input>?</i><br>Sue: <i>The street is wide.</i><br><br>**Mary concludes that<b> the street is not narrow.</b>**</p>"}]// NOTE NO COMMA


    
    ];