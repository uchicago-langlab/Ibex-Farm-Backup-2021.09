var shuffleSequence = seq("setcounter","Consent","Demographics","Instructions", sepWith("sep", rshuffle(startsWith("Q"))),"Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        leftComment: "Less natural",
        rightComment: "More natural",
        instructions: " ",
        randomOrder: false,
        hasCorrect: false,
        as: ["1","2","3","4","5","6","7"]
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

["setcounter", "__SetCounter__", { }],

["Consent", "Form", {consentRequired: true, html: {include: "Consent.html" }} ],    
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions1.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions2.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],

    
  
["sep", "Separator", {hideProgressBar: true, transfer: 500, normalMessage: " "}],
  
  
  
  
  




    
    
      
  
["Practice", "Message", {hideProgressBar: true, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">How nice of you.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {hideProgressBar: true, s: { html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/nice.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the pronunciation of the sentence seemed fairly typical. You probably selected a high number, like 5, 6, or 7.</p><p>Press any key to continue.</p>'}],  
  
  
["Practice", "Message", {hideProgressBar: true, consentRequired: false, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">If he calls, ask him to leave a message.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/message.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the sentence was not pronounced in a typical way. You probably selected a lower number, like 1, 2, or 3.</p><p>Press any key to continue.</p>'}],       
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],  
  




[["Q25NN", 145], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Scarlett helped Bill, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q25NO", 146], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Minerva helped Doug, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q25RN", 147], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Morgan despised Bill, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q25RO", 148], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Marcus despised Doug, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q25ON", 149], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Seamus hated Bill, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q25OO", 150], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The competitive game show became more heated. </font></p><p><font size="4">Thomas hated Doug, and Mary hated Doug, too.</font></p><p><font size="4">It was an exciting episode for the viewers. </font></p></center>', transfer: "click"}],
[["Q26NN", 151], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Ben replaced Asher, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q26NO", 152], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Dan replaced Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q26RN", 153], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Will watched Asher, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q26RO", 154], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Max watched Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q26ON", 155], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Donald saw Asher, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q26OO", 156], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Angus saw Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],
[["Q27NN", 157], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Darren pleased Johnny, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q27NO", 158], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Maggie pleased Jeffrey, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q27RN", 159], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Zach terrified Johnny, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q27RO", 160], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Mark terrified Jeffrey, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q27ON", 161], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Donny scared Johnny, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q27OO", 162], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Halloween costume party was at my house. </font></p><p><font size="4">Allan scared Jeffrey, and Frank scared Jeffrey, too.</font></p><p><font size="4">I want to host it again next year. </font></p></center>', transfer: "click"}],
[["Q28NN", 163], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Harrison sheltered Steven, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q28NO", 164], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Raphael sheltered Mabel, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q28RN", 165], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Zander perverted Steven, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q28RO", 166], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Norman perverted Mabel, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q28ON", 167], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Tammy corrupted Steven, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q28OO", 168], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We hired bad camp counselors for the summer. </font></p><p><font size="4">Hubert corrupted Mabel, and Jordan corrupted Mabel, too.</font></p><p><font size="4">We might never hire from high schools again. </font></p></center>', transfer: "click"}],
[["Q29NN", 169], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Angelica served Mac, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q29NO", 170], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Jeremiah served Rex, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q29RN", 171], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Katarina tainted Mac, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q29RO", 172], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Elizabeth tainted Rex, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q29ON", 173], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Don contaminated Mac, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q29OO", 174], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Most of the kitchen workers were catching the flu.</font></p><p><font size="4">Moe contaminated Rex, and James contaminated Rex, too.</font></p><p><font size="4">The entire staff should take the week off from work. </font></p></center>', transfer: "click"}],
[["Q30NN", 175], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Rebecca fed Mimi, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q30NO", 176], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Benjamin fed Arthur, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q30RN", 177], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Al sabotaged Mimi, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q30RO", 178], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Abe sabotaged Arthur, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q30ON", 179], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Chris undermined Mimi, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q30OO", 180], "Message", {hideProgressBar: true, html:'<center><p><font size="4">A large network of spies entered the royal court. </font></p><p><font size="4">Shane undermined Arthur, and Mark undermined Arthur, too.</font></p><p><font size="4">The intrigue was too much for the king to handle. </font></p></center>', transfer: "click"}],
[["Q31NN", 181], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Oliver duped Emma, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q31NO", 182], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Elijah duped Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q31RN", 183], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Henry supported Emma, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q31RO", 184], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Lukas supported Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q31ON", 185], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Simone defended Emma, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q31OO", 186], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Aaron defended Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],
[["Q32NN", 187], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Josh instructed Vicky, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q32NO", 188], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Liz instructed Owen, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q32RN", 189], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Carter ignored Vicky, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q32RO", 190], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Aidan ignored Owen, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q32ON", 191], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Anne excluded Vicky, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q32OO", 192], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The new and the old students studied together. </font></p><p><font size="4">Joe excluded Owen, and Sebastian excluded Owen, too. </font></p><p><font size="4">It was the first time 4th and 10th graders had studied together. </font></p></center>', transfer: "click"}],
[["Q33NN", 193], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Francis encouraged Alice, and Jeb heckled Isaac, too.</font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q33NO", 194], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Eva encouraged Isaac, and Jeb heckled Isaac, too.</font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q33RN", 195], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Faye interrupted Alice, and Jeb heckled Isaac, too.</font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q33RO", 196], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Jade interrupted Isaac, and Jeb heckled Isaac, too.</font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q33ON", 197], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Gabriel heckled Alice, and Jeb heckled Isaac, too.</font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q33OO", 198], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The day for student presentations had arrived. </font></p><p><font size="4">Vivian heckled Isaac, and Jeb heckled Isaac, too. </font></p><p><font size="4">The audience was very lively!</font></p></center>', transfer: "click"}],
[["Q34NN", 199], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Lynne fetched Edward, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q34NO", 200], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Joshua fetched Dylan, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q34RN", 201], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Belle placated Edward, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q34RO", 202], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Rob placated Dylan, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q34ON", 203], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Helena calmed Edward, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q34OO", 204], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The therapist\'s office opened for a new day. </font></p><p><font size="4">Adela calmed Dylan, and Ron calmed Dylan, too.</font></p><p><font size="4">It was a busy day for the therapists, but every appointment happened. </font></p></center>', transfer: "click"}],
[["Q35NN", 205], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Evelyn ignored Sophie, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q35NO", 206], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Emily ignored Anders, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q35RN", 207], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Isabelle detained Sophie, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q35RO", 208], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Abigail detained Anders, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q35ON", 209], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Harper arrested Sophie, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q35OO", 210], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police found the criminal gang in a bar. </font></p><p><font size="4">Ingrid arrested Anders, and Gene arrested Anders, too.</font></p><p><font size="4">All of the lawbreakers were apprehended. </font></p></center>', transfer: "click"}],
[["Q36NN", 211], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Kennedy grilled Lucy, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}],
[["Q36NO", 212], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Adrienne grilled Zoey, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}],
[["Q36RN", 213], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Sal fascinated Lucy, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}],
[["Q36RO", 214], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Matt fascinated Zoey, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}],
[["Q36ON", 215], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Nicholas dazzled Lucy, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}],
[["Q36OO", 216], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lawyers stood up to question the witnesses. </font></p><p><font size="4">Isaiah dazzled Zoey, and Caleb dazzled Zoey, too.</font></p><p><font size="4">It was an impressive trial to watch. </font></p></center>', transfer: "click"}]









  
  /*
  
Known file issues:

(1)

Male subject didn't record one sentence - Item 36, old verb old object (deaccented).
That means the following files weren't available:

36newVoldOdacM
36oldVoldOaccM
36oldVoldOdacM
36relVoldOdacM

They were all replaced with the file 36newVoldOaccM.wav and the sentence in the preview message controller was changed to match.
But, the code at the beginning of the line shows the condition they *should* be in, so these lines need to be subset out before analaysis.


(2)

In the files 15oldVnewOaccM.wav and 15oldVnewOdacM.wav, the male subject misread the first clause verb as
"admonished" instead of "astonished". The preview sentence was changed to match, but these trials should
be subset out before analysis because the verb does not license the correct (repeated) relation.

  
  

  
  
  */
  
  


















/*
Fillers/attention trials. The files zoo, apple, homework, movies, and contact should get high ratings.
buy, rainbow, room, eggs, and voice should get low ratings.
*/












/*comma*/


    
    




];










