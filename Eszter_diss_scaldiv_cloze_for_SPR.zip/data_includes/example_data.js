define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", "GuidedPractice1", "Feedback1", "GuidedPractice2", "Feedback2","practiceover", rshuffle(startsWith("E"),startsWith("f")), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
          transfer: "keypress",
        normalMessage: "Press any key to continue"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        leftComment: "very unnatural", rightComment: "very natural"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro3", "Form", {consentRequired: true, html: { include: "intro3.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: fill in the blank in each sentence with a single word."] 
],continueMessage:"Click here to start the experiment."}],


      ["Feedback1", "Message", {html: ["p", "Some possible answers are: strong or muscular."]}],  
       ["Feedback2", "Message", {html: ["p", "Some possible answers are: taken, free or occupied."]}],    

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //

    ["setcounter", "__SetCounter__", { }],

["GuidedPractice1", "Form", {html:"The wrestler is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not weak."}],
 
 ["GuidedPractice2", "Form", {html:"When Denise and her friends got to the restaurant, all the tables were <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],   


//Experimental items
 
["E1",  "Form", {html: "Drinking is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not obligatory."}],


["E2",  "Form", {html: "The model is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not stunning."}],

["E3",  "Form", {html: "John <input name='blank' size='30' class='obligatory' type='text' autofocus></input> the race and therefore did not complete it."}],

["E4",  "Form", {html: "The teacher <input name='blank' size='30' class='obligatory' type='text' autofocus></input> it is true and therefore does not know it is true."}],

["E5",  "Form", {html: "The elephant is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not enormous."}],

["E6",  "Form", {html: "The weather is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not cold."}],

["E7",  "Form", {html: "The machine <input name='blank' size='30' class='obligatory' type='text' autofocus></input> itself and therefore did not destroy itself."}],

["E8",  "Form", {html: "The sky is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not black."}],

["E9",  "Form", {html: "The task is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not impossible."}],

["E10",  "Form", {html: "Zack's carpet was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not filthy."}],

["E11",  "Form", {html: "The doctor <input name='blank' size='30' class='obligatory' type='text' autofocus></input> coffee and therefore does not loathe coffee."}],

["E12",  "Form", {html: "The sales will <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not triple."}],

["E13",  "Form", {html: "The candidate is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> skilled and therefore not more skilled."}],

["E14",  "Form", {html: "The movie is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not hilarious."}],

["E15",  "Form", {html: "The movie is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not excellent."}],

["E16",  "Form", {html: "The winner was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not ecstatic."}],

["E17",  "Form", {html: "The problem is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not unsolvable."}],

["E18",  "Form", {html: "The toxin is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not deadly."}],

["E19",  "Form", {html: "There is water <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not everywhere."}],

["E20",  "Form", {html: "The boy is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not starving."}],

["E21",  "Form", {html: "The student is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not brilliant."}],

["E22",  "Form", {html: "Chris's opponent was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not terrifying."}],

["E23",  "Form", {html: "The coast was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> flooded and therefore not totally flooded."}],

["E24",  "Form", {html: "The princess <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing and therefore does not love dancing."}],

["E25",  "Form", {html: "Bill's score <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Al's and therefore does not exceed it."}],

["E26",  "Form", {html: "Peter's answers were <input name='blank' size='30' class='obligatory' type='text' autofocus></input> wrong and therefore not entirely wrong."}],

["E27",  "Form", {html: "The house is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not ancient."}],

["E28",  "Form", {html: "Mistakes happened <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not twice."}],

["E29",  "Form", {html: "Jimmy writes books <input name='blank' size='30' class='obligatory' type='text' autofocus></input> plays and therefore not books and plays."}],

["E30",  "Form", {html: "The teenager is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not obese."}],

["E31",  "Form", {html: "The measure was supported <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not unanimously."}],

["E32",  "Form", {html: "The wine is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not delicious."}],

["E33",  "Form", {html: "The tank is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> full and therefore not completely full."}],

["E34",  "Form", {html: "The club <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dancing and therefore does not require dancing."}],

["E35",  "Form", {html: "Ann's speech was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not impeccable."}],

["E36",  "Form", {html: "Success is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not certain."}],

["E37",  "Form", {html: "The girl is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not beautiful."}],

["E38",  "Form", {html: "The residents are <input name='blank' size='30' class='obligatory' type='text' autofocus></input> Greek and therefore not exclusively Greek."}],

["E39",  "Form", {html: "A delay will <input name='blank' size='30' class='obligatory' type='text' autofocus></input> occur and therefore will not necessarily occur."}],

["E40",  "Form", {html: "The city <input name='blank' size='30' class='obligatory' type='text' autofocus></input> waste and therefore did not eliminate it."}],

["E41",  "Form", {html: "Stu's daughter was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not petrified."}],

["E42",  "Form", {html: "Kaye's illness was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not life-threatening."}],

["E43",  "Form", {html: "The two paintings are <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not identical."}],

["E44",  "Form", {html: "The train <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore did not stop."}],

["E45",  "Form", {html: "The fish is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not tiny."}],

["E46",  "Form", {html: "The shirt is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not tight."}],

["E47",  "Form", {html: "Cecilia trusts <input name='blank' size='30' class='obligatory' type='text' autofocus></input> politicians and therefore not all politicians."}],

["E48",  "Form", {html: "The runner <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore did not finish."}],

["E49",  "Form", {html: "The plant <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore did not strive."}],

["E50",  "Form", {html: "The worker is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not exhausted."}],

["E51",  "Form", {html: "Joey's parents <input name='blank' size='30' class='obligatory' type='text' autofocus></input> dating and therefore do not encourage it."}],

["E52",  "Form", {html: "The candidate <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore did not succeed."}],

["E53",  "Form", {html: "The wallpaper is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not hideous."}],

["E54",  "Form", {html: "Tom's interview was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not articulate."}],

["E55",  "Form", {html: "Tim's bathroom was <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not disgusting."}],

["E56",  "Form", {html: "The lawyer is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> early and therefore not always early."}],

["E57",  "Form", {html: "Phoebe <input name='blank' size='30' class='obligatory' type='text' autofocus></input> a car and therefore does not need a car."}],

["E58",  "Form", {html: "The weather is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not hot."}],

["E59",  "Form", {html: "The rehearsal went <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not superbly."}],

["E60",  "Form", {html: "The waiter is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not eager."}],


//Filler items
["filler1", "Form", {html: "The table is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not dirty."}],
["filler2", "Form", {html: "The soldier is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not harmless."}],
["filler3", "Form", {html: "The man is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not sober."}],
["filler4", "Form", {html: "The neighbor is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not rich."}],
["filler5", "Form", {html: "The gymnast is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not single."}],
["filler6", "Form", {html: "The doll is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not old."}],
["filler7", "Form", {html: "The street is <input name='blank' size='30' class='obligatory' type='text' autofocus></input> and therefore not narrow."}]// NOTE NO COMMA

];
