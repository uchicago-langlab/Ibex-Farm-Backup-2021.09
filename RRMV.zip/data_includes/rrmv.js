PennController.ResetPrefix(null) // Shorten command names (keep this line here)

//DebugOff()

// Determine exposure or control group
var x = Math.random();

if (x < 0.5) {
  group = "control";
} else {
  group = "exposure";
}

// Determine RR or MV block
var y = Math.random();

if (y < 0.5) {
  block = 'RR';
} else {
  block = 'MV';
}

fillerID = "filler_" + block

var shuffleSequence = seq("intro", precedeEachWith("fixation", "practice"), "presep", precedeEachWith("fixation", rshuffle('both', group)), precedeEachWith("fixation", rshuffle(fillerID, startsWith(block))), "exit");
//var shuffleSequence = seq("intro", "practice", "presep", sepWith("sep", rshuffle('both', group)), sepWith("sep", rshuffle(fillerID, startsWith(block))), "exit");

var practiceItemTypes = ["practice"];

var defaults = ["Form", {continueOnReturn: false, saveReactionTime: true, hideProgressBar: true, centerItems: false},
                "Message", {hideProgressBar: true, transfer: "keypress"},
                "Question", {as: [["F","F - Yes"],["J","J - No"]], autoFirstChar: false, hideProgressBar: true, randomOrder: false, presentHorizontally: true}, 
                //this should allow f & j to be keypresses, set autofirstchar to false, otherwise it goes by alphabetical order
                "DashedSentence", {mode: "self-paced reading", hideProgressBar: true},
                "DashedSentenceRed", {mode: "self-paced reading", hideProgressBar: true},          
                "FlashSentence", {hideProgressBar: true}
];

var items = [

["fixation", "FlashSentence", {s:"+", timeout:1000}], //it needs to be like this so that it's at least almost in line with the SPR items
["sep", "Separator", { }],
["presep", Separator, { transfer: 1500, normalMessage: "Please get ready. We will start. Please wait..." }],

["intro", "Form", {consentRequired: true, html: {include: "consent.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

// practices
["practice", "DashedSentence", {s:"The black spider is scared of the humans."}, 
	"Question", {q: "Is the spider black?"}],    
["practice", "DashedSentence", {s:"Only the best pencil is short."}, 
	"Question", {q: "Is the best pencil short?"}],
["practice", "DashedSentence", {s:"The workers were upset."}, 
	"Question", {q: "Were the workers happy?"}],
["practice", "DashedSentence", {s:"That one professor's red beard was hideous."}, 
	"Question", {q: "Was the beard red?"}],
["practice", "DashedSentence", {s:"The blanket was on the dresser."}, 
	"Question", {q: "Was the blanket on the floor?"}],
["practice", "DashedSentence", {s:"The coffee machine broke twice yesterday."}, 
	"Question", {q: "Did the coffee machine work properly?"}],
["practice", "DashedSentence", {s:"The artist screamed as his giant painting was destroyed."}, 
	"Question", {q: "Did the artist sigh calmly?"}],
["practice", "DashedSentence", {s:"The couple sang in unison."}, 
	"Question", {q: "Did only one person sing?"}],

// block 1
// fillers for both exposure and control groups
[['both', 1101], "DashedSentence", {s:"Each of the divers had a strict regimen so that they would be prepared for the swim meet."},
	"Question", {q: "Did the divers do the preparing?"}],

[['both', 1102], "DashedSentence", {s:"Many of the soldiers were looking forward to going home for the winter holidays."},
	"Question", {q: "Were the soldiers looking forward to something?"}],

[['both', 1103], "DashedSentence", {s:"The people downtown are frustrated by the lack of available parking."},
	"Question", {q: "Are the people downtown frustrated?"}],

[['both', 1104], "DashedSentence", {s:"The leader of the gambling ring was always mistrustful of his bodyguards."},
	"Question", {q: "Did the leader mistrust anyone?"}],

[['both', 1105], "DashedSentence", {s:"The university students sometimes move into the dormitories as early as August."},
	"Question", {q: "Did the students move in early?"}],

[['both', 1106], "DashedSentence", {s:"The runners were in much better shape in the Fall than in the Winter."},
	"Question", {q: "Were the runners in better shape in the Fall?"}],

[['both', 1107], "DashedSentence", {s:"The parents completely disagreed with the new regulations."},
	"Question", {q: "Did the parents do the disagreeing?"}],

[['both', 1108], "DashedSentence", {s:"The wealthy bankers liked to frequent the bars downtown."},
	"Question", {q: "Did the bankers frequent places downtown?"}],

[['both', 1109], "DashedSentence", {s:"The roofer got a terrible sunburn from being outside all day."},
	"Question", {q: "Did the roofer stay outside all day?"}],

[['both', 1110], "DashedSentence", {s:"The priceless ceramic sculpture had to sit on the top shelf of the lawyer's office."},
	"Question", {q: "Did the sculpture sit inside?"}],

[['both', 1111], "DashedSentence", {s:"The university's math courses were among the nation's most rigorous."},
	"Question", {q: "Did the university offer math courses?"}],

[['both', 1112], "DashedSentence", {s:"The company's health plan did not cover even the most basic health services."},
	"Question", {q: "Did the health plan not cover everything?"}],

[['both', 1113], "DashedSentence", {s:"Cameron's French class went on a trip to Paris one summer to improve their language skills."},
	"Question", {q: "Did the class go on a trip?"}],

[['both', 1114], "DashedSentence", {s:"Max's wedding had to be rescheduled because of a hurricane."},
	"Question", {q: "Did Max reschedule?"}],

[['both', 1115], "DashedSentence", {s:"The unpopular anthropology professor was finally going to retire."},
	"Question", {q: "Was the professor going to retire?"}],

[['both', 1116], "DashedSentence", {s:"The cyclist wanted to train throughout the winter so he moved to Hawaii."},
	"Question", {q: "Did the cyclist move?"}],

// RRs for exposure group
[['exposure', 1201], "DashedSentence", {s:"The little girl chosen a toy became very happy."},
	"Question", {q: "Did the little girl do the choosing?"}],

[['exposure', 1202], "DashedSentence", {s:"The artist drawn a picture was on his deathbed."},
	"Question", {q: "Did the artist do the drawing?"}],

[['exposure', 1203], "DashedSentence", {s:"The smart student given Swahili lessons learned quickly."},
	"Question", {q: "Did the student give the lessons?"}],

[['exposure', 1204], "DashedSentence", {s:"The children hidden Easter eggs found the Easter bunny."},
	"Question", {q: "Did the children do the hiding?"}],

[['exposure', 1205], "DashedSentence", {s:"The young man shown an apartment moved in with his partner."},
	"Question", {q: "Did the young man do the showing?"}],

[['exposure', 1206], "DashedSentence", {s:"The young man driven to his company had a meeting in the morning."},
	"Question", {q: "Did the young man do the driving?"}],

[['exposure', 1207], "DashedSentence", {s:"The congressman written a letter responded the next day."},
	"Question", {q: "Did the congressman do the writing?"}],

[['exposure', 1208], "DashedSentence", {s:"The man forgiven his sins learned to be merciful."},
	"Question", {q: "Did the man do the forgiving?"}],

[['exposure', 1209], "DashedSentence", {s:"The man forbidden the pleasure of eating sweets became healthier."},
	"Question", {q: "Did the man do the forbiding?"}],

[['exposure', 1210], "DashedSentence", {s:"The restaurant flown a shipment of salmon served the president."},
	"Question", {q: "Did the restaurant do the flying?"}],

[['exposure', 1211], "DashedSentence", {s:"The carpenter sawn a board by his buddy yelled at the foreman."},
	"Question", {q: "Did the carpenter do the sawing?"}],

[['exposure', 1212], "DashedSentence", {s:"The student stolen a muffin hit the thief."},
	"Question", {q: "Did the student do the stealing?"}],

[['exposure', 1213], "DashedSentence", {s:"The innkeeper sung a verse gave the singer a discount."},
	"Question", {q: "Did the innkeeper do the singing?"}],

[['exposure', 1214], "DashedSentence", {s:"The player thrown a frisbee did not catch it."},
	"Question", {q: "Did the player do the throwing?"}],

[['exposure', 1215], "DashedSentence", {s:"The man grown a tree by his daughter owns a large backyard."},
	"Question", {q: "Did the man do the growing?"}],

[['exposure', 1216], "DashedSentence", {s:"The woman woven a shawl by her mother entered into the interview room."},
	"Question", {q: "Did the woman do the weaving?"}],


// fillers for control group
[['control', 1301], "DashedSentence", {s:"The cat chased the mouse."},
	"Question", {q: "Did the mouse do the chasing?"}],

[['control', 1302], "DashedSentence", {s:"The hungry animal ate the human food."},
	"Question", {q: "Did the animal do the eating?"}],

[['control', 1303], "DashedSentence", {s:"The orchestra hated playing their most popular symphony."},
	"Question", {q: "Did the orchestra love playing everything?"}],

[['control', 1304], "DashedSentence", {s:"The apple fell far from the tree."},
	"Question", {q: "Did the apple stay in the tree?"}],

[['control', 1305], "DashedSentence", {s:"The telephone company was known for its expensive products."},
	"Question", {q: "Was the company known for anything?"}],

[['control', 1306], "DashedSentence", {s:"The picture frame that Fred bought was not red as promised."},
	"Question", {q: "Did Fred buy something?"}],

[['control', 1307], "DashedSentence", {s:"The student forgot to turn in his assignment on differential equations."},
	"Question", {q: "Did the student remember everything?"}],

[['control', 1308], "DashedSentence", {s:"The coffee was too hot for the stewardess to hold."},
	"Question", {q: "Was the coffee hot?"}],

[['control', 1309], "DashedSentence", {s:"Rachel forgot to get her boyfriend a present for his birthday."},
	"Question", {q: "Did Rachel remember everything?"}],

[['control', 1310], "DashedSentence", {s:"The blanket on the ground reminded the adult of his childhood."},
	"Question", {q: "Was the adult reminded of something?"}],

[['control', 1311], "DashedSentence", {s:"An unwanted carrot somehow got into the nurse's salad."},
	"Question", {q: "Was the carrot wanted?"}],

[['control', 1312], "DashedSentence", {s:"The statisticians laughed at the uneducated member of the fantasy football league."},
	"Question", {q: "Did the statisticians do the laughing?"}],

[['control', 1313], "DashedSentence", {s:"The number could not be found in the address book."},
	"Question", {q: "Was the number in the address book?"}],

[['control', 1314], "DashedSentence", {s:"The human brain is the focus of many generations of research."},
	"Question", {q: "Has research focused on the human brain?"}],

[['control', 1315], "DashedSentence", {s:"The shirt became moldy after being left in the washer for days."},
	"Question", {q: "Did the shirt stay clean?"}],

[['control', 1316], "DashedSentence", {s:"The tissue box was almost out of tissues."},
	"Question", {q: "Were there only a few tissues left?"}],


// block 2
// RRs
[['RR_Am', 2101], "DashedSentence", {s:"The eager bartender served the fried snacks worked till past midnight."},
	"Question", {q: "Did the bartender do the serving?"}],
[['RR_Un', 2101], "DashedSentence", {s:"The eager bartender who was served the fried snacks worked till past midnight."},
	"Question", {q: "Did the bartender do the serving?"}],

[['RR_Am', 2102], "DashedSentence", {s:"The experienced chef warned about the stove burnt his hand anyway."},
	"Question", {q: "Did the chef give the warning?"}],
[['RR_Un', 2102], "DashedSentence", {s:"The experienced chef who was warned about the stove burnt his hand anyway."},
	"Question", {q: "Did the chef give the warning?"}],

[['RR_Am', 2103], "DashedSentence", {s:"The hikers delivered the supplies sat down for a good meal."},
	"Question", {q: "Did the hikers do the delivering?"}],
[['RR_Un', 2103], "DashedSentence", {s:"The hikers who were delivered the supplies sat down for a good meal."},
	"Question", {q: "Did the hikers do the delivering?"}],

[['RR_Am', 2104], "DashedSentence", {s:"The senator assigned the secretary could not remember her name."},
	"Question", {q: "Did the senator do the assigning?"}],
[['RR_Un', 2104], "DashedSentence", {s:"The senator who was assigned the secretary could not remember her name."},
	"Question", {q: "Did the senator do the assigning?"}],

[['RR_Am', 2105], "DashedSentence", {s:"Some rescue workers warned about the avalanche decided to stand by."},
	"Question", {q: "Did the workers give the warning?"}],
[['RR_Un', 2105], "DashedSentence", {s:"Some rescue workers who were warned about the avalanche decided to stand by."},
	"Question", {q: "Did the workers give the warning?"}],

[['RR_Am', 2106], "DashedSentence", {s:"The children explained the plan refused to obey."},
	"Question", {q: "Did the children do the explaining?"}],
[['RR_Un', 2106], "DashedSentence", {s:"The children who were explained the plan refused to obey."},
	"Question", {q: "Did the children do the explaining?"}],

[['RR_Am', 2107], "DashedSentence", {s:"The childish employees served the hot dogs got a stomach ache."},
	"Question", {q: "Did the employees do the serving?"}],
[['RR_Un', 2107], "DashedSentence", {s:"The childish employees who were served the hot dogs got a stomach ache."},
	"Question", {q: "Did the employees do the serving?"}],

[['RR_Am', 2108], "DashedSentence", {s:"The nervous wrestler pushed through the crowd hadn't seen his opponent."},
	"Question", {q: "Did the wrestler do the pushing?"}],
[['RR_Un', 2108], "DashedSentence", {s:"The nervous wrestler who was pushed through the crowd hadn't seen his opponent."},
	"Question", {q: "Did the wrestler do the pushing?"}],

[['RR_Am', 2109], "DashedSentence", {s:"A small child fed the chicken smacked his lips."},
	"Question", {q: "Did the child do the feeding?"}],
[['RR_Un', 2109], "DashedSentence", {s:"A small child who was fed the chicken smacked his lips."},
	"Question", {q: "Did the child do the feeding?"}],

[['RR_Am', 2110], "DashedSentence", {s:"The computer programmers called about the problem knew what to do."},
	"Question", {q: "Did the programmers do the calling?"}],
[['RR_Un', 2110], "DashedSentence", {s:"The computer programmers who were called about the problem knew what to do."},
	"Question", {q: "Did the programmers do the calling?"}],


// MVs
[['MV_Am', 2201], "DashedSentence", {s:"The cook delivered the recipe before trying to take a nice long nap."},
	"Question", {q: "Did the cook do the delivering?"}],
[['MV_Un', 2201], "DashedSentence", {s:"The cook followed the recipe before trying to take a nice long nap."},
	"Question", {q: "Did the cook follow the recipe?"}],

[['MV_Am', 2202], "DashedSentence", {s:"The drunk tourists assigned the scavenger hunt item to the teams."},
	"Question", {q: "Did the tourists do the calling?"}],
[['MV_Un', 2202], "DashedSentence", {s:"The drunk tourists gave the scavenger hunt item to the teams."},
	"Question", {q: "Did the tourists do the giving?"}],

[['MV_Am', 2203], "DashedSentence", {s:"The experienced waitress served the grilled chicken in the nice restaurant."},
	"Question", {q: "Did the waitress do the serving?"}],
[['MV_Un', 2203], "DashedSentence", {s:"The experienced waitress ate the grilled chicken in the nice restaurant."},
	"Question", {q: "Did the waitress do the eating?"}],

[['MV_Am', 2204], "DashedSentence", {s:"The sleepy volunteers served the hot soup in the aid station."},
	"Question", {q: "Did the volunteers do the serving?"}],
[['MV_Un', 2204], "DashedSentence", {s:"The sleepy volunteers ate the hot soup in the aid station."},
	"Question", {q: "Did the volunteers do the eating?"}],

[['MV_Am', 2205], "DashedSentence", {s:"The aging professors warned about the midterm just before Fall break."},
	"Question", {q: "Did the professors give the warning?"}],
[['MV_Un', 2205], "DashedSentence", {s:"The aging professors spoke about the midterm just before Fall break."},
	"Question", {q: "Did the professors do the speaking?"}],

[['MV_Am', 2206], "DashedSentence", {s:"The candidate announced on the news his intent to run again."},
	"Question", {q: "Did the candidate make an announcement?"}],
[['MV_Un', 2206], "DashedSentence", {s:"The candidate repeated on the news his intent to run again."},
	"Question", {q: "Did the candidate do the repeating?"}],

[['MV_Am', 2207], "DashedSentence", {s:"The frantic shopper pushed through the door to find her kid."},
	"Question", {q: "Did the shopper do the pushing?"}],
[['MV_Un', 2207], "DashedSentence", {s:"The frantic shopper went through the door to find her kid."},
	"Question", {q: "Did the shopper go through the door?"}],

[['MV_Am', 2208], "DashedSentence", {s:"The child fed the chicken some bread crumbs off the floor."},
	"Question", {q: "Did the child do the feeding?"}],
[['MV_Un', 2208], "DashedSentence", {s:"The child gave the chicken some bread crumbs off the floor."},
	"Question", {q: "Did the child do the giving?"}],

[['MV_Am', 2209], "DashedSentence", {s:"The pawnshop owner told the rules to the customers."},
	"Question", {q: "Did the owner do the telling?"}],
[['MV_Un', 2209], "DashedSentence", {s:"The pawnshop owner gave the rules to the customers."},
	"Question", {q: "Did the owner do the giving?"}],

[['MV_Am', 2210], "DashedSentence", {s:"The cotton farmers warned about the bad floods just before harvest time."},
	"Question", {q: "Did the farmers give the warning?"}],
[['MV_Un', 2210], "DashedSentence", {s:"The cotton farmers talked about the bad floods just before harvest time."},
	"Question", {q: "Did the farmers do the talking?"}],



// fillers for RRs
[['filler_RR', 2301], "DashedSentence", {s:"The term papers from the previous semester were beginning to accumulate on the teacher's desk."},
	"Question", {q: "Were the papers kept at a low number?"}],

[['filler_RR', 2302], "DashedSentence", {s:"The shoppers love to spend all day at the mall on the weekends."},
	"Question", {q: "Do the shoppers love spending time at the mall?"}],

[['filler_RR', 2303], "DashedSentence", {s:"The coffee shop was a popular hangout for political activists."},
	"Question", {q: "Was the shop unpopular?"}],

[['filler_RR', 2304], "DashedSentence", {s:"The school principal had to work constantly all summer dealing with paperwork."},
	"Question", {q: "Did the principal do the working?"}],

[['filler_RR', 2305], "DashedSentence", {s:"The lawnmower did not always function properly when the grass was wet."},
	"Question", {q: "Did the lawnmower function improperly when wet?"}],

[['filler_RR', 2306], "DashedSentence", {s:"The new student disappeared after only three days of school."},
	"Question", {q: "Did the student disappear?"}],

[['filler_RR', 2307], "DashedSentence", {s:"The storekeepers were afraid that riots would ensue after the home team won the tournament."},
	"Question", {q: "Were the storekeepers afraid of their team losing?"}],

[['filler_RR', 2308], "DashedSentence", {s:"The real estate agent blundered when he revealed the house's plumbing problems."},
	"Question", {q: "Did the agent do the blundering?"}],

[['filler_RR', 2309], "DashedSentence", {s:"The library was open to all members of the community since it was supported by tax dollars."},
	"Question", {q: "Did the taxpayers do the supporting?"}],

[['filler_RR', 2310], "DashedSentence", {s:"The physics professor at the university was finally going to retire."},
	"Question", {q: "Did the professor teach physics?"}],

[['filler_RR', 2311], "DashedSentence", {s:"The landscaper never boasted of his achievements."},
	"Question", {q: "Did the landscaper do the boasting?"}],

[['filler_RR', 2312], "DashedSentence", {s:"The dance troupe came to set up their equipment."},
	"Question", {q: "Did the troupe do the setting up?"}],

[['filler_RR', 2313], "DashedSentence", {s:"The chess match lasted for hours and finally ended in a stalemate."},
	"Question", {q: "Did the match end?"}],

[['filler_RR', 2314], "DashedSentence", {s:"The street lamps usually came on automatically just before dark."},
	"Question", {q: "Did the lamps come on?"}],

[['filler_RR', 2315], "DashedSentence", {s:"The foreign ambassadors arrived to the meeting surrounded by security guards."},
	"Question", {q: "Did the ambassadors do the surrounding?"}],

[['filler_RR', 2316], "DashedSentence", {s:"Many of the city cops refuse to work in the rough parts of town."},
	"Question", {q: "Did the city cops do the refusing?"}],

[['filler_RR', 2317], "DashedSentence", {s:"The car salesman waited anxiously for more customers."},
	"Question", {q: "Did the salesman do the waiting?"}],

[['filler_RR', 2318], "DashedSentence", {s:"All the guitarists learned to play when they were teenagers."},
	"Question", {q: "Did the guitarists learn to play before adulthood?"}],

[['filler_RR', 2319], "DashedSentence", {s:"The angry customers decided to leave the restaurant."},
	"Question", {q: "Did the customers stay?"}],

[['filler_RR', 2320], "DashedSentence", {s:"The girls on the basketball team tried to practice all Summer."},
	"Question", {q: "Did the girls try to practice?"}],


// fillers for MVs
[['filler_MV', 2401], "DashedSentence", {s:"The children in the park could be heard three blocks away."},
	"Question", {q: "Were the children quiet?"}],

[['filler_MV', 2402], "DashedSentence", {s:"The power plant deserved more attention from the candidates during the election."},
	"Question", {q: "Was the power plant deserving of more attention?"}],

[['filler_MV', 2403], "DashedSentence", {s:"The quilts were sold by the side of the road for ten dollars."},
	"Question", {q: "Did the grocery store do the selling?"}],

[['filler_MV', 2404], "DashedSentence", {s:"The pilots flew over the city where they had just had a wonderful weekend."},
	"Question", {q: "Did the pilots do the flying?"}],

[['filler_MV', 2405], "DashedSentence", {s:"The prisoners were unable to cross the field without being seen."},
	"Question", {q: "Did the prisoners go undetected?"}],

[['filler_MV', 2406], "DashedSentence", {s:"Each of the cab drivers had their own favorite route to get to the airport."},
	"Question", {q: "Were the routes different?"}],

[['filler_MV', 2407], "DashedSentence", {s:"The new student caught everyone's attention when he came into the room."},
	"Question", {q: "Did the student fly under the radar?"}],

[['filler_MV', 2408], "DashedSentence", {s:"The valuable lamp was broken by the mischievous boy."},
	"Question", {q: "Did the boy do the breaking?"}],

[['filler_MV', 2409], "DashedSentence", {s:"All the undergraduates in the class had trouble keeping up."},
	"Question", {q: "Did the undergraduates find the class to be easy?"}],

[['filler_MV', 2410], "DashedSentence", {s:"The package never arrived despite many complaints."},
	"Question", {q: "Did the package arrive?"}],

[['filler_MV', 2411], "DashedSentence", {s:"The engineers at the plant had to wear helmets when they went near the machines."},
	"Question", {q: "Were helmets optional?"}],

[['filler_MV', 2412], "DashedSentence", {s:"The new experiment was the source of a great deal of excitement in the lab."},
	"Question", {q: "Did the new experiment bore the lab?"}],

[['filler_MV', 2413], "DashedSentence", {s:"The eccentric professor always inspired his students to think critically about their work."},
	"Question", {q: "Did the professor discourage his students?"}],

[['filler_MV', 2414], "DashedSentence", {s:"The former drug addict's memoirs were met with critical acclaim."},
	"Question", {q: "Did the critics like the book?"}],

[['filler_MV', 2415], "DashedSentence", {s:"The laptops were too expensive for most of the students."},
	"Question", {q: "Were the laptops cheap?"}],

]

