PennController.ResetPrefix(null) // Shorten command names (keep this line here)

DebugOff()

// Determine exposure or control group
var x = Math.random();

//if (x < 0.5) {
//  group = "control";
//} else {
//  group = "exposure";
//}

// Second batch only recruits exposure group
group = "exposure"


var shuffleSequence = seq("intro", "instruction", precedeEachWith("sep", "practice"), "presep", precedeEachWith("sep", rshuffle(startsWith(group))), 
    precedeEachWith("sep", rshuffle(startsWith("RR"), "filler_2")), precedeEachWith("sep", rshuffle(startsWith("MV"), "filler_3")), "exit");

var practiceItemTypes = ["practice"];

var defaults = ["Form", {continueOnReturn: false, saveReactionTime: true, hideProgressBar: true, centerItems: false},
                "Message", {hideProgressBar: true, transfer: "keypress"},
                "Question", {autoFirstChar: false, hideProgressBar: true, randomOrder: true, presentHorizontally: true, hasCorrect: true}, 
                "DashedSentence", {mode: "self-paced reading", hideProgressBar: true},
                "DashedSentenceRed", {mode: "self-paced reading", hideProgressBar: true},          
                "FlashSentence", {hideProgressBar: true}
];

var items = [

//["fixation", "FlashSentence", {s:"+", timeout:1000}], //it needs to be like this so that it's at least almost in line with the SPR items
["sep", "Separator", {errorMessage: "Oops. Your answer is wrong. Press any key to continue."}],
["presep", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The practice session is over now. You will start the experiment now. Please press the spacebar to continue"],]}], 
["presep", Separator, { transfer: 2500, normalMessage: "Please get ready. We will start. Please wait..." }],

["intro", "Form", {consentRequired: true, html: {include: "consent.html" }}],
["intro", "Form", {consentRequired: true, html: {include: "intro.html" }}],
["instruction", "Form", {consentRequired: true, html: {include: "instruction1.html" }}],
["instruction", "Form", {consentRequired: true, html: {include: "instruction2.html" }}],
["instruction", "Form", {consentRequired: true, html: {include: "instruction3.html" }}],
["exit", "Form", {consentRequired: false, html: {include: "exit1.html" }}],

// practices
["practice", "DashedSentence", {s:["The black spider", "is scared of", "the humans."]}, 
    "Question", {q: "What's the color of the spider", as: ["black", "brown"]}],

["practice", "DashedSentence", {s:["Only", "the best pencil", "is", "short."]}, 
    "Question", {q: "Is the best pencil short?", as: ["yes", "no"]}],

["practice", "DashedSentence", {s:["The workers", "were", "upset."]}, 
    "Question", {q: "Were the workers happy?", as: ["no", "yes"]}],

["practice", "DashedSentence", {s:["That one professor's", "red beard", "was", "hideous."]}, 
    "Question", {q: "What's the color of the beard?", as: ["red", "black"]}],

["practice", "DashedSentence", {s:["The blanket", "was", "on the dresser."]}, 
    "Question", {q: "Where was the blanket?", as: ["on the dresser", "on the floor"]}],

["practice", "DashedSentence", {s:["The coffee machine", "broke", "twice", "yesterday."]}, 
    "Question", {q: "Did the coffee machine work properly?", as: ["no", "yes"]}],

["practice", "DashedSentence", {s:["The artist", "screamed", "as", "his giant painting", "was destroyed."]}, 
    "Question", {q: "Did the artist sigh calmly?", as: ["no", "yes"]}],

["practice", "DashedSentence", {s:["The couple", "sang", "in unison."]}, 
    "Question", {q: "Did only one person sing?", as: ["no", "yes"]}],

// block 1
// RRs for exposure group
[['exposure_AM', 1201], "DashedSentence", {s:["The defendant", "examined", "by the lawyer", "turned out", "to be", "unreliable."]},
    "Question", {q: "Who was examined?", as: ["the defendant", "the lawyer"]}],
[['exposure_Un', 1201], "DashedSentence", {s:["The defendant", "that", "was", "examined", "by the lawyer", "turned out", "to be", "unreliable."]},
    "Question", {q: "Who was examined?", as: ["the defendant", "the lawyer"]}],

[['exposure_AM', 1202], "DashedSentence", {s:["The prisoner", "transported", "by the guards", "was", "closely", "watched."]},
    "Question", {q: "Who did the transporting?", as: ["the guards", "the prisoner"]}],
[['exposure_Un', 1202], "DashedSentence", {s:["The prisoner", "that", "was", "transported", "by the guards", "was", "closely", "watched."]},
    "Question", {q: "Who did the transporting?", as: ["the guards", "the prisoner"]}],

[['exposure_AM', 1203], "DashedSentence", {s:["The teacher", "loved", "by the class", "was", "very easy", "to understand."]},
    "Question", {q: "Who was loved?", as: ["the teacher", "the class"]}],
[['exposure_Un', 1203], "DashedSentence", {s:["The teacher", "that", "was", "loved", "by the class", "was", "very easy", "to understand."]},
    "Question", {q: "Who was loved?", as: ["the teacher", "the class"]}],

[['exposure_AM', 1204], "DashedSentence", {s:["The workers", "lifted", "by the crane", "were", "deposited", "on the roof."]},
    "Question", {q: "What was lifted?", as: ["the workers", "the crane"]}],
[['exposure_Un', 1204], "DashedSentence", {s:["The workers", "that", "were", "lifted", "by the crane", "were", "deposited", "on the roof."]},
    "Question", {q: "What was lifted?", as: ["the workers", "the crane"]}],

[['exposure_AM', 1205], "DashedSentence", {s:["The student", "graded", "by the professor", "received", "a low mark", "for this class"]},
    "Question", {q: "Who did the grading?", as: ["the professor", "the student"]}],
[['exposure_Un', 1205], "DashedSentence", {s:["The student", "that", "was", "graded", "by the professor", "received", "a low mark", "for this class"]},
    "Question", {q: "Who did the grading?", as: ["the professor", "the student"]}],

[['exposure_AM', 1206], "DashedSentence", {s:["The contestant", "selected", "by the judges", "did not", "deserve", "to win."]},
    "Question", {q: "Who did the selecting?", as: ["the judges", "the contestant"]}],
[['exposure_Un', 1206], "DashedSentence", {s:["The contestant", "that", "was", "selected", "by the judges", "did not", "deserve", "to win."]},
    "Question", {q: "Who did the selecting?", as: ["the judges", "the contestant"]}],

[['exposure_AM', 1207], "DashedSentence", {s:["The specialist", "requested", "by the hospital", "finally", "arrived", "in the afternoon."]},
    "Question", {q: "Who was requested?", as: ["the specialist", "the hospital"]}],
[['exposure_Un', 1207], "DashedSentence", {s:["The specialist", "that", "was", "requested", "by the hospital", "finally", "arrived", "in the afternoon."]},
    "Question", {q: "Who was requested?", as: ["the specialist", "the hospital"]}],

[['exposure_AM', 1208], "DashedSentence", {s:["The thief", "identified", "by the victim", "was", "held", "for questioning."]},
    "Question", {q: "Who was identified?", as: ["the thief", "the victim"]}],
[['exposure_Un', 1208], "DashedSentence", {s:["The thief", "that", "was", "identified", "by the victim", "was", "held", "for questioning."]},
    "Question", {q: "Who was identified?", as: ["the thief", "the victim"]}],

[['exposure_AM', 1209], "DashedSentence", {s:["The soldier", "captured", "by the enemy", "was", "closely", "guarded."]},
    "Question", {q: "Who did the capturing?", as: ["the enemy", "the soldier"]}],
[['exposure_Un', 1209], "DashedSentence", {s:["The soldier", "that", "was", "captured", "by the enemy", "was", "closely", "guarded."]},
    "Question", {q: "Who did the capturing?", as: ["the enemy", "the soldier"]}],

[['exposure_AM', 1210], "DashedSentence", {s:["The troops", "attacked", "by the terrorists", "suffered", "heavy", "losses."]},
    "Question", {q: "Who did the attacking?", as: ["the terrorists", "the troops"]}],
[['exposure_Un', 1210], "DashedSentence", {s:["The troops", "that", "were", "attacked", "by the terrorists", "suffered", "heavy", "losses."]},
    "Question", {q: "Who did the attacking?", as: ["the terrorists", "the troops"]}],

[['exposure_AM', 1211], "DashedSentence", {s:["The artist", "investigated", "by the historian", "was", "a complete unknown", "until", "last year."]},
    "Question", {q: "Who did the investigating?", as: ["the historian", "the artist"]}],
[['exposure_Un', 1211], "DashedSentence", {s:["The artist", "that", "was", "investigated", "by the historian", "was", "a complete unknown", "until", "last year."]},
    "Question", {q: "Who did the investigating?", as: ["the historian", "the artist"]}],

[['exposure_AM', 1212], "DashedSentence", {s:["The boy", "described", "by the lady", "was", "quite", "handsome."]},
    "Question", {q: "Who did the describing?", as: ["the lady", "the boy"]}],
[['exposure_Un', 1212], "DashedSentence", {s:["The boy", "that", "was", "described", "by the lady", "was", "quite", "handsome."]},
    "Question", {q: "Who did the describing?", as: ["the lady", "the boy"]}],

[['exposure_AM', 1213], "DashedSentence", {s:["The mailman", "expected", "by the secretary", "arrived", "too late", "today."]},
    "Question", {q: "Who was expected?", as: ["the mailman", "the secretary"]}],
[['exposure_Un', 1213], "DashedSentence", {s:["The mailman", "that", "was", "expected", "by the secretary", "arrived", "too late", "today."]},
    "Question", {q: "Who was expected?", as: ["the mailman", "the secretary"]}],

[['exposure_AM', 1214], "DashedSentence", {s:["The woman", "scratched", "by the cat", "was", "badly", "injured."]},
    "Question", {q: "Who did the scratching?", as: ["the cat", "the woman"]}],
[['exposure_Un', 1214], "DashedSentence", {s:["The woman", "that", "was", "scratched", "by the cat", "was", "badly", "injured."]},
    "Question", {q: "Who did the scratching?", as: ["the cat", "the woman"]}],

[['exposure_AM', 1215], "DashedSentence", {s:["The man", "recognized", "by the spy", "took off", "down", "the street."]},
    "Question", {q: "Who was recognized?", as: ["the man", "the spy"]}],
[['exposure_Un', 1215], "DashedSentence", {s:["The man", "that", "was", "recognized", "by the spy", "took off", "down", "the street."]},
    "Question", {q: "Who was recognized?", as: ["the man", "the spy"]}],

[['exposure_AM', 1216], "DashedSentence", {s:["The client", "wanted", "by the advertiser", "was", "worth", "a lot of money."]},
    "Question", {q: "Who was wanted?", as: ["the client", "the advertiser"]}],
[['exposure_Un', 1216], "DashedSentence", {s:["The client", "that", "was", "wanted", "by the advertiser", "was", "worth", "a lot of money."]},
    "Question", {q: "Who was wanted?", as: ["the client", "the advertiser"]}],


// fillers for control group
[['control', 1301], "DashedSentence", {s:["The cat", "is", "much bigger", "than", "the mouse."]},
    "Question", {q: "Which is bigger?", as: ["the cat", "the mouse"]}],

[['control', 1302], "DashedSentence", {s:["The hungry animal", "was", "so tired", "that", "it", "had", "no strength", "left."]},
    "Question", {q: "Did the animal still have strength?", as: ["no", "yes"]}],

[['control', 1303], "DashedSentence", {s:["The orchestra", "was", "planning to", "play", "their", "most popular", "symphony."]},
    "Question", {q: "How was the symphony to be played?", as: ["popular", "boring"]}],

[['control', 1304], "DashedSentence", {s:["The apples", "on that tree", "are", "surprisingly", "delicious."]},
    "Question", {q: "How are the apples?", as: ["delicious", "sour"]}],

[['control', 1305], "DashedSentence", {s:["The telephone company", "has", "the most expensive", "products", "on the market."]},
    "Question", {q: "How are the products of the telephone company?", as: ["expensive", "cheap"]}],

[['control', 1306], "DashedSentence", {s:["The picture frame", "that", "Fred", "bought", "was not", "red", "as promised."]},
    "Question", {q: "Who brought the picture frame?", as: ["Fred", "Kevin"]}],

[['control', 1307], "DashedSentence", {s:["The student", "was", "too nervous", "during", "the exam", "that", "he", "didn't", "do well."]},
    "Question", {q: "How did the student feel in the exam?", as: ["nervous", "relaxed"]}],

[['control', 1308], "DashedSentence", {s:["The coffee", "was", "too hot", "for", "the flight attendant", "to hold."]},
    "Question", {q: "How was the coffee?", as: ["hot", "cold"]}],

[['control', 1309], "DashedSentence", {s:["Rachel", "was", "late", "for", "her boyfriend's", "birthday party", "and", "she", "had", "no present", "with her."]},
    "Question", {q: "Did Rachel brought a present?", as: ["no", "yes"]}],

[['control', 1310], "DashedSentence", {s:["The blanket", "on the ground", "is", "from", "a well-known factory."]},
    "Question", {q: "What is on the ground?", as: ["the blanket", "the scarf"]}],

[['control', 1311], "DashedSentence", {s:["The kid", "was", "starving", "and", "he", "even", "ate", "the carrot", "in his bowl."]},
    "Question", {q: "Did the kid eat the carrot?", as: ["yes", "no"]}],

[['control', 1312], "DashedSentence", {s:["The statisticians", "were", "unhappy", "with", "the uneducated member", "of", "the fantasy football league."]},
    "Question", {q: "How did the statisticians feel?", as: ["unhappy", "happy"]}],

[['control', 1313], "DashedSentence", {s:["The number", "could not", "be found", "in", "the address book."]},
    "Question", {q: "Can the number be found?", as: ["no", "yes"]}],

[['control', 1314], "DashedSentence", {s:["The human brain", "is", "the focus", "of", "many generations", "of", "research."]},
    "Question", {q: "Is human brain a popular field of research?", as: ["yes", "no"]}],

[['control', 1315], "DashedSentence", {s:["The shirt", "was", "moldy", "after", "being left", "in", "the washer", "for days."]},
    "Question", {q: "How was the shirt?", as: ["moldy", "wet"]}],

[['control', 1316], "DashedSentence", {s:["The tissue box", "was", "almost", "out of", "tissues."]},
    "Question", {q: "Is the tissue box almost empty?", as: ["no", "yes"]}],


// block 2
// RRs
[['RR_AM', 2101], "DashedSentence", {s:["The patient", "examined", "by the doctor", "got", "a stomach ache", "last night."]},
    "Question", {q: "Who was examined?", as: ["the patient", "the doctor"]}],
[['RR_Un', 2101], "DashedSentence", {s:["The patient", "that", "was", "examined", "by the doctor", "got", "a stomach ache", "last night."]},
    "Question", {q: "Who was examined?", as: ["the patient", "the doctor"]}],

[['RR_AM', 2102], "DashedSentence", {s:["The man", "transported", "by the firefighters", "was", "admitted to", "the nearest hospital."]},
    "Question", {q: "Who did the transporting?", as: ["the firefighters", "the man"]}],
[['RR_Un', 2102], "DashedSentence", {s:["The man", "that", "was", "transported", "by the firefighters", "was", "admitted to", "the nearest hospital."]},
    "Question", {q: "Who did the transporting?", as: ["the firefighters", "the man"]}],

[['RR_AM', 2103], "DashedSentence", {s:["The singer", "loved", "by young people", "released", "a new song", "this year."]},
    "Question", {q: "Who was loved?", as: ["the singer", "young people"]}],
[['RR_Un', 2103], "DashedSentence", {s:["The singer", "that", "was", "loved", "by young people", "released", "a new song", "this year."]},
    "Question", {q: "Who was loved?", as: ["the singer", "young people"]}],

[['RR_AM', 2104], "DashedSentence", {s:["The kid", "lifted", "by the father", "didn't", "want to", "go to school."]},
    "Question", {q: "Who was lifted?", as: ["the kid", "the father"]}],
[['RR_Un', 2104], "DashedSentence", {s:["The kid", "that", "was", "lifted", "by the father", "didn't", "want to", "go to school."]},
    "Question", {q: "Who was lifted?", as: ["the kid", "the father"]}],

[['RR_AM', 2105], "DashedSentence", {s:["The candidate", "graded", "by the manager", "passed", "the interview", "for the job."]},
    "Question", {q: "Who did the grading?", as: ["the manager", "the candidate"]}],
[['RR_Un', 2105], "DashedSentence", {s:["The candidate", "that", "was", "graded", "by the manager", "passed", "the interview", "for the job."]},
    "Question", {q: "Who did the grading?", as: ["the manager", "the candidate"]}],

[['RR_AM', 2106], "DashedSentence", {s:["The participant", "selected", "by the researcher", "was not", "qualified", "for the experiment."]},
    "Question", {q: "Who did the selecting?", as: ["the researcher", "the participant"]}],
[['RR_Un', 2106], "DashedSentence", {s:["The participant", "that", "was", "selected", "by the researcher", "was not", "qualified", "for the experiment."]},
    "Question", {q: "Who did the selecting?", as: ["the researcher", "the participant"]}],

[['RR_AM', 2107], "DashedSentence", {s:["The attorney", "requested", "by the client", "decided", "not to take", "the case."]},
    "Question", {q: "Who was requested?", as: ["the attorney", "the client"]}],
[['RR_Un', 2107], "DashedSentence", {s:["The attorney", "that", "was", "requested", "by the client", "decided", "not to take", "the case."]},
    "Question", {q: "Who was requested?", as: ["the attorney", "the client"]}],

[['RR_AM', 2108], "DashedSentence", {s:["The passenger", "identified", "by the officer", "was", "denied", "boarding."]},
    "Question", {q: "Who was identified?", as: ["the passenger", "the officer"]}],
[['RR_Un', 2108], "DashedSentence", {s:["The passenger", "that", "was", "identified", "by the officer", "was", "denied", "boarding."]},
    "Question", {q: "Who was identified?", as: ["the passenger", "the officer"]}],

[['RR_AM', 2109], "DashedSentence", {s:["The thief", "captured", "by the policeman", "confessed to", "the crime", "he", "committed."]},
    "Question", {q: "Who did the capturing?", as: ["the policeman", "the thief"]}],
[['RR_Un', 2109], "DashedSentence", {s:["The thief", "that", "was", "captured", "by the policeman", "confessed to", "the crime", "he", "committed."]},
    "Question", {q: "Who did the capturing?", as: ["the policeman", "the thief"]}],

[['RR_AM', 2110], "DashedSentence", {s:["The novelist", "attacked", "by the editor", "drew", "heavily", "on", "her", "personal experience."]},
    "Question", {q: "Who did the attacking?", as: ["the editor", "the novelist"]}],
[['RR_Un', 2110], "DashedSentence", {s:["The novelist", "that", "was", "attacked", "by the editor", "drew", "heavily", "on", "her", "personal experience."]},
    "Question", {q: "Who did the attacking?", as: ["the editor", "the novelist"]}],

[['RR_AM', 2111], "DashedSentence", {s:["The politician", "investigated", "by the journalist", "embezzled", "thousands of dollars", "last year."]},
    "Question", {q: "Who did the investigating?", as: ["the journalist", "the politician"]}],
[['RR_Un', 2111], "DashedSentence", {s:["The politician", "that", "was", "investigated", "by the journalist", "embezzled", "thousands of dollars", "last year."]},
    "Question", {q: "Who did the investigating?", as: ["the journalist", "the politician"]}],

[['RR_AM', 2112], "DashedSentence", {s:["The student", "described", "by the professor", "is", "very", "smart."]},
    "Question", {q: "Who did the describing?", as: ["the professor", "the student"]}],
[['RR_Un', 2112], "DashedSentence", {s:["The student", "that", "was", "described", "by the professor", "is", "very", "smart."]},
    "Question", {q: "Who did the describing?", as: ["the professor", "the student"]}],

[['RR_AM', 2113], "DashedSentence", {s:["The actress", "expected", "by the fans", "was", "quite", "beautiful."]},
    "Question", {q: "Who was expected?", as: ["the actress", "the fans"]}],
[['RR_Un', 2113], "DashedSentence", {s:["The actress", "that", "was", "expected", "by the fans", "was", "quite", "beautiful."]},
    "Question", {q: "Who was expected?", as: ["the actress", "the fans"]}],

[['RR_AM', 2114], "DashedSentence", {s:["The man", "scratched", "by the dog", "was", "angry", "at", "the dog owner."]},
    "Question", {q: "Who did the scratching?", as: ["the dog", "the man"]}],
[['RR_Un', 2114], "DashedSentence", {s:["The man", "that", "was", "scratched", "by the dog", "was", "angry", "at", "the dog owner."]},
    "Question", {q: "Who did the scratching?", as: ["the dog", "the man"]}],

[['RR_AM', 2115], "DashedSentence", {s:["The thief", "recognized", "by the policeman", "started to", "run", "towards", "the park."]},
    "Question", {q: "Who was recognized?", as: ["the thief", "the policeman"]}],
[['RR_Un', 2115], "DashedSentence", {s:["The thief", "that", "was", "recognized", "by the policeman", "started to", "run", "towards", "the park."]},
    "Question", {q: "Who was recognized?", as: ["the thief", "the policeman"]}],

[['RR_AM', 2116], "DashedSentence", {s:["The assistant", "wanted", "by the manager", "was", "hard", "to hire."]},
    "Question", {q: "Who was wanted?", as: ["the assistant", "the manager"]}],
[['RR_Un', 2116], "DashedSentence", {s:["The assistant", "that", "was", "wanted", "by the manager", "was", "hard", "to hire."]},
    "Question", {q: "Who was wanted?", as: ["the assistant", "the manager"]}],


// fillers (block 2)
[['filler_2', 2201], "DashedSentence", {s:["The customers", "were", "angry", "at", "the restaurant waiter's", "indifferent attitude."]},
    "Question", {q: "What made customers angry?", as: ["the waiter", "the food"]}],

[['filler_2', 2202], "DashedSentence", {s:["The shoppers", "are fond of", "spending", "all day", "at the mall", "on the weekends."]},
    "Question", {q: "Where do the shoppers love to spend time?", as: ["shopping mall", "coffee shop"]}],

[['filler_2', 2203], "DashedSentence", {s:["The coffee shop", "was", "popular", "as", "a hangout", "among", "political activists."]},
    "Question", {q: "Where do the activists like to go?", as: ["the coffee shop", "the city hall"]}],

[['filler_2', 2204], "DashedSentence", {s:["The school principal", "was", "busy", "at", "dealing with", "paperwork", "all summer."]},
    "Question", {q: "Who had to deal with paperwork?", as: ["the school principal", "the professor"]}],

[['filler_2', 2205], "DashedSentence", {s:["Students", "were", "still", "confused", "about", "what", "the professor", "taught", "in the class."]},
    "Question", {q: "How did students feel about the class?", as: ["confused", "easy to understand"]}],

[['filler_2', 2206], "DashedSentence", {s:["The new student", "was", "tired", "of", "studying", "after", "only three days", "of school."]},
    "Question", {q: "After how many days of school did the student start to be tired of studying?", as: ["three", "five"]}],

[['filler_2', 2207], "DashedSentence", {s:["The storekeepers", "were", "afraid", "that", "riots", "would ensue."]},
    "Question", {q: "Who were afraid?", as: ["the storekeepers", "the policemen"]}],

[['filler_2', 2208], "DashedSentence", {s:["The real estate agent", "was shocked", "when", "he", "revealed", "the house's", "problems."]},
    "Question", {q: "Who revealed the house's problem?", as: ["the agent", "the tenant"]}],

[['filler_2', 2209], "DashedSentence", {s:["The library", "was", "open", "to", "all members", "of the community."]},
    "Question", {q: "What was open to community members?", as: ["the library", "the city hall"]}],

[['filler_2', 2210], "DashedSentence", {s:["Young people", "are", "more interested", "in", "electronic devices", "than", "in", "reading books."]},
    "Question", {q: "What is more attractive to young people?", as: ["electronic devices", "books"]}],

[['filler_2', 2211], "DashedSentence", {s:["The landscaper", "was keen to", "boast about", "his achievements."]},
    "Question", {q: "Who did the boasting?", as: ["the landscaper", "the architect"]}],

[['filler_2', 2212], "DashedSentence", {s:["The dance troupe", "is going to", "set up", "their equipment."]},
    "Question", {q: "Who will set up the equipment?", as: ["the dance troupe", "the choir"]}],

[['filler_2', 2213], "DashedSentence", {s:["The room", "was", "large enough", "to accomodate", "all the people", "in the department."]},
    "Question", {q: "Is the room large enough?", as: ["yes", "no"]}],

[['filler_2', 2214], "DashedSentence", {s:["Many people", "are opposed to", "the death penalty", "out of humanitarianism."]},
    "Question", {q: "What's people's attitude towards death penalty?", as: ["opposed", "supportive"]}],

[['filler_2', 2215], "DashedSentence", {s:["The man", "was", "passionately", "in love", "with", "the girl", "he", "met", "in college."]},
    "Question", {q: "Where did the man meet the girl?", as: ["in college", "in high school"]}],

[['filler_2', 2216], "DashedSentence", {s:["Many of the city cops", "were not", "willing", "to work", "in", "the rough parts", "of town."]},
    "Question", {q: "Who did not want to work?", as: ["the cops", "the taxi drivers"]}],


// Block 3
// MVs
[['MV_AM', 3101], "DashedSentence", {s:["The policeman", "examined", "the suspect", "before", "his colleagues", "arrived."]},
    "Question", {q: "Who was examined?", as: ["the suspect", "the policeman"]}],
[['MV_Un', 3101], "DashedSentence", {s:["The policeman", "saw", "the suspect", "before", "his colleagues", "arrived."]},
    "Question", {q: "Who was seen?", as: ["the suspect", "the policeman"]}],

[['MV_AM', 3102], "DashedSentence", {s:["The man", "transported", "the passengers", "to", "their", "destination."]},
    "Question", {q: "Who did the transporting?", as: ["the man", "the passengers"]}],
[['MV_Un', 3102], "DashedSentence", {s:["The man", "drove", "the passengers", "to", "their", "destination."]},
    "Question", {q: "Who did the driving?", as: ["the man", "the passengers"]}],

[['MV_AM', 3103], "DashedSentence", {s:["The girl", "loved", "the boy", "for", "his", "straightforwadness."]},
    "Question", {q: "Who was loved?", as: ["the boy", "the girl"]}],
[['MV_Un', 3103], "DashedSentence", {s:["The girl", "forgave", "the boy", "for", "his", "straightforwadness."]},
    "Question", {q: "Who was forgiven?", as: ["the boy", "the girl"]}],

[['MV_AM', 3104], "DashedSentence", {s:["The boy", "lifted", "his little sister", "out of", "the cradle", "gently."]},
    "Question", {q: "Who was lifted?", as: ["the sister", "the boy"]}],
[['MV_Un', 3104], "DashedSentence", {s:["The boy", "took", "his little sister", "out of", "the cradle", "gently."]},
    "Question", {q: "Who was taken out of the cradle?", as: ["the sister", "the boy"]}],

[['MV_AM', 3105], "DashedSentence", {s:["The instructor", "graded", "the student", "in", "an unfair manner", "after class."]},
    "Question", {q: "Who did the grading?", as: ["the instructor", "the student"]}],
[['MV_Un', 3105], "DashedSentence", {s:["The instructor", "spoke to", "the student", "in", "an unfair manner", "after class."]},
    "Question", {q: "Who did the speaking?", as: ["the instructor", "the student"]}],

[['MV_AM', 3106], "DashedSentence", {s:["The young woman", "selected", "a friend", "as", "the partner", "for her business."]},
    "Question", {q: "Who did the selecting?", as: ["the woman", "the friend"]}],
[['MV_Un', 3106], "DashedSentence", {s:["The young woman", "chose", "a friend", "as", "the partner", "for her business."]},
    "Question", {q: "Who did the choosing?", as: ["the woman", "the friend"]}],

[['MV_AM', 3107], "DashedSentence", {s:["The manager", "requested", "the secretary", "to announce", "the decision", "of the committee."]},
    "Question", {q: "Who was requested?", as: ["the secretary", "the manager"]}],
[['MV_Un', 3107], "DashedSentence", {s:["The manager", "forbade", "the secretary", "to announce", "the decision", "of the committee."]},
    "Question", {q: "Who was forbidden?", as: ["the secretary", "the manager"]}],

[['MV_AM', 3108], "DashedSentence", {s:["The man", "identified", "his girlfriend", "at", "the entrance", "of the museum."]},
    "Question", {q: "Who was identified?", as: ["the girlfriend", "the man"]}],
[['MV_Un', 3108], "DashedSentence", {s:["The man", "saw", "his girlfriend", "at", "the entrance", "of the museum."]},
    "Question", {q: "Who was seen?", as: ["the girlfriend", "the man"]}],

[['MV_AM', 3109], "DashedSentence", {s:["The criminal", "captured", "the boy", "to blackmail", "his", "parents."]},
    "Question", {q: "Who did the capturing?", as: ["the criminal", "the boy"]}],
[['MV_Un', 3109], "DashedSentence", {s:["The criminal", "hid", "the boy", "to blackmail", "his", "parents."]},
    "Question", {q: "Who did the hiding?", as: ["the criminal", "the boy"]}],

[['MV_AM', 3110], "DashedSentence", {s:["The youngster", "attacked", "a bear", "in", "the forest", "last week."]},
    "Question", {q: "Who did the attacking?", as: ["the youngster", "the bear"]}],
[['MV_Un', 3110], "DashedSentence", {s:["The youngster", "beat", "a bear", "in", "the forest", "last week."]},
    "Question", {q: "Who did the beating?", as: ["the youngster", "the bear"]}],

[['MV_AM', 3111], "DashedSentence", {s:["The manager", "investigated", "the client", "who", "he", "was about to", "collaborate with."]},
    "Question", {q: "Who did the investigating?", as: ["the manager", "the client"]}],
[['MV_Un', 3111], "DashedSentence", {s:["The manager", "wrote to", "the client", "who", "he", "was about to", "collaborate with."]},
    "Question", {q: "Who did the writing?", as: ["the manager", "the client"]}],

[['MV_AM', 3112], "DashedSentence", {s:["The artist", "described", "his dreams", "at", "the party", "to his friends."]},
    "Question", {q: "Who did the describing?", as: ["the artist", "the friends"]}],
[['MV_Un', 3112], "DashedSentence", {s:["The artist", "drew", "his dreams", "at", "the party", "for his friends."]},
    "Question", {q: "Who did the drawing?", as: ["the artist", "the friends"]}],

[['MV_AM', 3113], "DashedSentence", {s:["The committee", "expected", "the woman", "to be", "the leader", "of the company."]},
    "Question", {q: "Who was expected to be the leader?", as: ["the woman", "the committee"]}],
[['MV_Un', 3113], "DashedSentence", {s:["The committee", "chose", "the woman", "to be", "the leader", "of the company."]},
    "Question", {q: "Who was chosen to be the leader?", as: ["the woman", "the committee"]}],

[['MV_AM', 3114], "DashedSentence", {s:["The dog", "scratched", "the man", "violently", "when", "he", "came back", "home."]},
    "Question", {q: "Who did the scratching?", as: ["the dog", "the man"]}],
[['MV_Un', 3114], "DashedSentence", {s:["The dog", "shook", "the man", "violently", "when", "he", "came back", "home."]},
    "Question", {q: "Who did the shaking?", as: ["the dog", "the man"]}],

[['MV_AM', 3115], "DashedSentence", {s:["The man", "recognized", "the woman", "because of", "her", "red hair."]},
    "Question", {q: "Who was recognized?", as: ["the woman", "the man"]}],
[['MV_Un', 3115], "DashedSentence", {s:["The man", "saw", "the woman", "because of", "her", "red hair."]},
    "Question", {q: "Who was seen?", as: ["the woman", "the man"]}],

[['MV_AM', 3116], "DashedSentence", {s:["The school principal", "wanted", "the girl", "to give", "a speech", "at the commencement."]},
    "Question", {q: "Who was wanted to give a speech?", as: ["the girl", "the school principal"]}],
[['MV_Un', 3116], "DashedSentence", {s:["The school principal", "chose", "the girl", "to give", "a speech", "at the commencement."]},
    "Question", {q: "Who was chosen to give a speech?", as: ["the girl", "the school principal"]}],


// fillers (block 3)
[['filler_3', 3201], "DashedSentence", {s:["The children", "in the park", "were", "so noisy", "that", "they", "can", "be heard", "three blocks away."]},
    "Question", {q: "Where are the children?", as: ["in the park", "in the classroom"]}],

[['filler_3', 3202], "DashedSentence", {s:["The power plant", "was", "in need of", "more attention", "during the election."]},
    "Question", {q: "What is in need of more attention?", as: ["the power plant", "the factory"]}],

[['filler_3', 3203], "DashedSentence", {s:["The plane ride", "was", "short", "and", "we", "had", "barely finished", "our food", "before", "it", "landed."]},
    "Question", {q: "How was the plane ride?", as: ["short", "long"]}],

[['filler_3', 3204], "DashedSentence", {s:["The grocery store", "was", "five miles away", "from the apartment."]},
    "Question", {q: "How far away was the grocery store?", as: ["five miles", "three miles"]}],

[['filler_3', 3205], "DashedSentence", {s:["The prisoners", "were unable to", "cross", "the field."]},
    "Question", {q: "Who were unable to cross the field?", as: ["the prisoners", "the officers"]}],

[['filler_3', 3206], "DashedSentence", {s:["The physics course", "was", "hard", "to follow", "for most students."]},
    "Question", {q: "How was the physics course?", as: ["rigorous", "easy"]}],

[['filler_3', 3207], "DashedSentence", {s:["The new student", "was", "under", "everyone's attention", "when", "he", "came in."]},
    "Question", {q: "Who caught everyone's attention?", as: ["the new student", "the new professor"]}],

[['filler_3', 3208], "DashedSentence", {s:["The valuable lamp", "was broken", "by", "the mischievous boy."]},
    "Question", {q: "Who broke the lamp?", as: ["the boy", "the girl"]}],

[['filler_3', 3209], "DashedSentence", {s:["All the undergraduates", "in the class", "were", "struggling to", "keep up."]},
    "Question", {q: "How did the undergraduates find about the class?", as: ["difficult", "easy"]}],

[['filler_3', 3210], "DashedSentence", {s:["Caroline", "was", "very supportive", "during", "this difficult time."]},
    "Question", {q: "How was Caroline?", as: ["supportive", "indifferent"]}],

[['filler_3', 3211], "DashedSentence", {s:["The engineers", "at the plant", "had to", "wear", "helmets."]},
    "Question", {q: "What did the engineers have to wear?", as: ["the helmet", "the gloves"]}],

[['filler_3', 3212], "DashedSentence", {s:["The new experiment", "was", "the source", "of", "a great deal of", "excitement."]},
    "Question", {q: "How was the experiment?", as: ["exciting", "boring"]}],

[['filler_3', 3213], "DashedSentence", {s:["The cost", "of", "private treatment", "is", "prohibitive", "for most people."]},
    "Question", {q: "How is the private treament?", as: ["expensive", "cheap"]}],

[['filler_3', 3214], "DashedSentence", {s:["The president's memoirs", "were", "under attack", "by many critics."]},
    "Question", {q: "Whose memoirs were criticized?", as: ["president", "Secretary"]}],

[['filler_3', 3215], "DashedSentence", {s:["The laptops", "were", "too expensive", "for most students."]},
    "Question", {q: "How were the laptops?", as: ["expensive", "cheap"]}],

[['filler_3', 3216], "DashedSentence", {s:["The girls", "on", "the basketball team", "had to", "practice", "all summer."]},
    "Question", {q: "What sports did the girls play?", as: ["basketball", "volleyball"]}],

]




