var shuffleSequence = seq("setcounter", "consent", "background", "intro", sepWith("sep", seq("practice", "practiceover")), "presep",sepWith("sep", rshuffle(startsWith("v"),startsWith("f"))), "exit");



var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
        ignoreFailure:true
        //errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    //["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).
    
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
    
    ["background", "Form", {html: { include: "background.html" },validators: {},continueMessage:"Click here to send the results."} ],
    
    ["exit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    
    ["practiceover", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "That is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read two sentences and decide which of the two sounds more acceptable to you."],
                          ]}],

    ["intro", "Form", {
        html: { include: "example_intro.html" },
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],
    
    
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "Next you will see a practice example. In the pair you will see, the first sentence may sound more natural and acceptable to you than the second sentence. You should therefore choose the first sentence."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Mice are sitting on the arm of the chair.",
                                   "Mice is sitting on the arm of the chair."]}],
    
    
                                 
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "On the other hand, in this sentence, the second sentence is more acceptable than the first sentence. You should choose the second sentence."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This company relies to our help.",
                                   "This company relies on our help."]}],
    
    
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "The two sentences in this pair might both sound a little strange. Choose which one sounds more acceptable to you."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Shane has no idea from which store the birthday gift is from.",
                                   "Shane has no idea from which store the birthday gift is."]}],
    
    
   
    ["presep", Separator, { transfer: 1500, normalMessage: "Please get ready, we are about to start." }],
    
    
    /*Start here!
    Condition key:
    
    ["v1", #] = restrictive short pair
    ["v2", #] = non-restrictive short pair
    ["v3", #] = restrictive long pair
    ["v4", #] = non-restrictive long pair
    
    The order in each forced choice should always be "active > passive".
    
    Please use the question: "Choose the sentence that is more acceptable."
    
    */
    [["v1",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the students who the principal scolded for over an hour.",
                                     "Here are the students who were scolded by the principal for over an hour."]}],


    [["v2",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Sam's students, who the principal scolded for over an hour.",
                                     "Here are Sam's students, who were scolded by the principal for over an hour."]}],


    [["v3",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the students who Mary said the principal scolded for over an hour.",
                                     "Here are the students who Mary said were scolded by the principal for over an hour."]}],


    [["v4",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Sam's students, who Mary said the principal scolded for over an hour.",
                                     "Here are Sam's students, who Mary said were scolded by the principal for over an hour."]}],


    [["v1",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the HR representatives who the CEO assembled for an important meeting.",
                                     "These are the HR representatives who were assembled by the CEO for an important meeting."]}],


    [["v2",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the company's HR representatives, who the CEO assembled for an important meeting.",
                                     "These are the company's HR representatives, who were assembled by the CEO for an important meeting."]}],


    [["v3",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the HR representatives who Susan announced the CEO assembled for an important meeting.",
                                     "These are the HR representatives who Susan announced were assembled by the CEO for an important meeting."]}],


    [["v4",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the company's HR representatives, who Susan announced the CEO assembled for an important meeting.",
                                     "These are the company's HR representatives, who Susan announced were assembled by the CEO for an important meeting."]}],


    [["v1",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the patients who the nurse visited occasionally.",
                                     "Here are the patients who were visited by the nurse occasionally."]}],


    [["v2",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the doctor's patients, who the nurse visited occasionally.",
                                     "Here are the doctor's patients, who were visited by the nurse occasionally."]}],


    [["v3",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the patients who John presumed the nurse visited occasionally.",
                                     "Here are the patients who John presumed were visited by the nurse occasionally."]}],


    [["v4",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the doctor's patients, who John presumed the nurse visited occasionally.",
                                     "Here are the doctor's patients, who John presumed were visited by the nurse occasionally."]}],


    [["v1",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the catcher who the coach fired for no reason.",
                                     "This is the catcher who was fired by the coach for no reason."]}],


    [["v2",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the team's catcher, who the coach fired for no reason.",
                                     "This is the team's catcher, who was fired by the coach for no reason."]}],


    [["v3",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the catcher who Jane complained the coach fired for no reason.",
                                     "This is the catcher who Jane complained was fired by the coach for no reason."]}],


    [["v4",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the team's catcher, who Jane complained the coach fired for no reason.",
                                     "This is the team's catcher, who Jane complained was fired by the coach for no reason."]}],


    [["v1",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the passengers who the pilot briefed before takeoff.",
                                     "Here are the passengers who were briefed by the pilot before takeoff."]}],


    [["v2",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the airplane's passengers, who the pilot briefed before takeoff.",
                                     "Here are the airplane's passengers, who were briefed by the pilot before takeoff."]}],


    [["v3",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the passengers who Jack assumed the pilot briefed before takeoff.",
                                     "Here are the passengers who Jack assumed were briefed by the pilot before takeoff."]}],


    [["v4",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the airplane's passengers, who Jack assumed the pilot briefed before takeoff.",
                                     "Here are the airplane's passengers, who Jack assumed were briefed by the pilot before takeoff."]}],


    [["v1",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the dentist who the hygienist assisted this morning.",
                                     "This is the dentist who was assited by the hygienist this morning."]}],


    [["v2",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is David's dentist, who the hygienest assisted this morning.",
                                     "This is David's dentist, who was assited by the hygienist this morning."]}],


    [["v3",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the dentist who Mark hoped the hygienist assisted this morning.",
                                     "This is the dentist who Mark hoped was assited by the hygienist this morning."]}],


    [["v4",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is David's dentist, who Mark hoped the hygienist assisted this morning.",
                                     "This is David's dentist, who Mark hoped was assited by the hygienist this morning."]}],


    [["v1",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the fairies who the troll chased out of the trees.",
                                     "Here are the fairies who were chased by the troll out of the trees."]}],


    [["v2",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the forest's fairies, who the troll chased out of the trees.",
                                     "Here are the forest's fairies, who were chased by the troll out of the trees."]}],


    [["v3",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the fairies who Alice proved the troll chased out of the trees.",
                                     "Here are the fairies who Alice proved were chased by the troll out of the trees."]}],


    [["v4",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the forest's fairies, who Alice proved the troll chased out of the trees.",
                                     "Here are the forest's fairies, who Alice proved were chased by the troll out of the trees."]}],


    [["v1",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the ministers who the parishioners denounced for heresy.",
                                     "These are the ministers who were denounced by the parishioners for heresy."]}],


    [["v2",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the church's ministers, who the parishioners denounced for heresy.",
                                     "These are the church's ministers, who were denounced by the parishioners for heresy."]}],


    [["v3",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the ministers who James confirmed the parishioners denounced for heresy.",
                                     "These are the ministers who James confirmed were denounced by the parishioners for heresy."]}],


    [["v4",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the church's ministers, who James confirmed the parishioners denounced for heresy.",
                                     "These are the church's ministers, who James confirmed were denounced by the parishioners for heresy."]}],


    [["v1",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the princess who the knights escorted through the village.",
                                     "Here is the princess who was escorted by the knights through the village."]}],


    [["v2",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the country's princess, who the knights escorted through the village.",
                                     "Here is the country's princess, who was escorted by the knights through the village."]}],


    [["v3",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the princess who Henry implied the knights escorted through the village.",
                                     "Here is the princess who Henry implied was escorted by the knights through the village."]}],


    [["v4",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the country's princess, who Henry implied the knights escorted through the village.",
                                     "Here is the country's princess, who Henry implied was escorted by the knights through the village."]}],


    [["v1",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the tutors who Charles prepped all last week.",
                                     "These are the tutors who were prepped by Charles all last week."]}],


    [["v2",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the institute's tutors, who Charles prepped all last week.",
                                     "These are the institute's tutors, who were prepped by Charles all last week."]}],


    [["v3",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the tutors who Cathy asserted Charles prepped all last week.",
                                     "These are the tutors who Cathy asserted were prepped by Charles all last week."]}],


    [["v4",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the institute's tutors, who Cathy asserted Charles prepped all last week.",
                                     "These are the institute's tutors, who Cathy asserted were prepped by Charles all last week."]}],


    [["v1",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the jurors who the judge consulted in the big trial.",
                                     "Here are the jurors who were consulted by the judge in the big trial."]}],


    [["v2",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are today's jurors, who the judge consulted in the big trial.",
                                     "Here are today's jurors, who were consulted by the judge in the big trial."]}],


    [["v3",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the jurors who Leonard supposed the judge consulted in the big trial.",
                                     "Here are the jurors who Leonard supposed were consulted by the judge in the big trial."]}],


    [["v4",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are today's jurors, who Leonard supposed the judge consulted in the big trial.",
                                     "Here are today's jurors, who Leonard supposed were consulted by the judge in the big trial."]}],


    [["v1",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the parents who the teacher reassured with a calm voice.",
                                     "These are the parents who were reassured by the teacher with a calm voice."]}],


    [["v2",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are Sally's parents, who the teacher reassured with a calm voice.",
                                     "These are Sally's parents, who were reassured by the teacher with a calm voice."]}],


    [["v3",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the parents who Linda was certain the teacher reassured with a calm voice.",
                                     "These are the parents who Linda was certain were reassured by the teacher with a calm voice."]}],


    [["v4",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are Sally's parents, who Linda was certain the teacher reassured with a calm voice.",
                                     "These are Sally's parents, who Linda was certain were reassured by the teacher with a calm voice."]}],


    [["v1",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the survivors who the fireman rescued in a hurry.",
                                     "These are the survivors who were rescued by the fireman in a hurry."]}],


    [["v2",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the wreck's survivors, who the fireman rescued in a hurry.",
                                     "These are the wreck's survivors, who were rescued by the fireman in a hurry."]}],


    [["v3",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the survivors who Adam remarked the fireman rescued in a hurry.",
                                     "These are the survivors who Adam remarked were rescued by the fireman in a hurry."]}],


    [["v4",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the wreck's survivors, who Adam remarked the fireman rescued in a hurry.",
                                     "These are the wreck's survivors, who Adam remarked were rescued by the fireman in a hurry."]}],


    [["v1",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the captain who the sailors criticized without hesitation.",
                                     "Here is the captain who was criticized by the sailors without hesitation."]}],


    [["v2",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the ship's captain, who the sailors criticized without hesitation.",
                                     "Here is the ship's captain, who was criticized by the sailors without hesitation."]}],


    [["v3",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the captain who Betty alleged the sailors criticized without hesitation.",
                                     "Here is the captain who Betty alleged was criticized by the sailors without hesitation."]}],


    [["v4",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here is the ship's captain, who Betty alleged the sailors criticized without hesitation.",
                                     "Here is the ship's captain, who Betty alleged was criticized by the sailors without hesitation."]}],


    [["v1",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the candidates who the news anchor interviewed for two hours.",
                                     "These are the candidates who were interviewed by the news anchor for two hours."]}],


    [["v2",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are this year's candidates, who the news anchor interviewed for two hours.",
                                     "These are this year's candidates, who were interviewed by the news anchor for two hours."]}],


    [["v3",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the candidates who Ben insisted the news anchor interviewed for two hours.",
                                     "These are the candidates who Ben insisted were interviewed by the news anchor for two hours."]}],


    [["v4",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are this year's candidates, who Ben insisted the news anchor interviewed for two hours.",
                                     "These are this year's candidates, who Ben insisted were interviewed by the news anchor for two hours."]}],


    [["v1",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the sue chefs who the head chef complimented after work.",
                                     "Here are the sue chefs who were complimented by the head chef after work."]}],


    [["v2",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the restaurant's sue chefs, who the head chef complimented after work.",
                                     "Here are the restaurant's sue chefs, who were complimented by the head chef after work."]}],


    [["v3",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the sue chefs who Daisy speculated the head chef complimented after work.",
                                     "Here are the sue chefs who Daisy speculated were complimented by the head chef after work."]}],


    [["v4",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the restaurant's sue chefs, who Daisy speculated the head chef complimented after work.",
                                     "Here are the restaurant's sue chefs, who Daisy speculated were complimented by the head chef after work."]}],


    [["v1",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the runners who the trainer recorded on the track.",
                                     "Here are the runners who were recorded by the trainer on the track."]}],


    [["v2",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the school's runners, who the trainer recorded on the track.",
                                     "Here are the school's runners, who were recorded by the trainer on the track."]}],


    [["v3",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the runners who Derek thought the trainer recorded on the track.",
                                     "Here are the runners who Derek thought were recorded by the trainer on the track."]}],


    [["v4",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the school's runners, who Derek thought the trainer recorded on the track.",
                                     "Here are the school's runners, who Derek thought were recorded by the trainer on the track."]}],


    [["v1",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mayor who Stephen thanked on Sunday.",
                                     "This is the mayor who was thanked by Stephen on Sunday."]}],


    [["v2",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the city's mayor, who Stephen thanked on Sunday.",
                                     "This is the city's mayor, who was thanked by Stephen on Sunday."]}],


    [["v3",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mayor who Edward swore Stephen thanked on Sunday.",
                                     "This is the mayor who Edward swore was thanked by Stephen on Sunday."]}],


    [["v4",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the city's mayor, who Edward swore Stephen thanked on Sunday.",
                                     "This is the city's mayor, who Edward swore was thanked by Stephen on Sunday."]}],


    [["v1",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the photographers who Joni selected for the project.",
                                     "Here are the photographers who were selected by Joni for the project."]}],


    [["v2",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the event's photographers, who Joni selected for the project.",
                                     "Here are the event's photographers, who were selected by Joni for the project."]}],


    [["v3",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the photographers who Eliza rumored Joni selected for the project.",
                                     "Here are the photographers who Eliza rumored were selected by Joni for the project."]}],


    [["v4",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the event's photographers, who Eliza rumored Joni selected for the project.",
                                     "Here are the event's photographers, who Eliza rumored were selected by Joni for the project."]}],


    [["v1",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the lawyers who the bailiff removed from the court room.",
                                     "Here are the lawyers who were removed by the bailiff from the court room."]}],


    [["v2",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Tom's lawyers, who the bailiff removed from the court room.",
                                     "Here are Tom's lawyers, who were removed by the bailiff from the court room."]}],


    [["v3",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the lawyers who Gary stated the bailiff removed from the court room.",
                                     "Here are the lawyers who Gary stated were removed by the bailiff from the court room."]}],


    [["v4",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Tom's lawyers, who Gary stated the bailiff removed from the court room.",
                                     "Here are Tom's lawyers, who Gary stated were removed by the bailiff from the court room."]}],


    [["v1",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the stunt doubles who the director ridiculed on set.",
                                     "These are the stunt doubles who were ridiculed by the director on set."]}],


    [["v2",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the actor's stunt doubles, who the director ridiculed on set.",
                                     "These are the actor's stunt doubles, who were ridiculed by the director on set."]}],


    [["v3",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the stunt doubles who Grace heard the director ridiculed on set.",
                                     "These are the stunt doubles who Grace heard were ridiculed by the director on set."]}],


    [["v4",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the actor's stunt doubles, who Grace heard the director ridiculed on set.",
                                     "These are the actor's stunt doubles, who Grace heard were ridiculed by the director on set."]}],


    [["v1",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the children who Phil timed during the race.",
                                     "Here are the children who were timed by Phil during the race."]}],


    [["v2",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Jamie's children, who Phil timed during the race.",
                                     "Here are Jamie's children, who were timed by Phil during the race."]}],


    [["v3",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the children who Harry professed Phil timed during the race.",
                                     "Here are the children who Harry professed were timed by Phil during the race."]}],


    [["v4",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Jamie's children, who Harry professed Phil timed during the race.",
                                     "Here are Jamie's children, who Harry professed were timed by Phil during the race."]}],


    [["v1",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the painters who the curator discovered on the internet.",
                                     "Here are the painters who were discovered by the curator on the internet."]}],


    [["v2",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are this month's painters, who the curator discovered on the internet.",
                                     "Here are this month's painters, who were discovered by the curator on the internet."]}],


    [["v3",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the painters who Caroline figured the curator discovered on the internet.",
                                     "Here are the painters who Caroline figured were discovered by the curator on the internet."]}],


    [["v4",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are this month's painters, who Caroline figured the curator discovered on the internet.",
                                     "Here are this month's painters, who Caroline figured were discovered by the curator on the internet."]}],


    [["v1",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the employees who Monica trained on the job.",
                                     "These are the employees who were trained by Monica on the job."]}],


    [["v2",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are Rachel's employees, who Monica trained on the job.",
                                     "These are Rachel's employees, who were trained by Monica on the job."]}],


    [["v3",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the employees who Matthew doubted Monica trained on the job.",
                                     "These are the employees who Matthew doubted were trained by Monica on the job."]}],


    [["v4",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are Rachel's employees, who Matthew doubted Monica trained on the job.",
                                     "These are Rachel's employees, who Matthew doubted were trained by Monica on the job."]}],


    [["v1",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the janitors who Jill attacked out of the blue.",
                                     "These are the janitors who were attacked by Jill out of the blue."]}],


    [["v2",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the building's janitors, who Jill attacked out of the blue.",
                                     "These are the building's janitors, who were attacked by Jill out of the blue."]}],


    [["v3",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the janitors who Nina feared Jill attacked out of the blue.",
                                     "These are the janitors who Nina feared were attacked by Jill out of the blue."]}],


    [["v4",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the building's janitors, who Nina feared Jill attacked out of the blue.",
                                     "These are the building's janitors, who Nina feared were attacked by Jill out of the blue."]}],


    [["v1",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the neighbors who the police questioned on Tuesday.",
                                     "Here are the neighbors who were questioned by the police on Tuesday."]}],


    [["v2",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Nathan's neighbors, who the police questioned on Tuesday.",
                                     "Here are Nathan's neighbors, who were questioned by the police on Tuesday."]}],


    [["v3",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the neighbors who Neil mentioned the police questioned on Tuesday.",
                                     "Here are the neighbors who Neil mentioned were questioned by the police on Tuesday."]}],


    [["v4",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are Nathan's neighbors, who Neil mentioned the police questioned on Tuesday.",
                                     "Here are Nathan's neighbors, who Neil mentioned were questioned by the police on Tuesday."]}],


    [["v1",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the nominees who the judges greeted with applause.",
                                     "These are the nominees who were greeted by the judges with applause."]}],


    [["v2",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the contest's nominees, who the judges greeted with applause.",
                                     "These are the contest's nominees, who were greeted by the judges with applause."]}],


    [["v3",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the nominees who Nancy learned the judges greeted with applause.",
                                     "These are the nominees who Nancy learned were greeted by the judges with applause."]}],


    [["v4",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the contest's nominees, who Nancy learned the judges greeted with applause.",
                                     "These are the contest's nominees, who Nancy learned were greeted by the judges with applause."]}],


    [["v1",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the doctors who the district attorney investigated on a hunch.",
                                     "These are the doctors who were investigated by the district attorney on a hunch."]}],


    [["v2",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the hospital's doctors, who the district attorney investigated on a hunch.",
                                     "These are the hospital's doctors, who were investigated by the district attorney on a hunch."]}],


    [["v3",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the doctors who Oscar concluded the district attorney investigated on a hunch.",
                                     "These are the doctors who Oscar concluded were investigated by the district attorney on a hunch."]}],


    [["v4",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the hospital's doctors, who Oscar concluded the district attorney investigated on a hunch.",
                                     "These are the hospital's doctors, who Oscar concluded were investigated by the district attorney on a hunch."]}],


    [["v1",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the co-authors who the librarian invited to the school.",
                                     "These are the co-authors who were invited by the librarian to the school."]}],


    [["v2",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the book's co-authors, who the librarian invited to the school.",
                                     "These are the book's co-authors, who were invited by the librarian to the school."]}],


    [["v3",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the co-authors who Olivia deduced the librarian invited to the school.",
                                     "These are the co-authors who Olivia deduced were invited by the librarian to the school."]}],


    [["v4",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the book's co-authors, who Olivia deduced the librarian invited to the school.",
                                     "These are the book's co-authors, who Olivia deduced were invited by the librarian to the school."]}],


    [["v1",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the skiers who John found during the snowstorm.",
                                     "Here are the skiers who were found by John during the snowstorm."]}],


    [["v2",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the club's skiers, who John found during the snowstorm.",
                                     "Here are the club's skiers, who were found by John during the snowstorm."]}],


    [["v3",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the skiers who Sam testified John found during the snowstorm.",
                                     "Here are the skiers who Sam testified were found by John during the snowstorm."]}],


    [["v4",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the club's skiers, who Sam testified John found during the snowstorm.",
                                     "Here are the club's skiers, who Sam testified were found by John during the snowstorm."]}],


    [["v1",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the accountants who the manager guided to the break room.",
                                     "Here are the accountants who were guided by the manager to the break room."]}],


    [["v2",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the organization's accountants, who the manager guided to the break room.",
                                     "Here are the organization's accountants, who were guided by the manager to the break room."]}],


    [["v3",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the accountants who Tina suspected the manager guided to the break room.",
                                     "Here are the accountants who Tina suspected were guided by the manager to the break room."]}],


    [["v4",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["Here are the organization's accountants, who Tina suspected the manager guided to the break room.",
                                     "Here are the organization's accountants, who Tina suspected were guided by the manager to the break room."]}],


    [["v1",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the astronauts who the president praised in a press conference.",
                                     "These are the astronauts who were praised by the president in a press conference."]}],


    [["v2",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are NASA's astronauts, who the president praised in a press conference.",
                                     "These are NASA's astronauts, who were praised by the president in a press conference."]}],


    [["v3",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the astronauts who Tim confessed the president praised in a press conference.",
                                     "These are the astronauts who Tim confessed were praised by the president in a press conference."]}],


    [["v4",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are NASA's astronauts, who Tim confessed the president praised in a press conference.",
                                     "These are NASA's astronauts, who Tim confessed were praised by the president in a press conference."]}],

    [["f",33], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the boxer who sometimes loses his gloves.",
                                   "This is the boxer who sometimes lose his gloves."]}],
                        
    [["f",34], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the pirates who unfortunately was bombarding the ship.",
                                   "These are the pirates who unfortunately were bombarding the ship."]}],
    
    [["f",35], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here is the bachelor who really looks like Tom Cruise.",
                                   "Here is the bachelor who really look like Tom Cruise."]}],
    
    [["f",36], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here are the waiters who usually works the night shift.",
                                   "Here are the waiters who usually work the night shift."]}],
                        
    [["f",37], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the vendor who typically sells precious stones.",
                                   "This is the vendor who typically sell precious stones."]}],
    
    [["f",38], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the dancers who always steals the show.",
                                   "These are the dancers who always steal the show."]}],
    
    [["f",39], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here is the singer who regularly meets with her fans.",
                                   "Here is the singer who regularly meet with her fans."]}],
    
    [["f",40], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here are the athletes who consistently wins gold medals.",
                                   "Here are the athletes who consistently win gold medals."]}],
                        
    [["f",41], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the sheriff who seldom leaves the office.",
                                   "This is the sheriff who seldom leave the office."]}],
    
    [["f",42], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the comedians who rarely tells jokes sober.",
                                   "These are the comedians who rarely tell jokes sober."]}],


];
