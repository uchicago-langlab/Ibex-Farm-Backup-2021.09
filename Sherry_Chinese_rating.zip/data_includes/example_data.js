var shuffleSequence = seq("consent","intro", "intro1",sepWith("sep", seq("practice")), sepWith("sep", rshuffle(startsWith("HC"), startsWith("LC"))),"exit");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 300,
        normalMessage: " "
        //errorMessage: "回答错误。请等待下一个短语。"
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "按下数字键或单机框作答",
        leftComment: "非常不合理", rightComment: "非常合理"
    },
    "Question", {
        hasCorrect: false,
        randomOrder: false
    },

    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];
 // insert breaks
function modifyRunningOrder(ro) {

 for (var i = 0; i < ro.length; ++i) {
 if (i % 24 == 22 && i > 30 && i < 300) {
 ro[i].push(new DynamicElement(
 "Message",
 { html: "<p>   请休息一下，实验将在10秒后开始。</p>", transfer: 10000 },
 true
 ));
 }
 }
 return ro;
 }

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).
    ["consent", "Form", {
        html: { include: "example_intro.html" },
        
    } ],

    ["intro", "Form", {
        html: { include: "intro.html" },
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],
    ["intro1", "Form", {
        html: { include: "intro1.html" },
 
    } ],
    ["break", "Message", {
        html: { include: "break.html" },
        transfer: "keypress"
    } ],
    ["exit", "Form", {
        html: { include: "exit.html" },
        
    } ],

    //
    // Three practice items for self-paced reading (one with a comprehension question).
    //
    ["practice", "AcceptabilityJudgment", {s: "这个问题没有正确答案请点击或者按下数字作答"}],
    ["practice", "AcceptabilityJudgment", {s: "一只铅笔是较为合理的短语，请选择5-7之间的任意数字。"}],
    ["practice", "AcceptabilityJudgment", {s: "一块铅笔"}],
    

    //
    // Two "real" (i.e. non-filler) self-paced reading items with corresponding acceptability judgment items.
    // There are two conditions.
    //
[["HC.AN.VB",11], "AcceptabilityJudgment",{s:"激化税款"}],
[["HC.AN.VB",12], "AcceptabilityJudgment",{s:"推卸短信"}],
[["HC.AN.VB",13], "AcceptabilityJudgment",{s:"名列人群"}],
[["HC.LC.VB",11], "AcceptabilityJudgment",{s:"激化斗争"}],
[["HC.LC.VB",12], "AcceptabilityJudgment",{s:"推卸工作"}],
[["HC.LC.VB",13], "AcceptabilityJudgment",{s:"名列探花"}],
[["HC.HC.VB",11], "AcceptabilityJudgment",{s:"激化矛盾"}],
[["HC.HC.VB",12], "AcceptabilityJudgment",{s:"推卸责任"}],
[["HC.HC.VB",13], "AcceptabilityJudgment",{s:"名列前茅"}]]



    