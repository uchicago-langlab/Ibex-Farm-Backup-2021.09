var shuffleSequence = seq("setcounter","consent", "introfirst", "intro","intro2", seq("practice","practiceover", rshuffle(startsWith("E"))), "brexit");
//rshuffle(startsWith("E"),startsWith("f")))
//var shuffleSequence = seq("setcounter", "Demog", "instr", rshuffle(startsWith("item")));

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
"Separator", {
                ignoreFailure: "true"
    },
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: null,
        randomOrder: false,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [


["setcounter", "__SetCounter__", { }],

    
// ["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
// ["instr", "Form", {consentRequired: true, html: {include: "instr.html" }} ],

["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro2", "Form", {consentRequired: true, html: { include: "intro3.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: decide whether or not the second word you've seen is a word of English."] 
],continueMessage:"Click here to start the experiment."}],
    
  
  //practice
["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>favorite</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>elephant</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>game</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>sleavs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>bank</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>chair</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>bark</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>creacs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],

    
 //Scalar items   
[["Ealternative", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> allowed </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> obligatory </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  reputable </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> obligatory </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> attractive </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> stunning </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> brutal </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> stunning </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> begin </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> complete </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> defend </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> complete</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> believe </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> know </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  meet </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> know </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> big </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> enormous </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  illegal</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> enormous </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cool </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> cold </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> left </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  cold </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>damage</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> destroy </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> gather  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> destroy</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dark </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> black </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  sure </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> black</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> difficult </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> impossible </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> developing </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>impossible  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dirty </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> filthy </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  gracious </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> filthy  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dislike </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> loathe </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   thaw</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> loathe  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> double </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> triple</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  silence </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>triple </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> equally </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> more </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   there </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>more</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> funny </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hilarious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  relational</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hilarious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> good </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> excellent </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> digital</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  excellent </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 16], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> happy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ecstatic </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 16], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  specified </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>ecstatic  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 17], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>hard </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>unsolvable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 17], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  herniated </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> unsolvable</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 18], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> harmful</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> deadly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 18], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> written</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> deadly</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 19], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> here </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> everywhere </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 19], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  frequently</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> everywhere </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 20], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> hungry </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> starving </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 20], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  pronounced </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>starving  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 21], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> intelligent </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> brilliant</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 21], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> subsequent</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  brilliant</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 22], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>intimidating </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> terrifying </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 22], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> applicable </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> terrifying </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 23], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> largely </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> totally </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 23], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   anywhere</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> totally </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 24], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> like </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> love </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 24], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> move </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> love</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 25], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> match </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> exceed </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 25], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  regret </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>exceed  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 26], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> mostly </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> entirely </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 26], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> carefully </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> entirely  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 27], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> old </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ancient </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 27], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  surprised </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ancient </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 28], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> once</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> twice </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 28], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> please  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> twice  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 29], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> or </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> and </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 29], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  yes </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> and</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 30], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> overweight </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> obese </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 30], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  raging  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> obese</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 31], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> overwhelmingly </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> unanimously </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 31], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  progressively </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> unanimously  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 32], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> palatable </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> delicious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 32], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   suspicious</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>delicious  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 33], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> partially </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> completely </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 33], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  yesterday </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  completely</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 34], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> permit </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> require </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

//overlaps!!
[["Eunrelated", 34], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  increase </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> require  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 35], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> polished </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> impeccable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 35], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  consensual </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> impeccable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 36], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> possible </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> certain </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 36], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  western </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> certain </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 37], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> pretty </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> beautiful </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 37], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  following </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> beautiful  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 38], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> primarily </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> exclusively </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 38], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  desperately</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  exclusively </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 39], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> probably </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> necessarily </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 39], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> effectively </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> necessarily </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 40], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> reduce </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> eliminate </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 40], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  communicate </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> eliminate </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 41], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> scared </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> petrified </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 41], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   discerning</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> petrified</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 42], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> serious </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> life-threatening </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 42], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  centennial</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> life-threatening </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 43], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> similar </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> identical </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 43], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  instructional</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> identical </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 44], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> slow </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> stop</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 44], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  pay</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> stop</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 45], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> small </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tiny </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 45], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> afraid </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>tiny   </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 46], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> snug </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tight </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 46], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>   mere </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>tight </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 47], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> some </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> all </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 47], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> next </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> all  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 48], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> start </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> finish </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 48], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  reveal</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> finish </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 49], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> survive </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> strive </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 49], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>float </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>strive  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 50], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tired</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> exhausted</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 50], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> normative</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> exhausted </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 51], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tolerate </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> encourage </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 51], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  establish </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>encourage </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 52], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> try </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> succeed </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 52], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>attack </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  succeed  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 53], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> ugly </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hideous </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 53], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  pandemic </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hideous  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 54], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> understandable </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> articulate</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 54], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> diagonal  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>articulate </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 55], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> unpleasant</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> disgusting </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 55], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  sizable</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> disgusting  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 56], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> usually </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> always </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 56], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> again </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> always </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 57], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> want </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> need </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 57], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> reach </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  need  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 58], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> warm </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hot </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 58], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>huge </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> hot </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 59], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> well </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> superbly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 59], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> startlingly </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> superbly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Ealternative", 60], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> willing </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> eager </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Eunrelated", 60], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> homeless </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  eager </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],


//Thomas items: 60 symmetrical associates. the unrelated primes are taken from forward associates.
[["Esubalternative", 61], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>girl  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> boy</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 61], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> boulevard</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> boy </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 62], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> outside </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>inside </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 62], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>famine </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> inside </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 63], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> son </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>daughter </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 63], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>elk </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> daughter </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 64], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>far  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>near </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 64], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>truthful </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  near</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 65], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>brother  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>sister </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 65], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>slay </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> sister </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 66], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>innocent  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> guilty</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 66], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>atom </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> guilty </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 67], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> stupid </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> dumb</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 67], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cigar </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> dumb </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 68], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dawn </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>dusk </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 68], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>quill </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> dusk </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 69], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dryer </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>washer </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 69], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cobweb </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> washer </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 70], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> top </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> bottom</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 70], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>mare </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> bottom </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 71], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> standing </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> sitting</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 71], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>silence </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> sitting </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 72], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> scream </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>yell </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 72], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> crevice</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> yell </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 73], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>shirt  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> blouse</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 73], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> elbow</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> blouse </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 74], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  wife</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> husband</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 74], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> shears</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>husband  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 75], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  bride</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>groom </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 75], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tickle</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> groom </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 76], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> hammer </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>nail </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 76], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>butcher </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> nail</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 77], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>many  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>few </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 77], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> trousers</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> few </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 78], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  feet</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>toes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 78], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>dagger </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> toes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 79], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> borrow </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>lend </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 79], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tote</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>lend  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 80], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>male  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> female</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 80], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> toaster</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> female </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 81], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>good  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> bad</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 81], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>medical </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> bad </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 82], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  loose</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tight</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 82], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>peel </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tight </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 83], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> found </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>lost </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 83], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> crescent</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> lost </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 84], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  gold</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>silver </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 84], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>document </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> silver </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 85], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> uncle </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>aunt </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 85], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> aroma</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> aunt </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 86], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dinner </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> supper</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 86], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>kinetic </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  supper</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 87], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>positive  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>negative </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 87], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> mule</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> negative </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 88], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> prince </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> princess</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 88], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>lollipop </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>princess  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 89], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> minimum </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> maximum</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 89], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> touchdown</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> maximum </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 90], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> mine </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> yours</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 90], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>syringe </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> yours </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 120], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> early </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>late </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 120], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> kiwi</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>late  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 91], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> full </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> empty</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 91], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>keg </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>empty  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 92], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> fork </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>spoon </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 92], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> jupiter</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> spoon </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 93], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> over </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>under </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 93], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>galaxy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> under </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 94], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  garbage</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>trash </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 94], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> fracture</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> trash </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 95], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>lemon  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> lime</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 95], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> powerful</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> lime </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 96], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> even </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> odd</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 96], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> twister</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> odd </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 97], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> monkey </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ape</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 97], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>shutter </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ape </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 98], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> west </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> east</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 98], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> racquet</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> east </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 99], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> circle </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> square</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 99], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dim</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> square </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 100], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> verb </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> noun</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 100], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>component </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> noun </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 101], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  salt</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>pepper </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 101], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cobra </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> pepper </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 102], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> push </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>shove </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 102], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> nauseous</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> shove </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 103], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>actor  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> actress</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 103], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> hornet</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> actress </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 104], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  swamp</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>marsh </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 104], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>dine </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> marsh </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 105], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> man </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>woman </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 105], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> victor</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> woman </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

//overlaps
[["Esubalternative", 106], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> black </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>white </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 106], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>acre </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> white </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 107], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> right </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>left </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 107], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> malaria</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>left  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 108], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  syrup</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>pancakes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 108], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>lily </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> pancakes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 109], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> mom </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> dad</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 109], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> cafeteria</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>dad  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 110], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> remember</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>forget </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 110], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> survive</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> forget </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 111], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> today </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>tomorrow </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 111], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>interrupt </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>tomorrow  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 112], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> poor </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> rich</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 112], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>airport </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> rich </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 113], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  north</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> south</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 113], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> ashtray</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  south</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 114], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dime </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>nickel </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 114], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>annual </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>nickel  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 115], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> buyer </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>seller </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 115], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> wait</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>seller  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 116], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  grandma</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> grandpa</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 116], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> bulb</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  grandpa</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 117], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>forward  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> backward</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 117], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>plane </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>backward  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 118], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> increase </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>decrease </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 118], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> rude</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> decrease </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],

[["Esubalternative", 119], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> plus </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>minus </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}], 

[["Esubunrelated", 119], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>yearly </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> minus </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 1}],



//fillers: 

["Efiller1", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> calories </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> spraize  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller2", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> server </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> knewed    </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller3", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> cookies </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> sckared </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller4", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> sugar</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ghland </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller5", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>during </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>ghroats</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller6", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> worn</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>kleens</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller7", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> along</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>crtrexuch  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller8", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>bedroom </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>trex </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller9", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>alone </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>rheys</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller10", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>packed </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>citts</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller11", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>back </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>eals</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller12", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> scars</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>wayed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller13", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> amount</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>psells</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller14", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> horse</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>kaud</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller15", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>greedy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>keuth</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller16", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> under</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>koule</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller17", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>pickles </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>rypt</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller18", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>ponytail </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>huft</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller19", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> surgery</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>glene</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller20", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>lease </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>spewd</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller21", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> bridge</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>pruiff   </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller22", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> came</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>stintz</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller23", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>spy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>sckou  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller24", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>separated </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>sckou  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller25", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> drive</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>skard</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller26", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> fireworks</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>smerched</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller27", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> halted</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>chaugh </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller28", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> paper</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>dedes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller29", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>flavor </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>yais</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller30", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> cuddly</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>nuice</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller31", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> eating</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>thomms</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller32", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>handkerchief </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>knowndge</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller33", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> zone</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>scome</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller34", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Thursday</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>smornte</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller35", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>came </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>tweamms</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller36", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cotton candy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>truffs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller37", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>bottle </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>frournde</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller38", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>table </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>slowds</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller39", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> fascinating</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>proante</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller40", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> expected</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>scwursts</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller41", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dentist</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>blignth </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller42", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>saddened </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>skurs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller43", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> children</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>vighm</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller44", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> healthy</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>brarbed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller45", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> sandcastle</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>flalphed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller46", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> white</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>claned</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller47", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> red</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>dourved</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller48", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>farewell </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>jergued</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller49", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> risky</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>jauphed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller50", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dish</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>gheen</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller51", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>young </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>shaumb</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller52", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> purple</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>ghaint</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller53", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>long </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>shrames</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller54", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> nocturnal</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>gwerl</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller55", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>gold </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>ghlud</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller56", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> vegetarian</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>thwanc</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller57", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> fragrant</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>thruved</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller58", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> chewy</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>knasps</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller59", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>furry </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>scoands</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller60", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Norwegian</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>wheighm</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


//nonwords from Lupke&Pexman. primes generated online.
["Efiller61", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> vain</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  biast </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller62", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  unity </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  broin</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller63", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> absolute  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> cheir</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller64", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> dairy</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> chiat </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller65", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> remain</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>cirse </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller66", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  close</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>cleam </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller67", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> minute </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> crean  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller68", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> loot </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  dlain</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller69", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> consider </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>dronk </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller70", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> freckle </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> foult</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],

		["Efiller71", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>discover </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> friak  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller72", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> pottery </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> furce </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller73", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> sink  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> gloan</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller74", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>exploration </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> grien </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller75", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> contemporary</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> grute</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller76", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>brink  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> haund</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller77", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>confine  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> lamon</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller78", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> horizon </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> matal </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller79", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>unit  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> mavic</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller80", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>slot  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>naise </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],

["Efiller81", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tenant</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> pelch  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller82", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  offspring </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> piace </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller83", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  spot </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> pluce</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller84", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>slam </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> ponic </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller85", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>cooperation </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>puise </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller86", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> bang </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>sarve</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller87", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>offensive  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> scile  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller88", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  thank</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>scolp  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller89", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  foster</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> slail</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller90", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>medieval  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>slale </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


	["Efiller91", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> format</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> sluep  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller92", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> window  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>snirt  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller93", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> investment  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>speam </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller94", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> bounce </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> spoce </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller95", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> deserve</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tanic</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller96", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> hostage </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>teoth </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller97", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> sandwich </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> tleat  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller98", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> jacket </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> toach </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller99", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> slip </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> troil</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller100", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> scandal </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>wreat </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],

	["Efiller101", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> beam </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>  amter </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller102", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> censorship  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> blime </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller103", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> draw  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>chaim </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller104", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> lake </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> chiek </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller105", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> poetry </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>clain </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller106", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> tissue  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>crune </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller107", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> occupy </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> donce  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller108", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>secular  </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> droam </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller109", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> slave </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>elhow </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller110", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> ideology </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>fiast </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],

	["Efiller111", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> frant  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller112", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>gain </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>freil  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller113", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>  braid   </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>glain </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller114", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> professor </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>graup  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller115", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> kidnap </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> gruef</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller116", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> ambition </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>igeal </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller117", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> displace </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> loash  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller118", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> producer </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> lomic </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller119", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> mountain </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center>malon </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}],


["Efiller120", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> density </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
	"AcceptabilityJudgment", {s: {html:'<font size="6"><center> narve</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: 0}]


];