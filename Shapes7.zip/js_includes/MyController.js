define_ibex_controller({
    name: "MyController",
    jqueryWidget: {
        _init: function () {
           // this.options.transfer = null; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [1], /*Only move on to next page if ["Yes", "I don't know", or "no"] are clicked*/
                children: [
                               "PictureAccept", this.options,
                               "Question",  { 
                              //2nd controller
                                      q: null, //will be asked in PictureAccept part of controller
                                      as:  ["1", "2", "3", "4", "5","6","7"], //default answers for questions
                                      presentAsScale: true, 
                                      leftComment: "Not Enough", 
                                      rightComment: "Too Much",
                                      presentHorizontally: true} //display answers horizontally
                ]
            });
        }
    },
    properties: {}
});
