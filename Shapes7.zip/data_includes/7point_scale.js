/*
--Toronto-Psycholinguistics-Experiments--

Template that gives examples of everything Ibex can do for experiments
*/

var shuffleSequence = seq(startsWith("s"));
//var shuffleSequence = seq("Intro",  "practice", "Intro1","xep" , rshuffle(startsWith("s")), "Exit");
var practiceItemTypes = ["practice"];
var centerItems = true;


var defaults = [
    
    "MyController", {
        //randomOrder: true
        randomOrder: false 
        //setting default order for pictures to be random 
        //you can check this is true by simply trying experiment multiple times
     },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [



    /*
    ===================
    INTRODUCTION
    Can include files for Questionnaires, consent forms etc...
    ===================
    */

    //name of controller
["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro4.html" }} ],    
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],


    /*
    ===================
    IMAGE
    Controllers that work with Images and Questions
    ===================
    */
    
  ["practice", "MyController", { s: "''Click on the smiley face''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_yellowsmileyface1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_greensignal1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_moon_new.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_redarrow1.jpg"]]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you thought the instruction did not provide enough information to confidently identify the correct picture, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."],
                           ["p", "If you thought the instruction gave more information than needed in order to identify the object, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                           ["p", "If you believe that the instruction provided the right amount of information to identify the picture, you should have clicked on button 4."],
                           ["p", "Press any key to move on to the next example."]
                           ]}],
 
      ["practice", "MyController", { s: "''Click on the moon that is framed by a black box''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_greensignal1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_yellowsmileyface1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_moon_new.jpg"]]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "In this case, you probably clicked on one of the buttons corresponding to the higher end of the scale (6 or 7), since the instruction contained a lot of superfluous information."],
                           ["p", "The practice session is now over!"],
                           ["p", " Press any key to proceed to the next window."]
                           ]}],
    
    
 
 ["xep", Separator, {transfer: 2000, normalMessage: "Now you are ready to begin!" }],
    
    
    [["s1a", 1], "MyController", { s: "''Click on the bumpy square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show alongs with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_redsquare1.jpg"]]}],
    [["s1b", 1], "MyController", { s: "''Click on the bumpy square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle41.jpg"]]}],                              
    [["s2a", 2], "MyController", { s: "''Click on the open circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle1.jpg"]]}],
    [["s2b", 2], "MyController", { s: "''Click on the open circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"]]}],
    [["s3a", 3], "MyController", { s: "''Click on the bent line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_greenline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/bent_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_blueline1.jpg"]]}],
    [["s3b", 3], "MyController", { s: "''Click on the bent line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_greenline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/bent_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare11.jpg"]]}],
    [["s4a", 4], "MyController", { s: "''Click on the curved line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_redline4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_blueline1.jpg"]]}],
    [["s4b", 4], "MyController", { s: "''Click on the curved line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_redline4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"]]}],
    [["s5a", 5], "MyController", { s: "''Click on the spotted circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/spotted_greencircle1.jpg"]]}],
    [["s5b", 5], "MyController", { s: "''Click on the spotted circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/thick_greenarrow1.jpg"]]}],
    [["s6a", 6], "MyController", { s: "''Click on the striped square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare11.jpg"]]}],
    [["s6b", 6], "MyController", { s: "''Click on the striped square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"]]}],
    [["s7a", 7], "MyController", { s: "''Click on the bumpy triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_redtriangle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"]]}],
    [["s7b", 7], "MyController", { s: "''Click on the bumpy triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_redtriangle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcylinder2.jpg"]]}],
    [["s8a", 8], "MyController", { s: "''Click on the curved line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline1.jpg"]]}],
    [["s8b", 8], "MyController", { s: "''Click on the curved line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lighting.jpg"]]}],
    [["s9a", 9], "MyController", { s: "''Click on the spotted square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/spotted_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg "],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare1.jpg"]]}],
    [["s9b", 9], "MyController", { s: "''Click on the spotted square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/spotted_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg "],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle51.jpg"]]}],
    [["s10a", 10], "MyController", { s: "''Click on the striped triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_redtriangle4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],
    [["s10b", 10], "MyController", { s: "''Click on the striped triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_redtriangle4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_blueshape.jpg"]]}],                                                                                        
    [["s11a", 11], "MyController", { s: "''Click on the flat circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_bluecircle5.jpg"]]}],
    [["s11b", 11], "MyController", { s: "''Click on the flat circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"]]}],    
    [["s12a", 12], "MyController", { s: "''Click on the closed circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redline.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_yellowcircle5.jpg"]]}],
    [["s12b", 12], "MyController", { s: "''Click on the closed circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"]]}],    
    [["s13a", 13], "MyController", { s: "''Click on the straight line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_redline5.jpg"]]}],
    [["s13b", 13], "MyController", { s: "''Click on the straight line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud1.jpg"]]}],  
    [["s14a", 14], "MyController", { s: "''Click on the full cube''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_yellowcube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/full_redcylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_greencube3.jpg"]]}],
    [["s14b", 14], "MyController", { s: "''Click on the full cube''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_yellowcube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/full_redcylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greenspiral2.jpg"]]}],   
    [["s15a", 15], "MyController", { s: "''Click on the empty cube''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_bluecube5.jpg"]]}],
    [["s15b", 15], "MyController", { s: "''Click on the empty cube''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_bumpyline1.jpg"]]}], 
    [["s16a", 16], "MyController", { s: "''Click on the flat triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_sphere.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redtriangle5.jpg"]]}],
    [["s16b", 16], "MyController", { s: "''Click on the flat triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_sphere.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redspiral7.jpg"]]}],      
    [["s17a", 17], "MyController", { s: "''Click on the closed circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle5.jpg"]]}],
    [["s17b", 17], "MyController", { s: "''Click on the closed circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline2.jpg"]]}],     
    [["s18a", 18], "MyController", { s: "''Click on the straight line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline51.jpg"]]}],
    [["s18b", 18], "MyController", { s: "''Click on the straight line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_bluecylinder7.jpg"]]}],  
    [["s19a", 19], "MyController", { s: "''Click on the full cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_bluecylinder7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_greencube7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcylinder3.jpg"]]}],
    [["s19b", 19], "MyController", { s: "''Click on the full cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_bluecylinder7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_greencube7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline11.jpg"]]}], 
    [["s20a", 20], "MyController", { s: "''Click on the empty cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_redcylinder5.jpg"]]}],
    [["s20b", 20], "MyController", { s: "''Click on the empty cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline1.jpg"]]}],  
    [["s21a", 21], "MyController", { s: "''Click on the long line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_blueline3.jpg"]]}],
    [["s21b", 21], "MyController", { s: "''Click on the long line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluecircle12.jpg"]]}],   
    [["s22a", 22], "MyController", { s: "''Click on the short line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline51.jpg"]]}],
    [["s22b", 22], "MyController", { s: "''Click on the short line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],   
    [["s23a", 23], "MyController", { s: "''Click on the big square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_bluesquare3.jpg"]]}],
    [["s23b", 23], "MyController", { s: "''Click on the big square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline4.jpg"]]}],     
    [["s24a", 24], "MyController", { s: "''Click on the small triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle51.jpg"]]}],
    [["s24b", 24], "MyController", { s: "''Click on the small triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"]]}],  
    [["s25a", 25], "MyController", { s: "''Click on the wide oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_bluesquare7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval3.jpg"]]}],
    [["s25b", 25], "MyController", { s: "''Click on the wide oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_bluesquare7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],  
    [["s26a", 26], "MyController", { s: "''Click on the narrow rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_redrectangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle51.jpg"]]}],
    [["s26b", 26], "MyController", { s: "''Click on the narrow rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_redrectangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greenpentagon.jpg"]]}],     
    [["s27a", 27], "MyController", { s: "''Click on the tall spiral''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral3.jpg"]]}],
    [["s27b", 27], "MyController", { s: "''Click on the tall spiral''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redline4.jpg"]]}], 
    [["s28a", 28], "MyController", { s: "''Click on the short spiral''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/04/tall_redspiral2.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greenspiral5.jpg"]]}],
    [["s28b", 28], "MyController", { s: "''Click on the short spiral''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/04/tall_redspiral2.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_greensquare1.jpg"]]}],  
    [["s29a", 29], "MyController", { s: "''Click on the thick line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"]]}],
    [["s29b", 29], "MyController", { s: "''Click on the thick line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_blueshape2.jpg"]]}],
    [["s30a", 30], "MyController", { s: "''Click on the thin line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline53.jpg"]]}],
    [["s30b", 30], "MyController", { s: "''Click on the thin line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],  
    [["s31a", 31], "MyController", { s: "''Click on the long line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_greenline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline3.jpg"]]}],
    [["s31b", 31], "MyController", { s: "''Click on the long line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_greenline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar2.jpg"]]}],     
    [["s32a", 32], "MyController", { s: "''Click on the short line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcube7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline51.jpg"]]}],
    [["s32b", 32], "MyController", { s: "''Click on the short line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcube7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"]]}], 
    [["s33a", 33], "MyController", { s: "''Click on the big triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_greentriangle3.jpg"]]}],
    [["s33b", 33], "MyController", { s: "''Click on the big triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_thick_garabato.jpg"]]}], 
    [["s34a", 34], "MyController", { s: "''Click on the small square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare51.jpg"]]}],
    [["s34b", 34], "MyController", { s: "''Click on the small square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],  
    [["s35a", 35], "MyController", { s: "''Click on the wide rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle72.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle3.jpg"]]}],
    [["s35b", 35], "MyController", { s: "''Click on the wide rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle72.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline41.jpg"]]}],  
    [["s36a", 36], "MyController", { s: "''Click on the narrow oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval51.jpg"]]}],
    [["s36b", 36], "MyController", { s: "''Click on the narrow oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}], 
    [["s37a", 37], "MyController", { s: "''Click on the tall cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder3.jpg"]]}],
    [["s37b", 37], "MyController", { s: "''Click on the tall cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline2.jpg"]]}], 
    [["s38a", 38], "MyController", { s: "''Click on the short cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redcylinder51.jpg"]]}],
    [["s38b", 38], "MyController", { s: "''Click on the short cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"]]}],     
    [["s39a", 39], "MyController", { s: "''Click on the thick line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline3.jpg"]]}],
    [["s39b", 39], "MyController", { s: "''Click on the thick line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowsquare41.jpg"]]}], 
     [["s40a", 40], "MyController", { s: "''Click on the thin line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline51.jpg"]]}],
    [["s40b", 40], "MyController", { s: "''Click on the thin line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare4.jpg"]]}],   
    [["s41a", 41], "MyController", { s: "''Click on the red square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],      
    [["s41b", 41], "MyController", { s: "''Click on the red square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],    
    [["s42a", 42], "MyController", { s: "''Click on the green circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],   
    [["s42b", 42], "MyController", { s: "''Click on the green circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"]]}],          
    [["s43a", 43], "MyController", { s: "''Click on the blue line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline1.jpg"]]}],      
    [["s43b", 43], "MyController", { s: "''Click on the blue line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"]]}],    
    [["s44a", 44], "MyController", { s: "''Click on the yellow triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],     
    [["s44b", 44], "MyController", { s: "''Click on the yellow triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"]]}], 
    [["s45a", 45], "MyController", { s: "''Click on the red oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"]]}],       
    [["s45b", 45], "MyController", { s: "''Click on the red oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],   
    [["s46a", 46], "MyController", { s: "''Click on the green rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle51.jpg"]]}],  
    [["s46b", 46], "MyController", { s: "''Click on the green rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}], 
    [["s47a", 47], "MyController", { s: "''Click on the blue square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],  
    [["s47b", 47], "MyController", { s: "''Click on the blue square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_yellowtriangle1.jpg"]]}],        
    [["s48a", 48], "MyController", { s: "''Click on the yellow circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"]]}],  
    [["s48b", 48], "MyController", { s: "''Click on the yellow circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],       
    [["s49a", 49], "MyController", { s: "''Click on the red line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"]]}],  
    [["s49b", 49], "MyController", { s: "''Click on the red line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle11.jpg"]]}],                                                                                       
    [["s50a", 50], "MyController", { s: "''Click on the green triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],     
    [["s50b", 50], "MyController", { s: "''Click on the green triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"]]}],                                 
    [["s51a", 51], "MyController", { s: "''Click on the yellow oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"]]}],     
    [["s51b", 51], "MyController", { s: "''Click on the yellow oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle51.jpg"]]}],                                 
    [["s52a", 52], "MyController", { s: "''Click on the yellow rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle51.jpg"]]}],     
    [["s52b", 52], "MyController", { s: "''Click on the yellow rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"]]}],                                 
    [["s53a", 53], "MyController", { s: "''Click on the green square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],     
    [["s53b", 53], "MyController", { s: "''Click on the green square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"]]}],                                  
    [["s54a", 54], "MyController", { s: "''Click on the red circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],     
    [["s54b", 54], "MyController", { s: "''Click on the red circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}],                                 
    [["s55a", 55], "MyController", { s: "''Click on the red line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],     
    [["s55b", 55], "MyController", { s: "''Click on the red line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/full1_greensquare1.jpg"]]}], 
    [["s56a", 56], "MyController", { s: "''Click on the blue triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle11.jpg"]]}],     
    [["s56b", 56], "MyController", { s: "''Click on the blue triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"]]}],  
    [["s57a", 57], "MyController", { s: "''Click on the yellow square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],     
    [["s57b", 57], "MyController", { s: "''Click on the yellow square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline51.jpg"]]}],                                                                      
    [["s58a", 58], "MyController", { s: "''Click on the blue circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],    
    [["s58b", 58], "MyController", { s: "''Click on the blue circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"]]}],  
    [["s59a", 59], "MyController", { s: "''Click on the yellow line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline2.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle3.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/10/thick_redline1.jpg"]]}],      
    [["s59b", 59], "MyController", { s: "''Click on the yellow line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline2.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle3.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval11.jpg"]]}],   
    [["s60a", 60], "MyController", { s: "''Click on the red triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle11.jpg"]]}],                                                                                                                                                                
    [["s60b", 60], "MyController", { s: "''Click on the red triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],     
    [["s61", 61], "MyController", { s: "''Click on the square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"]]}],  
    [["s62", 62], "MyController", { s: "''Click on the arrow''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greenpentagon.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"]]}],   
    [["s63", 63], "MyController", { s: "''Click on the star''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star2.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"]]}],                                  
    [["s64", 64], "MyController", { s: "''Click on the spiral''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redspiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                     
    [["s65", 65], "MyController", { s: "''Click on the cylinder''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder6.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"]]}],                                     
    [["s66", 66], "MyController", { s: "''Click on the heart''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_greencylinder5.jpg"]]}],                                     
    [["s67", 67], "MyController", { s: "''Click on the triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redcylinder1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],                                     
    [["s68", 68], "MyController", { s: "''Click on the circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_greentriangle3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}],  
    [["s69", 69], "MyController", { s: "''Click on the cloud''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder7.jpg"]]}],                                  
    [["s70", 70], "MyController", { s: "''Click on the cube''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_greencube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redtriangle4.jpg"]]}],    
    [["s71", 71], "MyController", { s: "''Click on the red square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],                                  
    [["s72", 72], "MyController", { s: "''Click on the green triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"]]}],                                   
    [["s73", 73], "MyController", { s: "''Click on the blue line", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"]]}],                                   
    [["s74", 74], "MyController", { s: "''Click on the yellow circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"]]}],                                   
    [["s75", 75], "MyController", { s: "''Click on the red oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"]]}],                                   
    [["s76", 76], "MyController", { s: "''Click on the green square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],                                   
    [["s77", 77], "MyController", { s: "''Click on the blue triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"]]}],                                   
    [["s78", 78], "MyController", { s: "''Click on the yellow line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_greencircle1.jpg"]]}],                                   
    [["s79", 79], "MyController", { s: "''Click on the blue square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"]]}],                                   
    [["s80", 80], "MyController", { s: "''Click on the yellow rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s81", 81], "MyController", { s: "''Click on the square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],   
    [["s82", 82], "MyController", { s: "''Click on the circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"]]}],                                                                   
    [["s83", 83], "MyController", { s: "''Click on the triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                   
    [["s84", 84], "MyController", { s: "''Click on the rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                   
    [["s85", 85], "MyController", { s: "''Click on the line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"]]}],                                   
    [["s86", 86], "MyController", { s: "''Click on the oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenline4.jpg"]]}],                                   
    [["s87", 87], "MyController", { s: "''Click on the triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],                                   
    [["s88", 88], "MyController", { s: "''Click on the rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],                                   
    [["s89", 89], "MyController", { s: "''Click on the arrow''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],                                   
    [["s90", 90], "MyController", { s: "''Click on the oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"]]}],                                   
    [["s91", 91], "MyController", { s: "''Click on the square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s92", 92], "MyController", { s: "''Click on the circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],                                     
    [["s93", 93], "MyController", { s: "''Click on the triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"]]}],                                     
    [["s94", 94], "MyController", { s: "''Click on the arrow''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"]]}],                                     
    [["s95", 95], "MyController", { s: "''Click on the line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],                                     
    [["s96", 96], "MyController", { s: "''Click on the oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"]]}],                                     
    [["s97", 97], "MyController", { s: "''Click on the rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],                                     
    [["s98", 98], "MyController", { s: "''Click on the heart''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"]]}],                                     
    [["s99", 99], "MyController", { s: "''Click on the star''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star2.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"]]}],                                     
    [["s100", 100], "MyController", { s: "''Click on the sun''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                                                                                    
    [["s101", 101], "MyController", { s: "''Click on the blue square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],   
    [["s102", 102], "MyController", { s: "''Click on the yellow circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"]]}],                                                                   
    [["s103", 103], "MyController", { s: "''Click on the red triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                   
    [["s104", 104], "MyController", { s: "''Click on the green rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                   
    [["s105", 105], "MyController", { s: "''Click on the blue line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"]]}],                                   
    [["s106", 106], "MyController", { s: "''Click on the yellow oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenline4.jpg"]]}],                                   
    [["s107", 107], "MyController", { s: "''Click on the red triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],                                   
    [["s108", 108], "MyController", { s: "''Click on the green rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],                                   
    [["s109", 109], "MyController", { s: "''Click on the blue arrow''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_bluearrow1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],                                   
    [["s110", 110], "MyController", { s: "''Click on the red oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"]]}],                                   
    [["s111", 111], "MyController", { s: "''Click on the yellow square''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s112", 112], "MyController", { s: "''Click on the red circle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],                                     
    [["s113", 113], "MyController", { s: "''Click on the green triangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"]]}],                                     
    [["s114", 114], "MyController", { s: "''Click on the blue arrow''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"]]}],                                     
    [["s115", 115], "MyController", { s: "''Click on the yellow line''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],                                     
    [["s116", 116], "MyController", { s: "''Click on the red oval''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"]]}],                                     
    [["s117", 117], "MyController", { s: "''Click on the green rectangle''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],                                     
    [["s118", 118], "MyController", { s: "''Click on the blue heart''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"]]}],                                     
    [["s119", 119], "MyController", { s: "''Click on the yellow star''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"]]}],                                     
    [["s120", 120], "MyController", { s: "''Click on the red sun''", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}]                                   
 ];                                
                                     

