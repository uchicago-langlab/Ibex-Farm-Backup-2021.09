var shuffleSequence = seq("setcounter", "consent", "background", "intro", sepWith("sep", seq("practice", "practiceover")), "presep", sepWith("sep", rshuffle(startsWith("np"),startsWith("ag"),startsWith("psy"),startsWith("f"))), "exit");



var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
        ignoreFailure:true
        //errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).
    
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
    
    ["background", "Form", {html: { include: "background.html" },validators: {},continueMessage:"Click here to send the results."} ],
    
    ["exit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    
    ["practiceover", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "That is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read two sentences and decide which of the two sounds more acceptable to you."],
                          ]}],

    ["intro", "Form", {
        html: { include: "example_intro.html" },
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],
    
    
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "Next you will see a practice example. In the pair you will see, the first sentence may sound more natural and acceptable to you than the second sentence. You should therefore choose the first sentence."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Mice are sitting on the arm of the chair.",
                                   "Mice is sitting on the arm of the chair."]}],
    
    
                                 
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "On the other hand, in this sentence, the second sentence is more acceptable than the first sentence. You should choose the second sentence."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This company relies to our help.",
                                   "This company relies on our help."]}],
    
    
    [ "practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "The two sentences in this pair might both sound a little strange. Choose which one sounds more acceptable to you."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: false,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Shane has no idea from which store the birthday gift is from.",
                                   "Shane has no idea from which store the birthday gift is."]}],
    
    
   
    ["presep", Separator, { transfer: 1500, normalMessage: "Please get ready, we are about to start." }],
    
    
    /*Start here!
    Condition key:
    
    ["np1", #] = non-passivizing short pair
    ["np2", #] = non-passivizing long pair
    ...
    ["ag1", #] = agentive short pair
    ["ag2", #] = agentive long pair
    ...
    ["psy1", #] = psych short pair
    ["psy2", #] = psych long pair
    
    The order in each forced choice should always be "gap > RP".
    
    Please use the question: "Choose the sentence that is more acceptable."
    
    */
    
    [["np1",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the knight who a full beard suits.",
                                     "This is the knight who a full beard suits him."]}],


    [["np2",1], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the knight who the queen believes a full beard suits.",
                                     "This is the knight who the queen believes a full beard suits him."]}],


    [["np1",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the soldier who those shoes didn't fit.",
                                     "This is the soldier who those shoes didn't fit him."]}],


    [["np2",2], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the soldier who Miranda insisted those shoes didn't fit.",
                                     "This is the soldier who Miranda insisted those shoes didn't fit him."]}],


    [["np1",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the actress who my mother resembled.",
                                     "This is the actress who my mother resembled her."]}],


    [["np2",3], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the actress who Bob said my mother resembled.",
                                     "This is the actress who Bob said my mother resembled her."]}],


    [["np1",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the explorer who a strange adventure befell.",
                                     "This is the explorer who a strange adventure befell her."]}],


    [["np2",4], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the explorer who Carl was certain a strange adventure befell.",
                                     "This is the explorer who Carl was certain a strange adventure befell her."]}],


    [["np1",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the client who the detectives failed.",
                                     "This is the client who the detectives failed him."]}],


    [["np2",5], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the client who Barbara reported the detectives failed.",
                                     "This is the client who Barbara reported the detectives failed him."]}],


    [["np1",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the refugees who we housed last night.",
                                     "These are the refugees who we housed them last night."]}],


    [["np2",6], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the refugees who David supposed we housed last night.",
                                     "These are the refugees who David supposed we housed them last night."]}],


    [["np1",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the princess who the royal jewels flatter.",
                                     "This is the princess who the royal jewels flatter her."]}],


    [["np2",7], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the princess who Harry hopes the royal jewels flatter.",
                                     "This is the princess who Harry hopes the royal jewels flatter her."]}],


    [["np1",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the girl who Mike reminds of her grandfather.",
                                     "This is the girl who Mike reminds her of her grandfather."]}],


    [["np2",8], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the girl who we assume Mike reminds of her grandfather.",
                                     "This is the girl who we assume Mike reminds her of her grandfather."]}],


    [["np1",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the teacher who the students don't mind.",
                                     "This is the teacher who the students don't mind him."]}],


    [["np2",9], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the teacher who Judy mentioned the students don't mind.",
                                     "This is the teacher who Judy mentioned the students don't mind him."]}],


    [["np1",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the president who the proposal reached.",
                                     "This is the president who the proposal reached her."]}],


    [["np2",10], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the president who Jeff implied the proposal reached.",
                                     "This is the president who Jeff implied the proposal reached her."]}],


    [["np1",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the goddess who the warrior disobeyed.",
                                     "This is the goddess who the warrior disobeyed her."]}],


    [["np2",11], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the goddess who the king stated the warrior disobeyed.",
                                     "This is the goddess who the king stated the warrior disobeyed her."]}],


    [["np1",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the programmer who the start-up needed.",
                                     "This is the programmer who the start-up needed him."]}],


    [["np2",12], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the programmer who Joni heard the start-up needed.",
                                     "This is the programmer who Joni heard the start-up needed him."]}],


    [["np1",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the engineers who our company boasts.",
                                     "These are the engineers who our company boasts them."]}],


    [["np2",13], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the engineers who Peter thinks our company boasts.",
                                     "These are the engineers who Peter thinks our company boasts them."]}],


    [["np1",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the drummer who the band currently lacks.",
                                     "This is the drummer who the band currently lacks him."]}],


    [["np2",14], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the drummer who Selina figures the band currently lacks.",
                                     "This is the drummer who Selina figures the band currently lacks him."]}],


    [["np1",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the prince who Saudi Arabia had during its time of crisis.",
                                     "This is the prince who Saudi Arabia had him during its time of crisis."]}],


    [["np2",15], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the prince who the historian alleged Saudi Arabia had during its time of crisis.",
                                     "This is the prince who the historian alleged Saudi Arabia had him during its time of crisis."]}],


    [["np1",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the customers who the new features will benefit.",
                                     "These are the customers who the new features will benefit them."]}],


    [["np2",16], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the customers who the manager suspects the new features will benefit.",
                                     "These are the customers who the manager suspects the new features will benefit them."]}],


    [["ag1",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the king who the wizard conned.",
                                     "This is the king who the wizard conned him."]}],


    [["ag2",17], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the king who the druid insists the wizard conned.",
                                     "This is the king who the druid insists the wizard conned him."]}],


    [["ag1",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the heroine who the villain misled.",
                                     "This is the heroine who the villain misled her."]}],


    [["ag2",18], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the heroine who Charles said the villain misled.",
                                     "This is the heroine who Charles said the villain misled her."]}],


    [["ag1",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the criminal who the lawyers neglected.",
                                     "This is the criminal who the lawyers neglected him."]}],


    [["ag2",19], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the criminal who Candice was certain the lawyers neglected.",
                                     "This is the criminal who Candice was certain the lawyers neglected him."]}],


    [["ag1",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the performer who the judges praised.",
                                     "This is the performer who the judges praised her."]}],


    [["ag2",20], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the performer who Ben reported the judges praised.",
                                     "This is the performer who Ben reported the judges praised her."]}],


    [["ag1",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the representatives who the city council welcomed.",
                                     "These are the representatives who the city council welcomed them."]}],


    [["ag2",21], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the representatives who Edwin supposed the city council welcomed.",
                                     "These are the representatives who Edwin supposed the city council welcomed them."]}],


    [["ag1",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the townspeople who the ogre captured.",
                                     "These are the townspeople who the ogre captured them."]}],


    [["ag2",22], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the townspeople who Harley hopes the ogre captured.",
                                     "These are the townspeople who Harley hopes the ogre captured them."]}],


    [["ag1",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the celebrity who the pizza boy recognized.",
                                     "This is the celebrity who the pizza boy recognized her."]}],


    [["ag2",23], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the celebrity who Jake assumed the pizza boy recognized.",
                                     "This is the celebrity who Jake assumed the pizza boy recognized her."]}],


    [["ag1",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the milkman who the cow kicked in the head.",
                                     "This is the milkman who the cow kicked him in the head."]}],


    [["ag2",24], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the milkman who Janet mentioned the cow kicked in the head.",
                                     "This is the milkman who Janet mentioned the cow kicked him in the head."]}],


    [["ag1",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mayor who the FBI recordered in secret.",
                                     "This is the mayor who the FBI recordered her in secret."]}],


    [["ag2",25], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mayor who Chris implied the FBI recordered in secret.",
                                     "This is the mayor who Chris implied the FBI recordered her in secret."]}],


    [["ag1",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the priestess who Apollo chose.",
                                     "This is the priestess who Apollo chose her."]}],


    [["ag2",26], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the priestess who Poseidon stated Apollo chose.",
                                     "This is the priestess who Poseidon stated Apollo chose her."]}],


    [["ag1",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the bank teller who the thief robbed.",
                                     "This is the bank teller who the thief robbed him."]}],


    [["ag2",27], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the bank teller who Molly heard the thief robbed.",
                                     "This is the bank teller who Molly heard the thief robbed him."]}],


    [["ag1",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the accountants who the CEO fired.",
                                     "These are the accountants who the CEO fired them."]}],


    [["ag2",28], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the accountants who Patricia thought the CEO fired.",
                                     "These are the accountants who Patricia thought the CEO fired them."]}],


    [["ag1",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the sailor who the ship captain recruited.",
                                     "This is the sailor who the ship captain recruited him."]}],


    [["ag2",29], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the sailor who Serena figured the ship captain recruited.",
                                     "This is the sailor who Serena figured the ship captain recruited him."]}],


    [["ag1",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the secret agent who the spy betrayed.",
                                     "This is the secret agent who the spy betrayed him."]}],


    [["ag2",30], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the secret agent who Theresa alleged the spy betrayed.",
                                     "This is the secret agent who Theresa alleged the spy betrayed him."]}],


    [["ag1",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the staffers who the senator congratulated.",
                                     "These are the staffers who the senator congratulated them."]}],


    [["ag2",31], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the staffers who the speaker suspected the senator congratulated.",
                                     "These are the staffers who the speaker suspected the senator congratulated them."]}],
    
        [["ag1",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the admiral who the corporal tripped.",
                                     "This is the admiral who the corporal tripped him."]}],


    [["ag2",32], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the admiral who Ashley believed the corporal tripped.",
                                     "This is the admiral who Ashley believed the corporal tripped him."]}],


    [["psy1",33], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the jester who the report upset.",
                                     "This is the jester who the report upset him."]}],


    [["psy2",33], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the jester who the steward believes the report upset.",
                                     "This is the jester who the steward believes the report upset him."]}],


    [["psy1",34], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the lieutenant who the mission surprised.",
                                     "This is the lieutenant who the mission surprised him."]}],


    [["psy2",34], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the lieutenant who Allen insists the mission surprised.",
                                     "This is the lieutenant who Allen insists the mission surprised him."]}],


    [["psy1",35], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the contestant who the ceremony annoyed.",
                                     "This is the contestant who the ceremony annoyed her."]}],


    [["psy2",35], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the contestant who Bill said the ceremony annoyed.",
                                     "This is the contestant who Bill said the ceremony annoyed her."]}],


    [["psy1",36], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the villainess who the henchman angered.",
                                     "This is the villainess who the henchman angered her."]}],


    [["psy2",36], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the villainess who Charles was certain the henchman angered.",
                                     "This is the villainess who Charles was certain the henchman angered her."]}],


    [["psy1",37], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the consumer who the discount astonished.",
                                     "This is the consumer who the discount astonished him."]}],


    [["psy2",37], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the consumer who Cindy reported the discount astonished.",
                                     "This is the consumer who Cindy reported the discount astonished him."]}],


    [["psy1",38], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the hikers who the scenery shocked.",
                                     "These are the hikers who the scenery shocked them."]}],


    [["psy2",38], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the hikers who Gabriel supposed the scenery shocked.",
                                     "These are the hikers who Gabriel supposed the scenery shocked them."]}],


    [["psy1",39], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the squire who the castle bored.",
                                     "This is the squire who the castle bored him."]}],


    [["psy2",39], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the squire who Harriet hoped the castle bored.",
                                     "This is the squire who Harriet hoped the castle bored him."]}],


    [["psy1",40], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the theater attendant who the baby bothered.",
                                     "This is the theater attendant who the baby bothered her."]}],


    [["psy2",40], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the theater attendant who Jim assumed the baby bothered.",
                                     "This is the theater attendant who Jim assumed the baby bothered her."]}],


    [["psy1",41], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mailman who the thunderstorm alarmed.",
                                     "This is the mailman who thunderstorm alarmed him."]}],


    [["psy2",41], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mailman who Joan mentioned the thunderstorm alarmed.",
                                     "This is the mailman who Joan mentioned the thunderstorm alarmed him."]}],


    [["psy1",42], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the congresswoman who the election results discouraged.",
                                     "This is the congresswoman who the election results discouraged her."]}],


    [["psy2",42], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the congresswoman who Carlos implied the election results discouraged.",
                                     "This is the congresswoman who Carlos implied the election results discouraged her."]}],


    [["psy1",43], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the waitress who the truckers alarmed.",
                                     "This is the waitress who the truckers alarmed her."]}],


    [["psy2",43], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the waitress who Luke stated the truckers alarmed.",
                                     "This is the waitress who Luke stated the truckers alarmed her."]}],


    [["psy1",44], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the acrobat who the clown amused.",
                                     "This is the acrobat who the clown amused him."]}],


    [["psy2",44], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the acrobat who Pamela heard the clown amused.",
                                     "This is the acrobat who Pamela heard the clown amused him."]}],


    [["psy1",45], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the marketing managers who the Christmas party disappointed.",
                                     "These are the marketing managers who the Christmas party disappointed them."]}],


    [["psy2",45], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the marketing managers who Rebecca thought the Christmas party disappointed.",
                                     "These are the marketing managers who Rebecca thought the Christmas party disappointed them."]}],


    [["psy1",46], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mermaid who strong winds excite.",
                                     "This is the mermaid who strong winds excite her."]}],


    [["psy2",46], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the mermaid who Sean figures strong winds excite.",
                                     "This is the mermaid who Sean figures strong winds excite her."]}],


    [["psy1",47], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the merchant who the traders impressed.",
                                     "This is the merchant who the traders impressed him."]}],


    [["psy2",47], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["This is the merchant who Sherry alleged the traders impressed.",
                                     "This is the merchant who Sherry alleged the traders impressed him."]}],


    [["psy1",48], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the children who the monsters frightened.",
                                     "These are the children who the monsters frightened them."]}],


    [["psy2",48], "Question", {hasCorrect: true, randomOrder: true,
                                q: "Choose the sentence that is more acceptable.",
                                as: ["These are the children who the parents suspected the monsters frightened.",
                                     "These are the children who the parents suspected the monsters frightened them."]}],

    [["f",49], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the boxer who sometimes loses his gloves.",
                                   "This is the boxer who sometimes lose his gloves."]}],
                        
    [["f",50], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the pirates who unfortunately was bombarding the ship.",
                                   "These are the pirates who unfortunately were bombarding the ship."]}],
    
    [["f",51], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here is the bachelor who really looks like Tom Cruise.",
                                   "Here is the bachelor who really look like Tom Cruise."]}],
    
    [["f",52], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here are the waiters who usually works the night shift.",
                                   "Here are the waiters who usually work the night shift."]}],
                        
    [["f",53], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the vendor who typically sells precious stones.",
                                   "This is the vendor who typically sell precious stones."]}],
    
    [["f",54], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the dancers who always steals the show.",
                                   "These are the dancers who always steal the show."]}],
    
    [["f",55], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here is the singer who regularly meets with her fans.",
                                   "Here is the singer who regularly meet with her fans."]}],
    
    [["f",56], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["Here are the athletes who consistently wins gold medals.",
                                   "Here are the athletes who consistently win gold medals."]}],
                        
    [["f",57], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["This is the sheriff who seldom leaves the office.",
                                   "This is the sheriff who seldom leave the office."]}],
    
    [["f",58], "Question", {hasCorrect: true, randomOrder: true,
                              q: "Choose the sentence that is more acceptable.",
                              as: ["These are the comedians who rarely tells jokes sober.",
                                   "These are the comedians who rarely tell jokes sober."]}],

];
