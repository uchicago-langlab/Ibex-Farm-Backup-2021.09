var shuffleSequence = seq("setcounter","consent", "intro1","intro2",
                      sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit"  );

var completionMessage = "Thank you for your participation!"

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        errorMessage: "Wrong. Please wait for the next sentence.",
        ignoreFailure: true,
        hideProgressBar: true
    },
    "DashedSentence", {
        hideProgressBar: true
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: false,
        as: ["Yes","No"],
        randomOrder: false
    },
    "Message", {
       hideProgressBar: true
    },
        "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "Vorm", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "Scale_New", {
        startValue: 0, 
        endValue: 100,
        hideProgressBar: true,
        scaleLabels: true,
        saveReactionTime: true,
        leftLabel: "(Not relevant)", rightLabel: "(Very relevant)"
    },
    "StaticSentence",{
        hideProgressBar: true
    },
    "StaticSentence2",{
        hideProgressBar: true
    },
    "SingleSlider",{
        children: ["StaticSentence","StaticSentence2","Scale_New"],
        triggers: [2],
        hideProgressBar: true
    }
];



var items = [

    ["sep", "Separator", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html"}}],
    
    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],

     ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a sentence, and answer the question that follows it, using a 0-100 scale."],
                          ["p", "Drag the bar to choose your response on the scale."] 
],continueMessage:"Click here to start the experiment."}],
 
  ["setcounter", "__SetCounter__", { }],
    
// items
    


["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The bus driver is not furious.",
                                html: "On a 0-100 scale, how angry is the bus driver?"}],

["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The soldier is dangerous.",
                                html: "On a 0-100 scale, how harmless is the soldier?"}],

["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The wrestler is not strong.",
                                html: "On a 0-100 scale, how strong is the wrestler?"}],

//[["Eweak",1], "SingleSlider", {s: "", s2: "Drinking is allowed.", html: "On a 0-100 scale, how acceptable is drinking?"}],

    [["Enegstrong",1], "SingleSlider", {s: "", s2: "Drinking is not obligatory.", html: "On a 0-100 scale, how acceptable is drinking?"}],
//[["Eweak",2], "SingleSlider", {s: "", s2: "The model is attractive.", html: "On a 0-100 scale, how attractive is the model?"}],

    [["Enegstrong",2], "SingleSlider", {s: "", s2: "The model is not stunning.", html: "On a 0-100 scale, how attractive is the model?"}],
    //[["Eweak",3], "SingleSlider", {s: "", s2: "John began the race.", html: "On a 0-100 scale, how far along is John in the race?"}],

    [["Enegstrong",3], "SingleSlider", {s: "", s2: "John did not complete the race.", html: "On a 0-100 scale, how far along is John in the race?"}],

    //[["Eweak",4], "SingleSlider",       {s: "", s2: "The teacher believes it is true.", html: "On a 0-100 scale, how sure is the teacher that it is true?"}], 
[["Enegstrong",4], "SingleSlider",       {s: "", s2: "The teacher does not know it is true.", html: "On a 0-100 scale, how sure is the teacher that it is true?"}], 

//[["Eweak",5], "SingleSlider",       {s: "", s2: "The elephant is big.", html: "On a 0-100 scale, how big is the elephant?"}], 
[["Enegstrong",5], "SingleSlider",       {s: "", s2: "The elephant is not enormous.", html: "On a 0-100 scale, how big is the elephant?"}], 

//[["Eweak",6], "SingleSlider",       {s: "", s2: "The weather is cool.", html: "On a 0-100 scale, how cool is the weather?"}], 
[["Enegstrong",6], "SingleSlider",       {s: "", s2: "The weather is not cold.", html: "On a 0-100 scale, how cool is the weather?"}], 

//[["Eweak",7], "SingleSlider",       {s: "", s2: "The machine damaged itself.", html: "On a 0-100 scale, how damaged is the machine?"}],
[["Enegstrong",7], "SingleSlider",       {s: "", s2: "The machine did not destroy itself.", html: "On a 0-100 scale, how damaged is the machine?"}], 

//[["Eweak",8], "SingleSlider",       {s: "", s2: "The sky is dark.", html: "On a 0-100 scale, how dark is the sky?"}],
[["Enegstrong",8], "SingleSlider",       {s: "", s2: "The sky is not black.", html: "On a 0-100 scale, how dark is the sky?"}], 

//[["Eweak",9], "SingleSlider",       {s: "", s2: "The task is difficult.", html: "On a 0-100 scale, how difficult is the task?"}], 
[["Enegstrong",9], "SingleSlider",       {s: "", s2: "The task is not impossible.", html: "On a 0-100 scale, how difficult is the task?"}], 

//[["Eweak",10], "SingleSlider",       {s: "", s2: "Zack's carpet was dirty.", html: "On a 0-100 scale, how dirty is Zack's carpet?"}],
[["Enegstrong",10], "SingleSlider",       {s: "", s2: "Zack's carpet was not filthy.", html: "On a 0-100 scale, how dirty is Zack's carpet?"}],

//[["Eweak",11], "SingleSlider",       {s: "", s2: "The doctor dislikes coffee.", html: "On a 0-100 scale, how much does the doctor dislike coffee?"}], 
[["Enegstrong",11], "SingleSlider",       {s: "", s2: "The doctor does not loathe coffee.", html: "On a 0-100 scale, how much does the doctor dislike coffee?"}], 

//[["Eweak",12], "SingleSlider", {s: "", s2: "The sales will double. ", html: "On a 0-100 scale, how much will the sales increase?"}], 
[["Enegstrong",12], "SingleSlider", {s: "", s2: "The sales will not triple. ", html: "On a 0-100 scale, how much will the sales increase?"}],

//[["Eweak",13], "SingleSlider", {s: "", s2: "That candidate is equally skilled.", html: "On a 0-100 scale, how do the candidates' skills compare?"}],
[["Enegstrong",13], "SingleSlider", {s: "", s2: "That candidate is not more skilled.", html: "On a 0-100 scale, how do the candidates' skills compare?"}],

//[["Eweak",14], "SingleSlider", {s: "", s2: "The movie is funny.", html: "On a 0-100 scale, how funny is the movie?"}], 
[["Enegstrong",14], "SingleSlider", {s: "", s2: "The movie is not hilarious.", html: "On a 0-100 scale, how funny is the movie?"}], 

//[["Eweak",15], "SingleSlider", {s: "", s2: "The movie is good.", html: "On a 0-100 scale, how good is the movie?"}], 
[["Enegstrong",15], "SingleSlider", {s: "", s2: "The movie is not excellent.", html: "On a 0-100 scale, how good is the movie?"}],

//[["Eweak",16], "SingleSlider", {s: "", s2: "The winner was happy.", html: "On a 0-100 scale, how happy was the winner?"}],
[["Enegstrong",16], "SingleSlider", {s: "", s2: "The winner was not ecstatic.", html: "On a 0-100 scale, how happy was the winner?"}], 

//[["Eweak",17], "SingleSlider", {s: "", s2: "The problem is hard.", html: "On a 0-100 scale, how hard is the problem?"}], 
[["Enegstrong",17], "SingleSlider", {s: "", s2: "The problem is not unsolvable.", html: "On a 0-100 scale, how hard is the problem?"}], 

//[["Eweak",18], "SingleSlider", {s: "", s2: "The toxin is harmful.", html: "On a 0-100 scale, how harmful is the toxin?"}], 
[["Enegstrong",18], "SingleSlider", {s: "", s2: "The toxin is not deadly.", html: "On a 0-100 scale, how harmful is the toxin?"}],

//[["Eweak",19], "SingleSlider", {s: "", s2: "There is water here.", html: "On a 0-100 scale, how widespread is the water?"}], 
[["Enegstrong",19], "SingleSlider", {s: "", s2: "There isn't water everywhere.", html: "On a 0-100 scale, how widespread is the water?"}],

//[["Eweak",20], "SingleSlider", {s: "", s2: "The boy is hungry.", html: "On a 0-100 scale, how hungry is the boy?"}], 
[["Enegstrong",20], "SingleSlider", {s: "", s2: "The boy is not starving.", html: "On a 0-100 scale, how hungry is the boy?"}], 

//[["Eweak",21], "SingleSlider", {s: "", s2: "The student is intelligent.", html: "On a 0-100 scale, how intelligent is the student?"}], 
[["Enegstrong",21], "SingleSlider", {s: "", s2: "The student is not briliant.", html: "On a 0-100 scale, how intelligent is the student?"}], 

//[["Eweak",22], "SingleSlider", {s: "", s2: "Chris's opponent was intimidating.", html: "On a 0-100 scale, how intimidating was Chris's opponent?"}],
[["Enegstrong",22], "SingleSlider", {s: "", s2: "Chris's opponent was not terrifying.", html: "On a 0-100 scale, how intimidating was Chris's opponent?"}], 

//[["Eweak",23], "SingleSlider", {s: "", s2: "The coast was largely flooded.", html: "On a 0-100 scale, how flooded was the coast?"}], 
[["Enegstrong",23], "SingleSlider", {s: "", s2: "The coast was not totally flooded.", html: "On a 0-100 scale, how flooded was the coast?"}], 

//[["Eweak",24], "SingleSlider", {s: "", s2: "The princess likes dancing.", html: "On a 0-100 scale, how much does the princess like dancing?"}],
[["Enegstrong",24], "SingleSlider", {s: "", s2: "The princess does not love dancing.", html: "On a 0-100 scale, how much does the princess like dancing?"}], 

//[["Eweak",25], "SingleSlider", {s: "", s2: "Bill's score matches Al's.", html: "On a 0-100 scale, how does Bill's score compare to Al's?"}], 
[["Enegstrong",25], "SingleSlider", {s: "", s2: "Bill's score does not exceed Al's.", html: "On a 0-100 scale, how does Bill's score compare to Al's?"}], 

//[["Eweak",26], "SingleSlider", {s: "", s2: "Peter's answers were mostly wrong.", html: "On a 0-100 scale, how wrong were Peter's answers?"}], 
[["Enegstrong",26], "SingleSlider", {s: "", s2: "Peter's answers were not entirely wrong.", html: "On a 0-100 scale, how wrong were Peter's answers?"}], 

//[["Eweak",27], "SingleSlider", {s: "", s2: "The house is old.", html: "On a 0-100 scale, how old is the house?"}], 
[["Enegstrong",27], "SingleSlider", {s: "", s2: "The house is not ancient.", html: "On a 0-100 scale, how old is the house?"}], 

//[["Eweak",28], "SingleSlider", {s: "", s2: "Mistakes happened once.", html: "On a 0-100 scale, how many times did mistakes happen?"}], 
[["Enegstrong",28], "SingleSlider", {s: "", s2: "Mistakes did not happen twice.", html: "On a 0-100 scale, how many times did mistakes happen?"}], 

//[["Eweak",29], "SingleSlider", {s: "", s2: "Jimmy writes books or plays.", html: "On a 0-100 scale, how likely is it that Jimmy writes both books and plays?"}], 
[["Enegstrong",29], "SingleSlider", {s: "", s2: "Jimmy does not write books and plays.", html: "On a 0-100 scale, how likely is it that Jimmy writes both books and plays?"}], 

//[["Eweak",30], "SingleSlider", {s: "", s2: "The teenager is overweight.", html: "On a 0-100 scale, how overweight is the teenager?"}], 
[["Enegstrong",30], "SingleSlider", {s: "", s2: "The teenager is not obese.", html: "On a 0-100 scale, how overweight is the teenager?"}],

//[["Eweak",31], "SingleSlider", {s: "", s2: "The measure was supported overwhelmingly.", html: "On a 0-100 scale, how much was the measure supported?"}], 
[["Enegstrong",31], "SingleSlider", {s: "", s2: "The measure was not supported unanimously.", html: "On a 0-100 scale, how much was the measure supported?"}], 

//[["Eweak",32], "SingleSlider", {s: "", s2: "The wine is palatable.", html: "On a 0-100 scale, how palatable is the wine?"}], 
[["Enegstrong",32], "SingleSlider", {s: "", s2: "The wine is not delicious.", html: "On a 0-100 scale, how palatable is the wine?"}], 

//[["Eweak",33], "SingleSlider", {s: "", s2: "The tank is partially full.", html: "On a 0-100 scale, how full is the tank?"}], 
[["Enegstrong",33], "SingleSlider", {s: "", s2: "The tank is not completely full.", html: "On a 0-100 scale, how full is the tank?"}], 

//[["Eweak",34], "SingleSlider", {s: "", s2: "The club permits dancing.", html: "On a 0-100 scale, how obligatory is dancing in the club?"}],
[["Enegstrong",34], "SingleSlider", {s: "", s2: "The club does not require dancing.", html: "On a 0-100 scale, how obligatory is dancing in the club?"}],

//[["Eweak",35], "SingleSlider", {s: "", s2: "Ann's speech was polished.", html: "On a 0-100 scale, how polished was Anne's speech?"}], 
[["Enegstrong",35], "SingleSlider", {s: "", s2: "Ann's speech was not impeccable.", html: "On a 0-100 scale, how polished was Anne's speech?"}], 

//[["Eweak",36], "SingleSlider", {s: "", s2: "Success is possible.", html: "On a 0-100 scale, how likely is success?"}], 
[["Enegstrong",36], "SingleSlider", {s: "", s2: "Success is not certain.", html: "On a 0-100 scale, how likely is success?"}],

//[["Eweak",37], "SingleSlider", {s: "", s2: "The girl is pretty.", html: "On a 0-100 scale, how pretty is the girl?"}], 
[["Enegstrong",37], "SingleSlider", {s: "", s2: "The girl is not beautiful.", html: "On a 0-100 scale, how pretty is the girl?"}], 

//[["Eweak",38], "SingleSlider", {s: "", s2: "The residents are primarily Greek.", html: "On a 0-100 scale, how many of the residents are Greek?"}], 
[["Enegstrong",38], "SingleSlider", {s: "", s2: "The residents are not exclusively Greek.", html: "On a 0-100 scale, how many of the residents are Greek?"}], 

//[["Eweak",39], "SingleSlider", {s: "", s2: "A delay will probably occur.", html: "On a 0-100 scale, how likely is a delay to occur?"}], 
[["Enegstrong",39], "SingleSlider", {s: "", s2: "A delay will not necessarily occur.", html: "On a 0-100 scale, how likely is a delay to occur?"}], 

//[["Eweak",40], "SingleSlider", {s: "", s2: "The city reduced waste.", html: "On a 0-100 scale, how much did the city reduce waste?"}], 
[["Enegstrong",40], "SingleSlider", {s: "", s2: "The city did not eliminate waste.", html: "On a 0-100 scale, how much did the city reduce waste?"}], 

//[["Eweak",41], "SingleSlider", {s: "", s2: "Stu's daughter was scared.", html: "On a 0-100 scale, how scared was Stu's daughter?"}],
[["Enegstrong",41], "SingleSlider", {s: "", s2: "Stu's daughter was not petrified.", html: "On a 0-100 scale, how scared was Stu's daughter?"}], 

//[["Eweak",42], "SingleSlider", {s: "", s2: "Kaye's illness was serious.", html: "On a 0-100 scale, how serious was Kaye's illness?"}], 
[["Enegstrong",42], "SingleSlider", {s: "", s2: "Kaye's illness was not life-threatening.", html: "On a 0-100 scale, how serious was Kaye's illness?"}], 

//[["Eweak",43], "SingleSlider", {s: "", s2: "The two paintings are similar.", html: "On a 0-100 scale, how similar are the two paintings?"}], 
[["Enegstrong",43], "SingleSlider", {s: "", s2: "The two paintings are not identical.", html: "On a 0-100 scale, how similar are the two paintings?"}], 

//[["Eweak",44], "SingleSlider", {s: "", s2: "The train slowed.", html: "On a 0-100 scale, how much did the train slow?"}], 
[["Enegstrong",44], "SingleSlider", {s: "", s2: "The train did not stop.", html: "On a 0-100 scale, how much did the train slow?"}], 

//[["Eweak",45], "SingleSlider", {s: "", s2: "The fish is small.", html: "On a 0-100 scale, how small is the fish?"}],
[["Enegstrong",45], "SingleSlider", {s: "", s2: "The fish is not tiny.", html: "On a 0-100 scale, how small is the fish?"}], 

//[["Eweak",46], "SingleSlider", {s: "", s2: "The shirt is snug.", html: "On a 0-100 scale, how snug is the shirt?"}], 
[["Enegstrong",46], "SingleSlider", {s: "", s2: "The shirt is not tight.", html: "On a 0-100 scale, how snug is the shirt?"}], 

 //[["Eweak",47], "SingleSlider", {s: "", s2: "Cecilia trusts some politicians.", html: "On a 0-100 scale, how many politicians does Cecilia trust?"}], 
[["Enegstrong",47], "SingleSlider", {s: "", s2: "Cecilia does not trust all politicians.", html: "On a 0-100 scale, how many politicians does Cecilia trust?"}], 

//[["Eweak",48], "SingleSlider", {s: "", s2: "The runner started.", html: "On a 0-100 scale, how far along is the runner?"}], 
[["Enegstrong",48], "SingleSlider", {s: "", s2: "The runner did not finish.", html: "On a 0-100 scale, how far along is the runner?"}], 

//[["Eweak",49], "SingleSlider", {s: "", s2: "The plant survived.", html: "On a 0-100 scale, how well did the plant survive?"}], 
[["Enegstrong",49], "SingleSlider", {s: "", s2: "The plant did not thrive.", html: "On a 0-100 scale, how well did the plant survive?"}], 

//[["Eweak",50], "SingleSlider", {s: "", s2: "The worker is tired.", html: "On a 0-100 scale, how tired is the worker?"}], 
[["Enegstrong",50], "SingleSlider", {s: "", s2: "The worker is not exhausted.", html: "On a 0-100 scale, how tired is the worker?"}], 

//[["Eweak",51], "SingleSlider", {s: "", s2: "Joey's parents tolerate dating.", html: "On a 0-100 scale, how much do Joey's parents like dating?"}], 
[["Enegstrong",51], "SingleSlider", {s: "", s2: "Joey's parents do not encourage dating.", html: "On a 0-100 scale, how much do Joey's parents like dating?"}], 

//[["Eweak",52], "SingleSlider", {s: "", s2: "The candidate tried.", html: "On a 0-100 scale, how close is the candidate to success?"}], 
[["Enegstrong",52], "SingleSlider", {s: "", s2: "The candidate did not succeed.", html: "On a 0-100 scale, how close is the candidate to success?"}], 

//[["Eweak",53], "SingleSlider", {s: "", s2: "The wallpaper is ugly.", html: "On a 0-100 scale, how ugly is wallpaper?"}], 
[["Enegstrong",53], "SingleSlider", {s: "", s2: "The wallpaper is not hideous.", html: "On a 0-100 scale, how ugly is wallpaper?"}], 

//[["Eweak",54], "SingleSlider", {s: "", s2: "Tom's interview was understandable.", html: "On a 0-100 scale, how understandable was Tom's interview?"}],
[["Enegstrong",54], "SingleSlider", {s: "", s2: "Tom's interview was not articulate.", html: "On a 0-100 scale, how understandable was Tom's interview?"}], 

//[["Eweak",55], "SingleSlider", {s: "", s2: "Tim's bathroom was unpleasant.", html: "On a 0-100 scale, how unpleasant was Tim's bathroom?"}], 
[["Enegstrong",55], "SingleSlider", {s: "", s2: "Tim's bathroom was not disgusting.", html: "On a 0-100 scale, how unpleasant was Tim's bathroom?"}], 

//[["Eweak",56], "SingleSlider", {s: "", s2: "The lawyer is usually early.", html: "On a 0-100 scale, how often is the lawyer early?"}],
[["Enegstrong",56], "SingleSlider", {s: "", s2: "The lawyer is not always early.", html: "On a 0-100 scale, how often is the lawyer early?"}], 

//[["Eweak",57], "SingleSlider", {s: "", s2: "Phoebe wants a car.", html: "On a 0-100 scale, how necessary is a car for Phoebe?"}], 
[["Enegstrong",57], "SingleSlider", {s: "", s2: "Phoebe does not need a car.", html: "On a 0-100 scale, how necessary is a car for Phoebe?"}], 

//[["Eweak",58], "SingleSlider", {s: "", s2: "The weather is warm.", html: "On a 0-100 scale, how warm is the weather?"}], 
[["Enegstrong",58], "SingleSlider", {s: "", s2: "The weather is not hot.", html: "On a 0-100 scale, how warm is the weather?"}], 

//[["Eweak",59], "SingleSlider", {s: "", s2: "The rehearsal went well.", html: "On a 0-100 scale, how well did the rehearsal go?"}], 
[["Enegstrong",59], "SingleSlider", {s: "", s2: "The rehearsal did not go superbly.", html: "On a 0-100 scale, how well did the rehearsal go?"}], 

//[["Eweak",60], "SingleSlider", {s: "", s2: "The waiter is willing.", html: "On a 0-100 scale, how willing is the waiter?"}], 
[["Enegstrong",60], "SingleSlider", {s: "", s2: "The waiter is not eager.", html: "On a 0-100 scale, how willing is the waiter?"}], 

["filler1", "SingleSlider", {s: "",
                                s2: "The table is clean.",
                                html: "On a 0-100 scale, how dirty is the table?"}],
["filler2", "SingleSlider", {s: "",
                                s2: "The man is drunk.",
                                html: "On a 0-100 scale, how sober is the man?"}], 
["filler3", "SingleSlider", {s: "",
                                s2: "The neighbor is sleepy.",
                                html: "On a 0-100 scale, how alert is the neighbor?"}], 
["filler4", "SingleSlider", {s: "",
                                s2: "The gymnast is tall.",
                                html: "On a 0-100 scale, how short is the gymnast?"}],
["filler5", "SingleSlider", {s: "",
                                s2: "The street is wide.",
                                html: "On a 0-100 scale, how narrow is the street?"}]// NOTE NO COMMA


    
    ];