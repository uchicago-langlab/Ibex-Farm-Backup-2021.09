var shuffleSequence = seq("setcounter","consent", "introfirst", "intro","intro2", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E")))), "brexit");
//rshuffle(startsWith("E"),startsWith("f")))
//var shuffleSequence = seq("setcounter", "Demog", "instr", rshuffle(startsWith("item")));

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
"Separator", {transfer: 1000,
   normalMessage: " ",
   errorMessage: "Your answer was incorrect."
    },
    "AcceptabilityJudgment", {
        presentAsScale: true,
        instructions: null,
        randomOrder: false,
        hasCorrect: true
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "Question", {
        presentAsScale: true,
        hasCorrect: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [


["setcounter", "__SetCounter__", { }],

    
// ["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
// ["instr", "Form", {consentRequired: true, html: {include: "instr.html" }} ],

["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],

     ["intro2", "Form", {consentRequired: true, html: { include: "intro3.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: pay attention to the meaning of sentences, and decide whether the word that follows them is a word of English."] 
],continueMessage:"Click here to start the experiment."}],
    
  


  ["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Cats </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> are</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> my</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> favorite. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> elephant</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Do I hate cats?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 
  
  ["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Chess </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> a</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> game. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> sleavs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

  ["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Christina </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> rushed</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> to</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> the bank. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> chair</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was Christina in a hurry?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 
  
  ["practice", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> dog</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> barked.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> creacs </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 
    
    
  [["Ealternative", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Drinking </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> allowed. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> obligatory </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Can one consume beverages?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 1], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Drinking </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> allowed.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>reputable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Can one consume beverages?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


    
  [["Ealternative", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> This </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> model </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> attractive. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> stunning </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 2], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> This </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> model </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> attractive. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>brutal</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


[["Ealternative", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>John </center></font>', transfer: 400}, 
"Message", {html:'<font size="6"><center> began the race. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> complete </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did John participate in the race? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 3], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>John </center></font>', transfer: 400}, 
"Message", {html:'<font size="6"><center> began the race. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> defend </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did John participate in the race? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> teacher</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> believes it is true. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> know </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 4], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>teacher</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  believes it is true. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> meet </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>elephant </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> big. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> enormous </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 5], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>elephant </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  big. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> illegal </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> weather</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>cool. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> cold </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 6], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> weather</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  cool. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> left </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center> machine</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>might </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>damage itself.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> destroy </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the machine invulnerable?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 7], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 500}, "Message", {html:'<font size="6"><center>machine </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> might</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> damage itself. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> gather </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the machine invulnerable?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center> sky</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> dark. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> black </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the sky light?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 8], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center>sky </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  dark. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> sure</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the sky light?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center> task</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> difficult. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> impossible </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 9], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center>task </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  difficult. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> developing </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Zack&#39s </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center>carpet </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> dirty. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> filthy </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was Zack's carpet clean?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 10], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Zack&#39s </center></font>',transfer: 400}, "Message", {html:'<font size="6"><center> carpet</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  dirty. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> gracious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was Zack's carpet clean?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> doctor</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> dislikes coffee. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> loathe </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 11], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>doctor</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  dislikes coffee. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> thaw </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>sales </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> will</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> double. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> triple</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Will the sales change? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 12], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> sales</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> will</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  double. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> silence</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Will the sales change? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>candidate </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> equally skilled.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> more </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 13], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>candidate </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  equally skilled.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> there </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> movie</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> funny. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> hilarious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 14], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>movie </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  funny. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> relational </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> movie</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> good. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> excellent </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 15], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>movie </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> good. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> digital </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 16], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> winner</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> happy. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> ecstatic </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 16], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> winner</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  happy. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> specified </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 17], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>problem </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>hard. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>unsolvable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 17], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> problem</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  hard. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> herniated</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 18], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>toxin </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> harmful.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> deadly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 18], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>toxin </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> harmful.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> written</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 19], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>There </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> water</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> here. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> everywhere </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 19], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>There </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> is</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>water </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  here.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> frequently </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 20], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>boy</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> hungry. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> starving </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 20], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>boy </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  hungry. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> pronounced</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 21], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> student</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> intelligent.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> brilliant</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 21], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> student</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> intelligent. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> subsequent </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 22], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Chris&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>opponent </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>intimidating. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> terrifying </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 22], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Chris&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> opponent</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> intimidating. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> applicable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 23], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> coast</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> largely flooded.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> totally </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was there water on the coast? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 23], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>coast </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  largely flooded. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> anywhere </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was there water on the coast? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 24], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>princess </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> likes dancing. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> love </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 24], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>princess </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  likes dancing. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> move</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 25], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Bill&#39s </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>score </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> matches Al&#39s. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> exceed </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Do Bill and Al have the same score?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 25], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Bill&#39s </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>score </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> matches Al&#39s. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> regret </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Do Bill and Al have the same score?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 26], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Peter&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> answers</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> were</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> mostly wrong.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> entirely </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 26], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Peter&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> answers</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> were</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  mostly wrong.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> carefully </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 27], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>house </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> old. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> ancient </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was the house built a long time ago?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 27], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> house</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  old. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> surprised </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was the house built a long time ago? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 28], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Mistakes </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> happened</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> once.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> twice </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Were there no mistakes?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 28], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Mistakes</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> happened</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  once. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> please </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Were there no mistakes?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 29], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Jimmy </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> writes</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>books </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> or plays.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> and </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 29], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Jimmy </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> writes</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> books</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  or plays.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> yes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 30], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> teenager</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> overweight. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> obese </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 30], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>teenager </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  overweight. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> raging </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 31], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>measure </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> was</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>supported </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> overwhelmingly. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> unanimously </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did nobody support the measure?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 31], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>measure </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>supported </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  overwhelmingly. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> progressively </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did nobody support the measure?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 32], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>wine </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> palatable. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> delicious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 32], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> wine</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  palatable. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> suspicious </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 33], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>tank </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> partially full.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> completely </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was nothing left in the tank?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 33], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> tank</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  partially full. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> yesterday </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was nothing left in the tank?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 34], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> club</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> permits dancing. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> require </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 34], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> club</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  permits dancing. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> increase </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 35], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Anna&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>speech </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> polished. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> impeccable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did Ann have a speech?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 35], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Anna&#39s </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>speech </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  polished. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> consensual </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did Ann have a speech?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 36], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Success</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> possible. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> certain </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 36], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Success</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  possible. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> western </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 37], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>girl</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> pretty. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> beautiful </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 37], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> girl</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  pretty. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> following </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 38], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>residents </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> are</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> primarily Greek.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> exclusively </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 38], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> residents</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> are</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  primarily Greek.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> desperately </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 39], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>A </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>delay </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> will</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> probably occur.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> necessarily </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 39], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>A </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> delay</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>will </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  probably occur.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> effectively </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 40], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>city </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> reduced waste. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> eliminate </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 40], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>city </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  reduced waste. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> communicate </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 41], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Stu&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> daughter</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> scared. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> petrified </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 41], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Stu&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> daughter</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  scared. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> discerning </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 42], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Kaye&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> illness</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> serious. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> life-threatening </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 42], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Kaye&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> illness</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  serious. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> centennial </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 43], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> two</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>paintings </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> are</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> similar. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> identical </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 43], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> two</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> paintings</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>are </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  similar.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> instructional </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 44], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> train</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> slowed. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> stop</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the train speed up?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 44], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>train </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  slowed. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> pay </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the train speed up?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 45], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>fish </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> small. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> tiny </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 45], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>fish </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> small. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> afraid </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 46], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>shirt </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> snug. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> tight </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 46], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> shirt</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  snug. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> mere </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 47], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> bartender</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> saw</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> some cars. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> all </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was the bartender blind?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 47], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> bartender</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> saw</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  some cars.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> next </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was the bartender blind?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 48], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>runner </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> started. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> finish </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the runner withdraw?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 48], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> runner</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  started. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> reveal </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the runner withdraw?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 49], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>plant </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> survived. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> strive </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the plant die?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 49], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> plant</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> survived. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> float </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the plant die?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 50], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>worker </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> tired.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> exhausted</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 50], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>worker </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> tired. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> normative </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 51], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Joey&#39s</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>parents </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> tolerate dating. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> encourage </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 51], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Joey&#39s</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> parents</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  tolerate dating.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> establish</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 52], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> candidate</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> tried. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> succeed </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 52], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> candidate</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> tried. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> attack </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 53], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> wallpaper</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> ugly. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> hideous </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 53], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> wallpaper</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  ugly. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> pandemic </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 54], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Tom&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> interview</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> understandable. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> articulate</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 54], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Tom&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> interview</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> understandable. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> diagonal </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 55], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Tim&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> bathroom</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> unpleasant.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> disgusting </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did Tim's bathroom smell good?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 55], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> Tim&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> bathroom</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>  unpleasant. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> sizable </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did Tim's bathroom smell good?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 56], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> lawyer</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> usually early.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> always </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the lawyer typically late?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}], 

[["Eunrelated", 56], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> lawyer</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> usually early.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> again </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the lawyer typically late?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],

[["Ealternative", 57], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Phoebe </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> wants a car. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> need </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 57], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center>Phoebe </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> wants a car. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> reach </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 58], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> weather</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> warm. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> hot </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 58], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> weather</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> warm. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> huge </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],

[["Ealternative", 59], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> rehearsal</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> went</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> well. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> superbly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the rehearsal take place?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}], 

[["Eunrelated", 59], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>rehearsal </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> went</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> well. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> startlingly </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the rehearsal take place?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],

[["Ealternative", 60], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>waiter </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> willing. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> eager </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}], 

[["Eunrelated", 60], "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},
"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> waiter</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> willing. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> homeless </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],




["Efiller1", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> I</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>am </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>counting </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> calories. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> spraize  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Do I care how much I eat? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller2", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>He </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>hacked </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>into </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> server. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> knewed    </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was the server compromised? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller3", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Susan</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> decorated</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> cookies. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> sckared </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller4", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Bella </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> made</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> sugar cookies.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center> ghland </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller5", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> She</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>died </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>during childbirth.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>ghroats</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller6", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Bathing</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> suits</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> shouldn&#39t</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>be </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> worn.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>kleens</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Can one wear bathing suits?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller7", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Don&#39t </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>bring </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> your</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>pet </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> along.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>crtrexuch  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller8", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>She </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> sat</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> in</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> her</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>bedroom. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>trex </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller9", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Grandpa </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> realized</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> he&#39s</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> not</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>alone. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>rheys</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was there someone else with Grandpa? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller10", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> bus</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>packed. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>citts</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller11", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>They </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> traveled</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>back in time. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>eals</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller12", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>He </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> had</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> mental</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> scars.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>wayed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller13", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Lucifer </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>admired </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> amount of life.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>psells</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller14", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>Great </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> Dane</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> resembled</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>a </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> horse.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>kaud</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller15", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Never </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>underestimate </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>greedy. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>keuth</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller16", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>She </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> threw</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>you </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> under the bus.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>koule</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did she betray you?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller17", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> He</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>can </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> eat</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>pickles. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>rypt</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller18", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>His </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>hair </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>in</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>a</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>ponytail. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>huft</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was his hair down?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller19", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Peter</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> endured</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> surgery.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>glene</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did Peter have surgery?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller20", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> I</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>will </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>lease the boat. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>spewd</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller21", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> He</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> stepped</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> onto</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> bridge.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>pruiff   </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller22", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>New </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>ideas </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> came to light.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>stintz</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller23", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Harrold </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> didn&#39t</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>suspect</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>spy. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>sckou  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller24", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>I </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> wished</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> to</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>be </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>separated. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>sckou  </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller25", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>I </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> am</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>too </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>sick </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>to </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> drive.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>skard</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Can I drive now?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller26", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> retriever</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> feared</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> fireworks.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>smerched</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Were there fireworks? ", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller27", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> trip</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> halted.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>chaugh </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did the trip continue as planned?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller28", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>He </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> turned</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> in </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> paper.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>dedes </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller29", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> soup</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>has </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>flavor. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>yais</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the soup bland? ", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller30", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Porcupines</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>are </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> cuddly.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>nuice</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller31", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Joyce</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>enjoyed </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> eating pancakes.</center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>thomms</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller32", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> She</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> folded</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> her</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>handkerchief. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>knowndge</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller33", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> We</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>weren&#39t </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> in</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> zone.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>scome</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller34", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Choir</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>practice </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>on</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> Thursday.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>smornte</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was choir practice cancelled?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller35", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>A </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>message </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>came for you. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>tweamms</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller36", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Dan</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>ate</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>cotton candy. </center></font>', transfer: 500}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>truffs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller37", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>She </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> opened</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>bottle. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>frournde</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller38", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> book</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>in </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> front</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> of</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>the </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>table. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>slowds</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the book underneath the table?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller39", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> He</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> found</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>rain </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> fascinating.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>proante</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller40", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>It </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>didn&#39t </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>go </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> as</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> expected.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>scwursts</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did it go according to plan?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller41", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>He </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> went</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> to</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> dentist.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>blignth </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller42", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>She </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>saddened. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>skurs</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller43", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Mothers</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> serve</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>their </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> children.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>vighm</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller44", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Eating</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> eggs</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> healthy.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>brarbed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller45", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>It </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> a</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> sandcastle.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>flalphed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller46", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>towels</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> are</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> white.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>claned </center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Are the towels red?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller47", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> sunset</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> red.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>dourved</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller48", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> They</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>said </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>farewell. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>jergued</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Did they part?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller49", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Swimming </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> risky.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>jauphed</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller50", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Dolores </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>recognized </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> the</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> dish.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>gheen</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Was Dolores familiar with the dish?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],


["Efiller51", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>Sophia </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>young. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>shaumb</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller52", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>wine </center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> purple.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>ghaint</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller53", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> road</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>was </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>long. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>shrames</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller54", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> Owls</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>are </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> nocturnal.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>gwerl</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Are owls awake during the day?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller55", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> locket</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>gold. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>ghlud</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller56", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> casserole</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> vegetarian.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>thwanc</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Does the casserole contain meat?", as: ["F: yes", "J: no"], hasCorrect: 1, randomOrder: false}],


["Efiller57", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> incense</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> fragrant.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>thruved</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller58", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center>The </center></font>', transfer: 400}, "Message", {html:'<font size="6"><center>marshmallow </center></font>', transfer: 400},"Message", {html:'<font size="6"><center> was</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> chewy.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>knasps</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller59", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> rabbit</center></font>', transfer: 400},"Message", {html:'<font size="6"><center> is</center></font>', transfer: 400},
"Message", {html:'<font size="6"><center>furry. </center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>scoands</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}],


["Efiller60", "Message", {html:'<font size="6"><center> + </center></font> <p><center>Look at the + and press any key.</center></p>', transfer: "keypress"},"Message", {html:'<font size="6"><center> The</center></font>', transfer: 400}, "Message", {html:'<font size="6"><center> economist</center></font>', transfer: 400},"Message", {html:'<font size="6"><center>is </center></font>', transfer: 400},
"Message", {html:'<font size="6"><center> Norwegian.</center></font>', transfer: 400}, "Message", {html:' ', transfer: 750},
  "AcceptabilityJudgment", {s: {html:'<font size="6" color="blue"><center>wheighm</center></font>'}, q: " ", as: ["F: non-word","J: word"], hasCorrect: false}, "AcceptabilityJudgment", {s: " ", q: "Is the economist Scandinavian?", as: ["F: yes", "J: no"], hasCorrect: 0, randomOrder: false}],





];