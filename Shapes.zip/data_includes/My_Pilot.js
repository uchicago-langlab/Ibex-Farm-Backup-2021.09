/*
--Toronto-Psycholinguistics-Experiments--

Template that gives examples of everything Ibex can do for experiments
*/

var shuffleSequence = seq("Intro",  "practice", "xep", rshuffle(startsWith("s")), "Exit");
var practiceItemTypes = ["practice"];
var centerItems = true;


var defaults = [
    
    "MyController", {
        randomOrder: true 
        //setting default order for pictures to be random 
        //you can check this is true by simply trying experiment multiple times
     },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [



    /*
    ===================
    INTRODUCTION
    Can include files for Questionnaires, consent forms etc...
    ===================
    */

    //name of controller
["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],


    /*
    ===================
    IMAGE
    Controllers that work with Images and Questions
    ===================
    */
    
  ["practice", "MyController", { s: "This is a smiley face:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/pt_yellowsmileyface.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_greensignal1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_moon_new.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_redarrow1.jpg"]]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "Did you answer 'yes'? That sounds about right! Press any key to move on to the next example."]
                           ]}],
 
      ["practice", "MyController", { s: "This is a blue moon:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_greensignal1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/pt_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/pt_yellowsmileyface.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_moon_new.jpg"]]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "Hopefully your answer was 'no'! Press any key to proceed to the next window."]
                           ]}],
    
    
 
 ["xep", Separator, {transfer: 3000, normalMessage: "Now you are ready to begin!" }],
    
    
    [["s1a", 1], "MyController", { s: "This is a bumpy square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_redsquare1.jpg"]]}],
    [["s1b", 1], "MyController", { s: "This is a bumpy square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle41.jpg"]]}],                              
    [["s2a", 2], "MyController", { s: "This is an open circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_bluecircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle1.jpg"]]}],
    [["s2b", 2], "MyController", { s: "This is an open circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_bluecircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"]]}],
    [["s3a", 3], "MyController", { s: "This is a bent line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_greenline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/bent_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bent_blueline1.jpg"]]}],
    [["s3b", 3], "MyController", { s: "This is a bent line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_greenline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/bent_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare11.jpg"]]}],
    [["s4a", 4], "MyController", { s: "This is a curved line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_redline4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_blueline1.jpg"]]}],
    [["s4b", 4], "MyController", { s: "This is a curved line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_redline4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"]]}],
    [["s5a", 5], "MyController", { s: "This is a spotted circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/spotted_greencircle1.jpg"]]}],
    [["s5b", 5], "MyController", { s: "This is a spotted circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/thick_greenarrow1.jpg"]]}],
    [["s6a", 6], "MyController", { s: "This is a striped square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare11.jpg"]]}],
    [["s6b", 6], "MyController", { s: "This is a striped square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/striped_bluetriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"]]}],
    [["s7a", 7], "MyController", { s: "This is a bumpy triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_redtriangle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"]]}],
    [["s7b", 7], "MyController", { s: "This is a bumpy triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_redtriangle4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcylinder2.jpg"]]}],
    [["s8a", 8], "MyController", { s: "This is a curved line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_blueline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline1.jpg"]]}],
    [["s8b", 8], "MyController", { s: "This is a curved line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_blueline4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lighting.jpg"]]}],
    [["s9a", 9], "MyController", { s: "This is a spotted square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg "],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_redsquare1.jpg"]]}],
    [["s9b", 9], "MyController", { s: "This is a spotted square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowsquare4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg "],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle51.jpg"]]}],
    [["s10a", 10], "MyController", { s: "This is a striped triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],
    [["s10b", 10], "MyController", { s: "This is a striped triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle4.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_blueshape.jpg"]]}],                                                                                        
    [["s11a", 11], "MyController", { s: "This is a flat circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_greencircle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_bluecircle5.jpg"]]}],
    [["s11b", 11], "MyController", { s: "This is a flat circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_greencircle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"]]}],    
    [["s12a", 12], "MyController", { s: "This is a closed circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redline.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_yellowcircle5.jpg"]]}],
    [["s12b", 12], "MyController", { s: "This is a closed circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"]]}],    
    [["s13a", 13], "MyController", { s: "This is a straight line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_redline5.jpg"]]}],
    [["s13b", 13], "MyController", { s: "This is a straight line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_yellowcircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud1.jpg"]]}],  
    [["s14a", 14], "MyController", { s: "This is a full cube:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_yellowcube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/full_redcylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_greencube3.jpg"]]}],
    [["s14b", 14], "MyController", { s: "This is a full cube:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_yellowcube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/full_redcylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greenspiral2.jpg"]]}],   
    [["s15a", 15], "MyController", { s: "This is an empty cube:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_cube8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline4.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_bluecube5.jpg"]]}],
    [["s15b", 15], "MyController", { s: "This is an empty cube:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_cube8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/07/full_cylinder8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_bumpyline1.jpg"]]}], 
    [["s16a", 16], "MyController", { s: "This is a flat triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_sphere.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redtriangle5.jpg"]]}],
    [["s16b", 16], "MyController", { s: "This is a flat triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_sphere.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redspiral7.jpg"]]}],      
    [["s17a", 17], "MyController", { s: "This is a closed circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_greencircle5.jpg"]]}],
    [["s17b", 17], "MyController", { s: "This is a closed circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/open_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline2.jpg"]]}],     
    [["s18a", 18], "MyController", { s: "This is a straight line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline51.jpg"]]}],
    [["s18b", 18], "MyController", { s: "This is a straight line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_bluecylinder7.jpg"]]}],  
    [["s19a", 19], "MyController", { s: "This is a full cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_bluecylinder7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_greencube7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcylinder3.jpg"]]}],
    [["s19b", 19], "MyController", { s: "This is a full cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_bluecylinder7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/full_greencube7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline11.jpg"]]}], 
    [["s20a", 20], "MyController", { s: "This is an empty cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_cylinder8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_redcylinder5.jpg"]]}],
    [["s20b", 20], "MyController", { s: "This is an empty cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_cylinder8.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_cube8.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline1.jpg"]]}],  
    [["s21a", 21], "MyController", { s: "This is a long line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_blueline3.jpg"]]}],
    [["s21b", 21], "MyController", { s: "This is a long line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluecircle12.jpg"]]}],   
    [["s22a", 22], "MyController", { s: "This is a short line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline51.jpg"]]}],
    [["s22b", 22], "MyController", { s: "This is a short line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],   
    [["s23a", 23], "MyController", { s: "This is a big square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_redsquare7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_bluesquare3.jpg"]]}],
    [["s23b", 23], "MyController", { s: "This is a big square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_redsquare7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/08/big_yellowtriangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/curved_blueline4.jpg"]]}],     
    [["s24a", 24], "MyController", { s: "This is a small triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle51.jpg"]]}],
    [["s24b", 24], "MyController", { s: "This is a small triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"]]}],  
    [["s25a", 25], "MyController", { s: "This is a wide oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_bluesquare7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval3.jpg"]]}],
    [["s25b", 25], "MyController", { s: "This is a wide oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_bluesquare7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],  
    [["s26a", 26], "MyController", { s: "This is a narrow rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redrectangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle51.jpg"]]}],
    [["s26b", 26], "MyController", { s: "This is a narrow rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redrectangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greenpentagon.jpg"]]}],     
    [["s27a", 27], "MyController", { s: "This is a tall spiral:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral3.jpg"]]}],
    [["s27b", 27], "MyController", { s: "This is a tall spiral:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_redline4.jpg"]]}], 
    [["s28a", 28], "MyController", { s: "This is a short spiral:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral23.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greenspiral5.jpg"]]}],
    [["s28b", 28], "MyController", { s: "This is a short spiral:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral23.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_greensquare1.jpg"]]}],  
    [["s29a", 29], "MyController", { s: "This is a thick line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],                                 
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"]]}],
    [["s29b", 29], "MyController", { s: "This is a thick line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_blueshape2.jpg"]]}],
    [["s30a", 30], "MyController", { s: "This is a thin line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline53.jpg"]]}],
    [["s30b", 30], "MyController", { s: "This is a thin line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],  
    [["s31a", 31], "MyController", { s: "This is a long line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_greenline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline3.jpg"]]}],
    [["s31b", 31], "MyController", { s: "This is a long line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_greenline7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar2.jpg"]]}],     
    [["s32a", 32], "MyController", { s: "This is a short line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcube7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline51.jpg"]]}],
    [["s32b", 32], "MyController", { s: "This is a short line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_bluearrow1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_yellowcube7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"]]}], 
    [["s33a", 33], "MyController", { s: "This is a big triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_yellowtriangle7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/big_greentriangle3.jpg"]]}],
    [["s33b", 33], "MyController", { s: "This is a big triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_yellowtriangle7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/long_redline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_thick_garabato.jpg"]]}], 
    [["s34a", 34], "MyController", { s: "This is a small square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_bluesquare1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare51.jpg"]]}],
    [["s34b", 34], "MyController", { s: "This is a small square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/big_bluesquare1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],  
    [["s35a", 35], "MyController", { s: "This is a wide rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle3.jpg"]]}],
    [["s35b", 35], "MyController", { s: "This is a wide rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline41.jpg"]]}],  
    [["s36a", 36], "MyController", { s: "This is a narrow oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval51.jpg"]]}],
    [["s36b", 36], "MyController", { s: "This is a narrow oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}], 
    [["s37a", 37], "MyController", { s: "This is a tall cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_yellowcylinder7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline1.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_greencylinder3.jpg"]]}],
    [["s37b", 37], "MyController", { s: "This is a tall cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_yellowcylinder7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_bluespiral7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_wavyline2.jpg"]]}], 
    [["s38a", 38], "MyController", { s: "This is a short cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greencylinder1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redcylinder51.jpg"]]}],
    [["s38b", 38], "MyController", { s: "This is a short cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greencylinder1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redstar.jpg"]]}],     
    [["s39a", 39], "MyController", { s: "This is a thick line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_star.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline3.jpg"]]}],
    [["s39b", 39], "MyController", { s: "This is a thick line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_star.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowsquare41.jpg"]]}], 
     [["s40a", 40], "MyController", { s: "This is a thin line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"],                                 
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline51.jpg"]]}],
    [["s40b", 40], "MyController", { s: "This is a thin line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_redline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare4.jpg"]]}],   
    [["s41a", 41], "MyController", { s: "This is a red square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],      
    [["s41b", 41], "MyController", { s: "This is a red square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],    
    [["s42a", 42], "MyController", { s: "This is a green circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],   
    [["s42b", 42], "MyController", { s: "This is a green circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greencircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"]]}],          
    [["s43a", 43], "MyController", { s: "This is a blue line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline1.jpg"]]}],      
    [["s43b", 43], "MyController", { s: "This is a blue line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"]]}],    
    [["s44a", 44], "MyController", { s: "This is a yellow triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],     
    [["s44b", 44], "MyController", { s: "This is a yellow triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"]]}], 
    [["s45a", 45], "MyController", { s: "This is a red oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"]]}],       
    [["s45b", 45], "MyController", { s: "This is a red oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],   
    [["s46a", 46], "MyController", { s: "This is a green rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle51.jpg"]]}],  
    [["s46b", 46], "MyController", { s: "This is a green rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}], 
    [["s47a", 47], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],  
    [["s47b", 47], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_yellowtriangle1.jpg"]]}],        
    [["s48a", 48], "MyController", { s: "This is a yellow circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"]]}],  
    [["s48b", 48], "MyController", { s: "This is a yellow circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/wide_yellowrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],       
    [["s49a", 49], "MyController", { s: "This is a red line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"]]}],  
    [["s49b", 49], "MyController", { s: "This is a red line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle11.jpg"]]}],                                                                                       
    [["s50a", 50], "MyController", { s: "This is a green triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greentriangle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle11.jpg"]]}],     
    [["s50b", 50], "MyController", { s: "This is a green triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greentriangle1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"]]}],                                 
    [["s51a", 51], "MyController", { s: "This is a yellow oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"]]}],     
    [["s51b", 51], "MyController", { s: "This is a yellow oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowoval7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle51.jpg"]]}],                                 
    [["s52a", 52], "MyController", { s: "This is a yellow rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle51.jpg"]]}],     
    [["s52b", 52], "MyController", { s: "This is a yellow rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_thick_bumpyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"]]}],                                 
    [["s53a", 53], "MyController", { s: "This is a green square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],     
    [["s53b", 53], "MyController", { s: "This is a green square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"]]}],                                  
    [["s54a", 54], "MyController", { s: "This is a red circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],     
    [["s54b", 54], "MyController", { s: "This is a red circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}],                                 
    [["s55a", 55], "MyController", { s: "This is a red line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],     
    [["s55b", 55], "MyController", { s: "This is a red line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/long_redline7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/full1_greensquare1.jpg"]]}], 
    [["s56a", 56], "MyController", { s: "This is a blue triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle11.jpg"]]}],     
    [["s56b", 56], "MyController", { s: "This is a blue triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"]]}],  
    [["s57a", 57], "MyController", { s: "This is a yellow square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],     
    [["s57b", 57], "MyController", { s: "This is a yellow square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_blueline51.jpg"]]}],                                                                      
    [["s58a", 58], "MyController", { s: "This is a blue circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle11.jpg"]]}],    
    [["s58b", 58], "MyController", { s: "This is a blue circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluecircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_redsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"]]}],  
    [["s59a", 59], "MyController", { s: "This is a yellow line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle3.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/10/thick_redline1.jpg"]]}],      
    [["s59b", 59], "MyController", { s: "This is a yellow line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle3.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval11.jpg"]]}],   
    [["s60a", 60], "MyController", { s: "This is a red triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2014/04/spotted_greentriangle11.jpg"]]}],                                                                                                                                                                
    [["s60b", 60], "MyController", { s: "This is a red triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_redarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],     
    [["s61", 61], "MyController", { s: "This is a square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/blue_sun.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"]]}],  
    [["s62", 62], "MyController", { s: "This is a line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/curved_bluearrow4.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greenpentagon.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval7.jpg"]]}],   
    [["s63", 63], "MyController", { s: "This is a star:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/yellow_star.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluesquare5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redarrow1.jpg"]]}],                                  
    [["s64", 64], "MyController", { s: "This is a cone:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_redspiral7.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluesquare7.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                     
    [["s65", 65], "MyController", { s: "This is a cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_greencylinder6.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_redsquare3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/chereos_yellowoval.jpg"]]}],                                     
    [["s66", 66], "MyController", { s: "This is a star:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full_greencylinder5.jpg"]]}],                                     
    [["s67", 67], "MyController", { s: "This is a triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_yellowtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_redcylinder1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_lightingplain.jpg"]]}],                                     
    [["s68", 68], "MyController", { s: "This is an oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_greentriangle3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_sun.jpg"]]}],  
    [["s69", 69], "MyController", { s: "This is a cloud", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/red_cloud.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/tall_yellowcylinder7.jpg"]]}],                                  
    [["s70", 70], "MyController", { s: "This is a rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/full_greencube7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/tall_bluespiral2.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redtriangle4.jpg"]]}],    
    [["s71", 71], "MyController", { s: "This is a red square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_redsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],                                  
    [["s72", 72], "MyController", { s: "This is a striped triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"]]}],                                   
    [["s73", 73], "MyController", { s: "This is a blue line", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"]]}],                                   
    [["s74", 74], "MyController", { s: "This is an orange circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenarrow7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_redline7.jpg"]]}],                                   
    [["s75", 75], "MyController", { s: "This is a red oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"]]}],                                   
    [["s76", 76], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_greensquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"]]}],                                   
    [["s77", 77], "MyController", { s: "This is a blue triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_bluetriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"]]}],                                   
    [["s78", 78], "MyController", { s: "This is a red line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/big_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_greencircle1.jpg"]]}],                                   
    [["s79", 79], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"]]}],                                   
    [["s80", 80], "MyController", { s: "This is a green rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s81", 81], "MyController", { s: "This is a square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],   
    [["s82", 82], "MyController", { s: "This is an oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"]]}],                                                                   
    [["s83", 83], "MyController", { s: "This is a triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                   
    [["s84", 84], "MyController", { s: "This is a square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                   
    [["s85", 85], "MyController", { s: "This is a line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"]]}],                                   
    [["s86", 86], "MyController", { s: "This is a cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenline4.jpg"]]}],                                   
    [["s87", 87], "MyController", { s: "This is a triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],                                   
    [["s88", 88], "MyController", { s: "This is a line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],                                   
    [["s89", 89], "MyController", { s: "This is an arrow:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],                                   
    [["s90", 90], "MyController", { s: "This is an arrow:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"]]}],                                   
    [["s91", 91], "MyController", { s: "This is a square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s92", 92], "MyController", { s: "This is a triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],                                     
    [["s93", 93], "MyController", { s: "This is a triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"]]}],                                     
    [["s94", 94], "MyController", { s: "This is a rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"]]}],                                     
    [["s95", 95], "MyController", { s: "This is a line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],                                     
    [["s96", 96], "MyController", { s: "This is a circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"]]}],                                     
    [["s97", 97], "MyController", { s: "This is a rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],                                     
    [["s98", 98], "MyController", { s: "This is a cube:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"]]}],                                     
    [["s99", 99], "MyController", { s: "This is a star:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/yellow_star.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"]]}],                                     
    [["s100", 100], "MyController", { s: "This is a star:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2016/03/red_sun.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                                                                                    
    [["s101", 101], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bumpy_bluesquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_redline4.jpg"]]}],   
    [["s102", 102], "MyController", { s: "This is a yellow cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_yellowcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redrectangle5.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_bluetriangle7.jpg"]]}],                                                                   
    [["s103", 103], "MyController", { s: "This is a red triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/diagonal_bluearrow.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"]]}],                                   
    [["s104", 104], "MyController", { s: "This is a red rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle7.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_yellowcircle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}],                                   
    [["s105", 105], "MyController", { s: "This is a blue line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_blueline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_greenoval7.jpg"],                              
                                 ["D","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_sun.jpg"]]}],                                   
    [["s106", 106], "MyController", { s: "This is a blue oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_yellowoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/full1_bluesquare2.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_star1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenline4.jpg"]]}],                                   
    [["s107", 107], "MyController", { s: "This is a red triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redtriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_arch.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_yellowline7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_heart.jpg"]]}],                                   
    [["s108", 108], "MyController", { s: "This is a green circle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_star.jpg"]]}],                                   
    [["s109", 109], "MyController", { s: "This is a blue arrow:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/bent_bluearrow1.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"]]}],                                   
    [["s110", 110], "MyController", { s: "This is a yellow oval:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_bluetriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow1.jpg"]]}],                                   
    [["s111", 111], "MyController", { s: "This is a yellow square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_yellowsquare1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greentriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_blueline3.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"]]}],                                   
    [["s112", 112], "MyController", { s: "This is a red arrow:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/striped_redcircle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline7.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline7.jpg"]]}],                                     
    [["s113", 113], "MyController", { s: "This is a green triangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/spotted_greentriangle1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_redoval1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowoval1.jpg"]]}],                                     
    [["s114", 114], "MyController", { s: "This is a blue square:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_bluearrow1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_yellowtriangle1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/spotted_greencircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/open_redtriangle1.jpg"]]}],                                     
    [["s115", 115], "MyController", { s: "This is a yellow line:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/thick_yellowline1.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_greensquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_cloud.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"]]}],                                     
    [["s116", 116], "MyController", { s: "This is a red cylinder:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_redoval3.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_greenline1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_yellowsquare1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/long_blueline1.jpg"]]}],                                     
    [["s117", 117], "MyController", { s: "This is a green rectangle:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2016/03/wide_greenrectangle5.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_wavyline.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluecircle1.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/red_wavyline.jpg"]]}],                                     
    [["s118", 118], "MyController", { s: "This is a green heart:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/blue_heart.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/striped_redtriangle1.jpg"], 
                                 ["C","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/thick_greenarrow7.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_yellowtriangle1.jpg"]]}],                                     
    [["s119", 119], "MyController", { s: "This is a yellow star:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2016/03/yellow_star.jpg"],
                                 ["B","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_bluesquare1.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bent_greenline4.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/bumpy_redsquare1.jpg"]]}],                                     
    [["s120", 120], "MyController", { s: "This is a red sun:", /*question you want to ask*/ /*Have added condition /group/ to the type*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","https://lucian.uchicago.edu/blogs/lpl/files/2016/03/red_sun.jpg"],
                                 ["B","https://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_greenarrow4.jpg"], 
                                 ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/wide_yellowrectangle5.jpg"],                              
                                 ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/curved_bluearrow4.jpg"]]}]                                   
 ];                                
                                     

