var shuffleSequence = seq("Intro", "setcounter", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Unlikely)", 
        rightComment: "(Likely)"
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],







["practice", "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Lauren talked to Kyle</b>.</p><p>How likely do you think it is that</p><p><b>Lauren knew Kyle</b>?</p></center> '}}],
	
	
["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it seems likely that Lauren knew Kyle, so you should have selected one of the numbers on the higher end of the scale (5-7)."],
["p", "Press any key to continue."]
]}],
	
["practice", "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Harold was afraid of Victoria</b>.</p><p>How likely do you think it is that</p><p><b>Harold flirted with Victoria</b>?</p></center> '}}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it doesn\'t seem very likely that Harold flirted with Victoria, so you should have selected one of the numbers on the lower end of the scale (1-3)."],
["p", "Press any key to continue."]
]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],






/* original QP practice

["practice", "PictureScale", {
html:'<h><b><center><font size="5"> Planning a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/example_1.jpg" height="35%"<center>',
s: {html: '<center><p><i>Party host: </i>Do you want to come?</p> <p><i>Host\'s friend: </i>I\'d love to!</p> <p>On a scale from 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the host\'s friend meant:</p><p>I\'ll be at the party.</p></center> '}}],  

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it seems likely that the host\'s friend meant they would be at the party, so you should have clicked on one of the buttons on the higher end of the scale (5-7)."],
["p", "Press any key to continue."]
]}],
    
["practice", "PictureScale", {
html:'<h><b><center><font size="5"> Planning a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/example_2.jpg" height="35%"</center>',
s: {html: '<center><p><i> Host:</i> Can you bring a dessert?</p> <p><i> Host\'s friend:</i> I make great brownies.</p> <p>On a scale from 1 to 7, where 1 is the most likely and 7 is the least likely, how likely do you think it is that the host\'s friend meant:</p><p>I can\'t bring a dessert.</p></center> '}}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it doesn\'t seem very likely that the host\'s friend meant that they can\'t bring a dessert, so you should have clicked on one of the buttons on the lower end of the scale (1-3)."],
["p", "Press any key to continue."]
]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    
*/









[["q-bridge-1-related", 1], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>James congratulated Mary</b>.</p><p>How likely do you think it is that</p><p><b>James complimented Mary</b>?</p></center> '}}],
	
[["q-bridge-1-unrelated", 1], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>James congratulated Mary</b>.</p><p>How likely do you think it is that</p><p><b>James upset Mary</b>?</p></center> '}}],



[["q-bridge-2-related", 2], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>John suspected Robert</b>.</p><p>How likely do you think it is that</p><p><b>John distrusted Robert</b>?</p></center> '}}],
	
[["q-bridge-2-unrelated", 2], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>John suspected Robert</b>.</p><p>How likely do you think it is that</p><p><b>John called Robert</b>?</p></center> '}}],



[["q-bridge-3-related", 3], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Patricia bullied Jennifer</b>.</p><p>How likely do you think it is that</p><p><b>Patricia intimidated Jennifer</b>?</p></center> '}}],
	
[["q-bridge-3-unrelated", 3], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Patricia bullied Jennifer</b>.</p><p>How likely do you think it is that</p><p><b>Patricia accepted Jennifer</b>?</p></center> '}}],



[["q-bridge-4-related", 4], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Elizabeth alarmed Michael</b>.</p><p>How likely do you think it is that</p><p><b>Elizabeth frightened Michael</b>?</p></center> '}}],
	
[["q-bridge-4-unrelated", 4], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Elizabeth alarmed Michael</b>.</p><p>How likely do you think it is that</p><p><b>Elizabeth directed Michael</b>?</p></center> '}}],



[["q-bridge-5-related", 5], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>William frustrated Linda</b>.</p><p>How likely do you think it is that</p><p><b>William discouraged Linda</b>?</p></center> '}}],
	
[["q-bridge-5-unrelated", 5], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>William frustrated Linda</b>.</p><p>How likely do you think it is that</p><p><b>William echoed Linda</b>?</p></center> '}}],



[["q-bridge-6-related", 6], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>David misled Richard</b>.</p><p>How likely do you think it is that</p><p><b>David tricked Richard</b>?</p></center> '}}],
	
[["q-bridge-6-unrelated", 6], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>David misled Richard</b>.</p><p>How likely do you think it is that</p><p><b>David battled Richard</b>?</p></center> '}}],



[["q-bridge-7-related", 7], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Barbara annoyed Susan</b>.</p><p>How likely do you think it is that</p><p><b>Barbara harassed Susan</b>?</p></center> '}}],
	
[["q-bridge-7-unrelated", 7], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Barbara annoyed Susan</b>.</p><p>How likely do you think it is that</p><p><b>Barbara dressed Susan</b>?</p></center> '}}],



[["q-bridge-8-related", 8], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jessica indulged Joseph</b>.</p><p>How likely do you think it is that</p><p><b>Jessica spoiled Joseph</b>?</p></center> '}}],
	
[["q-bridge-8-unrelated", 8], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jessica indulged Joseph</b>.</p><p>How likely do you think it is that</p><p><b>Jessica threatened Joseph</b>?</p></center> '}}],



[["q-bridge-9-related", 9], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Thomas reminded Margaret</b>.</p><p>How likely do you think it is that</p><p><b>Thomas nagged Margaret</b>?</p></center> '}}],
	
[["q-bridge-9-unrelated", 9], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Thomas reminded Margaret</b>.</p><p>How likely do you think it is that</p><p><b>Thomas drew Margaret</b>?</p></center> '}}],



[["q-bridge-10-related", 10], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Charles amazed Christopher</b>.</p><p>How likely do you think it is that</p><p><b>Charles bewildered Christopher</b>?</p></center> '}}],
	
[["q-bridge-10-unrelated", 10], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Charles amazed Christopher</b>.</p><p>How likely do you think it is that</p><p><b>Charles healed Christopher</b>?</p></center> '}}],



[["q-bridge-11-related", 11], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sarah refuted Karen</b>.</p><p>How likely do you think it is that</p><p><b>Sarah corrected Karen</b>?</p></center> '}}],
	
[["q-bridge-11-unrelated", 11], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sarah refuted Karen</b>.</p><p>How likely do you think it is that</p><p><b>Sarah included Karen</b>?</p></center> '}}],



[["q-bridge-12-related", 12], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nancy supported Daniel</b>.</p><p>How likely do you think it is that</p><p><b>Nancy defended Daniel</b>?</p></center> '}}],
	
[["q-bridge-12-unrelated", 12], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nancy supported Daniel</b>.</p><p>How likely do you think it is that</p><p><b>Nancy duped Daniel</b>?</p></center> '}}],



[["q-bridge-13-related", 13], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Matthew ignored Betty</b>.</p><p>How likely do you think it is that</p><p><b>Matthew excluded Betty</b>?</p></center> '}}],
	
[["q-bridge-13-unrelated", 13], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Matthew ignored Betty</b>.</p><p>How likely do you think it is that</p><p><b>Matthew instructed Betty</b>?</p></center> '}}],



[["q-bridge-14-related", 14], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Anthony interrupted Donald</b>.</p><p>How likely do you think it is that</p><p><b>Anthony heckled Donald</b>?</p></center> '}}],
	
[["q-bridge-14-unrelated", 14], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Anthony interrupted Donald</b>.</p><p>How likely do you think it is that</p><p><b>Anthony encouraged Donald</b>?</p></center> '}}],



[["q-bridge-15-related", 15], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Lisa placated Dorothy</b>.</p><p>How likely do you think it is that</p><p><b>Lisa calmed Dorothy</b>?</p></center> '}}],
	
[["q-bridge-15-unrelated", 15], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Lisa placated Dorothy</b>.</p><p>How likely do you think it is that</p><p><b>Lisa fetched Dorothy</b>?</p></center> '}}],



[["q-bridge-16-related", 16], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sandra detained Mark</b>.</p><p>How likely do you think it is that</p><p><b>Sandra arrested Mark</b>?</p></center> '}}],
	
[["q-bridge-16-unrelated", 16], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sandra detained Mark</b>.</p><p>How likely do you think it is that</p><p><b>Sandra ignored Mark</b>?</p></center> '}}],



[["q-bridge-17-related", 17], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Paul fascinated Ashley</b>.</p><p>How likely do you think it is that</p><p><b>Paul dazzled Ashley</b>?</p></center> '}}],
	
[["q-bridge-17-unrelated", 17], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Paul fascinated Ashley</b>.</p><p>How likely do you think it is that</p><p><b>Paul grilled Ashley</b>?</p></center> '}}],



[["q-bridge-18-related", 18], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Steven charmed Andrew</b>.</p><p>How likely do you think it is that</p><p><b>Steven seduced Andrew</b>?</p></center> '}}],
	
[["q-bridge-18-unrelated", 18], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Steven charmed Andrew</b>.</p><p>How likely do you think it is that</p><p><b>Steven offended Andrew</b>?</p></center> '}}],



[["q-bridge-19-related", 19], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kimberly subdued Donna</b>.</p><p>How likely do you think it is that</p><p><b>Kimberly overpowered Donna</b>?</p></center> '}}],
	
[["q-bridge-19-unrelated", 19], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kimberly subdued Donna</b>.</p><p>How likely do you think it is that</p><p><b>Kimberly telephoned Donna</b>?</p></center> '}}],



[["q-bridge-20-related", 20], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Carol misinformed Kenneth</b>.</p><p>How likely do you think it is that</p><p><b>Carol deceived Kenneth</b>?</p></center> '}}],
	
[["q-bridge-20-unrelated", 20], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Carol misinformed Kenneth</b>.</p><p>How likely do you think it is that</p><p><b>Carol protected Kenneth</b>?</p></center> '}}],



[["q-bridge-21-related", 21], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>George influenced Michelle</b>.</p><p>How likely do you think it is that</p><p><b>George manipulated Michelle</b>?</p></center> '}}],
	
[["q-bridge-21-unrelated", 21], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>George influenced Michelle</b>.</p><p>How likely do you think it is that</p><p><b>George rescued Michelle</b>?</p></center> '}}],



[["q-bridge-22-related", 22], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Joshua outdid Kevin</b>.</p><p>How likely do you think it is that</p><p><b>Joshua outshined Kevin</b>?</p></center> '}}],
	
[["q-bridge-22-unrelated", 22], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Joshua outdid Kevin</b>.</p><p>How likely do you think it is that</p><p><b>Joshua questioned Kevin</b>?</p></center> '}}],



[["q-bridge-23-related", 23], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Emily caught Amanda</b>.</p><p>How likely do you think it is that</p><p><b>Emily exposed Amanda</b>?</p></center> '}}],
	
[["q-bridge-23-unrelated", 23], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Emily caught Amanda</b>.</p><p>How likely do you think it is that</p><p><b>Emily upstaged Amanda</b>?</p></center> '}}],



[["q-bridge-24-related", 24], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Helen tolerated Brian</b>.</p><p>How likely do you think it is that</p><p><b>Helen condoned Brian</b>?</p></center> '}}],
	
[["q-bridge-24-unrelated", 24], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Helen tolerated Brian</b>.</p><p>How likely do you think it is that</p><p><b>Helen released Brian</b>?</p></center> '}}],



[["q-bridge-25-related", 25], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Edward adored Melissa</b>.</p><p>How likely do you think it is that</p><p><b>Edward loved Melissa</b>?</p></center> '}}],
	
[["q-bridge-25-unrelated", 25], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Edward adored Melissa</b>.</p><p>How likely do you think it is that</p><p><b>Edward represented Melissa</b>?</p></center> '}}],



[["q-bridge-26-related", 26], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Ronald praised Timothy</b>.</p><p>How likely do you think it is that</p><p><b>Ronald flattered Timothy</b>?</p></center> '}}],
	
[["q-bridge-26-unrelated", 26], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Ronald praised Timothy</b>.</p><p>How likely do you think it is that</p><p><b>Ronald concerned Timothy</b>?</p></center> '}}],



[["q-bridge-27-related", 27], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Deborah respected Stephanie</b>.</p><p>How likely do you think it is that</p><p><b>Deborah revered Stephanie</b>?</p></center> '}}],
	
[["q-bridge-27-unrelated", 27], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Deborah respected Stephanie</b>.</p><p>How likely do you think it is that</p><p><b>Deborah warned Stephanie</b>?</p></center> '}}],



[["q-bridge-28-related", 28], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Laura avoided Jason</b>.</p><p>How likely do you think it is that</p><p><b>Laura disliked Jason</b>?</p></center> '}}],
	
[["q-bridge-28-unrelated", 28], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Laura avoided Jason</b>.</p><p>How likely do you think it is that</p><p><b>Laura involved Jason</b>?</p></center> '}}],



[["q-bridge-29-related", 29], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jeffrey fooled Rebecca</b>.</p><p>How likely do you think it is that</p><p><b>Jeffrey conned Rebecca</b>?</p></center> '}}],
	
[["q-bridge-29-unrelated", 29], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jeffrey fooled Rebecca</b>.</p><p>How likely do you think it is that</p><p><b>Jeffrey described Rebecca</b>?</p></center> '}}],



[["q-bridge-30-related", 30], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Ryan approached Gary</b>.</p><p>How likely do you think it is that</p><p><b>Ryan greeted Gary</b>?</p></center> '}}],
	
[["q-bridge-30-unrelated", 30], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Ryan approached Gary</b>.</p><p>How likely do you think it is that</p><p><b>Ryan controlled Gary</b>?</p></center> '}}],















[["q-entail-1-related", 31], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sharon consoled Cynthia</b>.</p><p>How likely do you think it is that</p><p><b>Sharon comforted Cynthia</b>?</p></center> '}}],
	
[["q-entail-1-unrelated", 31], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Sharon consoled Cynthia</b>.</p><p>How likely do you think it is that</p><p><b>Sharon applauded Cynthia</b>?</p></center> '}}],



[["q-entail-2-related", 32], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kathleen neglected Jacob</b>.</p><p>How likely do you think it is that</p><p><b>Kathleen ignored Jacob</b>?</p></center> '}}],
	
[["q-entail-2-unrelated", 32], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kathleen neglected Jacob</b>.</p><p>How likely do you think it is that</p><p><b>Kathleen berated Jacob</b>?</p></center> '}}],



[["q-entail-3-related", 33], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nicholas scammed Amy</b>.</p><p>How likely do you think it is that</p><p><b>Nicholas cheated Amy</b>?</p></center> '}}],
	
[["q-entail-3-unrelated", 33], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nicholas scammed Amy</b>.</p><p>How likely do you think it is that</p><p><b>Nicholas affirmed Amy</b>?</p></center> '}}],



[["q-entail-4-related", 34], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Eric entertained Stephen</b>.</p><p>How likely do you think it is that</p><p><b>Eric amused Stephen</b>?</p></center> '}}],
	
[["q-entail-4-unrelated", 34], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Eric entertained Stephen</b>.</p><p>How likely do you think it is that</p><p><b>Eric delayed Stephen</b>?</p></center> '}}],



[["q-entail-5-related", 35], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Shirley bested Anna</b>.</p><p>How likely do you think it is that</p><p><b>Shirley beat Anna</b>?</p></center> '}}],
	
[["q-entail-5-unrelated", 35], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Shirley bested Anna</b>.</p><p>How likely do you think it is that</p><p><b>Shirley replaced Anna</b>?</p></center> '}}],



[["q-entail-6-related", 36], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Angela shocked Jonathan</b>.</p><p>How likely do you think it is that</p><p><b>Angela surprised Jonathan</b>?</p></center> '}}],
	
[["q-entail-6-unrelated", 36], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Angela shocked Jonathan</b>.</p><p>How likely do you think it is that</p><p><b>Angela educated Jonathan</b>?</p></center> '}}],



[["q-entail-7-related", 37], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Larry billed Ruth</b>.</p><p>How likely do you think it is that</p><p><b>Larry charged Ruth</b>?</p></center> '}}],
	
[["q-entail-7-unrelated", 37], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Larry billed Ruth</b>.</p><p>How likely do you think it is that</p><p><b>Larry embarrassed Ruth</b>?</p></center> '}}],



[["q-entail-8-related", 38], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Justin scolded Scott</b>.</p><p>How likely do you think it is that</p><p><b>Justin admonished Scott</b>?</p></center> '}}],
	
[["q-entail-8-unrelated", 38], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Justin scolded Scott</b>.</p><p>How likely do you think it is that</p><p><b>Justin feared Scott</b>?</p></center> '}}],



[["q-entail-9-related", 39], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Brenda aggravated Pamela</b>.</p><p>How likely do you think it is that</p><p><b>Brenda annoyed Pamela</b>?</p></center> '}}],
	
[["q-entail-9-unrelated", 39], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Brenda aggravated Pamela</b>.</p><p>How likely do you think it is that</p><p><b>Brenda guided Pamela</b>?</p></center> '}}],



[["q-entail-10-related", 40], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nicole woke Frank</b>.</p><p>How likely do you think it is that</p><p><b>Nicole roused Frank</b>?</p></center> '}}],
	
[["q-entail-10-unrelated", 40], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Nicole woke Frank</b>.</p><p>How likely do you think it is that</p><p><b>Nicole impressed Frank</b>?</p></center> '}}],



[["q-entail-11-related", 41], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Brandon hugged Katherine</b>.</p><p>How likely do you think it is that</p><p><b>Brandon embraced Katherine</b>?</p></center> '}}],
	
[["q-entail-11-unrelated", 41], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Brandon hugged Katherine</b>.</p><p>How likely do you think it is that</p><p><b>Brandon rebuffed Katherine</b>?</p></center> '}}],



[["q-entail-12-related", 42], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Raymond despised Gregory</b>.</p><p>How likely do you think it is that</p><p><b>Raymond hated Gregory</b>?</p></center> '}}],
	
[["q-entail-12-unrelated", 42], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Raymond despised Gregory</b>.</p><p>How likely do you think it is that</p><p><b>Raymond helped Gregory</b>?</p></center> '}}],



[["q-entail-13-related", 43], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Virginia shoved Catherine</b>.</p><p>How likely do you think it is that</p><p><b>Virginia pushed Catherine</b>?</p></center> '}}],
	
[["q-entail-13-unrelated", 43], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Virginia shoved Catherine</b>.</p><p>How likely do you think it is that</p><p><b>Virginia spotted Catherine</b>?</p></center> '}}],



[["q-entail-14-related", 44], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Christine terrified Benjamin</b>.</p><p>How likely do you think it is that</p><p><b>Christine scared Benjamin</b>?</p></center> '}}],
	
[["q-entail-14-unrelated", 44], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Christine terrified Benjamin</b>.</p><p>How likely do you think it is that</p><p><b>Christine pleased Benjamin</b>?</p></center> '}}],



[["q-entail-15-related", 45], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Samuel astounded Debra</b>.</p><p>How likely do you think it is that</p><p><b>Samuel surprised Debra</b>?</p></center> '}}],
	
[["q-entail-15-unrelated", 45], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Samuel astounded Debra</b>.</p><p>How likely do you think it is that</p><p><b>Samuel punished Debra</b>?</p></center> '}}],



[["q-entail-16-related", 46], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Patrick perverted Alexander</b>.</p><p>How likely do you think it is that</p><p><b>Patrick corrupted Alexander</b>?</p></center> '}}],
	
[["q-entail-16-unrelated", 46], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Patrick perverted Alexander</b>.</p><p>How likely do you think it is that</p><p><b>Patrick sheltered Alexander</b>?</p></center> '}}],



[["q-entail-17-related", 47], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Samantha tainted Janet</b>.</p><p>How likely do you think it is that</p><p><b>Samantha contaminated Janet</b>?</p></center> '}}],
	
[["q-entail-17-unrelated", 47], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Samantha tainted Janet</b>.</p><p>How likely do you think it is that</p><p><b>Samantha served Janet</b>?</p></center> '}}],



[["q-entail-18-related", 48], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Rachel sabotaged Jack</b>.</p><p>How likely do you think it is that</p><p><b>Rachel undermined Jack</b>?</p></center> '}}],
	
[["q-entail-18-unrelated", 48], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Rachel sabotaged Jack</b>.</p><p>How likely do you think it is that</p><p><b>Rachel fed Jack</b>?</p></center> '}}],



[["q-entail-19-related", 49], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Dennis captured Carolyn</b>.</p><p>How likely do you think it is that</p><p><b>Dennis apprehended Carolyn</b>?</p></center> '}}],
	
[["q-entail-19-unrelated", 49], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Dennis captured Carolyn</b>.</p><p>How likely do you think it is that</p><p><b>Dennis strengthened Carolyn</b>?</p></center> '}}],



[["q-entail-20-related", 50], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jerry pestered Tyler</b>.</p><p>How likely do you think it is that</p><p><b>Jerry hassled Tyler</b>?</p></center> '}}],
	
[["q-entail-20-unrelated", 50], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Jerry pestered Tyler</b>.</p><p>How likely do you think it is that</p><p><b>Jerry stopped Tyler</b>?</p></center> '}}],



[["q-entail-21-related", 51], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Emma released Maria</b>.</p><p>How likely do you think it is that</p><p><b>Emma freed Maria</b>?</p></center> '}}],
	
[["q-entail-21-unrelated", 51], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Emma released Maria</b>.</p><p>How likely do you think it is that</p><p><b>Emma scared Maria</b>?</p></center> '}}],



[["q-entail-22-related", 52], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Heather dodged Aaron</b>.</p><p>How likely do you think it is that</p><p><b>Heather evaded Aaron</b>?</p></center> '}}],
	
[["q-entail-22-unrelated", 52], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Heather dodged Aaron</b>.</p><p>How likely do you think it is that</p><p><b>Heather supported Aaron</b>?</p></center> '}}],



[["q-entail-23-related", 53], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Henry pacified Diane</b>.</p><p>How likely do you think it is that</p><p><b>Henry quieted Diane</b>?</p></center> '}}],
	
[["q-entail-23-unrelated", 53], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Henry pacified Diane</b>.</p><p>How likely do you think it is that</p><p><b>Henry surprised Diane</b>?</p></center> '}}],



[["q-entail-24-related", 54], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Douglas soothed Jose</b>.</p><p>How likely do you think it is that</p><p><b>Douglas calmed Jose</b>?</p></center> '}}],
	
[["q-entail-24-unrelated", 54], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Douglas soothed Jose</b>.</p><p>How likely do you think it is that</p><p><b>Douglas taunted Jose</b>?</p></center> '}}],



[["q-entail-25-related", 55], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Julie detested Joyce</b>.</p><p>How likely do you think it is that</p><p><b>Julie hated Joyce</b>?</p></center> '}}],
	
[["q-entail-25-unrelated", 55], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Julie detested Joyce</b>.</p><p>How likely do you think it is that</p><p><b>Julie contacted Joyce</b>?</p></center> '}}],



[["q-entail-26-related", 56], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Evelyn idolized Peter</b>.</p><p>How likely do you think it is that</p><p><b>Evelyn admired Peter</b>?</p></center> '}}],
	
[["q-entail-26-unrelated", 56], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Evelyn idolized Peter</b>.</p><p>How likely do you think it is that</p><p><b>Evelyn refused Peter</b>?</p></center> '}}],



[["q-entail-27-related", 57], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Adam recommended Frances</b>.</p><p>How likely do you think it is that</p><p><b>Adam endorsed Frances</b>?</p></center> '}}],
	
[["q-entail-27-unrelated", 57], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Adam recommended Frances</b>.</p><p>How likely do you think it is that</p><p><b>Adam rejected Frances</b>?</p></center> '}}],



[["q-entail-28-related", 58], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Zachary captivated Nathan</b>.</p><p>How likely do you think it is that</p><p><b>Zachary intrigued Nathan</b>?</p></center> '}}],
	
[["q-entail-28-unrelated", 58], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Zachary captivated Nathan</b>.</p><p>How likely do you think it is that</p><p><b>Zachary imagined Nathan</b>?</p></center> '}}],



[["q-entail-29-related", 59], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Joan floored Christina</b>.</p><p>How likely do you think it is that</p><p><b>Joan astonished Christina</b>?</p></center> '}}],
	
[["q-entail-29-unrelated", 59], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Joan floored Christina</b>.</p><p>How likely do you think it is that</p><p><b>Joan picked Christina</b>?</p></center> '}}],



[["q-entail-30-related", 60], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kelly watched Walter</b>.</p><p>How likely do you think it is that</p><p><b>Kelly saw Walter</b>?</p></center> '}}],
	
[["q-entail-30-unrelated", 60], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p><br /><p>Suppose you know that</p><p><b>Kelly watched Walter</b>.</p><p>How likely do you think it is that</p><p><b>Kelly replaced Walter</b>?</p></center> '}}]












/*add the comma back and delete it from the final thing*/	
	
	
	
];


	
    
    



/*In this experiment, the "antecedent" condition refers to both the antecedent and the utterance, which matches the antecedent in form. */


/*
[["q1a",1] or "practice", "PictureScale", {
html:'<h><b><center><font size="5"> Title</font></center></b></h> <p></p> <center><img src = "imglink.jpg" height="10%"</center>',
s: {html: '<center><p>Utterance 1</p> <p>Utterance 2</p> <p>Prompt</p><p>Meaning</p></center> '}}],
*/
  
  /*  Old syntax - cleaner, but can\'t format text or put title above strip
[["q1e", 1], "PictureScale", {
html:'<center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%" <center>', 
s:["center",
["p", "At the grocery store"],
["p", "Son: I want to buy candy bars!"],
["p", "Father: We can\'t."],
["p", "On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant:"],
["p", "We can\'t buy any candy bars today."],
]}],
    */
    

/*
[["q-entail-1-related", 1], "AcceptabilityJudgment", {
s: {html: '<center><p>Use the scale to answer the question, where 7 represents <i>very likely</i> and 1 represents <i>very unlikely</i>.</p>
	<p>Suppose you know that</p>
	<p>NAME1 VERBED1 NAME2</p>
	<p>How likely do you think it is that</p>
	<p>NAME1 VERBED2 NAME2?</p>
	</center> '}}],

except the very last thing doesn't have a comma after it

and you need a right square bracket and a semicolon at the very end for unclear reasons

*/




	
	
	







