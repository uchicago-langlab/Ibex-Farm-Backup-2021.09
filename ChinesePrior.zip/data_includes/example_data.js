//this expt. is to find out for each item, given the two alternative meanings of the ambiguous string, how likely participants think that meaning is true. This is to find out the prior of that meaning. 
//the item script is modified from expt 6 (which corrected some errors in previous item list)
var shuffleSequence = seq("intro","setcounter","practice", "presep", sepWith("sep", rshuffle(startsWith("wh"), "f")), "exit");
var practiceItemTypes = ["practice"];

var progressBarText = "您的进度是"
var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
        ignoreFailure: true
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "请按此键继续。"
    }
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro00.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro0.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro4.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro5.html" }} ],
["setcounter", "__SetCounter__", { }],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

["sep", Separator, { }],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "下面您会做几个练习的例子。"],
                     
                          ["br",],
                          ["br",],
                          ["p", "请按空格键继续"],
                          ]}],
                             
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小宝的妈妈让他把碗里的胡萝卜吃完了才可以吃甜点。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(您下面会读到两种可能出现的情况，我们想知道您觉的哪种情况更有可能。)"],
                          ["p", "(如果您准备好了， 请按空格键)"],
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小宝很讨厌吃胡萝卜， 但他还是把大部分都吃了， 只剩了几块硬邦邦的。",
                                   "小宝很讨厌吃胡萝卜， 所以他宁愿不吃甜点也不要吃胡萝卜。"]}],
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "您知道怎么做了吗？"],
               
                          ["p", "请按空格键继续"],
                          ]}], 
                             
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "元旦汇演的时候丽莎的班上要排一个大合唱， 但学生人数不够。老师把能找来的学生都找来了， 也不管他们会不会唱歌。连小明都被拉进了合唱团。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(如果您准备好了， 请按空格键)"],
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小明在演出的时候唱得特别好，一鸣惊人。",
                                   "小明五音不全，不过合唱团人多，没被发现。"]}],
                                 
    
    
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "练习结束了。 您知道怎么做了吗？"],
                          ["p", "下面进入正式实验。有的情况可能比较复杂，请您仔细阅读。"],
                          ["br",],
                          ["p", "请按空格键继续"],
                          ]}], 
    
                                
    ["presep", Separator, { transfer: 2000, normalMessage: "请准备好， 我们要开始了。请等待。。。" }],

    
[ [ "wh-a", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["会议之后大会主席对外宣布了会议决定了联合国要对某些国家取消制裁， 也同时宣布了那些国家的名字。",
                                   "会议之后大会主席对外宣布了会议决定了联合国要对某些国家取消制裁， 但并没有同时宣布那些国家的名字。"]}],
                                   
[ [ "wh-b", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在联合国的一次特别会议上, 与会国家讨论了经济制裁的问题。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["会议之后大会主席对外宣布了会议决定了联合国要对某些国家取消制裁， 但并没有同时宣布那些国家的名字。",
                                   "会议决定了联合国要对某些国家取消制裁，但会议之后大会主席完全没有对外宣布这个消息。"]}],
                                   
[ [ "wh-a", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都了发言。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["会议之后王总记得财务部也有报告公司今年的财务状况，他也清楚得记得财务部报告的具体的盈利数额是多少。",
                                   "会议之后王总记得财务部也有报告公司今年的财务状况，但他就是想不起来财务部报告的具体的盈利数额是多少。"]}],
                                   
[ [ "wh-b", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王总参加了上周的年度总结会议， 很多部门的主管都作了发言。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["会议之后王总记得财务部也有报告公司今年的财务状况，但他就是想不起来财务部报告的具体的盈利数额是多少。",
                                   "财务部在会议上汇报了今年盈利和亏损的详细情况, 但会议之后王总不太记得财务部有作过这个报告。"]}],
                                   
[ [ "wh-a", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽代表她的研究团队作了一个报告。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["在她的报告里，艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的，她也同时宣布了这个城市的名字。",
                                   "在她的报告里，艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的，但目前她需要对这个城市的名字保密。"]}],
                                   
[ [ "wh-b", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在最近的一次考古界的学术会议上, 艾米丽代表她的研究团队作了一个报告。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["在她的报告里，艾米丽说她的团队找到了证据证实某一个有名的古城市其实是外星人建造的，但目前她需要对这个城市的名字保密。",
                                   "艾米丽的团队其实已经找到了证据证实某一个有名的古城市是外星人建造的，但她在自己的报告里完全隐瞒了这个发现。"]}],                           
    
[ [ "wh-a", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小王知道他的朋友们在背后八卦他去了哪些城市，他也猜的到朋友们都给出了什么样的答案。",
                                   "小王知道他的朋友们在背后八卦他去了哪些城市，不过他不太清楚朋友们都给出了什么样的答案。"]}],
                                   
[ [ "wh-b", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小王是个很神秘的人。 他到处旅行却从不把自己的行踪告诉给朋友们。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小王知道他的朋友们在背后八卦他去了哪些城市，不过他不太清楚朋友们都给出了什么样的答案。",
                                   "小王的朋友们在背后八卦小王去了哪些城市，但小王完全不知道朋友们在讨论关于他的八卦。"]}],
                                   

[ [ "wh-a", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["警方知道嫌疑人在酒后向女朋友丽莎透露过下一个抢劫目标, 他们也从丽莎那里得到了下个抢劫目标的具体时间和地点。",
                                   "警方知道嫌疑人在酒后向女朋友丽莎透露过下一个抢劫目标, 但他们不知道下个抢劫目标的具体时间和地点，因为丽莎拒绝告诉警方。"]}],
                                   
[ [ "wh-b", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警察局在调查最近的一系列银行抢劫案。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["警方知道嫌疑人在酒后向女朋友丽莎透露过下一个抢劫目标, 但他们不知道下个抢劫目标的具体时间和地点，因为丽莎拒绝告诉警方。",
                                   "嫌犯的女友丽莎很清楚嫌犯的下个抢劫目标是什么，但警方完全不知道丽莎有这方面的信息."]}],
                                                                      
[ [ "wh-a", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都忙得不可开交。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["这天约翰向大家公开了他已经告诉了董事会自己要辞去一个职务，他也坦诚地告诉了大家他要辞掉的是哪个职务。",
                                   "这天约翰向大家公开了他已经告诉了董事会自己要辞去一个职务，但具体是哪个职务他没有告诉大家。"]}],
                                   
[ [ "wh-b", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "约翰在公司里有好几个重要的职务, 每天都非常繁忙。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["这天约翰告诉大家他已经通知了董事会自己要辞去一个职务，但他没有向大家公开要辞去的到底是哪个职务。",
                                   "约翰已经通知了董事会自己要辞去一个职务，但他完全没有向大家公开这件事情。"]}],
                                   
[ [ "wh-a", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理."],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["马克预料到了老板很快会宣布他要给一个副经理升职，马克同时也估计到了到底哪个副经理会升职。",
                                   "马克预料到了老板很快会宣布他要给一个副经理升职，但他估计不出来到底哪个副经理会升职。"]}],
                                   
[ [ "wh-b", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "马克工作的部门有五个副经理."],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["马克预料到了老板很快会宣布他要给一个副经理升职，但他没有预料到到底哪个副经理会升职。",
                                   "老板宣布了他要给一个副经理升职，马克事前完全没预料到老板会打算给员工升职。"]}],
                                       
[ [ "wh-a", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["玛丽写信告诉父母说自己已经决定了想去的学校，她也明确告诉了父母到底是哪所学校。",
                                   "玛丽写信告诉父母说自己已经决定了想去的学校，但她没告诉父母到底是哪所学校。"]}],
                                   
[ [ "wh-b", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "高考报志愿的时候玛丽知道自己的父母不会同意自己去最想去的学校。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["玛丽写信告诉父母说自己已经决定了想去的学校，但她没告诉父母到底是哪所学校。",
                                   "玛丽已经决定了自己想去的学校，但她没有告诉父母自己已经做了决定。"]}],
                                      
[ [ "wh-a", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "大明星克鲁斯接受了记者的一次采访。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["克鲁斯告诉了记者他意识到了自己曾经做错了一些事，他也坦诚地告诉了记者到底是哪些事。",
                                   "克鲁斯告诉了记者他意识到了自己曾经做错了一些事，但他没有明确透露到底是哪些事。"]}],
                                   
[ [ "wh-b", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "大明星克鲁斯接受了记者的一次采访。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["克鲁斯告诉了记者他意识到了自己曾经做错了一些事，但他没有明确告诉记者到底是哪些事。",
                                   "尽管克鲁斯早就意识到了自己年轻时曾经做错了一些事，但他在采访中完全没有告诉记者自己对过去有所反省。"]}],
                                                                      
[ [ "wh-a", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩了一趟。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小张记得他的朋友告诉过他有一家中餐厅很好吃，他也清楚地记得朋友说的是哪一家餐厅。",
                                   "小张记得他的朋友告诉过他有一家中餐厅很好吃，但他想不起来到底是哪一家餐厅了。"]}],
                                   
[ [ "wh-b", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小张去芝加哥玩了一趟。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小张记得他的朋友告诉过他有一家中餐厅很好吃，但他忘记了到底是哪一家餐厅了。",
                                   "尽管小张的朋友告诉过他有一家中餐厅很好吃，但小张完全忘记了朋友有向他推荐过餐厅这件事。"]}],
                                       
[ [ "wh-a", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小李打听到了系主任已经内部决定了物理系要把工作给某个候选人，他也打听到了这个候选人到底是谁。",
                                   "小李打听到了系主任已经内部决定了物理系要把工作给某个候选人，但他打听不到这个候选人到底是谁。"]}],
                                   
[ [ "wh-b", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "小李最近申请了一份大学里物理系的教职工作。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["小李打听到了系主任已经内部决定了物理系要把工作给某个候选人，但他没打听这个候选人到底是谁。.",
                                   "系主任已经内部决定了物理系要把工作给某个候选人，但小李事先完全没打听到这个消息。"]}],
                                       
[ [ "wh-a", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件后召开了一个记者会。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["保罗向记者们公布了他已经查清楚了贪污犯挪用公款的所有事实和数据，他也同时公布了失踪公款的具体数额。.",
                                   "保罗向记者们公布了他已经查清楚了贪污犯挪用公款的所有事实和数据，但是他没有透露失踪公款的具体数额。"]}],
                                   
[ [ "wh-b", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "警官保罗在调查一桩银行贪污的案件后召开了一个记者会。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["保罗向记者们公布了他已经查清楚了贪污犯挪用公款的所有事实和数据，但是他没有透露失踪公款的具体数额。",
                                   "保罗其实已经查清楚了贪污犯挪用公款的所有事实和数据，但他没有向记者透露他已经调查清楚了情况。"]}],
                                   
[ [ "wh-a", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["玛丽记得老师详细解释过一份面粉要加多少糖，她也清楚记得老师说的面粉和糖的比例到底是多少。",
                                   "玛丽记得老师详细解释过一份面粉要加多少糖，但她忘记了老师说的面粉和糖的比例到底是多少。"]}],
                                   
[ [ "wh-b", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "玛丽在厨师学校学习。 昨天老师在课堂上教了一道很复杂的甜点。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["玛丽记得老师详细解释过一份面粉要加多少糖，但她忘记了老师说的面粉和糖的比例到底是多少。",
                                   "老师详细解释过一份面粉要加多少糖，但玛丽完全忘记了老师有解释过这件事。"]}],
                                                                      
[ [ "wh-a", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 他仔细作了调查核实。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["王教授告诉了学校他调查到了这个学生的确抄袭了一个作者，他也告诉了学校这个被抄袭的作者是谁。",
                                   "王教授告诉了学校他调查到了这个学生的确抄袭了一个作者，但他没有告诉学校这个被抄袭的作者是谁。"]}],
                                   
[ [ "wh-b", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授怀疑一个学生的论文涉及抄袭他人文章。 他仔细作了调查核实。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["王教授告诉了学校他调查到了这个学生的确抄袭了一个作者，但他没有告诉学校这个被抄袭的作者是谁。",
                                   "王教授调查到了这个被抄袭的作者是谁， 但他没告诉学校他已经有了调查结果这件事。"]}],
                                   
[ [ "wh-a", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行内部讨论决定只可以贷给他们一部分。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["公司被告知了银行已经有了决定他们能借给公司多少贷款，公司也被告知了具体数额。",
                                   "公司被告知了银行已经有了决定他们能借给公司多少贷款，但具体数额还没告诉公司。"]}],
                                   
[ [ "wh-b", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "茱莉的公司向银行申请了一大笔贷款。 银行内部讨论决定只可以贷给他们一部分。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["银行已经决定他们能借给公司多少贷款，但公司还没被告知银行已经有了决定这件事。",
                                   "公司被告知了银行已经有了决定他们能借给公司多少贷款，但公司还没被告知具体的贷款数额。"]}],
                                       
[ [ "wh-a", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。"],
                       
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["卡门的朋友知道她梦到了比赛的冠军属于哪一匹马，他们也知道卡门梦到的冠军马到底是哪一匹。",
                                   "卡门的朋友知道她梦到了比赛的冠军属于哪一匹马，但他们不知道卡门梦到的冠军马到底是哪一匹。"]}],
                                   
[ [ "wh-b", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "卡门和她的朋友都喜欢赌马。 这一天卡门梦到了在即将到来的比赛里有一匹马跑得最快, 赢了比赛。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["卡门的朋友知道她梦到了比赛的冠军属于哪一匹马，但他们不知道卡门梦到的冠军马到底是哪一匹。",
                                   "卡门梦到了比赛的冠军属于哪一匹马，但她的朋友们完全不知道她梦到了冠军马这件事。"]}],
        
    // 10 self-paced-reading filler sentences.
    //


[ [ "f", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "在期末考试之后张教授和他的助教苏珊一起批改完了考卷, 发现只有一个学生得了A。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["几天以后张教授在给教务处上报成绩的时候记不清那个得了A的学生的名字, 结果把成绩给报错了。学生们发现了这件事很生气。",
                                   "几天以后张教授在给教务处上报成绩的时候记不清那个得了A的学生的名字, 结果把成绩给报错了。但学生们对这件事一无所知。"]}], 
   
[ [ "f", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "公司最近业务很差。 卡洛斯猜测公司很快会让各个部门裁员。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["一周之后, 公司果然大裁员。大家都在观望下一轮裁员什么时候会到来，卡洛斯却猜测不会很快又有裁员。",
                                   "一周之后, 公司果然大裁员。大家都不相信下一轮裁员会很快发生，但卡洛斯却猜测很快又会有裁员。"]}], 

[ [ "f", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "克丽丝热衷于讨论政治。 最近美国和好几个国家有战争的可能性。"],
                       
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["克丽丝认为总统下周会宣布他要出兵哪个国家。她也很确定这个国家是哪个。",
                                   "克丽丝认为总统下周会宣布他要出兵哪个国家。但克丽丝并不确定这个国家是哪个。"]}], 
   
[ [ "f", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "期末考试之后, 历史老师在班上批评小明说他连秦朝的第一个皇帝是谁这么简单的题目都答错了。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "历史老师认为小明弄错了秦朝的第一个皇帝是谁。",
                              as: ["小明把题目看错了。",
                                   "小明完全没有复习功课。"]}],  
  

[ [ "f", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "哈里叫他的朋友来火车站接自己。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["但是他忘了告诉朋友他坐哪趟车了。 他不太确定他的朋友以为自己会什么时候到。",
                                   "哈里不记得朋友的电话号码是什么了, 幸好他告诉过朋友他坐哪趟车。"]}], 
    
    
[ [ "f", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "汤姆买彩票中了大奖! "],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["他告诉朋友们自己已经计划好了怎么用这笔钱, 但具体的计划他没有告诉大家。",
                                   "自己中了奖的事他连好朋友都没告诉。"]}], 

[ [ "f", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "总统大选快到了。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["尽管担心朋友之间政治立场不同，艾伦还是很早就告诉了朋友自己要投票给谁。 ",
                                   "艾伦告诉朋友们自己很早就决定了要投票给谁。 但他并没有透露具体的候选人, 因为担心朋友之间政治立场不同。"]}], 
   
[ [ "f", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "老王买了一栋很老的房子。 他在地下室找到一份陈旧的房屋图纸, 但这份图纸旧得字迹都模糊了。"],
                       
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["原先的屋主对每个房间都作了详细的规划。",
                                   "原先的屋主没有对每个房间作详细的规划."]}], 

  
[ [ "f", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "王教授让小李送一本书给另一个老师。 但是小李忘记王教授说的这个老师的名字了。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["他在教学楼里转来转去, 怎么也没想起来， 也没把书送到地方。",
                                   "他在教学楼里转来转去, 虽然怎么也没想起来， 但误打误撞还是最后把书送到了。"]}], 
 


[ [ "f", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "今年的电影节有三部影片入围最佳电影奖。 小张听说评委会已经在周一开会决定了最后的获奖名单。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "以下的哪种情况更有可能发生？",
                              as: ["具体的名单在颁奖典礼之前对外界完全保密，小张没有打听到任何消息。",
                                   "具体的名单在颁奖典礼之前完全没有对外界保密，颁奖礼之前新闻就出来了。"]}],  
];
