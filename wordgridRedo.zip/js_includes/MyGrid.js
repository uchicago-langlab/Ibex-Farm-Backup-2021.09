define_ibex_controller({
    name: "MyGrid",
    jqueryWidget: {
        _init: function () {
           // this.options.transfer = null; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [2],
                children: [           
                            "Question2",  this.options,
                            "Question",  this.options,
                            "Form",  {html: '请根据这个场景造一个句子。您造的句子需要包括以上这四个词，还需要符合场景描述的内容: <input type="text" name="sentence" size = "150" class = "obligatory">'},      
                ]
            });
        }
    },
    properties: {obligatory: ["as","as2"]}
});