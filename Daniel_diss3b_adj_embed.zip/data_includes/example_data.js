var shuffleSequence = seq("setcounter", "intro", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))), "payment");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "Question", {
        randomOrder: false,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var items = [

      // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
      // sequence to send results before the experiment has finished. This is NOT intended to allow
      // for incremental sending of results -- you should send results exactly once per experiment.
      // However, it does permit additional messages to be displayed to participants once the
      // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
      // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
      // otherwise, results are automatically sent at the end of the experiment.
      //
      //["sr", "__SendResults__", { }],

      ["sep", "Separator", { }],
       
      ["intro", "Form", {consentRequired: true, html: {include: "consent.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
      ["payment", "Form", {consentRequired: false, html: {include: "exit.html" }} ],
      //["practiceover", "Message", {html: ["div", ["p", "This is the end of the practice."],["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."]  ,continueMessage:"Click here to continue."}],

      ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
      ],continueMessage:"Click here to continue."}],


  

      // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
      // for latin square designs will be updated. (Previously, this was always updated upon completion
      // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
      // point in your running order. If given no options, the counter is incremented by one. If given
      // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
      // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
      //

      ["setcounter", "__SetCounter__", { }],

      // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
      // consent checkbox).

      //
      // 2 practice items for self-paced reading ( with a comprehension question).
      //

      ["practice", "DashedSentence", {s: ["The cat","and","the dog","that","belong to","the woman","ran","away."]},
                        "Question", {q: "Do the cat and the dog belong to the man?", as: ["yes","no"], hasCorrect: 1}],
      ["practice", "DashedSentence", {s: ["The fact","that","Leland","hates","frogs","concerned","his parents."]},
                        "Question", {q: "Does Leland hate frogs?", as: ["yes","no"], hasCorrect: 0}],

      //
      // 32 "real" (i.e. non-filler) self-paced reading items with corresponding comprehension questions
      // There are four conditions.
      //

      [["e.subj.comp",1], "DashedSentence",{s:["Those","federal","prison","wardens","who","John","thinks","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who John thinks reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",1], "DashedSentence",{s:["Those","wardens","who","John","thinks","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those wardens who John thinks reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",1], "DashedSentence",{s:["Those","federal","prison","wardens","who","John","thinks","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who John thinks reprimanded Andy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",1], "DashedSentence",{s:["Those","wardens","who","John","thinks","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those wardens who John thinks reprimanded Andy?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",2], "DashedSentence",{s:["Those","condemned","political","prisoners","who","Caroline","says","accidentally","angered","Amy","yesterday","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who Caroline says angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",2], "DashedSentence",{s:["Those","prisoners","who","Caroline","says","accidentally","angered","Amy","yesterday","escaped","the compound."]}, "Question",{q: "Was it those prisoners who Caroline says angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",2], "DashedSentence",{s:["Those","condemned","political","prisoners","who","Caroline","says","Amy","accidentally","angered","yesterday","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who Caroline says angered Amy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",2], "DashedSentence",{s:["Those","prisoners","who","Caroline","says","Amy","accidentally","angered","yesterday","escaped","the compound."]}, "Question",{q: "Was it those prisoners who Caroline says angered Amy?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",3], "DashedSentence",{s:["Those","experienced","stage","choreographers","who","Tim","believes","warmly","encouraged","Ben","last night","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who Tim believes encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",3], "DashedSentence",{s:["Those","choreographers","who","Tim","believes","warmly","encouraged","Ben","last night","created","the routine."]}, "Question",{q: "Was it those choreographers who Tim believes encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",3], "DashedSentence",{s:["Those","experienced","stage","choreographers","who","Tim","believes","Ben","warmly","encouraged","last night","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who Tim believes encouraged Ben?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",3], "DashedSentence",{s:["Those","choreographers","who","Tim","believes","Ben","warmly","encouraged","last night","created","the routine."]}, "Question",{q: "Was it those choreographers who Tim believes encouraged Ben?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",4], "DashedSentence",{s:["Those","sleazy","car","salespeople","who","Jude","claims","deviously","tricked","Luke","this morning","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who Jude claims tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",4], "DashedSentence",{s:["Those","salespeople","who","Jude","claims","deviously","tricked","Luke","this morning","left","the company."]}, "Question",{q: "Was it those salespeople who Jude claims tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",4], "DashedSentence",{s:["Those","sleazy","car","salespeople","who","Jude","claims","Luke","deviously","tricked","this morning","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who Jude claims tricked Luke?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",4], "DashedSentence",{s:["Those","salespeople","who","Jude","claims","Luke","deviously","tricked","this morning","left","the company."]}, "Question",{q: "Was it those salespeople who Jude claims tricked Luke?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",5], "DashedSentence",{s:["Those","graceful","ballet","dancers","who","George","says","wholeheartedly","praised","Kevin","this afternoon","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who George says praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",5], "DashedSentence",{s:["Those","dancers","who","George","says","wholeheartedly","praised","Kevin","this afternoon","won","the competition."]}, "Question",{q: "Was it those dancers who George says praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",5], "DashedSentence",{s:["Those","graceful","ballet","dancers","who","George","says","Kevin","wholeheartedly","praised","this afternoon","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who George says praised Kevin?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",5], "DashedSentence",{s:["Those","dancers","who","George","says","Kevin","wholeheartedly","praised","this afternoon","won","the competition."]}, "Question",{q: "Was it those dancers who George says praised Kevin?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",6], "DashedSentence",{s:["Those","wounded","American","soldiers","who","Sarah","believes","graciously","commended","Leah","this evening","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who Sarah believes commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",6], "DashedSentence",{s:["Those","soldiers","who","Sarah","believes","graciously","commended","Leah","this evening","organized","the march."]}, "Question",{q: "Was it those soldiers who Sarah believes commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",6], "DashedSentence",{s:["Those","wounded","American","soldiers","who","Sarah","believes","Leah","graciously","commended","this evening","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who Sarah believes commended Leah?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",6], "DashedSentence",{s:["Those","soldiers","who","Sarah","believes","Leah","graciously","commended","this evening","organized","the march."]}, "Question",{q: "Was it those soldiers who Sarah believes commended Leah?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians","who","Ali","claims","thoroughly","entertained","Jack","tonight","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who Ali claims entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",7], "DashedSentence",{s:["Those","comedians","who","Ali","claims","thoroughly","entertained","Jack","tonight","sold","the tickets."]}, "Question",{q: "Was it those comedians who Ali claims entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians","who","Ali","claims","Jack","thoroughly","entertained","tonight","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who Ali claims entertained Jack?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",7], "DashedSentence",{s:["Those","comedians","who","Ali","claims","Jack","thoroughly","entertained","tonight","sold","the tickets."]}, "Question",{q: "Was it those comedians who Ali claims entertained Jack?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",8], "DashedSentence",{s:["Those","emotional","crash","survivors","who","Jennifer","thinks","dutifully","assisted","Sophia","last week","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who Jennifer thinks assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",8], "DashedSentence",{s:["Those","survivors","who","Jennifer","thinks","dutifully","assisted","Sophia","last week","joined","the meeting."]}, "Question",{q: "Was it those survivors who Jennifer thinks assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",8], "DashedSentence",{s:["Those","emotional","crash","survivors","who","Jennifer","thinks","Sophia","dutifully","assisted","last week","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who Jennifer thinks assisted Sophia?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",8], "DashedSentence",{s:["Those","survivors","who","Jennifer","thinks","Sophia","dutifully","assisted","last week","joined","the meeting."]}, "Question",{q: "Was it those survivors who Jennifer thinks assisted Sophia?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks","who","Nico","believes","loyally","aided","Matthew","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",9], "DashedSentence",{s:["Those","monks","who","Nico","believes","loyally","aided","Matthew","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks","who","Nico","believes","Matthew","loyally","aided","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",9], "DashedSentence",{s:["Those","monks","who","Nico","believes","Matthew","loyally","aided","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those monks?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",10], "DashedSentence",{s:["Those","conservative","US","senators","who","Jerry","claims","carefully","interrogated","Tom","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who Jerry claims was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",10], "DashedSentence",{s:["Those","senators","who","Jerry","claims","carefully","interrogated","Tom","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who Jerry claims was interrogated by those senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",10], "DashedSentence",{s:["Those","conservative","US","senators","who","Jerry","claims","Tom","carefully","interrogated","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who Jerry claims was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",10], "DashedSentence",{s:["Those","senators","who","Jerry","claims","Tom","carefully","interrogated","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who Jerry claims was interrogated by those senators?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",11], "DashedSentence",{s:["Those","victorious","four-star","generals","who","Ruth","thinks","profusely","thanked","Stephanie","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who Ruth thinks was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",11], "DashedSentence",{s:["Those","generals","who","Ruth","thinks","profusely","thanked","Stephanie","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who Ruth thinks was thanked by those generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",11], "DashedSentence",{s:["Those","victorious","four-star","generals","who","Ruth","thinks","Stephanie","profusely","thanked","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who Ruth thinks was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",11], "DashedSentence",{s:["Those","generals","who","Ruth","thinks","Stephanie","profusely","thanked","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who Ruth thinks was thanked by those generals?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",12], "DashedSentence",{s:["Those","struggling","rock","musicians","who","Hallie","says","reluctantly","helped","Becky","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who Hallie says was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",12], "DashedSentence",{s:["Those","musicians","who","Hallie","says","reluctantly","helped","Becky","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who Hallie says was helped by those musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",12], "DashedSentence",{s:["Those","struggling","rock","musicians","who","Hallie","says","Becky","reluctantly","helped","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who Hallie says was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",12], "DashedSentence",{s:["Those","musicians","who","Hallie","says","Becky","reluctantly","helped","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who Hallie says was helped by those musicians?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices","who","Jane","claims","vehemently","accused","Ellen","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who Jane claims was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",13], "DashedSentence",{s:["Those","accomplices","who","Jane","claims","vehemently","accused","Ellen","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who Jane claims was accused by those accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices","who","Jane","claims","Ellen","vehemently","accused","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who Jane claims was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",13], "DashedSentence",{s:["Those","accomplices","who","Jane","claims","Ellen","vehemently","accused","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who Jane claims was accused by those accomplices?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",14], "DashedSentence",{s:["Those","undercover","federal","agents","who","Elsa","thinks","secretly","confronted","Anna","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who Elsa thinks was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",14], "DashedSentence",{s:["Those","agents","who","Elsa","thinks","secretly","confronted","Anna","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who Elsa thinks was confronted by those agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",14], "DashedSentence",{s:["Those","undercover","federal","agents","who","Elsa","thinks","Anna","secretly","confronted","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who Elsa thinks was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",14], "DashedSentence",{s:["Those","agents","who","Elsa","thinks","Anna","secretly","confronted","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who Elsa thinks was confronted by those agents?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",15], "DashedSentence",{s:["Those","celebrity","hair","stylists","who","Barack","says","hesitantly","hired","Teddy","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who Barack says was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",15], "DashedSentence",{s:["Those","stylists","who","Barack","says","hesitantly","hired","Teddy","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who Barack says was hired by those stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",15], "DashedSentence",{s:["Those","celebrity","hair","stylists","who","Barack","says","Teddy","hesitantly","hired","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who Barack says was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",15], "DashedSentence",{s:["Those","stylists","who","Barack","says","Teddy","hesitantly","hired","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who Barack says was hired by those stylists?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",16], "DashedSentence",{s:["Those","renowned","fashion","designers","who","Kennedy","believes","snidely","belittled","Alex","today","designed","the costume."]}, "Question",{q: "Was it Alex who Kennedy believes was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",16], "DashedSentence",{s:["Those","designers","who","Kennedy","believes","snidely","belittled","Alex","today","designed","the costume."]}, "Question",{q: "Was it Alex who Kennedy believes was belittled by those designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",16], "DashedSentence",{s:["Those","renowned","fashion","designers","who","Kennedy","believes","Alex","snidely","belittled","today","designed","the costume."]}, "Question",{q: "Was it Alex who Kennedy believes was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",16], "DashedSentence",{s:["Those","designers","who","Kennedy","believes","Alex","snidely","belittled","today","designed","the costume."]}, "Question",{q: "Was it Alex who Kennedy believes was belittled by those designers?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp",17], "DashedSentence",{s:["Those","senior","electrical","engineers","who","Mark","thinks","affectionately","mentored","Zack","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who Mark thinks mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",17], "DashedSentence",{s:["Those","engineers","who","Mark","thinks","affectionately","mentored","Zack","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who Mark thinks mentored those engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",17], "DashedSentence",{s:["Those","senior","electrical","engineers","who","Mark","thinks","Zack","affectionately","mentored","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who Mark thinks mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",17], "DashedSentence",{s:["Those","engineers","who","Mark","thinks","Zack","affectionately","mentored","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who Mark thinks mentored those engineers?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",18], "DashedSentence",{s:["Those","famous","young","actors","who","Zoey","says","caringly","guided","Madeline","last night","read","the script."]}, "Question",{q: "Was it Madeline who Zoey says guided those famous young actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",18], "DashedSentence",{s:["Those","actors","who","Zoey","says","caringly","guided","Madeline","last night","read","the script."]}, "Question",{q: "Was it Madeline who Zoey says guided those actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",18], "DashedSentence",{s:["Those","famous","young","actors","who","Zoey","says","Madeline","caringly","guided","last night","read","the script."]}, "Question",{q: "Was it Madeline who Zoey says guided those famous young actors?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",18], "DashedSentence",{s:["Those","actors","who","Zoey","says","Madeline","caringly","guided","last night","read","the script."]}, "Question",{q: "Was it Madeline who Zoey says guided those actors?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters","who","Michelle","believes","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",19], "DashedSentence",{s:["Those","reporters","who","Michelle","believes","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters","who","Michelle","believes","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",19], "DashedSentence",{s:["Those","reporters","who","Michelle","believes","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those reporters?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities","who","Elisa","claims","continuously","questioned","Fiona","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",20], "DashedSentence",{s:["Those","celebrities","who","Elisa","claims","continuously","questioned","Fiona","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities","who","Elisa","claims","Fiona","continuously","questioned","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",20], "DashedSentence",{s:["Those","celebrities","who","Elisa","claims","Fiona","continuously","questioned","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those celebrities?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",21], "DashedSentence",{s:["Those","corrupt","homicide","cops","who","Bilbo","says","aggressively","accosted","Ivan","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who Bilbo says accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",21], "DashedSentence",{s:["Those","cops","who","Bilbo","says","aggressively","accosted","Ivan","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who Bilbo says accosted those cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",21], "DashedSentence",{s:["Those","corrupt","homicide","cops","who","Bilbo","says","Ivan","aggressively","accosted","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who Bilbo says accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",21], "DashedSentence",{s:["Those","cops","who","Bilbo","says","Ivan","aggressively","accosted","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who Bilbo says accosted those cops?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",22], "DashedSentence",{s:["Those","ruthless","military","dictators","who","Ewan","believes","intentionally","ignored","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",22], "DashedSentence",{s:["Those","dictators","who","Ewan","believes","intentionally","ignored","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes ignored those dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",22], "DashedSentence",{s:["Those","ruthless","military","dictators","who","Ewan","believes","Isaac","intentionally","ignored","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",22], "DashedSentence",{s:["Those","dictators","who","Ewan","believes","Isaac","intentionally","ignored","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes ignored those dictators?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",23], "DashedSentence",{s:["Those","hardworking","factory","employees","who","Jackie","claims","brutally","berated","Alma","last week","finished","the project."]}, "Question",{q: "Was it Alma who Jackie claims berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",23], "DashedSentence",{s:["Those","employees","who","Jackie","claims","brutally","berated","Alma","last week","finished","the project."]}, "Question",{q: "Was it Alma who Jackie claims berated those employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",23], "DashedSentence",{s:["Those","hardworking","factory","employees","who","Jackie","claims","Alma","brutally","berated","last week","finished","the project."]}, "Question",{q: "Was it Alma who Jackie claims berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",23], "DashedSentence",{s:["Those","employees","who","Jackie","claims","Alma","brutally","berated","last week","finished","the project."]}, "Question",{q: "Was it Alma who Jackie claims berated those employees?", as :["yes","no"], hasCorrect: 0}],
      
      [["e.subj.comp",24], "DashedSentence",{s:["Those","cable","news","analysts","who","Corey","thinks","purposely","neglected","Ian","on Monday","published","the article."]}, "Question",{q: "Was it Ian who Corey thinks neglected those cable news analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",24], "DashedSentence",{s:["Those","analysts","who","Corey","thinks","purposely","neglected","Ian","on Monday","published","the article."]}, "Question",{q: "Was it Ian who Corey thinks neglected those analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",24], "DashedSentence",{s:["Those","cable","news","analysts","who","Corey","thinks","Ian","purposely","neglected","on Monday","published","the article."]}, "Question",{q: "Was it Ian who Corey thinks neglected those cable news analysts?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",24], "DashedSentence",{s:["Those","analysts","who","Corey","thinks","Ian","purposely","neglected","on Monday","published","the article."]}, "Question",{q: "Was it Ian who Corey thinks neglected those analysts?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates","who","Savannah","believes","cordially","welcomed","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who Savannah believes were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",25], "DashedSentence",{s:["Those","candidates","who","Savannah","believes","cordially","welcomed","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those candidates who Savannah believes were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates","who","Savannah","believes","Rosie","cordially","welcomed","on Tuesday","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who Savannah believes were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",25], "DashedSentence",{s:["Those","candidates","who","Savannah","believes","Rosie","cordially","welcomed","on Tuesday","threw","the party."]}, "Question",{q: "Was it those candidates who Savannah believes were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",26], "DashedSentence",{s:["Those","rich","European","tourists","who","Catherine","claims","blindly","followed","Isabella","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who Catherine claims were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",26], "DashedSentence",{s:["Those","tourists","who","Catherine","claims","blindly","followed","Isabella","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those tourists who Catherine claims were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",26], "DashedSentence",{s:["Those","rich","European","tourists","who","Catherine","claims","Isabella","blindly","followed","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who Catherine claims were followed by Isabella?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",26], "DashedSentence",{s:["Those","tourists","who","Catherine","claims","Isabella","blindly","followed","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those tourists who Catherine claims were followed by Isabella?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",27], "DashedSentence",{s:["Those","powerful","business","executives","who","Britta","thinks","diligently","instructed","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who Britta thinks were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",27], "DashedSentence",{s:["Those","executives","who","Britta","thinks","diligently","instructed","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those executives who Britta thinks were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",27], "DashedSentence",{s:["Those","powerful","business","executives","who","Britta","thinks","Jessica","diligently","instructed","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who Britta thinks were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",27], "DashedSentence",{s:["Those","executives","who","Britta","thinks","Jessica","diligently","instructed","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those executives who Britta thinks were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",28], "DashedSentence",{s:["Those","influential","legal","advisors","who","Annie","says","meticulously","counseled","Tess","on Friday","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who Annie says were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",28], "DashedSentence",{s:["Those","advisors","who","Annie","says","meticulously","counseled","Tess","on Friday","donated","the fund."]}, "Question",{q: "Was it those advisors who Annie says were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",28], "DashedSentence",{s:["Those","influential","legal","advisors","who","Annie","says","Tess","meticulously","counseled","on Friday","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who Annie says were counseled by Tess?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",28], "DashedSentence",{s:["Those","advisors","who","Annie","says","Tess","meticulously","counseled","on Friday","donated","the fund."]}, "Question",{q: "Was it those advisors who Annie says were counseled by Tess?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",29], "DashedSentence",{s:["Those","angry","taxi","drivers","who","Zane","claims","viciously","attacked","Keith","on Saturday","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who Zane claims were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",29], "DashedSentence",{s:["Those","drivers","who","Zane","claims","viciously","attacked","Keith","on Saturday","fled","the scene."]}, "Question",{q: "Was it those drivers who Zane claims were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",29], "DashedSentence",{s:["Those","angry","taxi","drivers","who","Zane","claims","Keith","viciously","attacked","on Saturday","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who Zane claims were attacked by Keith?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",29], "DashedSentence",{s:["Those","drivers","who","Zane","claims","Keith","viciously","attacked","on Saturday","fled","the scene."]}, "Question",{q: "Was it those drivers who Zane claims were attacked by Keith?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",30], "DashedSentence",{s:["Those","helpful","new","assistants","who","Troy","thinks","calmly","ushered","Simon","on Sunday","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who Troy thinks were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",30], "DashedSentence",{s:["Those","assistants","who","Troy","thinks","calmly","ushered","Simon","on Sunday","decorated","the office."]}, "Question",{q: "Was it those assistants who Troy thinks were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",30], "DashedSentence",{s:["Those","helpful","new","assistants","who","Troy","thinks","Simon","calmly","ushered","on Sunday","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who Troy thinks were ushered by Simon?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",30], "DashedSentence",{s:["Those","assistants","who","Troy","thinks","Simon","calmly","ushered","on Sunday","decorated","the office."]}, "Question",{q: "Was it those assistants who Troy thinks were ushered by Simon?", as :["yes","no"], hasCorrect: 0}],
      
      [["e.subj.comp",31], "DashedSentence",{s:["Those","dying","elderly","patients","who","Maria","says","lovingly","comforted","Elena","today","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who Maria says were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",31], "DashedSentence",{s:["Those","patients","who","Maria","says","lovingly","comforted","Elena","today","received","the vaccine."]}, "Question",{q: "Was it those patients who Maria says were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",31], "DashedSentence",{s:["Those","dying","elderly","patients","who","Maria","says","Elena","lovingly","comforted","today","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who Maria says were comforted by Elena?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",31], "DashedSentence",{s:["Those","patients","who","Maria","says","Elena","lovingly","comforted","today","received","the vaccine."]}, "Question",{q: "Was it those patients who Maria says were comforted by Elena?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp",32], "DashedSentence",{s:["Those","trained","hospice","nurses","who","Laura","believes","painstakingly","watched","Aliza","yesterday","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who Laura believes were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",32], "DashedSentence",{s:["Those","nurses","who","Laura","believes","painstakingly","watched","Aliza","yesterday","reached","the hospital."]}, "Question",{q: "Was it those nurses who Laura believes were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",32], "DashedSentence",{s:["Those","trained","hospice","nurses","who","Laura","believes","Aliza","painstakingly","watched","yesterday","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who Laura believes were watched by Aliza?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",32], "DashedSentence",{s:["Those","nurses","who","Laura","believes","Aliza","painstakingly","watched","yesterday","reached","the hospital."]}, "Question",{q: "Was it those nurses who Laura believes were watched by Aliza?", as :["yes","no"], hasCorrect: 0}],
     
      //
      // 32 self-paced-reading filler sentences with question.
      //

      ["filler.A.1", "DashedSentence",{s:["It was","those consumers","who","Connor","thinks","begrudgingly","contacted","Jack","last night."]}, "Question",{q: "Was it those consumers who Connor thinks contacted Jack?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.2", "DashedSentence",{s:["It was","those landlords","who","Frankie","says","generously","paid","Ariana","this morning."]}, "Question",{q: "Was it Ariana who Frankie says was paid by those landlords?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.3", "DashedSentence",{s:["It was","those builders","who","Chad","believes","contentedly","contracted","Grant","this afternoon."]}, "Question",{q: "Was it Grant who Chad believes contracted those builders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.4", "DashedSentence",{s:["It was","those administrators","who","Serena","claims","devotedly","obeyed","Anne","this evening."]}, "Question",{q: "Was it those administrators who Serena claims were obeyed by Anne?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.5", "DashedSentence",{s:["It was","those marathoners","who","Venus","says","Juliette","excessively","trained","tonight."]}, "Question",{q: "Was it those marathoners who Venus says trained Juliette?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.6", "DashedSentence",{s:["It was","those shareholders","who","Jeff","believes","William","steadfastly","trusted","last week."]}, "Question",{q: "Was it William who Jeff believes was trusted by those shareholders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.7", "DashedSentence",{s:["It was","those archaeologists","who","Grace","claims","Abby","eagerly","protested","on Monday."]}, "Question",{q: "Was it Abby who Grace claims protested those archaeologists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.8", "DashedSentence",{s:["It was","those ministers","who","Ava","thinks","Katie","constantly","distracted","on Tuesday."]}, "Question",{q: "Was it those ministers who Ava thinks were distracted by Katie?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.B.1", "DashedSentence",{s:["Carlos","believes","that","the fact","that","those writers","beautifully","described","Sergio","this afternoon","was","unprecedented."]}, "Question",{q: "Was it those writers who described Sergio?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.2", "DashedSentence",{s:["Joe","claims","that","the fact","that","those publishers","positively","endorsed","Thomas","this evening","was","rare."]}, "Question",{q: "Was it Thomas who was endorsed by those publishers?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.3", "DashedSentence",{s:["Diego","thinks","that","the fact","that","those chemists","arbitrarily","selected","Luis","tonight","was","unusual."]}, "Question",{q: "Was it Luis who selected those chemists?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.4", "DashedSentence",{s:["Larry","says","that","the fact","that","those planners","carelessly","mocked","Lynn","last week","was","normal."]}, "Question",{q: "Was it those planners who were mocked by Lynn?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.5", "DashedSentence",{s:["Derrick","claims","that","the fact","that","Jacob","negatively","rated","those recruiters","on Monday","was","surprising."]}, "Question",{q: "Was it those recruiters who rated Jacob?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.6", "DashedSentence",{s:["Frank","thinks","that","the fact","that","Terry","surreptitiously","observed","those investigators","on Tuesday","was","astonishing."]}, "Question",{q: "Was it Terry who was observed by those investigators?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.7", "DashedSentence",{s:["Charlotte","says","that","the fact","that","Kacey","attentively","shadowed","those clinicians","on Wednesday","was","impressive."]}, "Question",{q: "Was it Kacey who shadowed those clinicians?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.8", "DashedSentence",{s:["Evelyn","believes","that","the fact","that","Blythe","confidently","taught","those artisans","on Thursday","was","bizarre."]}, "Question",{q: "Was it those artisans who were taught by Blythe?", as:["yes","no"], hasCorrect: 0}],
      ["filler.C.1", "DashedSentence",{s:["It was","mind-boggling","that","those florists","nervously","notified","Nick","on Saturday."]}, "Question",{q: "Was it those florists who notified Nick?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.2", "DashedSentence",{s:["It was","uncanny","that","those orthodontists","unconditionally","forgave","Bennet","on Sunday."]}, "Question",{q: "Was it Bennet who was forgiven by those orthodontists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.3", "DashedSentence",{s:["It was","acceptable","that","those midwives","fearfully","alerted","Bill","today."]}, "Question",{q: "Was it Bill who alerted those midwives?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.4", "DashedSentence",{s:["It was","unacceptable","that","those marines","fiercely","assaulted","Lucas","yesterday."]}, "Question",{q: "Was it those marines who were assaulted by Lucas?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.5", "DashedSentence",{s:["It was","abnormal","that","Sadie","unethically","misinformed","those entrepreneurs","last night."]}, "Question",{q: "Was it those entrepreneurs who misinformed Sadie?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.6", "DashedSentence",{s:["It was","unbelievable","that","Xavier","unconsciously","misled","those captains","this morning."]}, "Question",{q: "Was it Xavier who was misled by those captains?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.7", "DashedSentence",{s:["It was","incredible","that","Chad","foolishly","indulged","those cooks","this afternoon."]}, "Question",{q: "Was it Chad who indulged those cooks?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.8", "DashedSentence",{s:["It was","mind-blowing","that","Leland","severely","underpaid","those pedicurists","this evening."]}, "Question",{q: "Was it those pedicurists who were underpaid by Leland?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.1", "DashedSentence",{s:["The newspaper","confirmed","that","those senators","mistakenly","exposed","Tabitha","last week."]}, "Question",{q: "Was it those senators who exposed Tabitha?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.2", "DashedSentence",{s:["The article","acknowledged","that","those treasurers","incorrectly","chastised","Preston","on Monday."]}, "Question",{q: "Was it Preston who was chastised by those treasurers?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.3", "DashedSentence",{s:["The show","explained","that","those chancellors","publicly","honored","Sienna","on Tuesday."]}, "Question",{q: "Was it Sienna who honored those chancellors?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.4", "DashedSentence",{s:["The book","demonstrated","that","those landscapers","overtly","defended","Justin","on Wednesday."]}, "Question",{q: "Was it those landscapers who were defended by Justin?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.5", "DashedSentence",{s:["The journal","established","that","Selena","sincerely","complimented","those superintendents","on Thursday."]}, "Question",{q: "Was it those superintendents who complimented Selena?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.6", "DashedSentence",{s:["The evidence","proved","that","Taylor","maliciously","antagonized","those cobblers","on Friday."]}, "Question",{q: "Was it Taylor who was antagonized by those cobblers?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.7", "DashedSentence",{s:["The company","recognized","that","Ethan","arrogantly","corrected","those interpreters","on Saturday."]}, "Question",{q: "Was it Ethan who corrected those interpreters?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.8", "DashedSentence",{s:["The documentary","revealed","that","Olivia","loudly","lauded","those barbers","on Sunday."]}, "Question",{q: "Was it those barbers who were lauded by Olivia?", as:["yes","no"], hasCorrect: 0}]


];
