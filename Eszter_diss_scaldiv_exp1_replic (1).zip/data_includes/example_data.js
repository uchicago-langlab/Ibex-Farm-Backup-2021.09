define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("v"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a sentence, and decide whether you can conclude something from that sentence."] 
],continueMessage:"Click here to start the experiment."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 
["practice", "MyController", {html: "<p>Mary: <i>The wrestler is strong.</i></p><p> Would you conclude from this that, according to Mary, the wrestler is not weak?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Mary: <i>The spy memorized the plan.</i></p><p> Would you conclude from this that, according to Mary, the spy did not discover the plan?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Mary: <i>The student is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//Experimental items
 
//["e1", "Question",       {q: "Mary: This student is intelligent. Would you conclude from this that, according to John, she is not brilliant?", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1",1], "MyController",       {html: "<p>Mary: <i>The food is adequate.</i></p><p> Would you conclude from this that, according to Mary, the food is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",1], "MyController",       {html: "<p>Mary: <i>The salary is adequate.</i></p><p> Would you conclude from this that, according to Mary, the salary is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",1], "MyController",       {html: "<p>Mary: <i>The solution is adequate.</i></p><p> Would you conclude from this that, according to Mary, the solution is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",2], "MyController",       {html: "<p>Mary: <i>Talking is allowed.</i></p><p> Would you conclude from this that, according to Mary, talking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",2], "MyController",       {html: "<p>Mary: <i>Drinking is allowed.</i></p><p> Would you conclude from this that, according to Mary, drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",2], "MyController",       {html: "<p>Mary: <i>Copying is allowed.</i></p><p> Would you conclude from this that, according to Mary, copying is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",3], "MyController",       {html: "<p>Mary: <i>The nurse is attractive.</i></p><p> Would you conclude from this that, according to Mary, the nurse is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",3], "MyController",       {html: "<p>Mary: <i>The model is attractive.</i></p><p> Would you conclude from this that, according to Mary, the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",3], "MyController",       {html: "<p>Mary: <i>The singer is attractive.</i></p><p> Would you conclude from this that, according to Mary, the singer is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",4], "MyController",       {html: "<p>Mary: <i>The student believes it will work out.</i></p><p> Would you conclude from this that, according to Mary, the student doesn't know it will work out?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",4], "MyController",       {html: "<p>Mary: <i>The mother believes it will happen.</i></p><p> Would you conclude from this that, according to Mary, the mother doesn't know it will happen?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",4], "MyController",       {html: "<p>Mary: <i>The teacher believes it is true.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",5], "MyController",       {html: "<p>Mary: <i>The elephant is big.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",5], "MyController",       {html: "<p>Mary: <i>The house is big.</i></p><p> Would you conclude from this that, according to Mary, the house is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",5], "MyController",       {html: "<p>Mary: <i>The tree is big.</i></p><p> Would you conclude from this that, according to Mary, the tree is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",6], "MyController",       {html: "<p>Mary: <i>The water is cheap.</i></p><p> Would you conclude from this that, according to Mary, the water is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",6], "MyController",       {html: "<p>Mary: <i>The electricity is cheap.</i></p><p> Would you conclude from this that, according to Mary, the electricity is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",6], "MyController",       {html: "<p>Mary: <i>The food is cheap.</i></p><p> Would you conclude from this that, according to Mary, the food is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",7], "MyController",       {html: "<p>Mary: <i>The child is content.</i></p><p> Would you conclude from this that, according to Mary, the child is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",7], "MyController",       {html: "<p>Mary: <i>The homemaker is content.</i></p><p> Would you conclude from this that, according to Mary, the homemaker is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",7], "MyController",       {html: "<p>Mary: <i>The musician is content.</i></p><p> Would you conclude from this that, according to Mary, the musician is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",8], "MyController",       {html: "<p>Mary: <i>The air is cool.</i></p><p> Would you conclude from this that, according to Mary, the air is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",8], "MyController",       {html: "<p>Mary: <i>The weather is cool.</i></p><p> Would you conclude from this that, according to Mary, the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",8], "MyController",       {html: "<p>Mary: <i>The room is cool.</i></p><p> Would you conclude from this that, according to Mary, the room is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",9], "MyController",       {html: "<p>Mary: <i>The fabric is dark.</i></p><p> Would you conclude from this that, according to Mary, the fabric is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",9], "MyController",       {html: "<p>Mary: <i>The sky is dark.</i></p><p> Would you conclude from this that, according to Mary, the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",9], "MyController",       {html: "<p>Mary: <i>The shirt is dark.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",10], "MyController",       {html: "<p>Mary: <i>The task is difficult.</i></p><p> Would you conclude from this that, according to Mary, the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",10], "MyController",       {html: "<p>Mary: <i>The journey is difficult.</i></p><p> Would you conclude from this that, according to Mary, the journey is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",10], "MyController",       {html: "<p>Mary: <i>The problem is difficult.</i></p><p> Would you conclude from this that, according to Mary, the problem is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",11], "MyController",       {html: "<p>Mary: <i>The boy dislikes broccoli.</i></p><p> Would you conclude from this that, according to Mary, the boy doesn't loathe broccoli?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",11], "MyController",       {html: "<p>Mary: <i>The teacher dislikes fighting.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't loathe fighting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",11], "MyController",       {html: "<p>Mary: <i>The doctor dislikes coffee.</i></p><p> Would you conclude from this that, according to Mary, the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",12], "MyController",       {html: "<p>Mary: <i>The biologist saw few of the birds.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the biologist saw none of the birds?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",12], "MyController",       {html: "<p>Mary: <i>The cop saw few of the children.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the cop saw none of the children?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",12], "MyController",       {html: "<p>Mary: <i>The observer saw few of the stars.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the observer saw none of the stars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",13], "MyController", {html: "<p>Mary: <i>The joke is funny.</i></p><p> Would you conclude from this that, according to Mary, the joke is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",13], "MyController", {html: "<p>Mary: <i>The play is funny.</i></p><p> Would you conclude from this that, according to Mary, the play is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",13], "MyController", {html: "<p>Mary: <i>The movie is funny.</i></p><p> Would you conclude from this that, according to Mary, the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",14], "MyController", {html: "<p>Mary: <i>The food is good.</i></p><p> Would you conclude from this that, according to Mary, the food is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",14], "MyController", {html: "<p>Mary: <i>The movie is good.</i></p><p> Would you conclude from this that, according to Mary, the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",14], "MyController", {html: "<p>Mary: <i>The sandwich is good.</i></p><p> Would you conclude from this that, according to Mary, the sandwich is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",15], "MyController", {html: "<p>Mary: <i>The layout is good.</i></p><p> Would you conclude from this that, according to Mary, the layout is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",15], "MyController", {html: "<p>Mary: <i>The solution is good.</i></p><p> Would you conclude from this that, according to Mary, the solution is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",15], "MyController", {html: "<p>Mary: <i>The answer is good.</i></p><p> Would you conclude from this that, according to Mary, the answer is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",16], "MyController", {html: "<p>Mary: <i>The problem is hard.</i></p><p> Would you conclude from this that, according to Mary, the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",16], "MyController", {html: "<p>Mary: <i>The issue is hard.</i></p><p> Would you conclude from this that, according to Mary, the issue is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",16], "MyController", {html: "<p>Mary: <i>The puzzle is hard.</i></p><p> Would you conclude from this that, according to Mary, the puzzle is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",17], "MyController", {html: "<p>Mary: <i>The boy is hungry.</i></p><p> Would you conclude from this that, according to Mary, the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",17], "MyController", {html: "<p>Mary: <i>The dog is hungry.</i></p><p> Would you conclude from this that, according to Mary, the dog is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",17], "MyController", {html: "<p>Mary: <i>The elephant is hungry.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",18], "MyController", {html: "<p>Mary: <i>The dress is special.</i></p><p> Would you conclude from this that, according to Mary, the dress is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",18], "MyController", {html: "<p>Mary: <i>The painting is special.</i></p><p> Would you conclude from this that, according to Mary, the painting is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",18], "MyController", {html: "<p>Mary: <i>The necklace is special.</i></p><p> Would you conclude from this that, according to Mary, the necklace is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",19], "MyController", {html: "<p>Mary: <i>The assistant is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",19], "MyController", {html: "<p>Mary: <i>The professor is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the professor is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",19], "MyController", {html: "<p>Mary: <i>The student is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",20], "MyController", {html: "<p>Mary: <i>The princess likes dancing.</i></p><p> Would you conclude from this that, according to Mary, the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",20], "MyController", {html: "<p>Mary: <i>The actress likes the movie.</i></p><p> Would you conclude from this that, according to Mary, the actress doesn't love the movie?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",20], "MyController", {html: "<p>Mary: <i>The manager likes spaghetti.</i></p><p> Would you conclude from this that, according to Mary, the manager doesn't love spaghetti?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",21], "MyController", {html: "<p>Mary: <i>The energy is low.</i></p><p> Would you conclude from this that, according to Mary, the energy is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",21], "MyController", {html: "<p>Mary: <i>The battery is low.</i></p><p> Would you conclude from this that, according to Mary, the battery is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",21], "MyController", {html: "<p>Mary: <i>The gas is low.</i></p><p> Would you conclude from this that, according to Mary, the gas is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",22], "MyController", {html: "<p>Mary: <i>The child may eat an apple.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the child has to eat an apple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",22], "MyController", {html: "<p>Mary: <i>The boy may watch television.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the boy has to watch television?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",22], "MyController", {html: "<p>Mary: <i>The dog may sleep on the bed.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the dog has to sleep on the bed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",23], "MyController", {html: "<p>Mary: <i>The lawyer may appear in person.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the lawyer will appear in person?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",23], "MyController", {html: "<p>Mary: <i>The teacher may come.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the teacher will come?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",23], "MyController", {html: "<p>Mary: <i>The student may pass.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the student will pass?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",24], "MyController", {html: "<p>Mary: <i>The party was memorable.</i></p><p> Would you conclude from this that, according to Mary, the party was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",24], "MyController", {html: "<p>Mary: <i>The view was memorable.</i></p><p> Would you conclude from this that, according to Mary, the view was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",24], "MyController", {html: "<p>Mary: <i>The movie was memorable.</i></p><p> Would you conclude from this that, according to Mary, the movie was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",25], "MyController", {html: "<p>Mary: <i>The house is old.</i></p><p> Would you conclude from this that, according to Mary, the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",25], "MyController", {html: "<p>Mary: <i>The mirror is old.</i></p><p> Would you conclude from this that, according to Mary, the mirror is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",25], "MyController", {html: "<p>Mary: <i>The table is old.</i></p><p> Would you conclude from this that, according to Mary, the table is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",26], "MyController", {html: "<p>Mary: <i>The food is palatable.</i></p><p> Would you conclude from this that, according to Mary, the food is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",26], "MyController", {html: "<p>Mary: <i>The wine is palatable.</i></p><p> Would you conclude from this that, according to Mary, the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",26], "MyController", {html: "<p>Mary: <i>The dessert is palatable.</i></p><p> Would you conclude from this that, according to Mary, the dessert is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",27], "MyController", {html: "<p>Mary: <i>The freshman participated.</i></p><p> Would you conclude from this that, according to Mary, the freshman did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",27], "MyController", {html: "<p>Mary: <i>The runner participated.</i></p><p> Would you conclude from this that, according to Mary, the runner did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",27], "MyController", {html: "<p>Mary: <i>The skier participated.</i></p><p> Would you conclude from this that, according to Mary, the skier did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",28], "MyController", {html: "<p>Mary: <i>Happiness is possible.</i></p><p> Would you conclude from this that, according to Mary, happiness is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",28], "MyController", {html: "<p>Mary: <i>Failing is possible.</i></p><p> Would you conclude from this that, according to Mary, failing is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",28], "MyController", {html: "<p>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that, according to Mary, success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",29], "MyController", {html: "<p>Mary: <i>The model is pretty.</i></p><p> Would you conclude from this that, according to Mary, the model is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",29], "MyController", {html: "<p>Mary: <i>The lady is pretty.</i></p><p> Would you conclude from this that, according to Mary, the lady is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",29], "MyController", {html: "<p>Mary: <i>The girl is pretty.</i></p><p> Would you conclude from this that, according to Mary, the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",30], "MyController", {html: "<p>Mary: <i>This plant is rare.</i></p><p> Would you conclude from this that, according to Mary, this plant is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",30], "MyController", {html: "<p>Mary: <i>This bird is rare.</i></p><p> Would you conclude from this that, according to Mary, this bird is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",30], "MyController", {html: "<p>Mary: <i>This fish is rare.</i></p><p> Would you conclude from this that, according to Mary, this fish is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",31], "MyController", {html: "<p>Mary: <i>This recording is scarce.</i></p><p> Would you conclude from this that, according to Mary, this recording is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",31], "MyController", {html: "<p>Mary: <i>This resource is scarce.</i></p><p> Would you conclude from this that, according to Mary, this resource is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",31], "MyController", {html: "<p>Mary: <i>This mineral is scarce.</i></p><p> Would you conclude from this that, according to Mary, this mineral is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",32], "MyController", {html: "<p>Mary: <i>The song is silly.</i></p><p> Would you conclude from this that, according to Mary, the song is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",32], "MyController", {html: "<p>Mary: <i>The joke is silly.</i></p><p> Would you conclude from this that, according to Mary, the joke is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",32], "MyController", {html: "<p>Mary: <i>The question is silly.</i></p><p> Would you conclude from this that, according to Mary, the question is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",33], "MyController", {html: "<p>Mary: <i>The room is small.</i></p><p> Would you conclude from this that, according to Mary, the room is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",33], "MyController", {html: "<p>Mary: <i>The car is small.</i></p><p> Would you conclude from this that, according to Mary, the car is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",33], "MyController", {html: "<p>Mary: <i>The fish is small.</i></p><p> Would you conclude from this that, according to Mary, the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",34], "MyController", {html: "<p>Mary: <i>The shirt is snug.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",34], "MyController", {html: "<p>Mary: <i>The dress is snug.</i></p><p> Would you conclude from this that, according to Mary, the dress is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",34], "MyController", {html: "<p>Mary: <i>The glove is snug.</i></p><p> Would you conclude from this that, according to Mary, the glove is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",35], "MyController", {html: "<p>Mary: <i>The bartender saw some of the cars.</i></p><p> Would you conclude from this that, according to Mary, the bartender did not see all of the cars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",35], "MyController", {html: "<p>Mary: <i>The nurse saw some of the signs.</i></p><p> Would you conclude from this that, according to Mary, the nurse did not see all of the signs?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",35], "MyController", {html: "<p>Mary: <i>The mathematician saw some of the issues.</i></p><p> Would you conclude from this that, according to Mary, the mathematician did not see all of the issues?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",36], "MyController", {html: "<p>Mary: <i>The assistant is sometimes angry.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not always angry?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",36], "MyController", {html: "<p>Mary: <i>The director is sometimes late.</i></p><p> Would you conclude from this that, according to Mary, the director is not always late?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",36], "MyController", {html: "<p>Mary: <i>The doctor is sometimes irritable.</i></p><p> Would you conclude from this that, according to Mary, the doctor is not always irritable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",37], "MyController", {html: "<p>Mary: <i>The athlete started.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",37], "MyController", {html: "<p>Mary: <i>The dancer started.</i></p><p> Would you conclude from this that, according to Mary, the dancer did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",37], "MyController", {html: "<p>Mary: <i>The runner started.</i></p><p> Would you conclude from this that, according to Mary, the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",38], "MyController", {html: "<p>Mary: <i>The quarterback is tired.</i></p><p> Would you conclude from this that, according to Mary, the quarterback is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",38], "MyController", {html: "<p>Mary: <i>The runner is tired.</i></p><p> Would you conclude from this that, according to Mary, the runner is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",38], "MyController", {html: "<p>Mary: <i>The worker is tired.</i></p><p> Would you conclude from this that, according to Mary, the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",39], "MyController", {html: "<p>Mary: <i>The candidate tried.</i></p><p> Would you conclude from this that, according to Mary, the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",39], "MyController", {html: "<p>Mary: <i>The athlete tried.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",39], "MyController", {html: "<p>Mary: <i>The scientist tried.</i></p><p> Would you conclude from this that, according to Mary, the scientist did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",40], "MyController", {html: "<p>Mary: <i>The wallpaper is ugly.</i></p><p> Would you conclude from this that, according to Mary, the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",40], "MyController", {html: "<p>Mary: <i>The sweater is ugly.</i></p><p> Would you conclude from this that, according to Mary, the sweater is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",40], "MyController", {html: "<p>Mary: <i>The painting is ugly.</i></p><p> Would you conclude from this that, according to Mary, the painting is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",41], "MyController", {html: "<p>Mary: <i>The movie is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the movie is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",41], "MyController", {html: "<p>Mary: <i>The picture is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the picture is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",41], "MyController", {html: "<p>Mary: <i>The news is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the news is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",42], "MyController", {html: "<p>Mary: <i>The weather is warm.</i></p><p> Would you conclude from this that, according to Mary, the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",42], "MyController", {html: "<p>Mary: <i>The sand is warm.</i></p><p> Would you conclude from this that, according to Mary, the sand is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",42], "MyController", {html: "<p>Mary: <i>The soup is warm.</i></p><p> Would you conclude from this that, according to Mary, the soup is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1",43], "MyController", {html: "<p>Mary: <i>The dog is wary.</i></p><p> Would you conclude from this that, according to Mary, the dog is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3",43], "MyController", {html: "<p>Mary: <i>The victim is wary.</i></p><p> Would you conclude from this that, according to Mary, the victim is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2",43], "MyController", {html: "<p>Mary: <i>The rabbit is wary.</i></p><p> Would you conclude from this that, according to Mary, the rabbit is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],


//Filler items
["filler1", "MyController", {html: "<p>Mary: <i>The table is clean.</i></p><p> Would you conclude from this that, according to Mary, the table is not dirty?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler2", "MyController", {html: "<p>Mary: <i>The soldier is dangerous.</i></p><p> Would you conclude from this that, according to Mary, the soldier is not harmless?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler3", "MyController", {html: "<p>Mary: <i>The man is drunk.</i></p><p> Would you conclude from this that, according to Mary, the man is not sober?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler4", "MyController", {html: "<p>Mary: <i>The neighbor is sleepy.</i></p><p> Would you conclude from this that, according to Mary, the neighbor is not rich?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler5", "MyController", {html: "<p>Mary: <i>The gymnast is tall.</i></p><p> Would you conclude from this that, according to Mary, the gymnast is not single?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler6", "MyController", {html: "<p>Mary: <i>The doll is ugly.</i></p><p> Would you conclude from this that, according to Mary, the doll is not old?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler7", "MyController", {html: "<p>Mary: <i>The street is wide.</i></p><p> Would you conclude from this that, according to Mary, the street is not narrow?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}]// NOTE NO COMMA

];
