var shuffleSequence = seq("intro","setcounter","practice", "presep", sepWith("sep", rshuffle(startsWith("VMM"),startsWith("EP"),"f")), "exit");
var practiceItemTypes = ["practice"];

//var progressBarText = "Your current progress"
//var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
    },
    
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "How acceptable is this sentence? Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
   
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var aj = "AcceptabilityJudgment";
var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],


["setcounter", "__SetCounter__", { }],


["sep", Separator, { }],
   ["practice", aj, {s: "This is just a practice sentence to get you used to the method of presentation."}],
 
    ["practice", aj, {s: "The cleaning lady working in the bathroom cursed himself for forgetting his wrench."}],
    
    ["practice", aj, {s: "The pop star sang herself hoarse at the concert last night."}],
 
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The practice session is over now. You will start the experiment now. Pleae press the spacebar to continue"],
                          ]}],
    
   
    ["presep", Separator, { transfer: 2000, normalMessage: "Please get ready. We will start. Please wait..." }],


[["VMM_a",1], aj, {s: "Rick didn't label the jar. Tim didn't either."}],
[["VMM_b",1], aj, {s: "Rick didn't label the jar. The bowl wasnt either."}],
[["VMM_c",1], aj, {s: "The jar wasn't labeled by Rick. The bowl wasnt either."}],
[["VMM_d",1], aj, {s: "The jar wasn't labeled by Rick. Tim didn't either."}],    
[["VMM_e",1], aj, {s: "The jar didn't lure Rick. The bowl didn't either."}],
[["VMM_f",1], aj, {s: "The jar didn't lure Rick. Tim wasnt either."}],
[["VMM_g",1], aj, {s: "Rick wasn't lured by the jar. Tim wasnt either."}],   
[["VMM_h",1], aj, {s: "Rick wasn't lured by the jar. The bowl didn't either."}],
    
[["VMM_a",2], aj, {s: "Joanna didn't complete the puzzle. Madeleine didn't either."}],
[["VMM_b",2], aj, {s: "Joanna didn't completed the puzzle. The crossword wasnt either."}],
[["VMM_c",2], aj, {s: "The puzzle wasn't completed by Joanna. The crossword wasnt either."}],
[["VMM_d",2], aj, {s: "The puzzle wasn't completed by Joanna. Madeleine didn't either."}],    
[["VMM_e",2], aj, {s: "The puzzle didn't amuse Joanna. The crossword didn't either."}],
[["VMM_f",2], aj, {s: "The puzzle didn't amuse Joanna. Madeleine wasnt either."}],
[["VMM_g",2], aj, {s: "Joanna wasn't amused by the puzzle. Madeleine wasnt either."}],   
[["VMM_h",2], aj, {s: "Joanna wasn't amused by the puzzle. the crossword didn't either."}],
    
[["VMM_a",3], aj, {s: "Katie didn't alter the plan. Carissa didn't either."}],
[["VMM_b",3], aj, {s: "Katie didn't alter the plan. The directions weren't either."}],
[["VMM_c",3], aj, {s: "The plan wasn't altered by Katie. The directions weren't either."}],
[["VMM_d",3], aj, {s: "The plan wasn't altered by Katie. Carissa didn't either."}],    
[["VMM_e",3], aj, {s: "The plan didn't delight Katie. The directions didn't either."}],
[["VMM_f",3], aj, {s: "The plan didn't delight Katie. Carissa wasnt either."}],
[["VMM_g",3], aj, {s: "Katie wasn't delighted by the plan. Carissa wasnt either."}],   
[["VMM_h",3], aj, {s: "Katie wasn't delighted by the plan. The directions didn't either."}],
  
    
[["VMM_a",4], aj, {s: "Julia didn't finish the ritual. Audrey didn't either."}],
[["VMM_b",4], aj, {s: "Julia didn't finish the ritual. The ceremony wasnt either."}],
[["VMM_c",4], aj, {s: "The ritual wasn't finished by Julia. The ceremony wasnt either."}],
[["VMM_d",4], aj, {s: "The ritual wasn't finished by Julia. Audrey didn't either."}],    
[["VMM_e",4], aj, {s: "The ritual didn't bore Julia. The ceremony didn't either."}],
[["VMM_f",4], aj, {s: "The ritual didn't bore Julia. Audrey wasnt either."}],
[["VMM_g",4], aj, {s: "Julia wasn't bored by the ritual. Audrey wasnt either."}],   
[["VMM_h",4], aj, {s: "Julia wasn't bored by the ritual. The ceremony didn't either."}],
 
[["VMM_a",5], aj, {s: "Maya didn't mute the song. Kristen didn't either."}],
[["VMM_b",5], aj, {s: "Maya didn't mute the song. The static wasnt either."}],
[["VMM_c",5], aj, {s: "The song wasn't muted by Maya. The static wasnt either."}],
[["VMM_d",5], aj, {s: "The song wasn't muted by Maya. Kristen didn't either."}],    
[["VMM_e",5], aj, {s: "The song didn't annoy Maya. The static didn't either."}],
[["VMM_f",5], aj, {s: "The song didn't annoy Maya. Kristen wasnt either."}],
[["VMM_g",5], aj, {s: "Maya wasn't annoyed by the song. Kristen wasnt either."}],   
[["VMM_h",5], aj, {s: "Maya wasn't annoyed by the song. The static didn't either."}],
 
[["VMM_a",6], aj, {s: "Alana didn't evade the cliff. Evelyn didn't either."}],
[["VMM_b",6], aj, {s: "Alana didn't evade the cliff. The gorge wasnt either."}],
[["VMM_c",6], aj, {s: "The cliff wasn't evaded by Alana. The gorge wasnt either."}],
[["VMM_d",6], aj, {s: "The cliff wasn't evaded by Alana. Evelyn didn't either."}],    
[["VMM_e",6], aj, {s: "The cliff didn't impress Alana. The gorge didn't either."}],
[["VMM_f",6], aj, {s: "The cliff didn't impress Alana. Evelyn wasnt either."}],
[["VMM_g",6], aj, {s: "Alana wasn't impressed by the cliff. Evelyn wasnt either."}],   
[["VMM_h",6], aj, {s: "Alana wasn't impressed by the cliff. The gorge didn't either."}],
 
[["VMM_a",7], aj, {s: "Mia didn't escort the parade. Olivia didn't either."}],
[["VMM_b",7], aj, {s: "Mia didn't escort the parade. The procession wasnt either."}],
[["VMM_c",7], aj, {s: "The parade wasn't escorted by Mia. The procession wasnt either."}],
[["VMM_d",7], aj, {s: "The parade wasn't escorted by Mia. Olivia didn't either."}],    
[["VMM_e",7], aj, {s: "The parade didn't frustrate Mia. The procession didn't either."}],
[["VMM_f",7], aj, {s: "The parade didn't frustrate Mia. Olivia wasnt either."}],
[["VMM_g",7], aj, {s: "Mia wasn't frustrated by the parade. Olivia wasnt either."}],   
[["VMM_h",7], aj, {s: "Mia wasn't frustrated by the parade. The procession didn't either."}],
 
[["VMM_a",8], aj, {s: "Sarah didn't heed the warning. Abbie didn't either."}],
[["VMM_b",8], aj, {s: "Sarah didn't heed the warning. The omen wasnt either."}],
[["VMM_c",8], aj, {s: "The warning wasn't heeded by Sarah. The omen wasnt either."}],
[["VMM_d",8], aj, {s: "The warning wasn't heeded by Sarah. Abbie didn't either."}],    
[["VMM_e",8], aj, {s: "The warning didn't disturb Sarah. The omen didn't either."}],
[["VMM_f",8], aj, {s: "The warning didn't disturb Sarah. Abbie wasnt either."}],
[["VMM_g",8], aj, {s: "Sarah wasn't disturbed by the warning. Abbie wasnt either."}],   
[["VMM_h",8], aj, {s: "Sarah wasn't disturbed by the warning. The omen didn't either."}],
 
[["VMM_a",9], aj, {s: "Marina didn't reject the compliment. Kayla didn't either."}],
[["VMM_b",9], aj, {s: "Marina didn't reject the compliment. The suggestion wasnt either."}],
[["VMM_c",9], aj, {s: "The compliment wasn't rejected by Marina. The suggestion wasnt either."}],
[["VMM_d",9], aj, {s: "The compliment wasn't rejected by Marina. Kayla didn't either."}],    
[["VMM_e",9], aj, {s: "The compliment didn't excite Marina. The suggestion didn't either."}],
[["VMM_f",9], aj, {s: "The compliment didn't excite Marina. Kayla wasnt either."}],
[["VMM_g",9], aj, {s: "Marina wasn't excited by the compliment. Kayla wasnt either."}],   
[["VMM_h",9], aj, {s: "Marina wasn't excited by the compliment. The suggestion didn't either."}],
 
[["VMM_a",10], aj, {s: "Hannah didn't weighe the necklace. Emily didn't either."}],
[["VMM_b",10], aj, {s: "Hannah didn't weighe the necklace. The talisman wasnt either."}],
[["VMM_c",10], aj, {s: "The necklace wasn't weighed by Hannah. The talisman wasnt either."}],
[["VMM_d",10], aj, {s: "The necklace wasn't weighed by Hannah. Emily didn't either."}],    
[["VMM_e",10], aj, {s: "The necklace didn't soothe Hannah. The talisman didn't either."}],
[["VMM_f",10], aj, {s: "The necklace didn't soothe Hannah. Emily wasnt either."}],
[["VMM_g",10], aj, {s: "Hannah wasn't soothed by the necklace. Emily wasnt either."}],   
[["VMM_h",10], aj, {s: "Hannah wasn't soothed by the necklace. The talisman didn't either."}],
 
[["VMM_a",11], aj, {s: "Jack didn't write the advertisement. David didn't either."}],
[["VMM_b",11], aj, {s: "Jack didn't write the advertisement. The quote wasnt either."}],
[["VMM_c",11], aj, {s: "The advertisement wasn't written by Jack. The quote wasnt either."}],
[["VMM_d",11], aj, {s: "The advertisement wasn't written by Jack. David didn't either."}],    
[["VMM_e",11], aj, {s: "The advertisement didn't anger Jack. The quote didn't either."}],
[["VMM_f",11], aj, {s: "The advertisement didn't anger Jack. David wasnt either."}],
[["VMM_g",11], aj, {s: "Jack wasn't angered by the advertisement. David wasnt either."}],   
[["VMM_h",11], aj, {s: "Jack wasn't angered by the advertisement. The quote didn't either."}],
 
[["VMM_a",12], aj, {s: "Camille didn't build the pyramid. Sophia didn't either."}],
[["VMM_b",12], aj, {s: "Camille didn't build the pyramid. The monument wasnt either."}],
[["VMM_c",12], aj, {s: "The pyramid wasn't built by Camille. The monument wasnt either."}],
[["VMM_d",12], aj, {s: "The pyramid wasn't built by Camille. Sophia didn't either."}],    
[["VMM_e",12], aj, {s: "The pyramid didn't awe Camille. The monument didn't either."}],
[["VMM_f",12], aj, {s: "The pyramid didn't awe Camille. Sophia wasnt either."}],
[["VMM_g",12], aj, {s: "Camille wasn't awed by the pyramid. Sophia wasnt either."}],   
[["VMM_h",12], aj, {s: "Camille wasn't awed by the pyramid. The monument didn't either."}],
 
[["VMM_a",13], aj, {s: "Cristina didn't record the criticism. Michelle didn't either."}],
[["VMM_b",13], aj, {s: "Cristina didn't record the criticism. The question wasnt either."}],
[["VMM_c",13], aj, {s: "The criticism wasn't recorded by Cristina. The question wasnt either."}],
[["VMM_d",13], aj, {s: "The criticism wasn't recorded by Cristina. Michelle didn't either."}],    
[["VMM_e",13], aj, {s: "The criticism didn't disappoint Cristina. The question didn't either."}],
[["VMM_f",13], aj, {s: "The criticism didn't disappoint Cristina. Michelle wasnt either."}],
[["VMM_g",13], aj, {s: "Cristina wasn't disappointed by the criticism. Michelle wasnt either."}],   
[["VMM_h",13], aj, {s: "Cristina wasn't disappointed by the criticism. The question didn't either."}],
 
[["VMM_a",14], aj, {s: "Cindy didn't embrace the doll. Deirdre didn't either."}],
[["VMM_b",14], aj, {s: "Cindy didn't embrace the doll. The dress wasnt either."}],
[["VMM_c",14], aj, {s: "The doll wasn't embraced by Cindy. The dress wasnt either."}],
[["VMM_d",14], aj, {s: "The doll wasn't embraced by Cindy. Deirdre didn't either."}],    
[["VMM_e",14], aj, {s: "The doll didn't interest Cindy. The dress didn't either."}],
[["VMM_f",14], aj, {s: "The doll didn't interest Cindy. Deirdre wasnt either."}],
[["VMM_g",14], aj, {s: "Cindy wasn't interested by the doll. Deirdre wasnt either."}],   
[["VMM_h",14], aj, {s: "Cindy wasn't interested by the doll. The dress didn't either."}],
 
[["VMM_a",15], aj, {s: "Nikki didn't edit the article. Margaret didn't either."}],
[["VMM_b",15], aj, {s: "Nikki didn't edit the article. The headline wasnt either."}],
[["VMM_c",15], aj, {s: "The article wasn't edited by Nikki. The headline wasnt either."}],
[["VMM_d",15], aj, {s: "The article wasn't edited by Nikki. Margaret didn't either."}],    
[["VMM_e",15], aj, {s: "The article didn't alarm Nikki. The headline didn't either."}],
[["VMM_f",15], aj, {s: "The article didn't alarm Nikki. Margaret wasnt either."}],
[["VMM_g",15], aj, {s: "Nikki wasn't alarmed by the article. Margaret wasnt either."}],   
[["VMM_h",15], aj, {s: "Nikki wasn't alarmed by the article. The headline didn't either."}],
 
[["VMM_a",16], aj, {s: "Rebecca didn't release the announcement. Emma didn't either."}],
[["VMM_b",16], aj, {s: "Rebecca didn't release the announcement. The result wasnt either."}],
[["VMM_c",16], aj, {s: "The announcement wasn't released by Rebecca. The result wasnt either."}],
[["VMM_d",16], aj, {s: "The announcement wasn't released by Rebecca. Emma didn't either."}],    
[["VMM_e",16], aj, {s: "The announcement didn't bother Rebecca. The result didn't either."}],
[["VMM_f",16], aj, {s: "The announcement didn't bother Rebecca. Emma wasnt either."}],
[["VMM_g",16], aj, {s: "Rebecca wasn't bothered by the announcement. Emma wasnt either."}],   
[["VMM_h",16], aj, {s: "Rebecca wasn't bothered by the announcement. The result didn't either."}],
 
[["VMM_a",17], aj, {s: "Isabel didn't controll the plane. Helen didn't either."}],
[["VMM_b",17], aj, {s: "Isabel didn't controll the plane. The robot wasnt either."}],
[["VMM_c",17], aj, {s: "The plane wasn't controlled by Isabel. The robot wasnt either."}],
[["VMM_d",17], aj, {s: "The plane wasn't controlled by Isabel. Helen didn't either."}],    
[["VMM_e",17], aj, {s: "The plane didn't amaze Isabel. The robot didn't either."}],
[["VMM_f",17], aj, {s: "The plane didn't amaze Isabel. Helen wasnt either."}],
[["VMM_g",17], aj, {s: "Isabel wasn't amazed by the plane. Helen wasnt either."}],   
[["VMM_h",17], aj, {s: "Isabel wasn't amazed by the plane. The robot didn't either."}],
 
[["VMM_a",18], aj, {s: "Lisa didn't scratch the label. Claudette didn't either."}],
[["VMM_b",18], aj, {s: "Lisa didn't scratch the label. The sign wasnt either."}],
[["VMM_c",18], aj, {s: "The label wasn't scratched by Lisa. The sign wasnt either."}],
[["VMM_d",18], aj, {s: "The label wasn't scratched by Lisa. Claudette didn't either."}],    
[["VMM_e",18], aj, {s: "The label didn't tempt Lisa. The sign didn't either."}],
[["VMM_f",18], aj, {s: "The label didn't tempt Lisa. Claudette wasnt either."}],
[["VMM_g",18], aj, {s: "Lisa wasn't tempted by the label. Claudette wasnt either."}],   
[["VMM_h",18], aj, {s: "Lisa wasn't tempted by the label. The sign didn't either."}],
 
[["VMM_a",19], aj, {s: "Brian didn't reproduce the experiment. Roger didn't either."}],
[["VMM_b",19], aj, {s: "Brian didn't reproduce the experiment. The tests weren't either."}],
[["VMM_c",19], aj, {s: "The experiment wasn't reproduced by Brian. The tests weren't either."}],
[["VMM_d",19], aj, {s: "The experiment wasn't reproduced by Brian. Roger didn't either."}],    
[["VMM_e",19], aj, {s: "The experiment didn't convince Brian. The tests didn't either."}],
[["VMM_f",19], aj, {s: "The experiment didn't convince Brian. Roger wasnt either."}],
[["VMM_g",19], aj, {s: "Brian wasn't convinced by the experiment. Roger wasnt either."}],   
[["VMM_h",19], aj, {s: "Brian wasn't convinced by the experiment. The tests didn't either."}],
 
[["VMM_a",20], aj, {s: "Louis didn't neglect the castle. John didn't either."}],
[["VMM_b",20], aj, {s: "Louis didn't neglect the castle. The house wasnt either."}],
[["VMM_c",20], aj, {s: "The castle wasn't neglected by Louis. The house wasnt either."}],
[["VMM_d",20], aj, {s: "The castle wasn't neglected by Louis. John didn't either."}],    
[["VMM_e",20], aj, {s: "The castle didn't astound Louis. The house didn't either."}],
[["VMM_f",20], aj, {s: "The castle didn't astound Louis. John wasnt either."}],
[["VMM_g",20], aj, {s: "Louis wasn't astounded by the castle. John wasnt either."}],   
[["VMM_h",20], aj, {s: "Louis wasn't astounded by the castle. The house didn't either."}],
 
[["VMM_a",21], aj, {s: "Mark didn't denounce the story. Tommy didn't either."}],
[["VMM_b",21], aj, {s: "Mark didn't denounce the story. The sermon wasnt either."}],
[["VMM_c",21], aj, {s: "The story wasn't denounced by Mark. The sermon wasnt either."}],
[["VMM_d",21], aj, {s: "The story wasn't denounced by Mark. Tommy didn't either."}],    
[["VMM_e",21], aj, {s: "The story didn't provoke Mark. The sermon didn't either."}],
[["VMM_f",21], aj, {s: "The story didn't provoke Mark. Tommy wasnt either."}],
[["VMM_g",21], aj, {s: "Mark wasn't provoked by the story. Tommy wasnt either."}],   
[["VMM_h",21], aj, {s: "Mark wasn't provoked by the story. The sermon didn't either."}],
 
[["VMM_a",22], aj, {s: "Jeremy didn't authorize the interview. Phillip didn't either."}],
[["VMM_b",22], aj, {s: "Jeremy didn't authorize the interview. The broadcast wasnt either."}],
[["VMM_c",22], aj, {s: "The interview wasn't authorized by Jeremy. The broadcast wasnt either."}],
[["VMM_d",22], aj, {s: "The interview wasn't authorized by Jeremy. Phillip didn't either."}],    
[["VMM_e",22], aj, {s: "The interview didn't embarrass Jeremy. The broadcast didn't either."}],
[["VMM_f",22], aj, {s: "The interview didn't embarrass Jeremy. Phillip wasnt either."}],
[["VMM_g",22], aj, {s: "Jeremy wasn't embarrassed by the interview. Phillip wasnt either."}],   
[["VMM_h",22], aj, {s: "Jeremy wasn't embarrassed by the interview. The broadcast didn't either."}],
 
[["VMM_a",23], aj, {s: "Liam didn't tape the fight. Mason didn't either."}],
[["VMM_b",23], aj, {s: "Liam didn't tape the fight. The argument wasnt either."}],
[["VMM_c",23], aj, {s: "The fight wasn't taped by Liam. The argument wasnt either."}],
[["VMM_d",23], aj, {s: "The fight wasn't taped by Liam. Mason didn't either."}],    
[["VMM_e",23], aj, {s: "The fight didn't frighten Liam. The argument didn't either."}],
[["VMM_f",23], aj, {s: "The fight didn't frighten Liam. Mason wasnt either."}],
[["VMM_g",23], aj, {s: "Liam wasn't frightened by the fight. Mason wasnt either."}],   
[["VMM_h",23], aj, {s: "Liam wasn't frightened by the fight. The argument didn't either."}],
 
[["VMM_a",24], aj, {s: "Isaac didn't lose the script. Theodore didn't either."}],
[["VMM_b",24], aj, {s: "Isaac didn't lose the script. The letter wasnt either."}],
[["VMM_c",24], aj, {s: "The script wasn't lost by Isaac. The letter wasnt either."}],
[["VMM_d",24], aj, {s: "The script wasn't lost by Isaac. Theodore didn't either."}],    
[["VMM_e",24], aj, {s: "The script didn't demoralize Isaac. The letter didn't either."}],
[["VMM_f",24], aj, {s: "The script didn't demoralize Isaac. Theodore wasnt either."}],
[["VMM_g",24], aj, {s: "Isaac wasn't demoralized by the script. Theodore wasnt either."}],   
[["VMM_h",24], aj, {s: "Isaac wasn't demoralized by the script. The letter didn't either."}],
 
[["VMM_a",25], aj, {s: "Jackson didn't remove the dust. Scott didn't either."}],
[["VMM_b",25], aj, {s: "Jackson didn't remove the dust. The mold wasnt either."}],
[["VMM_c",25], aj, {s: "The dust wasn't removed by Jackson. The mold wasnt either."}],
[["VMM_d",25], aj, {s: "The dust wasn't removed by Jackson. Scott didn't either."}],    
[["VMM_e",25], aj, {s: "The dust didn't shock Jackson. The mold didn't either."}],
[["VMM_f",25], aj, {s: "The dust didn't shock Jackson. Scott wasnt either."}],
[["VMM_g",25], aj, {s: "Jackson wasn't shocked by the dust. Scott wasnt either."}],   
[["VMM_h",25], aj, {s: "Jackson wasn't shocked by the dust. The mold didn't either."}],
 
[["VMM_a",26], aj, {s: "Solomon didn't time the match. Samuel didn't either."}],
[["VMM_b",26], aj, {s: "Solomon didn't time the match. The game wasnt either."}],
[["VMM_c",26], aj, {s: "The match wasn't timed by Solomon. The game wasnt either."}],
[["VMM_d",26], aj, {s: "The match wasn't timed by Solomon. Samuel didn't either."}],    
[["VMM_e",26], aj, {s: "The match didn't thrill Solomon. The game didn't either."}],
[["VMM_f",26], aj, {s: "The match didn't thrill Solomon. Samuel wasnt either."}],
[["VMM_g",26], aj, {s: "Solomon wasn't thrilled by the match. Samuel wasnt either."}],   
[["VMM_h",26], aj, {s: "Solomon wasn't thrilled by the match. The game didn't either."}],
 
[["VMM_a",27], aj, {s: "Kevin didn't praise the book. Will didn't either."}],
[["VMM_b",27], aj, {s: "Kevin didn't praise the book. The essay wasnt either."}],
[["VMM_c",27], aj, {s: "The book wasn't praised by Kevin. The essay wasnt either."}],
[["VMM_d",27], aj, {s: "The book wasn't praised by Kevin. Will didn't either."}],    
[["VMM_e",27], aj, {s: "The book didn't please Kevin. The essay didn't either."}],
[["VMM_f",27], aj, {s: "The book didn't please Kevin. Will wasnt either."}],
[["VMM_g",27], aj, {s: "Kevin wasn't pleased by the book. Will wasnt either."}],   
[["VMM_h",27], aj, {s: "Kevin wasn't pleased by the book. The essay didn't either."}],

[["VMM_a",28], aj, {s: "Zach didn't analyze the finances. Alexander didn't either."}],
[["VMM_b",28], aj, {s: "Zach didn't analyze the finances. The reports weren't either."}],
[["VMM_c",28], aj, {s: "The finances weren't analyzed by Zach. The reports weren't either."}],
[["VMM_d",28], aj, {s: "The finances weren't analyzed by Zach. Alexander didn't either."}],    
[["VMM_e",28], aj, {s: "The finances didn't upset Zach. The reports didn't either."}],
[["VMM_f",28], aj, {s: "The finances didn't upset Zach. Alexander wasnt either."}],
[["VMM_g",28], aj, {s: "Zach wasn't upset by the finances. Alexander wasnt either."}],   
[["VMM_h",28], aj, {s: "Zach wasn't upset by the finances. The reports didn't either."}],
 
[["VMM_a",29], aj, {s: "Christian didn't cut the ropes. Anthony didn't either."}],
[["VMM_b",29], aj, {s: "Christian didn't cut the ropes. The restraints weren't either."}],
[["VMM_c",29], aj, {s: "The ropes weren't cut by Christian. The restraints weren't either."}],
[["VMM_d",29], aj, {s: "The ropes weren't cut by Christian. Anthony didn't either."}],    
[["VMM_e",29], aj, {s: "The ropes didn't terrify Christian. The restraints didn't either."}],
[["VMM_f",29], aj, {s: "The ropes didn't terrify Christian. Anthony wasnt either."}],
[["VMM_g",29], aj, {s: "Christian wasn't terrified by the ropes. Anthony wasnt either."}],   
[["VMM_h",29], aj, {s: "Christian wasn't terrified by the ropes. The restraints didn't either."}],
 
[["VMM_a",30], aj, {s: "James didn't interrupt the lecture. Ian didn't either."}],
[["VMM_b",30], aj, {s: "James didn't interrupt the lecture. The speech wasnt either."}],
[["VMM_c",30], aj, {s: "The lecture wasn't interrupted by James. The speech wasnt either."}],
[["VMM_d",30], aj, {s: "The lecture wasn't interrupted by James. Ian didn't either."}],    
[["VMM_e",30], aj, {s: "The lecture didn't discourage James. The speech didn't either."}],
[["VMM_f",30], aj, {s: "The lecture didn't discourage James. Ian wasnt either."}],
[["VMM_g",30], aj, {s: "James wasn't discouraged by the lecture. Ian wasnt either."}],   
[["VMM_h",30], aj, {s: "James wasn't discouraged by the lecture. The speech didn't either."}],
 
[["VMM_a",31], aj, {s: "Steve didn't identify the flash. Brayden didn't either."}],
[["VMM_b",31], aj, {s: "Steve didn't identify the flash. The glow wasnt either."}],
[["VMM_c",31], aj, {s: "The flash wasn't identified by Steve. The glow wasnt either."}],
[["VMM_d",31], aj, {s: "The flash wasn't identified by Steve. Brayden didn't either."}],    
[["VMM_e",31], aj, {s: "The flash didn't scare Steve. The glow didn't either."}],
[["VMM_f",31], aj, {s: "The flash didn't scare Steve. Brayden wasnt either."}],
[["VMM_g",31], aj, {s: "Steve wasn't scared by the flash. Brayden wasnt either."}],   
[["VMM_h",31], aj, {s: "Steve wasn't scared by the flash. The glow didn't either."}],
 
[["VMM_a",32], aj, {s: "Christopher didn't conceal the jewel. Robert didn't either."}],
[["VMM_b",32], aj, {s: "Christopher didn't conceal the jewel. The ring wasnt either."}],
[["VMM_c",32], aj, {s: "The jewel wasn't concealed by Christopher. The ring wasnt either."}],
[["VMM_d",32], aj, {s: "The jewel wasn't concealed by Christopher. Robert didn't either."}],    
[["VMM_e",32], aj, {s: "The jewel didn't stun Christopher. The ring didn't either."}],
[["VMM_f",32], aj, {s: "The jewel didn't stun Christopher. Robert wasnt either."}],
[["VMM_g",32], aj, {s: "Christopher wasn't stunned by the jewel. Robert wasnt either."}],   
[["VMM_h",32], aj, {s: "Christopher wasn't stunned by the jewel. The ring didn't either."}],


[["EP_a",33], aj, {s: "Daniel planned to send his mother a note."}],
[["EP_b",33], aj, {s: "Daniel planned to send a note to his mother."}],

[["EP_a",34], aj, {s: "The pastor wanted to serve the visitors some food."}],
[["EP_b",34], aj, {s: "The pastor wanted to serve some food to the visitors."}],

[["EP_a",35], aj, {s: "The clerk said she would charge the businessman full price."}],
[["EP_b",35], aj, {s: "The clerk said she would charge full price to the businessman."}],

[["EP_a",36], aj, {s: "The representative said the company would ship the customers a replacement."}],
[["EP_b",36], aj, {s: "The representative said the company would ship a replacement to the customers."}],

[["EP_a",37], aj, {s: "Deanna usually feeds her dog a treat on Wednesdays."}],
[["EP_b",37], aj, {s: "Deanna usually feeds a treat to her dog on Wednesdays."}],

[["EP_a",38], aj, {s: "Robin said he would lend the gambler some money."}],
[["EP_b",38], aj, {s: "Robin said he would lend some money to the gambler."}],

[["EP_a",39], aj, {s: "The board wanted to allocate us some funds."}],
[["EP_b",39], aj, {s: "The board wanted to allocate some funds to us."}],

[["EP_a",40], aj, {s: "Jason wasn't told to repay the bank the money."}],
[["EP_b",40], aj, {s: "Jason wasn't told to repay the money to the bank."}],

[["EP_a",41], aj, {s: "Reginald asked Georgette to wire him some money."}],
[["EP_b",41], aj, {s: "Reginald asked Georgette to wire some money to him."}],

[["EP_a",42], aj, {s: "The rescue worker needed to throw the stranded explorer the heavy rope."}],
[["EP_b",42], aj, {s: "The rescue worker needed to throw the heavy rope to the stranded explorer."}],

[["EP_a",43], aj, {s: "The casino owner wanted to deal the gamblers the fake card."}],
[["EP_b",43], aj, {s: "The casino owner wanted to deal the fake card to the gamblers."}],

[["EP_a",44], aj, {s: "The foundation planned to award the university a grant."}],
[["EP_b",44], aj, {s: "The foundation planned to award a grant to the university."}],

[["f",45], aj, {s: "This is the father that the son who betrayed him has always been very unfair."}],
[["f",46], aj, {s: "This is the boy that the newspaper reports that the cop who beat him up was leading the operation."}],
[["f",47], aj, {s: "This is the striker that I heard that the defender who punched in the face was kicked out of the game."}],
[["f",48], aj, {s: "This is the customer that the waiter who is famous for being unfriendly hit him."}],
[["f",49], aj, {s: "This is the gentleman that the girl who sells ripped carpets deceived her."}],
[["f",50], aj, {s: "This is the guy that the man who could be imprisoned for reckless driving ran him over."}],
[["f",51], aj, {s: "This is the clerk that the manager who downgraded him has always been really mean."}],
[["f",52], aj, {s: "This is the engineer that the manager who has always had trust in young people hired him."}],

      
    
];




