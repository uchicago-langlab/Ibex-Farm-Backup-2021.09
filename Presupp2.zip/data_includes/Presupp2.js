var shuffleSequence = seq("setcounter","Consent","Demographics","Instructions", sepWith("sep", rshuffle(startsWith("Q"))),"Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        leftComment: "Less natural",
        rightComment: "More natural",
        instructions: " ",
        randomOrder: false,
        hasCorrect: false,
        as: ["1","2","3","4","5","6","7"]
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

["setcounter", "__SetCounter__", { }],

["Consent", "Form", {consentRequired: true, html: {include: "Consent.html" }} ],    
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions1.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions2.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],

    
  
["sep", "Separator", {hideProgressBar: true, transfer: 500, normalMessage: " "}],
  
  
  
  
  




    
    
      
  
["Practice", "Message", {hideProgressBar: true, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">How nice of you.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {hideProgressBar: true, s: { html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/nice.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the pronunciation of the sentence seemed fairly typical. You probably selected a high number, like 5, 6, or 7.</p><p>Press any key to continue.</p>'}],  
  
  
["Practice", "Message", {hideProgressBar: true, consentRequired: false, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">If he calls, ask him to leave a message.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/message.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the sentence was not pronounced in a typical way. You probably selected a lower number, like 1, 2, or 3.</p><p>Press any key to continue.</p>'}],       
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],  
  










[["Q13NN", 73], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Mark applauded Anthony, and Ted comforted Erica, too. </font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q13NO", 74], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Ben applauded Erica, and Ted comforted Erica, too. </font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q13RN", 75], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Mary consoled Anthony, and Ted comforted Erica, too.</font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q13RO", 76], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Harry consoled Erica, and Ted comforted Erica, too. </font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q13ON", 77], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Sam comforted Anthony, and Ted comforted Erica, too. </font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q13OO", 78], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The lottery winners and losers were announced.</font></p><p><font size="4">Bill comforted Erica, and Ted comforted Erica, too.</font></p><p><font size="4">A hundred-million dollar prize awaited the winner. </font></p></center>', transfer: "click"}],
[["Q14NN", 79], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Carlos affirmed Molly, and Reagan cheated Sally, too. </font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q14NO", 80], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Marcos affirmed Sally, and Reagan cheated Sally, too. </font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q14RN", 81], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Abigail scammed Molly, and Reagan cheated Sally, too.</font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q14RO", 82], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Kennedy scammed Sally, and Reagan cheated Sally, too. </font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q14ON", 83], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Alfie cheated Molly, and Reagan cheated Sally, too.</font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q14OO", 84], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The big table was completely set for poker. </font></p><p><font size="4">Maxwell cheated Sally, and Reagan cheated Sally, too. </font></p><p><font size="4">I don\'t think they were still friends after that night. </font></p></center>', transfer: "click"}],
[["Q15NN", 85], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Benjamin picked Roger, and Greg astonished Martha, too.</font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q15NO", 86], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Shirley-Ann picked Martha, and Greg astonished Martha, too.</font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q15RN", 87], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Elijah floored Susie, and Greg astonished Martha, too.</font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q15RO", 88], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Martina floored Martha, and Greg astonished Martha, too.</font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q15ON", 89], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Sam astonished Millie, and Greg astonished Martha, too.</font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q15OO", 90], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The class had P.E. during second period.</font></p><p><font size="4">Wayne astonished Martha, and Greg astonished Martha, too. </font></p><p><font size="4">The teacher enjoyed watching the students go wild in a basketball game.  </font></p></center>', transfer: "click"}],
[["Q16NN", 91], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Chad embarrassed Karen, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q16NO", 92], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Bill embarrassed Linda, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q16RN", 93], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Oliver billed Karen, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q16RO", 94], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Gabriel billed Linda, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q16ON", 95], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Anthony charged Karen, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q16OO", 96], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The plumbers entered the next bathroom  with their tools. </font></p><p><font size="4">Sebastian charged Linda, and Joseph charged Linda, too. </font></p><p><font size="4">There should have been a plumbing inspection months ago. </font></p></center>', transfer: "click"}],
[["Q17NN", 97], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Christopher feared Pauline, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q17NO", 98], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Anthony feared Amy, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q17RN", 99], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Samuel scolded Pauline, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q17RO", 100], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Jess scolded Amy, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q17ON", 101], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Don admonished Pauline, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q17OO", 102], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids threw a ball and smashed the vase on the floor.</font></p><p><font size="4">Sal admonished Amy, and Chris admonished Amy, too. </font></p><p><font size="4">They should never play baseball inside again!</font></p></center>', transfer: "click"}],
[["Q18NN", 103], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Emma impressed Leslie, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q18NO", 104], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Joanne impressed Andy, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q18RN", 105], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Amelia woke Leslie, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q18RO", 106], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Eliza woke Andy, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q18ON", 107], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Alexis roused Leslie, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q18OO", 108], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The marching band started early morning practice. </font></p><p><font size="4">Jeremy roused Andy, and Cecil roused Andy, too.</font></p><p><font size="4">Maybe they should start at 8 in the morning instead of 5. </font></p></center>', transfer: "click"}],
[["Q19NN", 109], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Demetrius upset Elizabeth, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q19NO", 110], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Alexander upset Olivia, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q19RN", 111], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Paul congratulated Elizabeth, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q19RO", 112], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Karl congratulated Olivia, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q19ON", 113], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Justin complimented Elizabeth, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q19OO", 114], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The guests moved over to the wedding reception. </font></p><p><font size="4">Frances complimented Olivia, and George complimented Olivia, too.</font></p><p><font size="4">The newlyweds were excited to greet people after the ceremony. </font></p></center>', transfer: "click"}],
[["Q20NN", 115], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Jonathan accepted Jane, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q20NO", 116], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Marissa accepted Roy, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q20RN", 117], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Veronica bullied Jane, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q20RO", 118], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Alexandra bullied Roy, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q20ON", 119], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Anne intimidated Jane, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q20OO", 120], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids started a kickball game during recess. </font></p><p><font size="4">Ruth intimidated Roy, and Kendall intimidated Roy, too.</font></p><p><font size="4">Schoolyard scuffles and games go hand in hand, it seems. </font></p></center>', transfer: "click"}],
[["Q21NN", 121], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Dahlia echoed Lily, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q21NO", 122], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Zachary echoed Anna, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q21RN", 123], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Benny frustrated Lily, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q21RO", 124], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Matthew frustrated Anna, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q21ON", 125], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Elise discouraged Lily, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q21OO", 126], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We just had a family therapy appointment.</font></p><p><font size="4">Chloe discouraged Anna, and Nate discouraged Anna, too. </font></p><p><font size="4">I think another appointment would be good for the family. </font></p></center>', transfer: "click"}],
[["Q22NN", 127], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Maggie threatened Will, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q22NO", 128], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Rosa threatened Eve, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q22RN", 129], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Gaia indulged Will, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q22RO", 130], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Jackie indulged Eve, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q22ON", 131], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Clara spoiled Will, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q22OO", 132], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We visited my family in Arizona. </font></p><p><font size="4">Mickey spoiled Eve, and Walter spoiled Eve, too. </font></p><p><font size="4">We\'re not going back to the Southwest for while. </font></p></center>', transfer: "click"}],
[["Q23NN", 133], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Rosalie drew Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q23NO", 134], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Samantha drew Phoebe, and Mira nagged Phoebe, too.</font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q23RN", 135], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Pete reminded Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q23RO", 136], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Mark reminded Phoebe, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q23ON", 137], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Marina nagged Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q23OO", 138], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Theodore nagged Phoebe, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],
[["Q24NN", 139], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Eli included Ethan, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}],
[["Q24NO", 140], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Adelle included Mason, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}],
[["Q24RN", 141], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Logan refuted Ethan, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}],
[["Q24RO", 142], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Ali refuted Mason, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}],
[["Q24ON", 143], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Lucas corrected Ethan, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}],
[["Q24OO", 144], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The science clubs held joint meetings for everyone.  </font></p><p><font size="4">Liam corrected Mason, and Daisy corrected Mason, too.</font></p><p><font size="4">I think clear communication would be better for everyone in the future. </font></p></center>', transfer: "click"}]







  
  /*
  
Known file issues:

(1)

Male subject didn't record one sentence - Item 36, old verb old object (deaccented).
That means the following files weren't available:

36newVoldOdacM
36oldVoldOaccM
36oldVoldOdacM
36relVoldOdacM

They were all replaced with the file 36newVoldOaccM.wav and the sentence in the preview message controller was changed to match.
But, the code at the beginning of the line shows the condition they *should* be in, so these lines need to be subset out before analaysis.


(2)

In the files 15oldVnewOaccM.wav and 15oldVnewOdacM.wav, the male subject misread the first clause verb as
"admonished" instead of "astonished". The preview sentence was changed to match, but these trials should
be subset out before analysis because the verb does not license the correct (repeated) relation.

  
  

  
  
  */
  
  


















/*
Fillers/attention trials. The files zoo, apple, homework, movies, and contact should get high ratings.
buy, rainbow, room, eggs, and voice should get low ratings.
*/












/*comma*/


    
    




];










