$.ui.Form._ibex_options.countsForProgressBar = true;

//var os = require('os');

function blank(a, b) {
   var sentence = b ? b : a;
   var n = b ? a : null;

   var seq = [""];
   var inBlank = false;
   for (var i = 0; i < sentence.length; ++i) {
       var c = sentence.charAt(i)
       if (inBlank) {
           if (c == '_')
               (seq[seq.length-1])++;
           else {
               seq.push(c);
               inBlank = true;
           }
       }
       else {
           if (c != '_')
               seq[seq.length-1] += c
           else {
               seq.push(1);
               inBlank = true;
           }
       }
   }

   var ihtml = "";
   var bcount = 0;
   for (var i = 0; i < seq.length; ++i) {
       if (typeof(seq[i]) == "number") {
           ++bcount;
           var input = " <input type='text' name='blank-" + bcount + "' size='" + (n ? n : seq[i]) + "'></input> ";  
           ihtml += input;
       }
       else {
           ihtml += $("<div>").text(seq[i])[0].innerHTML;
       }
   }

   var e = "<p>";
   var validators = { };
   var bcount = 0;
   for (var i = 0; i < seq.length; ++i) {
       if (typeof(seq[i]) == "number") {
           ++bcount;
           e += "<label class='error' for='blank-" + bcount + "'></label>";
           validators['blank-' + bcount] = function (s) { if (s && ! s.match(/^\s*$/)) return true; else return "You must fill in the blank."; }
       }
   }
   e += "</p>"

   return {
       html: "<p>" + ihtml + "</p>" + e,
       validators: validators
   };
}
            
// var shuffleSequence   =  seq("intro", "instructions",  
//                          sepWith("sep",randomize(rshuffle("measure_list1"))),
//                          "sr","code");
       
// ======================SHUFFLESEQUENCE IS HERE ========================================================================================          
       
var shuffleSequence   =  seq("intro", "instructions",  
                            "startofpractice", "GuidedPractice1", "Feedback1", "GuidedPractice2", "Feedback2", "GuidedPractice3", "Feedback3", "endofpractice",
                            sepWith("sep",randomize(rshuffle("therefore_list1","toomuch_list","control"))),
                            "sr","code");
       
       
// ======================SHUFFLESEQUENCE IS HERE ========================================================================================   

var practiceItemTypes = ["GuidedPractice1","GuidedPractice2","GuidedPractice3"];

//var manualSendResults = true; 

var defaults = [

    "Separator", {
        transfer: "keypress",
        normalMessage: "Press any key to continue",
    },


     "AcceptabilityJudgment", { as: ["1", "2", "3", "4", "5", "6", "7"],
                               presentAsScale: true,
                               instructions: "Use number keys or click boxes to answer.",
                               leftComment: "(very implausible)", rightComment: "(very plausible)" },

    "Message", {hideProgressBar: true},

    "Form", {
        hideProgressBar: false,
        continueOnReturn: true,
        saveReactionTime: true
    }
];


var items = [
    
    
    //Introduction and Consent Form
    
    ["intro", "Form", {
        html: {include: "info_consent.html"},
        validators: {age: function (s) {if (s >= 18) return true; else return "Bad value for \u2018age\u2019";}
        }
    }],

    //Instructions
    
    ["instructions", "Message", {html: {include: "instructions.html"}}],
    
    //Separator
    
    ["sep", "Separator", { }],

    //Manually send results
    
    //["sr", "__SendResults__", { }],
    
    // Short practice.
    
    ["practice" , "AcceptabilityJudgment", {s: {html: "The burglar was worried about vandals in the neighborhood."}}],
    ["practice" , "AcceptabilityJudgment", {s: {html: "The hairdressers motioned for the next client to sit down."}}],     
    
    
    //Start of practice message.
    
    ["startofpractice", "Message", {html: "<p><i>Before you begin, here are three short paractice questions for you to complete.<br>Please pay attention to the feedback.</i></p><br>" }],
    
    
    //End of practice message.
    
    ["endofpractice", "Message", {html: "<p><i>This is the end of the practice items.</i></p><br>" }],
    
    //Guided Practice
    
    ["GuidedPractice1" , "Form", {html:"Denise ignored her friend's advice and didn't book a table in advance.<br>Therefore, when they got to the restaurant, all the tables were <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],
    ["Feedback1", "Message", {html: {include:  "Feedback1.html"}}],    
    ["GuidedPractice2" , "Form", {html:"The cafe owner was pleasant and took the time to chat to the customers.<br>His wife, however, was <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],
    ["Feedback2", "Message", {html: {include:  "Feedback2.html"}}],
    ["GuidedPractice3" , "Form", {html:"The soldier had a minor injury to his head.<br>The doctor said it was nothing to worry about.<br>Even so, his injury <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],
    ["Feedback3", "Message", {html: {include:  "Feedback3.html"}}],
    
    
    //Debriefing with payment code.  
    
    ["code", "Form", {
        continueMessage: "Please press here to complete the experiment",
        consentRequired: false, 
        html: {include: "exit.html"} 
    }],    
    
    
    [["therefore_list1",2161], "Form", {html:"Pam was a beginner woodwork enthusiast and had just completed her first dining table.<br>The table came out a bit wobbly and she had to put a folded napkin under one of the legs.<br>Therefore, she was <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],
    [["therefore_list1",1164], "Form", {html:"Aman repainted his grandparents' garden shed a year ago.<br>He mistakenly used interior paint for the job.<br>Therefore, the paint looked <input name='blank' size='30' class='obligatory' type='text' autofocus></input>."}],

    //Control Items -- to check that participants are paying attention.  
   
[["control",003] , "Form", {html:"The smallest positive odd number is: <input name='blank' size='30' class='obligatory' type='text'></input>."}],
[["control",004] , "Form", {html:"The smallest positive even number is: <input name='blank' size='30' class='obligatory' type='text'></input>."}],

    
];
    
//]; 
