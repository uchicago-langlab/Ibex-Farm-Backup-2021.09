var shuffleSequence = seq("setcounter", "intro", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))), "payment");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "Question", {
        randomOrder: false,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var items = [

      // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
      // sequence to send results before the experiment has finished. This is NOT intended to allow
      // for incremental sending of results -- you should send results exactly once per experiment.
      // However, it does permit additional messages to be displayed to participants once the
      // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
      // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
      // otherwise, results are automatically sent at the end of the experiment.
      //
      //["sr", "__SendResults__", { }],

      ["sep", "Separator", { }],
       
      ["intro", "Form", {consentRequired: true, html: {include: "consent.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
      ["payment", "Form", {consentRequired: false, html: {include: "exit.html" }} ],
      //["practiceover", "Message", {html: ["div", ["p", "This is the end of the practice."],["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."]  ,continueMessage:"Click here to continue."}],

      ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
      ],continueMessage:"Click here to continue."}],


  

      // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
      // for latin square designs will be updated. (Previously, this was always updated upon completion
      // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
      // point in your running order. If given no options, the counter is incremented by one. If given
      // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
      // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
      //
      ["setcounter", "__SetCounter__", { }],

      // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
      // consent checkbox).

      //
      // 2 practice items for self-paced reading ( with a comprehension question).
      //
      ["practice", "DashedSentence", {s: ["The cat","and","the dog","that","belong to","the woman","ran","away."]},
                        "Question", {q: "Do the cat and the dog belong to the man?", as: ["yes","no"], hasCorrect: 1}],
      ["practice", "DashedSentence", {s: ["The fact","that","Leland","hates","frogs","concerned","his parents."]},
                        "Question", {q: "Does Leland hate frogs?", as: ["yes","no"], hasCorrect: 0}],

      //
      // 32 "real" (i.e. non-filler) self-paced reading items with corresponding comprehension questions
      // There are four conditions.
      //

      [["e.subj.comp",1], "DashedSentence",{s:["It seems","that","those lawyers","and judges","who","John","thinks","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those lawyers and judges who John thinks reprimanded Andy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",1], "DashedSentence",{s:["It seems","that","those judges","who","John","thinks","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those judges who John thinks reprimanded Andy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",1], "DashedSentence",{s:["It seems","that","those lawyers","and judges","who","John","thinks","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those lawyers and judges who John thinks reprimanded Andy?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",1], "DashedSentence",{s:["It seems","that","those judges","who","John","thinks","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those judges who John thinks reprimanded Andy?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",2], "DashedSentence",{s:["It appears","that","those designers","and decorators","who","Caroline", "says","inadvertently","angered","Amy","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those designers and decorators who Caroline says angered Amy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",2], "DashedSentence",{s:["It appears","that","those decorators","who","Caroline", "says","inadvertently","angered","Amy","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those decorators who Caroline says angered Amy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",2], "DashedSentence",{s:["It appears","that","those designers","and decorators","who","Caroline", "says","Amy","inadvertently","angered","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those designers and decorators who Caroline says angered Amy?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",2], "DashedSentence",{s:["It appears","that","those decorators","who","Caroline", "says","Amy","inadvertently","angered","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those decorators who Caroline says angered Amy?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",3], "DashedSentence",{s:["It seems","that","those biologists","and researchers","who","Tim","believes","warmly","encouraged","Ben","last night","studied","the disease."]}, "Question",{q: "Was it those biologists and researchers who Tim believes encouraged Ben?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",3], "DashedSentence",{s:["It seems","that","those researchers","who","Tim","believes","warmly","encouraged","Ben","last night","studied","the disease."]}, "Question",{q: "Was it those researchers who Tim believes encouraged Ben?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",3], "DashedSentence",{s:["It seems","that","those biologists","and researchers","who","Tim","believes","Ben","warmly","encouraged","last night","studied","the disease."]}, "Question",{q: "Was it those biologists and researchers who Tim believes encouraged Ben?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",3], "DashedSentence",{s:["It seems","that","those researchers","who","Tim","believes","Ben","warmly","encouraged","last night","studied","the disease."]}, "Question",{q: "Was it those researchers who Tim believes encouraged Ben?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",4], "DashedSentence",{s:["It appears","that","those publicists","and managers","who","Jude","claims","diligently","represented","Luke","this morning","answered","the letter."]}, "Question",{q: "Was it those publicists and managers who Jude claims represented Luke?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",4], "DashedSentence",{s:["It appears","that","those managers","who","Jude","claims","diligently","represented","Luke","this morning","answered","the letter."]}, "Question",{q: "Was it those managers who Jude claims represented Luke?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",4], "DashedSentence",{s:["It appears","that","those publicists","and managers","who","Jude","claims","Luke","diligently","represented","this morning","answered","the letter."]}, "Question",{q: "Was it those publicists and managers who Jude claims represented Luke?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",4], "DashedSentence",{s:["It appears","that","those managers","who","Jude","claims","Luke","diligently","represented","this morning","answered","the letter."]}, "Question",{q: "Was it those managers who Jude claims represented Luke?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",5], "DashedSentence",{s:["It seems","that","those singers","and dancers","who","George","says","mercilessly","derided","Kevin","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those singers and dancers who George says derided Kevin?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",5], "DashedSentence",{s:["It seems","that","those dancers","who","George","says","mercilessly","derided","Kevin","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those dancers who George says derided Kevin?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",5], "DashedSentence",{s:["It seems","that","those singers","and dancers","who","George","says","Kevin","mercilessly","derided","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those singers and dancers who George says derided Kevin?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",5], "DashedSentence",{s:["It seems","that","those dancers","who","George","says","Kevin","mercilessly","derided","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those dancers who George says derided Kevin?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",6], "DashedSentence",{s:["It appears","that","those clerks","and coordinators","who","Sarah","believes","rudely","criticized","Leah","this evening","organized","the calendar."]}, "Question",{q: "Was it those clerks and coordinators who Sarah believes criticized Leah?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",6], "DashedSentence",{s:["It appears","that","those coordinators","who","Sarah","believes","rudely","criticized","Leah","this evening","organized","the calendar."]}, "Question",{q: "Was it those coordinators who Sarah believes criticized Leah?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",6], "DashedSentence",{s:["It appears","that","those clerks","and coordinators","who","Sarah","believes","Leah","rudely","criticized","this evening","organized","the calendar."]}, "Question",{q: "Was it those clerks and coordinators who Sarah believes criticized Leah?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",6], "DashedSentence",{s:["It appears","that","those coordinators","who","Sarah","believes","Leah","rudely","criticized","this evening","organized","the calendar."]}, "Question",{q: "Was it those coordinators who Sarah believes criticized Leah?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",7], "DashedSentence",{s:["It seems","that","those cashiers","and bussers","who","Ali","claims","adequately","served","Jack","tonight","prepared","the food."]}, "Question",{q: "Was it those cashiers and bussers who Ali claims served Jack?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",7], "DashedSentence",{s:["It seems","that","those bussers","who","Ali","claims","adequately","served","Jack","tonight","prepared","the food."]}, "Question",{q: "Was it those bussers who Ali claims served Jack?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",7], "DashedSentence",{s:["It seems","that","those cashiers","and bussers","who","Ali","claims","Jack","adequately","served","tonight","prepared","the food."]}, "Question",{q: "Was it those cashiers and bussers who Ali claims served Jack?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",7], "DashedSentence",{s:["It seems","that","those bussers","who","Ali","claims","Jack","adequately","served","tonight","prepared","the food."]}, "Question",{q: "Was it those bussers who Ali claims served Jack?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",8], "DashedSentence",{s:["It appears","that","those dieticians","and technicians","who","Jennifer","thinks","dutifully","assisted","Sophia","last week","administered","the test."]}, "Question",{q: "Was it those dieticians and technicians who Jennifer thinks assisted Sophia?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",8], "DashedSentence",{s:["It appears","that","those technicians","who","Jennifer","thinks","dutifully","assisted","Sophia","last week","administered","the test."]}, "Question",{q: "Was it those technicians who Jennifer thinks assisted Sophia?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",8], "DashedSentence",{s:["It appears","that","those dieticians","and technicians","who","Jennifer","thinks","Sophia","dutifully","assisted","last week","administered","the test."]}, "Question",{q: "Was it those dieticians and technicians who Jennifer thinks assisted Sophia?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",8], "DashedSentence",{s:["It appears","that","those technicians","who","Jennifer","thinks","Sophia","dutifully","assisted","last week","administered","the test."]}, "Question",{q: "Was it those technicians who Jennifer thinks assisted Sophia?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",9], "DashedSentence",{s:["It seems","that","those photographers","and journalists","who","Nico","believes","loyally","aided","Matthew","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those photographers and journalists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",9], "DashedSentence",{s:["It seems","that","those journalists","who","Nico","believes","loyally","aided","Matthew","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those journalists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",9], "DashedSentence",{s:["It seems","that","those photographers","and journalists","who","Nico","believes","Matthew","loyally","aided","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those photographers and journalists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",9], "DashedSentence",{s:["It seems","that","those journalists","who","Nico","believes","Matthew","loyally","aided","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who Nico believes was aided by those journalists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",10], "DashedSentence",{s:["It appears","that","those composers","and pianists","who","Jerry","claims","lovingly","comforted","Tom","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who Jerry claims was comforted by those composers and pianists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",10], "DashedSentence",{s:["It appears","that","those pianists","who","Jerry","claims","lovingly","comforted","Tom","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who Jerry claims was comforted by those pianists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",10], "DashedSentence",{s:["It appears","that","those composers","and pianists","who","Jerry","claims","Tom","lovingly","comforted","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who Jerry claims was comforted by those composers and pianists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",10], "DashedSentence",{s:["It appears","that","those pianists","who","Jerry","claims","Tom","lovingly","comforted","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who Jerry claims was comforted by those pianists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",11], "DashedSentence",{s:["It seems","that","those policemen","and firemen","who","Ruth","thinks","swiftly","called","Stephanie","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who Ruth thinks was called by those policemen and firemen?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",11], "DashedSentence",{s:["It seems","that","those firemen","who","Ruth","thinks","swiftly","called","Stephanie","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who Ruth thinks was called by those firemen?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",11], "DashedSentence",{s:["It seems","that","those policemen","and firemen","who","Ruth","thinks","Stephanie","swiftly","called","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who Ruth thinks was called by those policemen and firemen?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",11], "DashedSentence",{s:["It seems","that","those firemen","who","Ruth","thinks","Stephanie","swiftly","called","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who Ruth thinks was called by those firemen?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",12], "DashedSentence",{s:["It appears","that","those psychologists","and psychiatrists","who","Hallie","says","seriously","doubted","Becky","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who Hallie says was doubted by those psychologists and psychiatrists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",12], "DashedSentence",{s:["It appears","that","those psychiatrists","who","Hallie","says","seriously","doubted","Becky","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who Hallie says was doubted by those psychiatrists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",12], "DashedSentence",{s:["It appears","that","those psychologists","and psychiatrists","who","Hallie","says","Becky","seriously","doubted","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who Hallie says was doubted by those psychologists and psychiatrists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",12], "DashedSentence",{s:["It appears","that","those psychiatrists","who","Hallie","says","Becky","seriously","doubted","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who Hallie says was doubted by those psychiatrists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",13], "DashedSentence",{s:["It seems","that","those painters","and framers","who","Jane","claims","emphatically","denounced","Ellen","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who Jane claims was denounced by those painters and framers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",13], "DashedSentence",{s:["It seems","that","those framers","who","Jane","claims","emphatically","denounced","Ellen","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who Jane claims was denounced by those framers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",13], "DashedSentence",{s:["It seems","that","those painters","and framers","who","Jane","claims","Ellen","emphatically","denounced","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who Jane claims was denounced by those painters and framers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",13], "DashedSentence",{s:["It seems","that","those framers","who","Jane","claims","Ellen","emphatically","denounced","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who Jane claims was denounced by those framers?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",14], "DashedSentence",{s:["It appears","that","those electricians","and plumbers","who","Elsa","thinks","reluctantly","helped","Anna","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who Elsa thinks was helped by those electricians and plumbers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",14], "DashedSentence",{s:["It appears","that","those plumbers","who","Elsa","thinks","reluctantly","helped","Anna","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who Elsa thinks was helped by those plumbers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",14], "DashedSentence",{s:["It appears","that","those electricians","and plumbers","who","Elsa","thinks","Anna","reluctantly","helped","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who Elsa thinks was helped by those electricians and plumbers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",14], "DashedSentence",{s:["It appears","that","those plumbers","who","Elsa","thinks","Anna","reluctantly","helped","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who Elsa thinks was helped by those plumbers?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",15], "DashedSentence",{s:["It seems","that","those tailors","and seamstresses","who","Barack","says","halfheartedly","hired","Teddy","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who Barack says was hired by those tailors and seamstresses?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",15], "DashedSentence",{s:["It seems","that","those seamstresses","who","Barack","says","halfheartedly","hired","Teddy","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who Barack says was hired by those seamstresses?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",15], "DashedSentence",{s:["It seems","that","those tailors","and seamstresses","who","Barack","says","Teddy","halfheartedly","hired","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who Barack says was hired by those tailors and seamstresses?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",15], "DashedSentence",{s:["It seems","that","those seamstresses","who","Barack","says","Teddy","halfheartedly","hired","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who Barack says was hired by those seamstresses?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",16], "DashedSentence",{s:["It appears","that","those engineers","and contractors","who","Kennedy","believes","eagerly","introduced","Alex","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who Kennedy believes was introduced by those engineers and contractors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",16], "DashedSentence",{s:["It appears","that","those contractors","who","Kennedy","believes","eagerly","introduced","Alex","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who Kennedy believes was introduced by those contractors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",16], "DashedSentence",{s:["It appears","that","those engineers","and contractors","who","Kennedy","believes","Alex","eagerly","introduced","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who Kennedy believes was introduced by those engineers and contractors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",16], "DashedSentence",{s:["It appears","that","those contractors","who","Kennedy","believes","Alex","eagerly","introduced","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who Kennedy believes was introduced by those contractors?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",17], "DashedSentence",{s:["It seems","that","those teachers","and professors","who","Mark","thinks","affectionately","mentored","Zack","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who Mark thinks mentored those teachers and professors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",17], "DashedSentence",{s:["It seems","that","those professors","who","Mark","thinks","affectionately","mentored","Zack","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who Mark thinks mentored those professors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",17], "DashedSentence",{s:["It seems","that","those teachers","and professors","who","Mark","thinks","Zack","affectionately","mentored","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who Mark thinks mentored those teachers and professors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",17], "DashedSentence",{s:["It seems","that","those professors","who","Mark","thinks","Zack","affectionately","mentored","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who Mark thinks mentored those professors?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",18], "DashedSentence",{s:["It appears","that","those veterinarians","and zoologists","who","Zoey","says","quickly","advised","Madeline","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who Zoey says advised those veterinarians and zoologists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",18], "DashedSentence",{s:["It appears","that","those zoologists","who","Zoey","says","quickly","advised","Madeline","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who Zoey says advised those zoologists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",18], "DashedSentence",{s:["It appears","that","those veterinarians","and zoologists","who","Zoey","says","Madeline","quickly","advised","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who Zoey says advised those veterinarians and zoologists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",18], "DashedSentence",{s:["It appears","that","those zoologists","who","Zoey","says","Madeline","quickly","advised","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who Zoey says advised those zoologists?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",19], "DashedSentence",{s:["It seems","that","those coaches","and directors","who","Michelle","believes","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those coaches and directors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",19], "DashedSentence",{s:["It seems","that","those directors","who","Michelle","believes","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those directors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",19], "DashedSentence",{s:["It seems","that","those coaches","and directors","who","Michelle","believes","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those coaches and directors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",19], "DashedSentence",{s:["It seems","that","those directors","who","Michelle","believes","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who Michelle believes drilled those directors?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",20], "DashedSentence",{s:["It appears","that","those bankers","and tellers","who","Elisa","claims","thoroughly","questioned","Fiona","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those bankers and tellers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",20], "DashedSentence",{s:["It appears","that","those tellers","who","Elisa","claims","thoroughly","questioned","Fiona","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those tellers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",20], "DashedSentence",{s:["It appears","that","those bankers","and tellers","who","Elisa","claims","Fiona","thoroughly","questioned","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those bankers and tellers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",20], "DashedSentence",{s:["It appears","that","those tellers","who","Elisa","claims","Fiona","thoroughly","questioned","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who Elisa claims questioned those tellers?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",21], "DashedSentence",{s:["It seems","that","those librarians","and volunteers","who","Bilbo","says","enthusiastically","guided","Ivan","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who Bilbo says guided those librarians and volunteers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",21], "DashedSentence",{s:["It seems","that","those volunteers","who","Bilbo","says","enthusiastically","guided","Ivan","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who Bilbo says guided those volunteers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",21], "DashedSentence",{s:["It seems","that","those librarians","and volunteers","who","Bilbo","says","Ivan","enthusiastically","guided","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who Bilbo says guided those librarians and volunteers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",21], "DashedSentence",{s:["It seems","that","those volunteers","who","Bilbo","says","Ivan","enthusiastically","guided","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who Bilbo says guided those volunteers?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",22], "DashedSentence",{s:["It appears","that","those witnesses","and defendants","who","Ewan","believes","frighteningly","interrogated","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes interrogated those witnesses and defendants?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",22], "DashedSentence",{s:["It appears","that","those defendants","who","Ewan","believes","frighteningly","interrogated","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes interrogated those defendants?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",22], "DashedSentence",{s:["It appears","that","those witnesses","and defendants","who","Ewan","believes","Isaac","frighteningly","interrogated","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes interrogated those witnesses and defendants?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",22], "DashedSentence",{s:["It appears","that","those defendants","who","Ewan","believes","Isaac","frighteningly","interrogated","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who Ewan believes interrogated those defendants?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",23], "DashedSentence",{s:["It seems","that","those clients","and patrons","who","Jackie","claims","hurriedly","commanded","Amy","last week","finished","the project."]}, "Question",{q: "Was it Amy who Jackie claims commanded those clients and patrons?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",23], "DashedSentence",{s:["It seems","that","those patrons","who","Jackie","claims","hurriedly","commanded","Amy","last week","finished","the project."]}, "Question",{q: "Was it Amy who Jackie claims commanded those patrons?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",23], "DashedSentence",{s:["It seems","that","those clients","and patrons","who","Jackie","claims","Amy","hurriedly","commanded","last week","finished","the project."]}, "Question",{q: "Was it Amy who Jackie claims commanded those clients and patrons?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",23], "DashedSentence",{s:["It seems","that","those patrons","who","Jackie","claims","Amy","hurriedly","commanded","last week","finished","the project."]}, "Question",{q: "Was it Amy who Jackie claims commanded those patrons?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",24], "DashedSentence",{s:["It appears","that","those repairmen","and mechanics","who","Corey","thinks","consciously","neglected","Ian","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who Corey thinks neglected those repairmen and mechanics?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",24], "DashedSentence",{s:["It appears","that","those mechanics","who","Corey","thinks","consciously","neglected","Ian","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who Corey thinks neglected those mechanics?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",24], "DashedSentence",{s:["It appears","that","those repairmen","and mechanics","who","Corey","thinks","Ian","consciously","neglected","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who Corey thinks neglected those repairmen and mechanics?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",24], "DashedSentence",{s:["It appears","that","those mechanics","who","Corey","thinks","Ian","consciously","neglected","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who Corey thinks neglected those mechanics?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",25], "DashedSentence",{s:["It seems","that","those socialites","and influencers","who","Savannah","believes","snobbishly","excluded","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those socialites and influencers who Savannah believes were excluded by Rosie?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",25], "DashedSentence",{s:["It seems","that","those influencers","who","Savannah","believes","snobbishly","excluded","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those influencers who Savannah believes were excluded by Rosie?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",25], "DashedSentence",{s:["It seems","that","those socialites","and influencers","who","Savannah","believes","Rosie","snobbishly","excluded","on Tuesday","threw","the party."]}, "Question",{q: "Was it those socialites and influencers who Savannah believes were excluded by Rosie?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",25], "DashedSentence",{s:["It seems","that","those influencers","who","Savannah","believes","Rosie","snobbishly","excluded","on Tuesday","threw","the party."]}, "Question",{q: "Was it those influencers who Savannah believes were excluded by Rosie?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",26], "DashedSentence",{s:["It appears","that","those comedians","and performers","who","Catherine","claims","barely","recognized","Isabella","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those comedians and performers who Catherine claims were recognized by Isabella?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",26], "DashedSentence",{s:["It appears","that","those performers","who","Catherine","claims","barely","recognized","Isabella","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those performers who Catherine claims were recognized by Isabella?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",26], "DashedSentence",{s:["It appears","that","those comedians","and performers","who","Catherine","claims","Isabella","barely","recognized","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those comedians and performers who Catherine claims were recognized by Isabella?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",26], "DashedSentence",{s:["It appears","that","those performers","who","Catherine","claims","Isabella","barely","recognized","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those performers who Catherine claims were recognized by Isabella?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",27], "DashedSentence",{s:["It seems","that","those secretaries","and bosses","who","Britta","thinks","carefully","counseled","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those secretaries and bosses who Britta thinks were counseled by Jessica?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",27], "DashedSentence",{s:["It seems","that","those bosses","who","Britta","thinks","carefully","counseled","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those bosses who Britta thinks were counseled by Jessica?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",27], "DashedSentence",{s:["It seems","that","those secretaries","and bosses","who","Britta","thinks","Jessica","carefully","counseled","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those secretaries and bosses who Britta thinks were counseled by Jessica?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",27], "DashedSentence",{s:["It seems","that","those bosses","who","Britta","thinks","Jessica","carefully","counseled","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those bosses who Britta thinks were counseled by Jessica?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",28], "DashedSentence",{s:["It appears","that","those doctors","and nurses","who","Annie","says","previously","consulted","Tess","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those doctors and nurses who Annie says were consulted by Tess?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",28], "DashedSentence",{s:["It appears","that","those nurses","who","Annie","says","previously","consulted","Tess","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those nurses who Annie says were consulted by Tess?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",28], "DashedSentence",{s:["It appears","that","those doctors","and nurses","who","Annie","says","Tess","previously","consulted","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those doctors and nurses who Annie says were consulted by Tess?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",28], "DashedSentence",{s:["It appears","that","those nurses","who","Annie","says","Tess","previously","consulted","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those nurses who Annie says were consulted by Tess?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",29], "DashedSentence",{s:["It seems","that","those artists","and sculptors","who","Zane","claims","cordially","welcomed","Keith","on Saturday","made","the piece."]}, "Question",{q: "Was it those artists and sculptors who Zane claims were welcomed by Keith?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",29], "DashedSentence",{s:["It seems","that","those sculptors","who","Zane","claims","cordially","welcomed","Keith","on Saturday","made","the piece."]}, "Question",{q: "Was it those sculptors who Zane claims were welcomed by Keith?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",29], "DashedSentence",{s:["It seems","that","those artists","and sculptors","who","Zane","claims","Keith","cordially","welcomed","on Saturday","made","the piece."]}, "Question",{q: "Was it those artists and sculptors who Zane claims were welcomed by Keith?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",29], "DashedSentence",{s:["It seems","that","those sculptors","who","Zane","claims","Keith","cordially","welcomed","on Saturday","made","the piece."]}, "Question",{q: "Was it those sculptors who Zane claims were welcomed by Keith?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",30], "DashedSentence",{s:["It appears","that","those conductors","and accompanists","who","Troy","thinks","fully","prepared","Simon","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those conductors and accompanists who Troy thinks were prepared by Simon?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",30], "DashedSentence",{s:["It appears","that","those accompanists","who","Troy","thinks","fully","prepared","Simon","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those accompanists who Troy thinks were prepared by Simon?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",30], "DashedSentence",{s:["It appears","that","those conductors","and accompanists","who","Troy","thinks","Simon","fully","prepared","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those conductors and accompanists who Troy thinks were prepared by Simon?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",30], "DashedSentence",{s:["It appears","that","those accompanists","who","Troy","thinks","Simon","fully","prepared","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those accompanists who Troy thinks were prepared by Simon?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",31], "DashedSentence",{s:["It seems","that","those medics","and EMTs","who","Maria","says","successfully","relieved","Elena","today","reached","the hospital."]}, "Question",{q: "Was it those medics and EMTs who Maria says were relieved by Elena?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",31], "DashedSentence",{s:["It seems","that","those EMTs","who","Maria","says","successfully","relieved","Elena","today","reached","the hospital."]}, "Question",{q: "Was it those EMTs who Maria says were relieved by Elena?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",31], "DashedSentence",{s:["It seems","that","those medics","and EMTs","who","Maria","says","Elena","successfully","relieved","today","reached","the hospital."]}, "Question",{q: "Was it those medics and EMTs who Maria says were relieved by Elena?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",31], "DashedSentence",{s:["It seems","that","those EMTs","who","Maria","says","Elena","successfully","relieved","today","reached","the hospital."]}, "Question",{q: "Was it those EMTs who Maria says were relieved by Elena?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",32], "DashedSentence",{s:["It appears","that","those therapists","and counselors","who","Laura","believes","compassionately","consoled","Aliza","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those therapists and counselors who Laura believes were consoled by Aliza?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",32], "DashedSentence",{s:["It appears","that","those counselors","who","Laura","believes","compassionately","consoled","Aliza","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those counselors who Laura believes were consoled by Aliza?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",32], "DashedSentence",{s:["It appears","that","those therapists","and counselors","who","Laura","believes","Aliza","compassionately","consoled","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those therapists and counselors who Laura believes were consoled by Aliza?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",32], "DashedSentence",{s:["It appears","that","those counselors","who","Laura","believes","Aliza","compassionately","consoled","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those counselors who Laura believes were consoled by Aliza?", as:["yes","no"], hasCorrect: 0}],   
 
      //
      // 32 self-paced-reading filler sentences with question.
      //

      ["filler.A.1", "DashedSentence",{s:["It was","those consumers","who","Connor","thinks","begrudgingly","contacted","Jack","last night."]}, "Question",{q: "Was it those consumers who Connor thinks contacted Jack?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.2", "DashedSentence",{s:["It was","those landlords","who","Frankie","says","generously","paid","Ariana","this morning."]}, "Question",{q: "Was it Ariana who Frankie says was paid by those landlords?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.3", "DashedSentence",{s:["It was","those builders","who","Chad","believes","contentedly","contracted","Grant","this afternoon."]}, "Question",{q: "Was it Grant who Chad believes contracted those builders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.4", "DashedSentence",{s:["It was","those administrators","who","Serena","claims","devotedly","obeyed","Anne","this evening."]}, "Question",{q: "Was it those administrators who Serena claims were obeyed by Anne?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.5", "DashedSentence",{s:["It was","those marathoners","who","Venus","says","Juliette","excessively","trained","tonight."]}, "Question",{q: "Was it those marathoners who Venus says trained Juliette?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.6", "DashedSentence",{s:["It was","those shareholders","who","Jeff","believes","William","steadfastly","trusted","last week."]}, "Question",{q: "Was it William who Jeff believes was trusted by those shareholders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.7", "DashedSentence",{s:["It was","those archaeologists","who","Grace","claims","Abby","blindly","followed","on Monday."]}, "Question",{q: "Was it Abby who Grace claims followed those archaeologists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.8", "DashedSentence",{s:["It was","those ministers","who","Ava","thinks","Katie","constantly","distracted","on Tuesday."]}, "Question",{q: "Was it those ministers who Ava thinks were distracted by Katie?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.B.1", "DashedSentence",{s:["Carlos","believes","that","the fact","that","those writers","beautifully","described","Sergio","this afternoon","was","unprecedented."]}, "Question",{q: "Was it those writers who described Sergio?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.2", "DashedSentence",{s:["Joe","claims","that","the fact","that","those publishers","positively","endorsed","Thomas","this evening","was","rare."]}, "Question",{q: "Was it Thomas who was endorsed by those publishers?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.3", "DashedSentence",{s:["Diego","thinks","that","the fact","that","those chemists","arbitrarily","selected","Luis","tonight","was","unusual."]}, "Question",{q: "Was it Luis who selected those chemists?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.4", "DashedSentence",{s:["Larry","says","that","the fact","that","those planners","carelessly","mocked","Lynn","last week","was","normal."]}, "Question",{q: "Was it those planners who were mocked by Lynn?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.5", "DashedSentence",{s:["Derrick","claims","that","the fact","that","Jacob","negatively","rated","those recruiters","on Monday","was","surprising."]}, "Question",{q: "Was it those recruiters who rated Jacob?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.6", "DashedSentence",{s:["Frank","thinks","that","the fact","that","Terry","secretly","observed","those investigators","on Tuesday","was","astonishing."]}, "Question",{q: "Was it Terry who was observed by those investigators?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.7", "DashedSentence",{s:["Charlotte","says","that","the fact","that","Kacey","attentively","shadowed","those clinicians","on Wednesday","was","impressive."]}, "Question",{q: "Was it Kacey who shadowed those clinicians?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.8", "DashedSentence",{s:["Evelyn","believes","that","the fact","that","Blythe","confidently","instructed","those artisans","on Thursday","was","bizarre."]}, "Question",{q: "Was it those artisans who were instructed by Blythe?", as:["yes","no"], hasCorrect: 0}],
      ["filler.C.1", "DashedSentence",{s:["It was","mind-boggling","that","those florists","nervously","notified","Nick","on Saturday."]}, "Question",{q: "Was it those florists who notified Nick?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.2", "DashedSentence",{s:["It was","uncanny","that","those orthodontists","graciously","forgave","Bennet","on Sunday."]}, "Question",{q: "Was it Bennet who was forgiven by those orthodontists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.3", "DashedSentence",{s:["It was","acceptable","that","those midwives","fearfully","alerted","Bill","today."]}, "Question",{q: "Was it Bill who alerted those midwives?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.4", "DashedSentence",{s:["It was","unacceptable","that","those marines","fiercely","attacked","Lucas","yesterday."]}, "Question",{q: "Was it those marines who were attacked by Lucas?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.5", "DashedSentence",{s:["It was","abnormal","that","Sadie","unethically","misinformed","those entrepreneurs","last night."]}, "Question",{q: "Was it those entrepreneurs who misinformed Sadie?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.6", "DashedSentence",{s:["It was","unbelievable","that","Xavier","accidentally","misled","those captains","this morning."]}, "Question",{q: "Was it Xavier who was misled by those captains?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.7", "DashedSentence",{s:["It was","incredible","that","Chad","foolishly","indulged","those cooks","this afternoon."]}, "Question",{q: "Was it Chad who indulged those cooks?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.8", "DashedSentence",{s:["It was","mind-blowing","that","Leland","severely","underpaid","those pedicurists","this evening."]}, "Question",{q: "Was it those pedicurists who were underpaid by Leland?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.1", "DashedSentence",{s:["The newspaper","confirmed","that","those senators","mistakenly","exposed","Tabitha","last week."]}, "Question",{q: "Was it those senators who exposed Tabitha?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.2", "DashedSentence",{s:["The article","acknowledged","that","those treasurers","incorrectly","chastised","Preston","on Monday."]}, "Question",{q: "Was it Preston who was chastised by those treasurers?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.3", "DashedSentence",{s:["The show","explained","that","those chancellors","publicly","honored","Sienna","on Tuesday."]}, "Question",{q: "Was it Sienna who honored those chancellors?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.4", "DashedSentence",{s:["The book","demonstrated","that","those landscapers","overtly","defended","Justin","on Wednesday."]}, "Question",{q: "Was it those landscapers who were defended by Justin?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.5", "DashedSentence",{s:["The journal","established","that","Selena","sincerely","complimented","those superintendents","on Thursday."]}, "Question",{q: "Was it those superintendents who complimented Selena?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.6", "DashedSentence",{s:["The evidence","proved","that","Taylor","maliciously","antagonized","those cobblers","on Friday."]}, "Question",{q: "Was it Taylor who was antagonized by those cobblers?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.7", "DashedSentence",{s:["The company","recognized","that","Ethan","arrogantly","corrected","those interpreters","on Saturday."]}, "Question",{q: "Was it Ethan who corrected those interpreters?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.8", "DashedSentence",{s:["The documentary","revealed","that","Olivia","loudly","lauded","those barbers","on Sunday."]}, "Question",{q: "Was it those barbers who were lauded by Olivia?", as:["yes","no"], hasCorrect: 0}]


];
