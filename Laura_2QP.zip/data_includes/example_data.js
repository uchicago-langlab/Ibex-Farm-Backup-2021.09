
//Eszter's (ask her for "practiceover" and "brexit"). Ask Ming for consent.
//var shuffleSequence = seq(sepWith("sep", seq("practice", rshuffle(startsWith("DO"), startsWith("IO"), startsWith("CLLD"), startsWith("FIL")))));

//var shuffleSequence = seq("setcounter","consent", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("e"),startsWith("f")))), "brexit");

var shuffleSequence = seq("introSTOP");

var practiceItemTypes = ["practice"];

var showProgressBar = true;

var defaults = [
    "Separator", {
        transfer: 750,
        normalMessage: " ",
        errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: " ",
        leftComment: "Inaceptable", rightComment: "Aceptable"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Clickeá para continuar"
    }
];

var items = [

	["setcounter", "__SetCounter__", { }],

    ["sep", "Separator", { }],

    ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }}],

    ["practiceover", "Form", {consentRequired: true, html: {include: "practiceover.html" }}],

    ["practicestarts", "Form", {consentRequired: true, html: {include: "practicestarts.html" }}],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html" }}],

    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }}],

    ["intro3", "Form", {consentRequired: true, html: {include: "intro3.html" }}],

    ["intro4", "Form", {consentRequired: true, html: {include: "intro4.html" }}],

    ["introSTOP", "Form", {consentRequired: true, html: {include: "introSTOP.html" }}],

    ["exit", "Form", {consentRequired: true, html: {include: "exit.html" }}],

    //
    // Three practice items for the Acceptability Judgment task:
    //
    ["practice", "AcceptabilityJudgment", {s: "Juan vio a los estudiantes que hablaron con el director después de clase."}],
    ["practice", "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al actor que el director de la obra viajó a Berlín."}],
    ["practice", "AcceptabilityJudgment", {s: "El médico ayudó a la enfermera que el paciente golpeó al policía a la salida del hospital."}],
    ["practice", "AcceptabilityJudgment", {s: "Los jueces condenaron al ladrón que mató a los estudiantes cuando escapaba."}],

    //
    // 24 experimental sets for the DO sub-experiment.
    // This is a 3x2 design: 6 conditions: 
    //

    [["DO.GAP.NI",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera ayudó en la prisión."}],
    [["DO.CL.NI",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera lo ayudó en la prisión."}],
    [["DO.GAP.CNP",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera que ayudó está presa."}],
    [["DO.CL.CNP",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera que lo ayudó está presa."}],
    [["DO.GAP.WH",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera no recuerda si ayudó en la prisión."}],
    [["DO.CL.WH",1], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al médico que la enfermera no recuerda si lo ayudó en la prisión."}],

    [["DO.GAP.NI",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente entrevistó en Paris."}],
    [["DO.CL.NI",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente lo entrevistó en Paris."}],
    [["DO.GAP.CNP",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente que entrevistó viajó a Paris."}],
    [["DO.CL.CNP",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente que lo entrevistó viajó a Paris."}],
    [["DO.GAP.WH",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente no recuerda si entrevistó en Paris."}],
    [["DO.CL.WH",2], "AcceptabilityJudgment", {s: "La cocinera contrató al mozo que el gerente no recuerda si lo entrevistó en Paris."}],

    [["DO.GAP.NI",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras premiaron por escribir un libro."}],
    [["DO.CL.NI",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras lo premiaron por escribir un libro."}],
    [["DO.GAP.CNP",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras que premiaron escribieron un libro."}],
    [["DO.CL.CNP",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras que lo premiaron escribieron un libro."}],
    [["DO.GAP.WH",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras no recuerdan si premiaron por escribir un libro."}],
    [["DO.CL.WH",3], "AcceptabilityJudgment", {s: "La directora vio al estudiante que las profesoras no recuerdan si lo premiaron por escribir un libro."}],

	[["DO.GAP.NI",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico golpeó cuando estaba borracho."}],
    [["DO.CL.NI",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico lo golpeó cuando estaba borracho."}],
    [["DO.GAP.CNP",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico que golpeó estaba borracho."}],
    [["DO.CL.CNP",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico que lo golpeó estaba borracho."}],
    [["DO.GAP.WH",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico no recuerda si golpeó cuando estaba borracho."}],
    [["DO.CL.WH",4], "AcceptabilityJudgment", {s: "La bailarina abrazó al actor que el músico no recuerda si lo golpeó cuando estaba borracho."}],

    [["DO.GAP.NI",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro denunció ante la prensa."}],
    [["DO.CL.NI",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro la denunció ante la prensa."}],
    [["DO.GAP.CNP",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro que denunció declaró ante la prensa."}],
    [["DO.CL.CNP",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro que la denunció declaró ante la prensa."}],
    [["DO.GAP.WH",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro no recuerda si denunció ante la prensa."}],
    [["DO.CL.WH",5], "AcceptabilityJudgment", {s: "El presidente ayudó a la senadora que el ministro no recuerda si la denunció ante la prensa."}],

    [["DO.GAP.NI",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón hirió en el asalto del banco."}],
    [["DO.CL.NI",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón lo hirió en el asalto del banco."}],
    [["DO.GAP.CNP",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón que hirió asaltó un banco."}],
    [["DO.CL.CNP",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón que lo hirió asaltó un banco."}],
    [["DO.GAP.WH",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón no recuerda si hirió en el asalto del banco."}],
    [["DO.CL.WH",6], "AcceptabilityJudgment", {s: "Las médicas visitaron al hombre que el ladrón no recuerda si lo hirió en el asalto del banco."}],

	[["DO.GAP.NI",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective persiguió en Barcelona."}],
    [["DO.CL.NI",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective los persiguió en Barcelona."}],
    [["DO.GAP.CNP",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective que persiguió vive en Barcelona."}],
    [["DO.CL.CNP",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective que los persiguió vive en Barcelona."}],
    [["DO.GAP.WH",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective no recuerda si persiguió en Barcelona."}],
    [["DO.CL.WH",7], "AcceptabilityJudgment", {s: "La policía capturó a los asesinos que el detective no recuerda si los persiguió en Barcelona."}],

    [["DO.GAP.NI",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso atacó en una plaza."}],
    [["DO.CL.NI",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso las atacó en una plaza."}],
    [["DO.GAP.CNP",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso que atacó se escondió en una plaza."}],
    [["DO.CL.CNP",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso que las atacó se escondió en una plaza."}],
    [["DO.GAP.WH",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso no recuerda si atacó en una plaza."}],
    [["DO.CL.WH",8], "AcceptabilityJudgment", {s: "Los abogados ayudaron a las chicas que el sospechoso no recuerda si las atacó en una plaza."}],

    [["DO.GAP.NI",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer reconoció en un restaurante."}],
    [["DO.CL.NI",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer los reconoció en un restaurante."}],
    [["DO.GAP.CNP",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer que reconoció trabaja en un restaurante."}],
    [["DO.CL.CNP",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer que los reconoció trabaja en un restaurante."}],
    [["DO.GAP.WH",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer no recuerda si reconoció en un restaurante."}],
    [["DO.CL.WH",9], "AcceptabilityJudgment", {s: "El policía interrogó a los sospechosos que la mujer no recuerda si los reconoció en un restaurante."}],

    [["DO.GAP.NI",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director felicitó por el premio Nobel."}],
    [["DO.CL.NI",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director las felicitó por el premio Nobel."}],
    [["DO.GAP.CNP",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director que felicitó ganó el premio Nobel."}],
    [["DO.CL.CNP",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director que las felicitó ganó el premio Nobel."}],
    [["DO.GAP.WH",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director no recuerda si felicitó por el premio Nobel."}],
    [["DO.CL.WH",10], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron a las médicas que el director no recuerda si las felicitó por el premio Nobel."}],

    [["DO.GAP.NI",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista acusó de corrupción el martes pasado."}],
    [["DO.CL.NI",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista lo acusó de corrupción el martes pasado."}],
    [["DO.GAP.CNP",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista que acusó de corrupción se fugó el martes pasado."}],
    [["DO.CL.CNP",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista que lo acusó de violencia se fugó el martes pasado."}],
    [["DO.GAP.WH",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista no recuerda si acusó de corrupción el martes pasado."}],
    [["DO.CL.WH",11], "AcceptabilityJudgment", {s: "Rodrigo vio al diputado que la periodista no recuerda si lo acusó de corrupción el martes pasado."}],

    [["DO.GAP.NI",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro premió por sus descubrimientos en Física."}],
    [["DO.CL.NI",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro los premió por sus descubrimientos en Física."}],
    [["DO.GAP.CNP",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro que premió por sus descubrimientos es físico."}],
    [["DO.CL.CNP",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro que los premió por sus descubrimientos es físico."}],
    [["DO.GAP.WH",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro no recuerda si premió por sus descubrimientos en Física."}],
    [["DO.CL.WH",12], "AcceptabilityJudgment", {s: "El presidente felicitó a los científicos que el ministro no recuerda si los premió por sus descubrimientos en Física."}],

    [["DO.GAP.NI",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos mataron mientras manejaba un auto."}],
    [["DO.CL.NI",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos la mataron mientras manejaba un auto."}],
    [["DO.GAP.CNP",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos que mataron manejaban un auto."}],
    [["DO.CL.CNP",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos que la mataron manejaban un auto."}],
    [["DO.GAP.WH",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos no recuerdan si mataron mientras manejaba un auto."}],
    [["DO.CL.WH",13], "AcceptabilityJudgment", {s: "El profesor reconoció a la mujer que los asesinos no recuerdan si la mataron mientras manejaba un auto."}],

	[["DO.GAP.NI",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos despidieron por recibir coimas."}],
    [["DO.CL.NI",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos lo despidieron por recibir coimas."}],
    [["DO.GAP.CNP",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos que despidieron recibieron coimas."}],
    [["DO.CL.CNP",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos que lo despidieron recibieron coimas."}],
    [["DO.GAP.WH",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos no recuerdan si despidieron por recibir coimas."}],
    [["DO.CL.WH",14], "AcceptabilityJudgment", {s: "La periodista entrevistó al empleado que los directivos no recuerdan si lo despidieron por recibir coimas."}],

    [["DO.GAP.NI",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer insultó en el hospital."}],
    [["DO.CL.NI",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer lo insultó en el hospital."}],
    [["DO.GAP.CNP",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer que insultó trabaja en el hospital."}],
    [["DO.CL.CNP",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer que lo insultó trabaja en el hospital."}],
    [["DO.GAP.WH",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer no recuerda si insultó en el hospital."}],
    [["DO.CL.WH",15], "AcceptabilityJudgment", {s: "Las enfermeras vieron al médico que la mujer no recuerda si lo insultó en el hospital."}],

    [["DO.GAP.NI",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas entrevistaron en México."}],
    [["DO.CL.NI",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas lo entrevistaron en México."}],
    [["DO.GAP.CNP",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas que entrevistaron trabajan en México."}],
    [["DO.CL.CNP",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas que lo entrevistaron trabajan en México."}],
    [["DO.GAP.WH",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas no recuerdan si entrevistaron en México."}],
    [["DO.CL.WH",16], "AcceptabilityJudgment", {s: "Sofía vio al modelo que los periodistas no recuerdan si lo entrevistaron en México."}],

	[["DO.GAP.NI",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez investigó por evasión en España."}],
    [["DO.CL.NI",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez la investigó por evasión en España."}],
    [["DO.GAP.CNP",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez que investigó por evasión vive en España."}],
    [["DO.CL.CNP",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez que la investigó por evasión vive en España."}],
    [["DO.GAP.WH",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez no recuerda si investigó por evasión en España."}],
    [["DO.CL.WH",17], "AcceptabilityJudgment", {s: "Fernando llamó a la senadora que el juez no recuerda si la investigó por evasión en España."}],
    
    [["DO.GAP.NI",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista recomendó para jugar en Racing."}],
    [["DO.CL.NI",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista los recomendó para jugar en Racing."}],
    [["DO.GAP.CNP",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista que recomendó juega en Racing."}],
    [["DO.CL.CNP",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista que los recomendó juega en Racing."}],
    [["DO.GAP.WH",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista no recuerda si recomendó para jugar en Racing."}],
    [["DO.CL.WH",18], "AcceptabilityJudgment", {s: "La prensa criticó a los entrenadores que el futbolista no recuerda si los recomendó para jugar en Racing."}],
    
    [["DO.GAP.NI",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón acuchilló en el Mercado Central."}],
    [["DO.CL.NI",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón la acuchilló en el Mercado Central."}],
    [["DO.GAP.CNP",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón que acuchilló trabajaba en el Mercado Central."}],
    [["DO.CL.CNP",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón que la acuchilló trabajaba en el Mercado Central."}],
    [["DO.GAP.WH",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón no recuerda si acuchilló en el Mercado Central."}],
    [["DO.CL.WH",19], "AcceptabilityJudgment", {s: "La médica salvó a la mujer que el ladrón no recuerda si la acuchilló en el Mercado Central."}],
    
    [["DO.GAP.NI",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer vio cuando robaba las joyas."}],
    [["DO.CL.NI",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer lo vio cuando robaba las joyas."}],
    [["DO.GAP.CNP",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer que vio robó las joyas."}],
    [["DO.CL.CNP",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer que lo vio robó las joyas."}],
    [["DO.GAP.WH",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer no recuerda si vio cuando robaba las joyas."}],
    [["DO.CL.WH",20], "AcceptabilityJudgment", {s: "Los jueces condenaron al acusado que la mujer no recuerda si lo vio cuando robaba las joyas."}],
    
    [["DO.GAP.NI",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada acusó por televisión."}],
    [["DO.CL.NI",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada acusó por televisión."}],
    [["DO.GAP.CNP",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada que acusó habló en televisión."}],
    [["DO.CL.CNP",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada que lo acusó habló en televisión."}],
    [["DO.GAP.WH",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada no recuerda si acusó por televisión."}],
    [["DO.CL.WH",21], "AcceptabilityJudgment", {s: "Las periodistas defendieron al actor que la abogada no recuerda si lo acusó por televisión."}],
    
	[["DO.GAP.NI",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria besó en la fiesta de fin de año."}],
    [["DO.CL.NI",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria lo besó en la fiesta de fin de año."}],
    [["DO.GAP.CNP",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria que besó organizó la fiesta de fin de año."}],
    [["DO.CL.CNP",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria que lo besó organizó la fiesta de fin de año."}],
    [["DO.GAP.WH",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria no recuerdan si besó en la fiesta de fin de año."}],
    [["DO.CL.WH",22], "AcceptabilityJudgment", {s: "Julia vio al empleado que la secretaria no recuerdan si lo besó en la fiesta de fin de año."}],

	[["DO.GAP.NI",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista entrevistó en Canadá."}],
    [["DO.CL.NI",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista la entrevistó en Canadá."}],
    [["DO.GAP.CNP",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista que entrevistó viajó a Canadá."}],
    [["DO.CL.CNP",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista que lo entrevistó viajó a Canadá."}],
    [["DO.GAP.WH",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista no recuerda si entrevistó en Canadá."}],
    [["DO.CL.WH",23], "AcceptabilityJudgment", {s: "El asesino envenenó a la actriz que el periodista no recuerda si lo entrevistó en Canadá."}],

	[["DO.GAP.NI",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza citó en la causa de las coimas."}],
    [["DO.CL.NI",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza los citó en la causa las coimas."}],
    [["DO.GAP.CNP",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza que citó está presa por coimas."}],
    [["DO.CL.CNP",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza que los citó está presa por coimas."}],
    [["DO.GAP.WH",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza no recuerda si citó en la causa de las coimas."}],
    [["DO.CL.WH",24], "AcceptabilityJudgment", {s: "Pedro vio a los abogados que la jueza no recuerda si los citó en la causa de las coimas."}],

    //
    // 24 experimental sets for the IO sub-experiment.
    // This is a 3x2 design: 6 conditions: 
    //

    [["IO.GAP.NI",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera entregó los informes en el hospital."}],
    [["IO.CL.NI",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera le entregó los informes en el hospital."}],
    [["IO.GAP.CNP",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera que entregó los informes trabaja en el hospital."}],
    [["IO.CL.CNP",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera que le entregó los informes trabaja en el hospital."}],
    [["IO.GAP.WH",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera no recuerda si entregó los informes en el hospital."}],
    [["IO.CL.WH",25], "AcceptabilityJudgment", {s: "Los directores vieron al cirujano al que la enfermera no recuerda si le entregó los informes en el hospital."}],

    [["IO.GAP.NI",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera regaló un libro sobre cocina italiana."}],
    [["IO.CL.NI",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera le regaló un libro sobre cocina italiana."}],
    [["IO.GAP.CNP",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera que regaló un libro viajó a Italia."}],
    [["IO.CL.CNP",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera que le regaló un libro viajó a Italia."}],
    [["IO.GAP.WH",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera no recuerda si regaló un libro sobre cocina italiana."}],
    [["IO.CL.WH",26], "AcceptabilityJudgment", {s: "Martín atendió al médico al que la enfermera no recuerda si le regaló un libro sobre cocina italiana."}],

    [["IO.GAP.NI",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente entregó las armas después de la batalla."}],
    [["IO.CL.NI",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente les entregó las armas después de la batalla."}],
    [["IO.GAP.CNP",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente que entregó las armas abandonó la batalla."}],
    [["IO.CL.CNP",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente que les entregó las armas abandonó la batalla."}],
    [["IO.GAP.WH",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente no recuerda si entregó las armas después de la batalla."}],
    [["IO.CL.WH",27], "AcceptabilityJudgment", {s: "La presidenta condecoró a los soldados a los que el teniente no recuerda si les entregó las armas después de la batalla."}],

    [["IO.GAP.NI",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante dio un ramo de flores cuando ganó un Oscar."}],
    [["IO.CL.NI",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante le dio un ramo de flores cuando ganó un Oscar."}],
    [["IO.GAP.CNP",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante que dio un ramo de flores ganó un Oscar."}],
    [["IO.CL.CNP",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante que le dio un ramo de flores ganó un Oscar."}],
    [["IO.GAP.WH",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante no se acuerda si dio un ramo de flores cuando ganó un Oscar."}],
    [["IO.CL.WH",28], "AcceptabilityJudgment", {s: "Los periodistas llamaron a la actriz a la que el cantante no se acuerda si le dio un ramo de flores cuando ganó un Oscar."}],

    [["IO.GAP.NI",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra contó la verdad sobre el incendio."}],
    [["IO.CL.NI",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra les contó la verdad sobre el incendio."}],
    [["IO.GAP.CNP",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra que contó la verdad murió en un incendio."}],
    [["IO.CL.CNP",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra que les contó la verdad murió en un incendio."}],
    [["IO.GAP.WH",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra no recuerda si contó la verdad sobre el incendio."}],
    [["IO.CL.WH",29], "AcceptabilityJudgment", {s: "Los maestros hablaron con los estudiantes a los que la maestra no recuerda si les contó la verdad sobre el incendio."}],

	[["IO.GAP.NI",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa devolvió el dinero robado de la caja fuerte."}],
    [["IO.CL.NI",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa le devolvió el dinero robado de la caja fuerte."}],
    [["IO.GAP.CNP",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa que devolvió el dinero robó una caja fuerte."}],
    [["IO.CL.CNP",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa que le devolvió el dinero robó una caja fuerte."}],
    [["IO.GAP.WH",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa no recuerda si devolvió el dinero robado de la caja fuerte."}],
    [["IO.CL.WH",30], "AcceptabilityJudgment", {s: "El policía habló con el hombre al que la sospechosa no recuerda si le devolvió el dinero robado de la caja fuerte."}],
    
	[["IO.GAP.NI",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra enseñó física cuántica después de clase."}],
    [["IO.CL.NI",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra le enseñó física cuántica después de clase."}],
    [["IO.GAP.CNP",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra que enseñó física cuántica da clases a la mañana."}],
    [["IO.CL.CNP",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra que le enseñó física cuántica da clases a la mañana."}],
    [["IO.GAP.WH",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra no recuerda si enseñó física cuántica después de clase."}],
    [["IO.CL.WH",31], "AcceptabilityJudgment", {s: "El director llamó al estudiante al que la maestra no recuerda si le enseñó física cuántica después de clase."}],
 
	[["IO.GAP.NI",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista pidió fotos de la gira por Asia."}],
    [["IO.CL.NI",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista le pidió fotos de la gira por Asia."}],
    [["IO.GAP.CNP",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista que pidió fotos de la gira viajó a Asia."}],
    [["IO.CL.CNP",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista que le pidió fotos de la gira viajó a Asia."}],
    [["IO.GAP.WH",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista no recuerda si pidió fotos de la gira por Asia."}],
    [["IO.CL.WH",32], "AcceptabilityJudgment", {s: "Las actrices denunciaron al cantante al que la periodista no recuerda si le pidió fotos de la gira por Asia."}],
 
	[["IO.GAP.NI",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos mostraron los informes secretos en Chicago."}],
    [["IO.CL.NI",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos le mostraron los informes secretos en Chicago."}],
    [["IO.GAP.CNP",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos que mostraron los informes secretos viven en Chicago."}],
    [["IO.CL.CNP",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos que le mostraron los informes secretos viven en Chicago."}],
    [["IO.GAP.WH",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos no recuerdan si mostraron los informes secretos en Chicago."}],
    [["IO.CL.WH",33], "AcceptabilityJudgment", {s: "Los jueces condenaron al profesor al que los científicos no recuerdan si le mostraron los informes secretos en Chicago."}],
 
 	[["IO.GAP.NI",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante ofreció sustancias ilegales en el hospital."}],
    [["IO.CL.NI",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante le ofreció sustancias ilegales en el hospital."}],
    [["IO.GAP.CNP",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante que ofreció sustancias ilegales trabaja en un hospital."}],
    [["IO.CL.CNP",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante que le ofreció sustancias ilegales trabaja en un hospital."}],
    [["IO.GAP.WH",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante no recuerda si ofreció sustancias ilegales en el hospital."}],
    [["IO.CL.WH",34], "AcceptabilityJudgment", {s: "Mariano vio al niño al que el traficante no recuerda si le ofreció sustancias ilegales en el hospital."}],
 
 	[["IO.GAP.NI",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria entregó las llaves de la oficina."}],
    [["IO.CL.NI",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria le entregó las llaves de la oficina."}],
    [["IO.GAP.CNP",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria que entregó las llaves faltó a la oficina."}],
    [["IO.CL.CNP",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria que le entregó las llaves faltó a la oficina."}],
    [["IO.GAP.WH",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria no recuerda si entregó las llaves de la oficina."}],
    [["IO.CL.WH",35], "AcceptabilityJudgment", {s: "Susana acusó al empleado al que la secretaria no recuerda si le entregó las llaves de la oficina."}],
 
 	[["IO.GAP.NI",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria solicitó el currículum para trabajar en el banco."}],
    [["IO.CL.NI",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria le solicitó el currículum para trabajar en el banco."}],
    [["IO.GAP.CNP",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria que solicitó el currículum trabaja en el banco."}],
    [["IO.CL.CNP",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria que le solicitó el currículum trabaja en el banco."}],
    [["IO.GAP.WH",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria no recuerda si solicitó el currículum para trabajar en el banco."}],
    [["IO.CL.WH",36], "AcceptabilityJudgment", {s: "Marta entrevistó al candidato al que la secretaria no recuerda si le solicitó el currículum para trabajar en el banco."}],
    
    [["IO.GAP.NI",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director ocultó la verdad sobre los medicamentos vencidos."}],
    [["IO.CL.NI",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director le ocultó la verdad sobre los medicamentos vencidos."}],
    [["IO.GAP.CNP",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director que ocultó la verdad vendió medicamentos vencidos."}],
    [["IO.CL.CNP",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director que le ocultó la verdad vendió medicamentos vencidos."}],
    [["IO.GAP.WH",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director no recuerda si ocultó la verdad sobre los medicamentos vencidos."}],
    [["IO.CL.WH",37], "AcceptabilityJudgment", {s: "La secretaria llamó al médico al que el director no recuerda si le ocultó la verdad sobre los medicamentos vencidos."}],
    
    [["IO.GAP.NI",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero robó las herramientas mientras trabajaba en la obra."}],
    [["IO.CL.NI",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero le robó las herramientas mientras trabajaba en la obra."}],
    [["IO.GAP.CNP",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero que robó las herramientas trabaja en la obra."}],
    [["IO.CL.CNP",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero que le robó las herramientas trabaja en la obra."}],
    [["IO.GAP.WH",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero no recuerda si robó las herramientas en la obra."}],
    [["IO.CL.WH",38], "AcceptabilityJudgment", {s: "Los ingenieros hablaron con el operario al que el obrero no recuerda si le robó las herramientas en la obra."}],
    
    [["IO.GAP.NI",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante dedicó una canción en el festival de Berlín."}],
    [["IO.CL.NI",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante le dedicó una canción en el festival de Berlín."}],
    [["IO.GAP.CNP",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante que dedicó una canción participó en el festival de Berlín."}],
    [["IO.CL.CNP",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante que le dedicó una canción participó en el festival de Berlín."}],
    [["IO.GAP.WH",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante no recuerda si dedicó una canción en el festival de Berlín."}],
    [["IO.CL.WH",39], "AcceptabilityJudgment", {s: "La productora eligió al actor al que la cantante no recuerda si le dedicó una canción en el festival de Berlín."}],
    
    [["IO.GAP.NI",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra dio un soborno en el Congreso."}],
    [["IO.CL.NI",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra le dio un soborno en el Congreso."}],
    [["IO.GAP.CNP",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra que dio un soborno trabaja en el Congreso."}],
    [["IO.CL.CNP",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra que le dio un soborno trabaja en el Congreso."}],
    [["IO.GAP.WH",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra no recuerda si dio un soborno en el Congreso."}],
    [["IO.CL.WH",40], "AcceptabilityJudgment", {s: "La jueza absolvió al policía al que la ministra no recuerda si le dio un soborno en el Congreso."}],

    [["IO.GAP.NI",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor entregó los exámenes de Biología."}],
    [["IO.CL.NI",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor les entregó los exámenes de Biología."}],
    [["IO.GAP.CNP",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor que entregó los exámenes enseña Biología."}],
    [["IO.CL.CNP",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor que les entregó los exámenes enseña Biología."}],
    [["IO.GAP.WH",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor no recuerda si entregó los exámenes de Biología."}],
    [["IO.CL.WH",41], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor no recuerda si les entregó los exámenes de Biología."}],
    
    [["IO.GAP.NI",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante mostró las nuevas canciones de su nuevo show."}],
    [["IO.CL.NI",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante le mostró las nuevas canciones de su nuevo show."}],
    [["IO.GAP.CNP",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante que mostró las nuevas canciones dio un show."}],
    [["IO.CL.CNP",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante que le mostró las nuevas canciones dio un show."}],
    [["IO.GAP.WH",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante no recuerda si mostró las nuevas canciones de su nuevo show."}],
    [["IO.CL.WH",42], "AcceptabilityJudgment", {s: "Martina fotografió a la modelo a la que el cantante no recuerda si le mostró las nuevas canciones de su nuevo show."}],
     
    [["IO.GAP.NI",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada ofreció pruebas de la corrupción en Chaco."}],
    [["IO.CL.NI",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada le ofreció pruebas de la corrupción en Chaco."}],
    [["IO.GAP.CNP",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada que ofreció pruebas de la corrupción vive en Chaco."}],
    [["IO.CL.CNP",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada que le ofreció pruebas de la corrupción vive en Chaco."}],
    [["IO.GAP.WH",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada no recuerda si ofreció pruebas de la corrupción en Chaco."}],
    [["IO.CL.WH",43], "AcceptabilityJudgment", {s: "La periodista habló con el ministro al que la diputada no recuerda si le ofreció pruebas de la corrupción en Chaco."}],
    
    [["IO.GAP.NI",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor ofreció ayuda en el examen de Matemáticas."}],
    [["IO.CL.NI",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor le ofreció ayuda en el examen de Matemáticas."}],
    [["IO.GAP.CNP",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor que ofreció ayuda en el examen enseña Matemáticas."}],
    [["IO.CL.CNP",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor que le ofreció ayuda en el examen enseña Matemáticas."}],
    [["IO.GAP.WH",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor no recuerda si ofreció ayuda en el examen de Matemáticas."}],
    [["IO.CL.WH",44], "AcceptabilityJudgment", {s: "Juan habló con el estudiante al que el profesor no recuerda si le ofreció ayuda en el examen de Matemáticas."}],
    
	[["IO.GAP.NI",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras regalaron flores para su cumpleaños."}],
    [["IO.CL.NI",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras le regalaron flores para su cumpleaños."}],
    [["IO.GAP.CNP",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras que regalaron flores organizaron el cumpleaños."}],
    [["IO.CL.CNP",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras que le regalaron flores organizaron el cumpleaños."}],
    [["IO.GAP.WH",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras no recuerdan si regalaron flores para su cumpleaños."}],
    [["IO.CL.WH",45], "AcceptabilityJudgment", {s: "Los estudiantes hablaron con la profesora a la que las directoras no recuerdan si le regalaron flores para su cumpleaños."}],
    
    [["IO.GAP.NI",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro entregó un premio por rescatar a las víctimas del incendio."}],
    [["IO.CL.NI",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro les entregó un premio por rescatar a las víctimas del incendio."}],
    [["IO.GAP.CNP",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro que entregó un premio se reunió con las víctimas del incendio."}],
    [["IO.CL.CNP",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro que les entregó un premio se reunió las víctimas del incendio."}],
    [["IO.GAP.WH",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro no recuerda si entregó un premio por rescatar a las víctimas del incendio."}],
    [["IO.CL.WH",46], "AcceptabilityJudgment", {s: "Felipe felicitó a los bomberos a los que el ministro no recuerda si les entregó un premio por rescatar a las víctimas del incendio."}],
    
    [["IO.GAP.NI",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor explicó la teoría de la relatividad antes del examen."}],
    [["IO.CL.NI",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor les explicó la teoría de la relatividad antes del examen."}],
    [["IO.GAP.CNP",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor que explicó la teoría de la relatividad tomó el examen."}],
    [["IO.CL.CNP",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor que les explicó la teoría de la relatividad tomó el examen."}],
    [["IO.GAP.WH",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor no recuerda si explicó la teoría de la relatividad antes del examen."}],
    [["IO.CL.WH",47], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor no recuerda si les explicó la teoría de la relatividad antes del examen."}],
    
    [["IO.GAP.NI",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro entregó información confidencial sobre el atentado."}],
    [["IO.CL.NI",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro le entregó información confidencial sobre el atentado."}],
    [["IO.GAP.CNP",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro que entregó información confidencial participó en el atentado."}],
    [["IO.CL.CNP",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro que le entregó información confidencial participó en el atentado."}],
    [["IO.GAP.WH",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro no recuerda si entregó información confidencial sobre el atentado."}],
    [["IO.CL.WH",48], "AcceptabilityJudgment", {s: "Matías llamó al periodista al que el ministro no recuerda si le entregó información confidencial sobre el atentado."}],
    
    //
    // 24 experimental sets for the CLLD sub-experiment.
    // This is a 3x2 design: 6 conditions: 
    //

    [["CLLD.GAP.NI",49], "AcceptabilityJudgment", {s: "A Juan, el director cree que los profesores vieron a la salida del colegio."}],
    [["CLLD.CL.NI",49], "AcceptabilityJudgment", {s: "A Juan, el director cree que los profesores lo vieron a la salida del colegio."}],
    [["CLLD.GAP.WH",49], "AcceptabilityJudgment", {s: "A Juan, el director no sabe si los profesores vieron a la salida del colegio."}],
    [["CLLD.CL.WH",49], "AcceptabilityJudgment", {s: "A Juan, el director no sabe si los profesores lo vieron a la salida del colegio."}],
    [["CLLD.GAP.RC",49], "AcceptabilityJudgment", {s: "A Juan, el director conoce a los profesores que vieron a la salida del colegio."}],
    [["CLLD.CL.RC",49], "AcceptabilityJudgment", {s: "A Juan, el director conoce a los profesores que lo vieron a la salida del colegio."}],

    [["CLLD.GAP.NI",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista dijo que la actriz criticó en una entrevista por la radio."}],
    [["CLLD.CL.NI",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista dijo que la actriz la criticó en una entrevista por la radio."}],
    [["CLLD.GAP.WH",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista no sabe si la actriz criticó en una entrevista por la radio."}],
    [["CLLD.CL.WH",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista no sabe si la actriz la criticó en una entrevista por la radio."}],
    [["CLLD.GAP.RC",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista habló con la actriz que criticó en una entrevista por la radio."}],
    [["CLLD.CL.RC",50], "AcceptabilityJudgment", {s: "A Sofía, la periodista habló con la actriz que la criticó en una entrevista por la radio."}],

    [["CLLD.GAP.NI",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores contaron que el director echó del colegio."}],
    [["CLLD.CL.NI",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores contaron que el director lo echó del colegio."}],
    [["CLLD.GAP.WH",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores no se acuerdan si el director echó del colegio."}],
    [["CLLD.CL.WH",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores no se acuerdan si el director lo echó del colegio."}],
    [["CLLD.GAP.RC",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores hablaron con el director que echó del colegio."}],
    [["CLLD.CL.RC",51], "AcceptabilityJudgment", {s: "A Marcelo, los profesores hablaron con el director que lo echó del colegio."}],

    [["CLLD.GAP.NI",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras creen que la médica curó de cáncer."}],
    [["CLLD.CL.NI",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras creen que la médica la curó de cáncer."}],
    [["CLLD.GAP.WH",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras no saben si la médica curó de cáncer."}],
    [["CLLD.CL.WH",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras no saben si la médica la curó de cáncer."}],
    [["CLLD.GAP.RC",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras hablaron con la médica que curó de cáncer."}],
    [["CLLD.CL.RC",52], "AcceptabilityJudgment", {s: "A Mariana, las enfermeras hablaron con la médica que la curó de cáncer."}],

	[["CLLD.GAP.NI",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada dijo que el mozo golpeó en el restaurante."}],
    [["CLLD.CL.NI",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada dijo que el mozo lo golpeó en el restaurante."}],
    [["CLLD.GAP.WH",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada no recuerda si el mozo golpeó en el restaurante."}],
    [["CLLD.CL.WH",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada no recuerda si el mozo lo golpeó en el restaurante."}],
    [["CLLD.GAP.RC",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada denunció al mozo que golpeó en el restaurante."}],
    [["CLLD.CL.RC",53], "AcceptabilityJudgment", {s: "A Oscar, la encargada denunció al mozo que lo golpeó en el restaurante."}],

    [["CLLD.GAP.NI",54], "AcceptabilityJudgment", {s: "A Matías, el portero cree que el contador mató el sábado a la noche."}],
    [["CLLD.CL.NI",54], "AcceptabilityJudgment", {s: "A Matías, el portero cree que el contador lo mató el sábado a la noche."}],
    [["CLLD.GAP.WH",54], "AcceptabilityJudgment", {s: "A Matías, el portero no sabe si el contador mató el sábado a la noche."}],
    [["CLLD.CL.WH",54], "AcceptabilityJudgment", {s: "A Matías, el portero no sabe si el contador lo mató el sábado a la noche."}],
    [["CLLD.GAP.RC",54], "AcceptabilityJudgment", {s: "A Matías, el portero vio al contador que mató el sábado a la noche."}],
    [["CLLD.CL.RC",54], "AcceptabilityJudgment", {s: "A Matías, el portero vio al contador que lo mató el sábado a la noche."}],
    
    [["CLLD.GAP.NI",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria dijo que el gerente contrató para la nueva sucursal."}],
    [["CLLD.CL.NI",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria dijo que el gerente la contrató para la nueva sucursal."}],
    [["CLLD.GAP.WH",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria no se acuerda si el gerente contrató para la nueva sucursal."}],
    [["CLLD.CL.WH",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria no se acuerda si el gerente la contrató para la nueva sucursal."}],
    [["CLLD.GAP.RC",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria habló con el gerente que contrató para la nueva sucursal."}],
    [["CLLD.CL.RC",55], "AcceptabilityJudgment", {s: "A Martina, la secretaria habló con el gerente que la contrató para la nueva sucursal."}],

 	[["CLLD.GAP.NI",56], "AcceptabilityJudgment", {s: "A Juan, el profesor cree que los estudiantes molestaron en el recreo."}],
    [["CLLD.CL.NI",56], "AcceptabilityJudgment", {s: "A Juan, el profesor cree que los estudiantes lo molestaron en el recreo."}],
    [["CLLD.GAP.WH",56], "AcceptabilityJudgment", {s: "A Juan, el profesor no sabe si los estudiantes molestaron en el recreo."}],
    [["CLLD.CL.WH",56], "AcceptabilityJudgment", {s: "A Juan, el profesor no sabe si los estudiantes lo molestaron en el recreo."}],
    [["CLLD.GAP.RC",56], "AcceptabilityJudgment", {s: "A Juan, el profesor llamó a los estudiantes que molestaron en el recreo."}],
    [["CLLD.CL.RC",56], "AcceptabilityJudgment", {s: "A Juan, el profesor llamó a los estudiantes que lo molestaron en el recreo."}],

	[["CLLD.GAP.NI",57], "AcceptabilityJudgment", {s: "A Fernando, la policía declaró que los sospechosos hirieron durante el asalto."}],
    [["CLLD.CL.NI",57], "AcceptabilityJudgment", {s: "A Fernando, la policía declaró que los sospechosos lo hirieron durante el asalto."}],
    [["CLLD.GAP.WH",57], "AcceptabilityJudgment", {s: "A Fernando, la policía no sabe si los sospechosos hirieron durante el asalto."}],
    [["CLLD.CL.WH",57], "AcceptabilityJudgment", {s: "A Fernando, la policía no sabe si los sospechosos lo hirieron durante el asalto."}],
    [["CLLD.GAP.RC",57], "AcceptabilityJudgment", {s: "A Fernando, la policía interrogó a los sospechosos que hirieron durante el asalto."}],
    [["CLLD.CL.RC",57], "AcceptabilityJudgment", {s: "A Fernando, la policía interrogó a los sospechosos que lo hirieron durante el asalto."}],
    
    [["CLLD.GAP.NI",58], "AcceptabilityJudgment", {s: "A Julia, la maestra dijo que el portero vio a la salida del colegio."}],
    [["CLLD.CL.NI",58], "AcceptabilityJudgment", {s: "A Julia, la maestra dijo que el portero la vio a la salida del colegio."}],
    [["CLLD.GAP.WH",58], "AcceptabilityJudgment", {s: "A Julia, la maestra no sabe si el portero vio a la salida del colegio."}],
    [["CLLD.CL.WH",58], "AcceptabilityJudgment", {s: "A Julia, la maestra no sabe si el portero la vio a la salida del colegio."}],
    [["CLLD.GAP.RC",58], "AcceptabilityJudgment", {s: "A Julia, la maestra habló con el portero que vio a la salida del colegio."}],
    [["CLLD.CL.RC",58], "AcceptabilityJudgment", {s: "A Julia, la maestra habló con el portero que la vio a la salida del colegio."}],

	[["CLLD.GAP.NI",59], "AcceptabilityJudgment", {s: "A Martina, los empleados piensan que el gerente besó en la fiesta de fin de año."}],
    [["CLLD.CL.NI",59], "AcceptabilityJudgment", {s: "A Martina, los empleados piensan que el gerente la besó en la fiesta de fin de año."}],
    [["CLLD.GAP.WH",59], "AcceptabilityJudgment", {s: "A Martina, los empleados no se acuerdan si el gerente besó en la fiesta de fin de año."}],
    [["CLLD.CL.WH",59], "AcceptabilityJudgment", {s: "A Martina, los empleados no se acuerdan si el gerente la besó en la fiesta de fin de año."}],
    [["CLLD.GAP.RC",59], "AcceptabilityJudgment", {s: "A Martina, los empleados vieron al gerente que besó en la fiesta de fin de año."}],
    [["CLLD.CL.RC",59], "AcceptabilityJudgment", {s: "A Martina, los empleados vieron al gerente que la besó en la fiesta de fin de año."}],
    
    [["CLLD.GAP.NI",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos dijeron que el cirujano operó del corazón el mes pasado."}],
    [["CLLD.CL.NI",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos dijeron que el cirujano la operó del corazón el mes pasado."}],
    [["CLLD.GAP.WH",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos no saben si el cirujano operó del corazón el mes pasado."}],
    [["CLLD.CL.WH",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos no saben si el cirujano la operó del corazón el mes pasado."}],
    [["CLLD.GAP.RC",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos hablaron con el cirujano que operó del corazón el mes pasado."}],
    [["CLLD.CL.RC",60], "AcceptabilityJudgment", {s: "A Mónica, los médicos hablaron con el cirujano que la operó del corazón el mes pasado."}],

	[["CLLD.GAP.NI",61], "AcceptabilityJudgment", {s: "A Julián, la policía cree que los bomberos rescataron del incendio en la fábrica."}],
    [["CLLD.CL.NI",61], "AcceptabilityJudgment", {s: "A Julián, la policía cree que los bomberos lo rescataron del incendio en la fábrica."}],
    [["CLLD.GAP.WH",61], "AcceptabilityJudgment", {s: "A Julián, la policía no sabe si los bomberos rescataron del incendio en la fábrica."}],
    [["CLLD.CL.WH",61], "AcceptabilityJudgment", {s: "A Julián, la policía no sabe si los bomberos lo rescataron del incendio en la fábrica."}],
    [["CLLD.GAP.RC",61], "AcceptabilityJudgment", {s: "A Julián, la policía vio a los bomberos que rescataron del incendio en la fábrica."}],
    [["CLLD.CL.RC",61], "AcceptabilityJudgment", {s: "A Julián, la policía vio a los bomberos que lo rescataron del incendio en la fábrica."}],

	[["CLLD.GAP.NI",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz dijo que los periodistas entrevistaron en Miami."}],
    [["CLLD.CL.NI",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz dijo que los periodistas lo entrevistaron en Miami."}],
    [["CLLD.GAP.WH",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz no recuerda si los periodistas entrevistaron en Miami."}],
    [["CLLD.CL.WH",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz no recuerda si los periodistas lo entrevistaron en Miami."}],
    [["CLLD.GAP.RC",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz llamó a los periodistas que entrevistaron en Miami."}],
    [["CLLD.CL.RC",62], "AcceptabilityJudgment", {s: "A Esteban, la actriz llamó a los periodistas que lo entrevistaron en Miami."}],
    
    [["CLLD.GAP.NI",63], "AcceptabilityJudgment", {s: "A Laura, la directora cree que el comité eligió para el puesto de gerente."}],
    [["CLLD.CL.NI",63], "AcceptabilityJudgment", {s: "A Laura, la directora cree que el comité la eligió para el puesto de gerente."}],
    [["CLLD.GAP.WH",63], "AcceptabilityJudgment", {s: "A Laura, la directora no sabe si el comité eligió para el puesto de gerente."}],
    [["CLLD.CL.WH",63], "AcceptabilityJudgment", {s: "A Laura, la directora no sabe si el comité la eligió para el puesto de gerente."}],
    [["CLLD.GAP.RC",63], "AcceptabilityJudgment", {s: "A Laura, la directora habló con el comité que eligió para el puesto de gerente."}],
    [["CLLD.CL.RC",63], "AcceptabilityJudgment", {s: "A Laura, la directora habló con el comité que la eligió para el puesto de gerente."}],

	[["CLLD.GAP.NI",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces creen que la diputada sobornó antes de las elecciones."}],
    [["CLLD.CL.NI",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces creen que la diputada lo sobornó antes de las elecciones."}],
    [["CLLD.GAP.WH",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces no saben si la diputada sobornó antes de las elecciones."}],
    [["CLLD.CL.WH",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces no saben si la diputada lo sobornó antes de las elecciones."}],
    [["CLLD.GAP.RC",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces citaron a la diputada que sobornó antes de las elecciones."}],
    [["CLLD.CL.RC",64], "AcceptabilityJudgment", {s: "A Rodrigo, los jueces citaron a la diputada que lo sobornó antes de las elecciones."}],

	[["CLLD.GAP.NI",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera dijo que la médica curó de una enfermedad terminal."}],
    [["CLLD.CL.NI",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera dijo que la médica lo curó de una enfermedad terminal."}],
    [["CLLD.GAP.WH",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera no recuerda si la médica curó de una enfermedad terminal."}],
    [["CLLD.CL.WH",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera no recuerda si la médica lo curó de una enfermedad terminal."}],
    [["CLLD.GAP.RC",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera vio a la médica que curó de una enfermedad terminal."}],
    [["CLLD.CL.RC",65], "AcceptabilityJudgment", {s: "A Mario, la enfermera vio a la médica que lo curó de una enfermedad terminal."}],

	[["CLLD.GAP.NI",66], "AcceptabilityJudgment", {s: "A Pedro, el productor cree que el director contrató para una nueva serie."}],
    [["CLLD.CL.NI",66], "AcceptabilityJudgment", {s: "A Pedro, el productor cree que el director lo contrató para una nueva serie."}],
    [["CLLD.GAP.WH",66], "AcceptabilityJudgment", {s: "A Pedro, el productor no se acuerda si el director contrató para una nueva serie."}],
    [["CLLD.CL.WH",66], "AcceptabilityJudgment", {s: "A Pedro, el productor no se acuerda si el director lo contrató para una nueva serie."}],
    [["CLLD.GAP.RC",66], "AcceptabilityJudgment", {s: "A Pedro, el productor llamó al director que contrató para una nueva serie."}],
    [["CLLD.CL.RC",66], "AcceptabilityJudgment", {s: "A Pedro, el productor llamó al director que lo contrató para una nueva serie."}],

	[["CLLD.GAP.NI",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista cree que el director siguió a la salida de un ensayo."}],
    [["CLLD.CL.NI",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista cree que el director la siguió a la salida de un ensayo."}],
    [["CLLD.GAP.WH",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista no sabe si el director siguió a la salida de un ensayo."}],
    [["CLLD.CL.WH",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista no sabe si el director la siguió a la salida de un ensayo."}],
    [["CLLD.GAP.RC",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista habló con el director que siguió a la salida de un ensayo."}],
    [["CLLD.CL.RC",67], "AcceptabilityJudgment", {s: "A Valeria, el pianista habló con el director que la siguió a la salida de un ensayo."}],
    
    [["CLLD.GAP.NI",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos dijeron que el productor eligió para el elenco de la obra."}],
    [["CLLD.CL.NI",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos dijeron que el productor la eligió para el elenco de la obra."}],
    [["CLLD.GAP.WH",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos no se acuerdan si el productor eligió para el elenco de la obra."}],
    [["CLLD.CL.WH",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos no se acuerdan si el productor la eligió para el elenco de la obra."}],
    [["CLLD.GAP.RC",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos llamaron al productor que eligió para el elenco de la obra."}],
    [["CLLD.CL.RC",68], "AcceptabilityJudgment", {s: "A Roxana, los músicos llamaron al productor que la eligió para el elenco de la obra."}],
    
    [["CLLD.GAP.NI",69], "AcceptabilityJudgment", {s: "A Julia, la maestra cree que los chicos golpearon en el recreo."}],
    [["CLLD.CL.NI",69], "AcceptabilityJudgment", {s: "A Julia, la maestra cree que los chicos la golpearon en el recreo."}],
    [["CLLD.GAP.WH",69], "AcceptabilityJudgment", {s: "A Julia, la maestra no se acuerda si los chicos golpearon en el recreo."}],
    [["CLLD.CL.WH",69], "AcceptabilityJudgment", {s: "A Julia, la maestra no se acuerda si los chicos la golpearon en el recreo."}],
    [["CLLD.GAP.RC",69], "AcceptabilityJudgment", {s: "A Julia, la maestra habló con los chicos que golpearon en el recreo."}],
    [["CLLD.CL.RC",69], "AcceptabilityJudgment", {s: "A Julia, la maestra habló con los chicos que la golpearon en el recreo."}],
    
    [["CLLD.GAP.NI",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas dicen que la modelo besó en un restaurante de Cancún."}],
    [["CLLD.CL.NI",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas dicen que la modelo lo besó en un restaurante de Cancún."}],
    [["CLLD.GAP.WH",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas no saben si la modelo besó en un restaurante de Cancún."}],
    [["CLLD.CL.WH",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas no saben si la modelo lo besó en un restaurante de Cancún."}],
    [["CLLD.GAP.RC",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas entrevistaron a la modelo que besó en un restaurante de Cancún."}],
    [["CLLD.CL.RC",70], "AcceptabilityJudgment", {s: "A Marcelo, los periodistas entrevistaron a la modelo que lo besó en un restaurante de Cancún."}],
    
    [["CLLD.GAP.NI",71], "AcceptabilityJudgment", {s: "A Juan, el ministro piensa que los diputados eligieron como ciudadano ilustre."}],
    [["CLLD.CL.NI",71], "AcceptabilityJudgment", {s: "A Juan, el ministro piensa que los diputados lo eligieron como ciudadano ilustre."}],
    [["CLLD.GAP.WH",71], "AcceptabilityJudgment", {s: "A Juan, el ministro no se acuerda si los diputados eligieron como ciudadano ilustre."}],
    [["CLLD.CL.WH",71], "AcceptabilityJudgment", {s: "A Juan, el ministro no se acuerda si los diputados lo eligieron como ciudadano ilustre."}],
    [["CLLD.GAP.RC",71], "AcceptabilityJudgment", {s: "A Juan, el ministro habló con los diputados que eligieron como ciudadano ilustre."}],
    [["CLLD.CL.RC",71], "AcceptabilityJudgment", {s: "A Juan, el ministro habló con los diputados que lo eligieron como ciudadano ilustre."}],
    
    [["CLLD.GAP.NI",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles creen que el pintor estafó el año pasado."}],
    [["CLLD.CL.NI",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles creen que el pintor lo estafó el año pasado."}],
    [["CLLD.GAP.WH",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles no saben si el pintor estafó el año pasado."}],
    [["CLLD.CL.WH",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles no saben si el pintor lo estafó el año pasado."}],
    [["CLLD.GAP.RC",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles vieron al pintor que estafó el año pasado."}],
    [["CLLD.CL.RC",72], "AcceptabilityJudgment", {s: "A Oscar, los albañiles vieron al pintor que lo estafó el año pasado."}],
    
    //
    /// 24 Fillers
    //

	[["FIL",73], "AcceptabilityJudgment", {s: "Romina conoce a los periodistas que hablaron con el cantante después de la gira."}],
	[["FIL",74], "AcceptabilityJudgment", {s: "Tamara habló con las enfermeras que ganaron un premio por sus servicios en el hospital."}],
	[["FIL",75], "AcceptabilityJudgment", {s: "Federico vio a los operarios que murieron en el accidente causado por la grúa."}],
	[["FIL",76], "AcceptabilityJudgment", {s: "Los médicos no saben si la enfermera vio al paciente salir de la clínica después de la operación."}],
	[["FIL",77], "AcceptabilityJudgment", {s: "Esteban no se acuerda si los profesores felicitaron al estudiante que ganó un concurso literario."}],
	[["FIL",78], "AcceptabilityJudgment", {s: "Los ministros no saben si el presidente felicitó a los científicos que descubrieron un nuevo planeta."}],
	[["FIL",79], "AcceptabilityJudgment", {s: "La enfermera dijo que los bomberos salvaron a Juan de morir en el incendio en la fábrica."}],
	[["FIL",80], "AcceptabilityJudgment", {s: "Los profesores creen que los estudiantes insultaron al director del colegio después de clase."}],
	[["FIL",81], "AcceptabilityJudgment", {s: "Los periodistas contaron que los diputados sobornaron al juez para que no cuente la verdad."}],
	[["FIL",82], "AcceptabilityJudgment", {s: "Sofía vio al hombre que golpeó a Mariano cuando salía de un restaurant el sábado a la noche."}],
	[["FIL",83], "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al abogado que defendió a la actriz de las acusaciones en su contra."}],
	[["FIL",84], "AcceptabilityJudgment", {s: "Fernando aplaudió al boxeador que derrotó al campeón mundial en la última pelea del año."}],
	[["FIL",85], "AcceptabilityJudgment", {s: "La policía vio al médico que la secretaria besó al director del hospital en la reunión."}],
	[["FIL",86], "AcceptabilityJudgment", {s: "Bruno golpeó a los estudiantes que el profesor aprobó a todos en el examen de Historia."}],
	[["FIL",87], "AcceptabilityJudgment", {s: "Los empleados ayudaron al jefe que el gerente despidió a la secretaria por llegar tarde al trabajo."}],
	[["FIL",88], "AcceptabilityJudgment", {s: "Juan vio a los obreros que el ingeniero no recuerda si Martín compró un terreno en el Sur."}],
	[["FIL",89], "AcceptabilityJudgment", {s: "Las actrices abrazaron al productor que Mariano no sabe si la serie saldrá el año que viene."}],
	[["FIL",90], "AcceptabilityJudgment", {s: "Laura besó al empleado que el secretario no recuerda si contrató al abogado."}],
	[["FIL",91], "AcceptabilityJudgment", {s: "Juan habló con los estudiantes a los que el profesor envió cuando pasaron de año."}],
	[["FIL",92], "AcceptabilityJudgment", {s: "Martina denunció a los senadores a los que el presidente dedicó sin su consentimiento."}],
	[["FIL",93], "AcceptabilityJudgment", {s: "Los policías detuvieron al acusado al que la jueza envió en televisión."}],
	[["FIL",94], "AcceptabilityJudgment", {s: "A Juan, el árbitro escuchó el rumor de que los jugadores golpearon sin motivos."}],
	[["FIL",95], "AcceptabilityJudgment", {s: "A Martina, los periodistas contaron la noticia de que la jueza citó a declarar."}],
	[["FIL",96], "AcceptabilityJudgment", {s: "A Matías, la abogada escuchó el rumor de que los médicos operaron del corazón."}]

];
