/* This software is licensed under a BSD license; see the LICENSE file for details. */

define_ibex_controller({
name: "AcceptabilityJudgment_Overt",

jqueryWidget: {
    _init: function () {
        var opts = {
            options:     this.options,
            triggers:    [1],
            children:    [this.options._dashed ? "DashedSentence" : "FlashSentence",
                          this.options._dashed ? {
                                                     s: this.options.s,
                                                     mode: this.options.mode,
                                                     display: this.options.display,
                                                     blankText: this.options.blankText,
                                                     wordTime: this.options.wordTime,
                                                     wordPauseTime: this.options.wordPauseTime,
                                                     sentenceDescType: this.options.sentenceDescType,
                                                     showAhead: this.options.showAhead,
                                                     showBehind: this.options.showBehind
                                                 } :
                                                 {
                                                     s: this.options.s,
                                                     timeout: null, // Already present for 'Question'
                                                     audio: this.options.audio,
                                                     audioMessage: this.options.audioMessage,
                                                     audioTrigger: this.options.audioTrigger
                                                 },
                          this.options._dashed ? "!Question_Overt" : (this.options.s.audio ? "*Question_Overt" : "Question_Overt"),
                          { q:                   this.options.q,
                            as:                  this.options.as,
                            hasCorrect:          dget(this.options, "hasCorrect", false),
                            presentAsScale:      false,
                            presentHorizontally: true,
                            autoFirstChar:       true,
                            randomOrder:         false,
                            showNumbers:         false,
                            timeout:             this.options.timeout,
                            instructions:        this.options.instructions,
                            leftComment:         this.options.leftComment,
                            rightComment:        this.options.rightComment }]/*,
            manipulators: [
                [0, function(div) { div.css('font-size', "larger"); return div; }]
            ]*/
        };

        this.element.VBox(opts);
    }
},

properties: {
    obligatory: ["s", "as"],
    htmlDescription:
        function (opts) {
            var s = ibex_controller_get_property("FlashSentence", "htmlDescription")(opts);
            var q = ibex_controller_get_property("Question_Overt", "htmlDescription")(opts);
            var p =
                $("<p>")
                .append($("<p>").append("Q: ").append($(q)))
                .append("<br>").append($("<b>").text("S:"))
                .append($(s));
             return p;
        }
}
});