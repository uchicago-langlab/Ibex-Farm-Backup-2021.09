var shuffleSequence = seq("setcounter","Intro1","Intro2","Intro","Intro3","Intro4","Intro5","Intro6","practice", rshuffle(startsWith("imp"),startsWith("f"),startsWith("sub")),"Exit")

//var counterOverride = 3;
var ds = DashedSentence;
var q = Question;



var defaults = [
    Separator,{ignoreFailure: true},
    q,{hasCorrect: true, randomOrder: true},
    ds,{mode: "self-paced reading", display: "dashed"},
    "Message", {
        hideProgressBar: true
 
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        randomOrder: false,
        instructions: "Click boxes to answer.",
        leftComment: "(Highly Unlikely)", rightComment: "(Highly Likely)"
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
   
];

var items = [
["setcounter", "__SetCounter__", { }],   
["Intro0", "Form", {consentRequired: true, html: {include: "intro1_norm.html" }} ],  
["Intro1", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["Intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],    
["Intro3", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],  
["Intro4", "Form", {consentRequired: true, html: {include: "intro4.html" }} ], 
["Intro5", "Form", {consentRequired: true, html: {include: "intro5.html" }} ],    
["Intro6", "Form", {consentRequired: true, html: {include: "intro6.html" }} ],      
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],


 ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Mike told Stacey that he felt like going out for dinner that night."],
          ]},
          ds, { s: "Stacey replied that she had had a big lunch that day."},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Stacey will go out to dinner with Mike?"}}],                          
  
  ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Not today, thanks'', it means that you think it is unlikely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."], 
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Sure, but let's get something light like a salad'', it means that you think it is likely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                           ["p", "If on the other hand you were not sure how Myke should have interpreted Stacey's answer, you should have clicked on button 4."],
   
                           ["p", "Press any key to move on to the next example."]
                           ]}],                      
                          
 
   ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Cecilia asked his boss if she could get a raise."],
          ]},
          ds, { s: "Her boss replied that the company had just acquired expensive new equipment."},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Cecilia's boss will give her a raise?"}}],                          
    
                          
    ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sorry, we just spent a lot of money and we cannot afford to give you a raise right now'', it means that you think it's very unlikely that she will receive a raise. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."],
                            
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sure, we now have a lot of money to invest in the company'', it means that you think it's very likely that she will receive a raise. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                            
                           ["p", "If on the other hand you were not sure how Cecilia should have interpreted her boss' answer, you should have clicked on button 4."],
                           ["p", "Press any key to move on to the next example."]
                           ]}],                                          
  

   ["xep", Separator, {transfer: 2000, normalMessage: "Now you are ready to begin!" }],    
    
    
[ [ "impr_a", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],                        
                     ]},
                     ds, { s:  "The nurse replied that 10 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 10 patients waitlisted, no more and no fewer?"}}],
 
[ [ "impr_b", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 100 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 100 patients waitlisted, no more and no fewer?"}}],

[ [ "impr_c", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 1,000 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 1,000 patients waitlisted, no more and no fewer?"}}],

[ [ "impr_d", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 10 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 10 patients waitlisted, no more and no fewer?"}}],
 
[ [ "impr_e", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 100 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 100 patients waitlisted, no more and no fewer?"}}],

[ [ "impr_f", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 1,000 patients were currently waitlisted."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 1,000 patients waitlisted, no more and no fewer?"}}],
                    
[ [ "impr_a", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 200 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 200 dollars, no more and no less?"}}],
   
                    
[ [ "impr_b", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 2,000 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 2,000 dollars, no more and no less?"}}],
                                       
[ [ "impr_c", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 20,000 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 20,000 dollars, no more and no less?"}}], 
                    
[ [ "impr_d", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 200 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 200 dollars, no more and no less?"}}],
   
                    
[ [ "impr_e", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 2,000 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 2,000 dollars, no more and no less?"}}],       
                                       
[ [ "impr_f", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 20,000 dollars less per year."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that Peet's yearly salary reduction would be exactly 20,000 dollars, no more and no less?"}}],
                  
[ [ "impr_a", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 30 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 30 points, no more and no fewer?"}}],
                    
                  
[ [ "impr_b", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 300 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 300 points, no more and no fewer?"}}],
                    
                  
[ [ "impr_c", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 3,000 points, no more and no fewer?"}}],
                    
                  
[ [ "impr_d", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 30 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 30 points, no more and no fewer?"}}],
                  
[ [ "impr_e", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 300 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 300 points, no more and no fewer?"}}],
                                
[ [ "impr_f", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 3,000 points, no more and no fewer?"}}],
                  
[ [ "impr_a", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 50 gallons on a daily basis."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 50 gallons of milk, no more and no fewer?"}}],
                 
[ [ "impr_b", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 500 gallons on a daily basis."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 500 gallons of milk, no more and no fewer?"}}],
                  
[ [ "impr_c", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 5,000 gallons on a daily basis."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 5,000 gallons of milk, no more and no fewer?"}}], 
                  
[ [ "impr_d", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 50 gallons on a daily basis."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 50 gallons of milk, no more and no fewer?"}}],  
                  
[ [ "impr_e", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 500 gallons on a daily basis."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 500 gallons of milk, no more and no fewer?"}}],                           
                  
[ [ "impr_f", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 5,000 gallons on a daily basis."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 5,000 gallons of milk, no more and no fewer?"}}],  
                                                                                                    
[ [ "impr_a", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 400, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 4,000, not more and not fewer?"}}],

                                                                                                    
[ [ "impr_c", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 40,000, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_d", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 400, not more and not fewer?"}}],
                                                                                                 
[ [ "impr_e", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 4,000, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_f", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 40,000, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 400 dollars, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 4,000 dollars, not more and not fewer?"}}],
                                                                                                                    
[ [ "impr_c", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 40,000 dollars, not more and not fewer?"}}],
                                                                                                                    
[ [ "impr_d", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 400 dollars, not more and not fewer?"}}],
                                                                                                                    
[ [ "impr_e", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 4,000 dollars, not more and not fewer?"}}],
                                                                                                                                                     
[ [ "impr_f", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 40,000 dollars, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 900 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 900 people had participated, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 9,000 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 9,000 people had participated, not more and not fewer?"}}],
                                                                                                                                      
[ [ "impr_c", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 90,000 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 90,000 people had participated, not more and not fewer?"}}],
                                                                                                                                      
[ [ "impr_d", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 900 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 900 people had participated, not more and not fewer?"}}],
                                                                                                                                      
[ [ "impr_e", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 9,000 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 9,000 people had participated, not more and not fewer?"}}],
                                                                                                                                             
[ [ "impr_f", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 90,000 people had submitted their answers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 90,000 people had participated, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 60 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 60 dollars the last time she played, not more and not fewer? "}}],
                                                                                                     
[ [ "impr_b", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 600 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 600 dollars the last time she played, not more and not fewer? "}}],
                                                                                                         
[ [ "impr_c", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 6,000 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 6,000 dollars the last time she played, not more and not fewer? "}}], 
                                                                                                         
[ [ "impr_d", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 60 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 60 dollars the last time she played, not more and not fewer? "}}],
                                                                                                         
[ [ "impr_e", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 600 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 600 dollars the last time she played, not more and not fewer? "}}],
                                                                                                                
[ [ "impr_f", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 6,000 dollars the last time she played."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 6,000 dollars the last time she played, not more and not fewer? "}}],
                                                                                                    
[ [ "impr_a", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 70 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 70 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 700 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 700 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                                     
[ [ "impr_c", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 7,000 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 7,000 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                                     
[ [ "impr_d", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 70 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 70 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                                     
[ [ "impr_e", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 700 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 700 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                                         
[ [ "impr_f", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 7,000 people had voted there that day."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 7,000 people had voted that day at the precinct, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 10 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 10 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 100 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 100 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                        
[ [ "impr_c", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 1,000 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 1,000 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                        
[ [ "impr_d", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 10 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 10 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                        
[ [ "impr_e", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 100 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 100 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                                      
[ [ "impr_f", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 1,000 pounds at the time."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 1,000 pounds of cocaine in his apartment, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 80 feet, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 800 feet, not more and not fewer?"}}],
                                                                                                      
[ [ "impr_c", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 8,000 feet, not more and not fewer?"}}],
                                                                                                      
[ [ "impr_d", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 80 feet, not more and not fewer?"}}],
                                                                                                      
[ [ "impr_e", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 800 feet, not more and not fewer?"}}],
                                                                                                                 
[ [ "impr_f", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 8,000 feet, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_a", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 900 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 900 gallons had been spilled, not more and not fewer?"}}],
                                                                                                    
[ [ "impr_b", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 9,000 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 9,000 gallons had been spilled, not more and not fewer?"}}],
                                                                                                       
[ [ "impr_c", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 90,000 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 90,000 gallons had been spilled, not more and not fewer?"}}],
                                                                                                       
[ [ "impr_d", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 900 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 900 gallons had been spilled, not more and not fewer?"}}],
                                                                                                       
[ [ "impr_e", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 9,000 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 9,000 gallons had been spilled, not more and not fewer?"}}],
                                                                                                           
[ [ "impr_f", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 90,000 gallons had been spilled."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 90,000 gallons had been spilled, not more and not fewer?"}}],
                                                                                                   
[ [ "impr_a", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 500 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 500 rows long, not more and not fewer?"}}],
                                                                                                   
[ [ "impr_b", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 5,000 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 5,000 rows long, not more and not fewer?"}}],
                                                                                                                          
[ [ "impr_c", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 50,000 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 50,000 rows long, not more and not fewer?"}}],
                                                                                                                          
[ [ "impr_d", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 500 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 500 rows long, not more and not fewer?"}}],
                                                                                                                          
[ [ "impr_e", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 5,000 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 5,000 rows long, not more and not fewer?"}}],
                                                                                                                             
[ [ "impr_f", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 50,000 rows not including headers."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 50,000 rows long, not more and not fewer?"}}],
                                                                                                   
[ [ "impr_a", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 200 was the age of the artifact."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 200 years old, no more and no less? "}}],
                                                                                                                                                                                                                                   
[ [ "impr_b", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 2,000 was the age of the artifact."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 2,000 years old, no more and no less? "}}],
                                                                                                                                
[ [ "impr_c", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 20,000 was the age of the artifact."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 20,000 years old, no more and no less? "}}],
                                                                                                                                
[ [ "impr_d", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 200 was the age of the artifact."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 200 years old, no more and no less? "}}],
                                                                                                                                
[ [ "impr_e", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 2,000 was the age of the artifact."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 2,000 years old, no more and no less? "}}],
                                                                                                                                         
[ [ "impr_f", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 20,000 was the age of the artifact."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 20,000 years old, no more and no less? "}}],
                                                                                         
[ [ "impr_a", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 30 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 30 degrees, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 300 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 300 degrees, no more and no less?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                   
[ [ "impr_c", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 3,000 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 3,000 degrees, no more and no less?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
[ [ "impr_d", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 30 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 30 degrees, no more and no less?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
[ [ "impr_e", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 300 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 300 degrees, no more and no less?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
[ [ "impr_f", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 3,000 degrees was the target temperature."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 3,000 degrees, no more and no less?"}}],
                                                                           
[ [ "impr_a", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 700 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 700 clicks, not more and not fewer?"}}],
                                                                                                   
[ [ "impr_b", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 7,000 clicks, not more and not fewer?"}}],
                                                                                                         
[ [ "impr_c", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 70,000 clicks, not more and not fewer?"}}],
                                                                                                         
[ [ "impr_d", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 700 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 700 clicks, not more and not fewer?"}}],
                                                                                                         
[ [ "impr_e", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 7,000 clicks, not more and not fewer?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
[ [ "impr_f", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 70,000 clicks, not more and not fewer?"}}],
                                                                                                   
[ [ "impr_a", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 20 chairs in the main room."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 20 chairs, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 200 chairs in the main room."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 200 chairs, no more and no less?"}}],
                                                                                                                  
[ [ "impr_c", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 2,000 chairs, no more and no less?"}}],
                                                                                                                  
[ [ "impr_d", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 20 chairs in the main room."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 20 chairs, no more and no less?"}}],
                                                                                                                  
[ [ "impr_e", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 200 chairs in the main room."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 200 chairs, no more and no less?"}}],
                                                                                                                    
[ [ "impr_f", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 2,000 chairs, no more and no less?"}}],
                                                                                                   
[ [ "impr_a", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 30 rooms, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 300 rooms, no more and no less?"}}],
                                                                                                                           
[ [ "impr_c", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 3,000 rooms, no more and no less?"}}],
                                                                                                                           
[ [ "impr_d", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 30 rooms, no more and no less?"}}],
                                                                                                                           
[ [ "impr_e", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 300 rooms, no more and no less?"}}],
                                                                                                                                               
[ [ "impr_f", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 3,000 rooms, no more and no less?"}}],
                                                                                                   
[ [ "impr_a", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 80 Democrats would attend the event."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 80 Democrats would attend the event, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 800 Democrats would attend the event."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 800 Democrats would attend the event, no more and no less?"}}],
                                                                                                        
[ [ "impr_c", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 8,000 Democrats would attend the event."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 8,000 Democrats would attend the event, no more and no less?"}}], 
                                                                                                        
[ [ "impr_d", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 80 Democrats would attend the event."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 80 Democrats would attend the event, no more and no less?"}}],
                                                                                                        
[ [ "impr_e", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 800 Democrats would attend the event."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 800 Democrats would attend the event, no more and no less?"}}],
                                                                                                          
[ [ "impr_f", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 8,000 Democrats would attend the event."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 8,000 Democrats would attend the event, no more and no less?"}}],
                                                                                                   
[ [ "impr_a", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 60 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 60 stamps, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 600 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 600 stamps, no more and no less?"}}],
                                                                                                                          
[ [ "impr_c", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 6,000 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 6,000 stamps, no more and no less?"}}], 
                                                                                                                          
[ [ "impr_d", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 60 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 60 stamps, no more and no less?"}}],
                                                                                                                          
[ [ "impr_e", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 600 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 600 stamps, no more and no less?"}}],
                                                                                                                                   
[ [ "impr_f", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 6,000 stamps at a very good price."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 6,000 stamps, no more and no less?"}}],
                                                                                                   
[ [ "impr_a", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 90 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 90 units of blood had been contaminated in the flood, no more and no less? "}}], 
                                                                                                  
[ [ "impr_b", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 900 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 900 units of blood had been contaminated in the flood, no more and no less? "}}],
                                                                                                             
[ [ "impr_c", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 9,000 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 9,000 units of blood had been contaminated in the flood, no more and no less? "}}],
                                                                                                             
[ [ "impr_d", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 90 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 90 units of blood had been contaminated in the flood, no more and no less? "}}],
                                                                                                             
[ [ "impr_e", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 900 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 900 units of blood had been contaminated in the flood, no more and no less? "}}],
                                                                                                                    
[ [ "impr_f", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 9,000 units had been contaminated."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 9,000 units of blood had been contaminated in the flood, no more and no less? "}}],
                                                                                                   
[ [ "impr_a", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 60 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 60 accounts had been stolen, no more and no less?"}}],
                                                                                                  
[ [ "impr_b", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 600 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 600 accounts had been stolen, no more and no less?"}}],
                                                                                                                
[ [ "impr_c", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 6,000 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 6,000 accounts had been stolen, no more and no less?"}}],
                                                                                                                
[ [ "impr_d", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 60 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 60 accounts had been stolen, no more and no less?"}}],
                                                                                                               
[ [ "impr_e", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 600 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 600 accounts had been stolen, no more and no less?"}}],
                                                                                                                         
[ [ "impr_f", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 6,000 accounts had been stolen."},
                    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that information from exactly 6,000 accounts had been stolen, no more and no less?"}}],
                                                                                                   
[ [ "impr_a", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 50 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 50 students had gotten the message, no more and no less? "}}], 
                                                                                                   
[ [ "impr_b", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 500 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 500 students had gotten the message, no more and no less? "}}],
                                                                                                                    
[ [ "impr_c", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 5,000 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 5,000 students had gotten the message, no more and no less? "}}],
                                                                                                                    
[ [ "impr_d", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 50 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 50 students had gotten the message, no more and no less? "}}],
                                                                                                                    
[ [ "impr_e", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 500 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 500 students had gotten the message, no more and no less? "}}],
                                                                                                                                                         
[ [ "impr_f", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 5,000 students had gotten the message."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 5,000 students had gotten the message, no more and no less? "}}],
                                                                                                   
[ [ "impr_a", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 40 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
                                                                                                   
[ [ "impr_b", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 400 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 400 views, no more and no less?"}}],
                                                                                                             
[ [ "impr_c", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 4,000 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 4,000 views, no more and no less?"}}],
                                                                                                             
[ [ "impr_d", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 40 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
                                                                                                            
[ [ "impr_e", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 400 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 400 views, no more and no less?"}}],
                                                                                                                 
[ [ "impr_f", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 4,000 views from several countries."},
                    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
 
[ [ "f_1", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Gertrude had been driving all day to visit her family in upstate New York. She had planned to get there by around dinner time, but she got lost, and it was now very late. While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was."],
                          
                          ]},
                    ds, { s: "The map showed that the nearest lodge was still several miles away."} , "Question", {q: "What was several miles away?", as: ["Lodge", "Hostel", "Cabin"]}],
                           
[ [ "f_1", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Iz had been reading about various airplanes, and was fascinated when she found out that many airplanes could be identified simply by the noises they made. She soon taught herself the noise every airplane model made, and in order to see how much she learned, Iz went outside and tested herself to see exactly how many airplane noises she could identify."],
                          
                          ]},
                    ds, { s: "She found that she could identify every airplane noise."} , "Question", {q: "What type of sound is Iz identifying?", as: ["Airplane noises", "Car horns", "Train whistles"]}],
  
[ [ "f_1", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Kevin was doing a research paper about all the sucessful coups d'etat that had ever happened in history. As Kevin was doing his research, he noticed that he never saw any mention of America, so he became curious if America had ever had a successful coup d'etat. So Kevin went to the library to find out exactly how many successful coups d'etat there had been in American history."],
                          
                          ]},
                    ds, { s: "He learned that there had been none."} , "Question", {q: "How many coups d'etat have there been in American history?", as: ["Zero", "One", "Two"]}],
  
[ [ "f_1", 28 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Pat told his parents that he wanted to be a politician. His parents suggested that if he wanted to get involved in politics, a good way to start would be to help with another politician's campaign, so he signed up to be on Jim Gilmore's campaign team. Each day, members of the campaign team got various assignments, and his assignment was to go door to door to talk to people and convince them to vote for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day."],
                          
                          ]},
                    ds, { s: "Pat answered that he had knocked on an enormous number of doors."} , "Question", {q: "Who is Pat campaigning for?", as: ["Jim Gilmore", "Lincoln Chafee", "Lawrence Lessig"]}],
  
[ [ "f_2", 29 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Angela was talking to her friend, Elsa, and they were arguing about how many hours students spent procrastinating. Elsa was arguing that students spent a great deal of time procrastinating, and Angela thought, on average, students didn't spend that much time procrastinating, so Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating."],
                          
                          ]},
                    ds, { s: "She found that the average student procrastinates an average of 20 hours per week."} , "Question", {q: "What did Angela study?", as: ["Procrastination", "Sleeping", "Eating"]}],

[ [ "f_2", 30 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Finals were about two weeks away, and Zach just spilled a cup of coffee all over his laptop. He didn't have a lot of money saved, but he wouldn't be able to get through finals without his laptop with all of his notes and papers from this term. When he took his computer to the computer repair store, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop."],
                          
                          ]},
                    ds, { s: "The agent told him that it would probably cost him 500 dollars."} , "Question", {q: "What does Zach need repaired?", as: ["Laptop", "Refrigerator", "Car"]}],

[ [ "f_2", 31 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "William loved learning about different historical periods, and was currently reading about famous train heists. He knew Jesse James committed a major train heist, but he wasn't sure how much money he had stolen, so he looked up curiously how many dollars Jesse James had stolen in his robbery."],
                          
                          ]},
                    ds, { s: "He learned that the estimate was that 3,000 dollars had been taken."} , "Question", {q: "Who is William studying?", as: ["Jesse James", "Walter White", "Al Capone"]}],
 
[ [ "f_2", 32 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Anyone who knew Nina at all knew she spoke many languages. She was always talking about the differences between various languages, and every time she was on the phone with one of her internet friends, she spoke a different language, so many of her acquaintances began to wonder fervently how many languages Nina spoke."],
                          
                          ]},
                    ds, { s: "She revealed one day that she spoke more than 10 languages."} , "Question", {q: "What is the polyglot's name?", as: ["Nina", "Bill", "Ted"]}],
    
    
[ [ "f_3", 33 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Remy was one of the judges for this year's scavenger hunt, and he was working on clues for the items since the fall. He was very proud of his work, and wanted to make sure that all of his friends participated so they could appreciate this thing that he had put so many hours into, along with his fellow judges. He asked his friends persistently how many of them would be participating in the scavenger hunt in the spring."],
                          
                          ]},
                    ds, { s: "He learned that few of his friends would participate."} , "Question", {q: "When does the scavenger hunt take place?", as: ["Spring", "Fall", "Winter"]}],
  
[ [ "f_3", 34 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rebecca was talking to a few of her friends, and mentioned how she was having a hard time finding people to volunteer at the phone bank because so far everyone she had asked said either there's no way they would call people they didn't know or they were already busy. Her friends replied that they might be willing to help, so Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday."],
                          
                          ]},
                    ds, { s: "They said they would be willing to make calls for a few hours."} , "Question", {q: "What kind of volunteer work were Rebecca's friends going to do?", as: ["Phone calls", "Tutoring", "Coaching"]}],
  
[ [ "subexp_a", 35 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "As the new student representative, Mary was receiving an increasing amount of emails from students concerned about their academic status. That morning, Mary received a message from an undergraduate who didn't know how many days there would be a hold placed on her account due to a late library book."],
                          
                          ]},
                     ds, { s: "Mary replied that any student who has a late library book would have a hold placed on their account for 10 days."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mary meant that the hold on the account would last exactly 10 days, no more and no less?"}}],

[ [ "subexp_b", 35 ],"Message", {consentRequired: false, transfer: "keypress",
                  html: ["div",
                           ["p", "As the new student representative, Mary was receiving an increasing amount of emails from students concerned about their academic status. That morning, Mary received a message from an undergraduate who didn't know how many days there would be a hold placed on her account due to a late library book."],
                          
                          ]},
                     ds, { s: "Mary replied that any student who have a late library book would have a hold placed on their account for 10 days."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mary meant that the hold on the account would last exactly 10 days, no more and no less?"}}],
  

[ [ "subexp_a", 36 ],"Message", {consentRequired: false, transfer: "keypress",
                   html: ["div",
                           ["p", "After a disturbing incident at his office, Alan heard two policemen and a coworker talking about what could be done to help."],
                          
                          ]},
                     ds, { s: "The policemen said that the co-workers that were involved in the incident had to provide a 500 word statement."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the policemen meant that the statement had to be exactly 500 words, no more and no less?"}}],
                                 
[ [ "subexp_b", 36 ],"Message", {consentRequired: false, transfer: "keypress",
                html: ["div",
                           ["p", "After a disturbing incident at his office, Alan heard two policemen and a coworker talking about what could be done to help."],
                          
                          ]},
                     ds, { s: "The policemen said that the co-workers that was involved in the incident had to provide a 500 word statement."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the policemen meant that the statement had to be exactly 500 words, no more and no less?"}}], 
   
[ [ "subexp_a", 37 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "During a town-hall meeting, the mayor was replying to questions about how the funds from a recent emergency package would be used to help communities affected by a recent tornado."],
                          
                          ]},
                     ds, { s: "The Mayor said that the neighborhood that receives the most applications would get 10 million dollars."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the mayor meant that the neighborhood with more applications would receive exactly 10 million dollars, no more and no less?"}}],   

[ [ "subexp_b", 37 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "During a town-hall meeting, the mayor was replying to questions about how the funds from a recent emergency package would be used to help communities affected by a recent tornado."],
                          
                          ]},
                     ds, { s: "The Mayor said that the neighborhood that receive the most applications would get 10 million dollars."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the mayor meant that the neighborhood with more applications would receive exactly 10 million dollars, no more and no less?"}}],

[ [ "subexp_a", 38 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "Alexa was the head of the tech department. As part of a new security test, the company sent out fake phishing emails to its employees, to see if they would compromise any company information. Half the employees failed this test, so at the next tech department meeting, one of Alexa’s co-workers brought up the results of the cyber-security test."],
                          
                          ]},
                     ds, { s: "Alexa insisted that any employee that fails the company's test should undergo 20 hours of additional training."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Alexa meant that the training would last exactly 20 hours, no more and no less?"}}],    
    
[ [ "subexp_b", 38 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "Alexa was the head of the tech department. As part of a new security test, the company sent out fake phishing emails to its employees, to see if they would compromise any company information. Half the employees failed this test, so at the next tech department meeting, one of Alexa’s co-workers brought up the results of the cyber-security test."],
                          
                          ]},
                     ds, { s: "Alexa insisted that any employee that fail the company's test should undergo 20 hours of additional training."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Alexa meant that the training would last exactly 20 hours, no more and no less?"}}], 

[ [ "subexp_a", 39 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "The coach had heard from his assistant coach that several players on his team were planning to miss training for a vacation they had previously planned. When the coach found out about this, he sent an email to these players."],
                          
                          ]},
                     ds, { s: "The coach reminded the players who were planning to go on vacation that they had 30 vacation days per year."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coach meant that the players had exactly 30 vacation days per year, no more and no less?"}}], 

[ [ "subexp_b", 39 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "The coach had heard from his assistant coach that several players on his team were planning to miss training for a vacation they had previously planned. When the coach found out about this, he sent an email to these players."],
                          
                          ]},
                     ds, { s: "The coach reminded the players who was planning to go on vacation that they had 30 vacation days per year."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coach meant that the players had exactly 30 vacation days per year, no more and no less?"}}],
[ [ "subexp_a", 40 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "Before prom, all of the prom attendees had to attend a talk about the dangers of drunk driving, as was the school policy. Many of the students were bored by this talk, and a few in the back row started to goof off."],
                          
                          ]},
                     ds, { s: "The speaker told the teenagers who were sitting in the back row to tell him 10 facts from the presentation."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the speaker meant exactly 10 facts, no more and no less?"}}],    
  
[ [ "subexp_b", 40 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "Before prom, all of the prom attendees had to attend a talk about the dangers of drunk driving, as was the school policy. Many of the students were bored by this talk, and a few in the back row started to goof off."],
                          
                          ]},
                     ds, { s: "The speaker told the teenagers who was sitting in the back row to tell him 10 facts from the presentation."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the speaker meant exactly 10 facts, no more and no less?"}}],

[ [ "subexp_a", 41 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "After the ruling of the judge, the spokesman representing the banks that had been found guilty of embezzlement gave a press conference."],
                          
                          ]},
                     ds, { s: "The spokesman revealed that the bank that pays a 50 million dollars fee would be exonerated."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the spokesman meant that the fee would be exactly 50 million dollars, no more and no less?"}}],

[ [ "subexp_b", 41 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "After the ruling of the judge, the spokesman representing the banks that had been found guilty of embezzlement gave a press conference."],
                          
                          ]},
                     ds, { s: "The spokesman revealed that the bank that pay a 50 million dollars fee would be exonerated."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the spokesman meant that the fee would be exactly 50 million dollars, no more and no less?"}}],
                             
[ [ "subexp_a", 42 ],"Message", {consentRequired: false, transfer: "keypress",
               html: ["div",
                           ["p", "The Promontory, a local restaurant, had a reservation for a big party on Tuesday night. Monday night, the manager was very anxious about the tables not being ready for Tuesday's party."],
                          
                          ]},
                     ds, { s: "The waiters who were getting ready to go home replied that all tables would be ready 40 minutes before the reservation."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the waiters meant that the tables would be ready exactly 40 minutes before reservation, no more and no less?"}}],
                                 
[ [ "subexp_b", 42 ],"Message", {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "The Promontory, a local restaurant, had a reservation for a big party on Tuesday night. Monday night, the manager was very anxious about the tables not being ready for Tuesday's party."],
                          
                          ]},
                     ds, { s: "The waiters who was getting ready to go home replied that all tables would be ready 40 minutes before the reservation."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the waiters meant that the tables would be ready exactly 40 minutes before reservation, no more and no less?"}}],
    
[ [ "subexp_a", 43 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "When he assigned the project, the teacher mentioned that the best project in the class would get some kind of award. When it came time to hand in the projects, the students asked him what the best project's award would be."],
                          
                          ]},
                     ds, { s: "The teacher replied that the student that obtains the highest score would get a 200 dollar gift-card."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the teacher meant that the gift-card would be worth exactly 200 dollars, no more and no less?"}}],
                                 
[ [ "subexp_b", 43 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "When he assigned the project, the teacher mentioned that the best project in the class would get some kind of award. When it came time to hand in the projects, the students asked him what the best project's award would be."],
                          
                          ]},
                     ds, { s: "The teacher replied that the student that obtain the highest score would get a 200 dollar gift-card."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the teacher meant that the gift-card would be worth exactly 200 dollars, no more and no less?"}}],
    
[ [ "subexp_a", 44 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "The university hired an architect to build a new dorm on campus. The construction site engineer told the architect that some of the construction workers had filed a complaint requesting better safety equipment. The architect asked if these workers were inexperienced enough."],
                          
                          ]},
                     ds, { s: "The engineer said that the workers that filed the complain have 10 years of experience."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that the workers had exactly 10 years of experience, no more and no less?"}}],
                                 
[ [ "subexp_b", 44 ],"Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                           ["p", "The university hired an architect to build a new dorm on campus. The construction site engineer told the architect that some of the construction workers had filed a complaint requesting better safety equipment. The architect asked if these workers were inexperienced enough."],
                          
                          ]},
                     ds, { s: "The engineer said that the workers that filed the complain has 10 years of experience."},
                     "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that the workers had exactly 10 years of experience, no more and no less?"}}]      


];