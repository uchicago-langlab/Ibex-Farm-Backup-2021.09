var shuffleSequence = seq("intro","Practice", "presep", sepWith("sep", rshuffle("Exp", "f")), "exit");
//variable declarations
//var counterOverride = 3;
//var practiceItemTypes = ["practice"];
var ds = DashedSentence;
var q = Question;

var defaults = [
    Separator, {ignoreFailure: false, errorMessage: "Oops! Wrong answer!"},
    q, {hasCorrect: true, randomOrder: false, presentHorizontally: true, as: [["f", "Yes"], ["j", "No"]]},
    ds, {mode: "self-paced reading", display: "in place"}
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro0.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

["sep", Separator, { }],

["Practice", ds, {s: ["This is", "just a practice sentence", "to get you used", "to the method", "of presentation."]}, q, {q:"Was that sentence easy?", hasCorrect: 0}, Separator, {}],

["Practice", ds, {s: ["This is", "another practice sentence", "which is longer", "and a little more complicated", "than the one", "you just read."]}, q, {q:"Did you read that at a normal pace?", hasCorrect: 0}, Separator, {}],
                           
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all there is to it! Let's try some practice sentences more like the ones you'll be seeing in the experiment:"]
                           ]}],
                           
["Practice", ds, {s: ["Many doctors", "have", "several patients", "a day.", "The doctors", "that", "have", "many appointments", "experience", "lots", "of", "stress", "from", "their jobs."]}, q, {q:"Do the doctors experience lots of stress?", hasCorrect: 0}, Separator, {}],  

["Practice", ds, {s: ["Certain cereals", "contain", "many nutrients.", "The boy", "eats", "oatmeal", "every day", "for", "breakfast."]}, q, {q: "Are they saying that the girl eats oatmeal?", hasCorrect: 1}, Separator, {}],

["Practice", ds, {s: ["The election", "this year", "had", "an interesting result.",  "The senators", "who", "no one", "voted", "for", "won", "the election."]}, q,{q: "Did the senators win the election?", hasCorrect: 0}, Separator, {}],
                          
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. It will last approximately 15 minutes, and will require your full attention throughout that period. Thank you for your help!"]]}],                       

["presep", Separator, {transfer: 3000, normalMessage: "Get your hands in position, and get ready to begin!"}],


[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "was", "meant", "to", "be", "followed,", "but", "in_the_end", "they", "didn't."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "was", "meant", "to", "be", "followed,", "but", "in_the_end", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "was", "meant", "to", "be", "followed,", "but", "in_the_end", "they", "maintained", "it", "was", "subject", "to", "exceptions."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "was", "meant", "to", "be", "followed,", "but", "in_the_end", "they", "were", "hesitant."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "the_following_year,", "but", "in_the_end", "they", "didn't."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "the_following_year,", "but", "in_the_end", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "the_following_year,", "but", "in_the_end", "they", "maintained", "it", "indefinitely."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 1], ds, {s: ["The_city_government", "planned_to", "maintain", "the_constitution", "the_following_year,", "but", "in_the_end", "they", "were", "hesitant."]}, Separator, {}, ds, {s: ["The_commentator", "maintained", "her_statement", "was", "not", "unsuitable", "for", "a_television_program."]}, q, {q: "Did the commentator defend her statement?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "was", "haphazard,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the_firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "was", "haphazard,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "was", "haphazard,", "but", "in_the_end", "he", "established", "it", "was", "more", "or", "less", "safe."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "was", "haphazard,", "but", "in_the_end", "he", "was", "frustrated."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "in", "May,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the_firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "in", "May,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "in", "May,", "but", "in_the_end", "he", "established", "it", "much", "later."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 2], ds, {s: ["The_entrepreneur", "tried_to", "establish", "the_company", "in", "May,", "but", "in_the_end", "he", "was", "frustrated."]}, Separator, {}, ds, {s: ["The_CEO", "established", "the_firm", "was", "secretly", "about", "to", "go", "under."]}, q, {q: "Was the CEO worried about the firm?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "was", "impossible", "to", "overcome,", "but", "afraid", "of", "discouraging", "people", "he", "didn't."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "was", "impossible", "to", "overcome,", "but", "afraid", "of", "discouraging", "people", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "was", "impossible", "to", "overcome,", "but", "afraid", "of", "discouraging", "people", "he", "only", "pointed", "out", "the_problem", "was", "difficult", "to", "solve."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "was", "impossible", "to", "overcome,", "but", "afraid", "of", "discouraging", "people", "he", "kept", "silent."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "at", "the_meeting,", "but", "afraid", "of", "discouraging", "people", "he", "didn't."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "at", "the_meeting,", "but", "afraid", "of", "discouraging", "people", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "at", "the_meeting,", "but", "afraid", "of", "discouraging", "people", "he", "only", "pointed", "out", "the_problem", "privately", "to", "the_president."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 3], ds, {s: ["The_professor", "planned_to", "point_out", "the_problem", "at", "the_meeting,", "but", "afraid", "of", "discouraging", "people", "he", "kept", "silent."]}, Separator, {}, ds, {s: ["The_teacher", "pointed_out", "the_student's_error", "was", "the_product", "of", "carelessness."]}, q, {q: "Was the teacher dissatisfied with the student's performance?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "was", "safely", "taken", "home,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "was", "safely", "taken", "home,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "was", "safely", "taken", "home,", "but", "in_the_end", "he", "only", "saw", "it", "was", "put", "in", "the_car."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "was", "safely", "taken", "home,", "but", "in_the_end", "he", "went", "home."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "inside", "the_shelter,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "inside", "the_shelter,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "inside", "the_shelter,", "but", "in_the_end", "he", "saw", "it", "at", "the_entrance."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 4], ds, {s: ["The_father", "was_told_to", "see", "the_dog", "inside", "the_shelter,", "but", "in_the_end", "he", "went", "home."]}, Separator, {}, ds, {s: ["The_chef", "saw", "the_omelet", "was", "still", "not", "cooked", "enough."]}, q, {q: "Was the omelet undercooked?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "was", "crucial,", "but", "in", "the_report", "he", "didn't."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "was", "crucial,", "but", "in", "the_report", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "was", "crucial,", "but", "in", "the_report", "he", "acknowledged", "it", "was", "only", "somewhat", "crucial."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "was", "crucial,", "but", "in", "the_report", "he", "was", "dishonest."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "in", "his_letter,", "but", "in", "the_report", "he", "didn't."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "in", "his_letter,", "but", "in", "the_report", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "in", "his_letter,", "but", "in", "the_report", "he", "acknowledged", "it", "only", "somewhat."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 5], ds, {s: ["The_lieutenant", "hoped_to", "acknowledge", "the_civilians'_help", "in", "his_letter,", "but", "in", "the_report", "he", "was", "dishonest."]}, Separator, {}, ds, {s: ["The_hostess", "acknowledged", "the_celebrity's_presence", "was", "intimidating", "to", "the_other_guests."]}, q, {q: "Was the hostess at all afraid of the guest?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "was", "forged,", "but", "at", "the_town_meeting", "she", "didn't."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "was", "forged,", "but", "at", "the_town_meeting", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "was", "forged,", "but", "at", "the_town_meeting", "she", "certified", "it", "was", "actually", "valid."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "was", "forged,", "but", "at", "the_town_meeting", "she", "spoke", "softly."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "for", "the_public,", "but", "at", "the_town_meeting", "she", "didn't."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "for", "the_public,", "but", "at", "the_town_meeting", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "for", "the_public,", "but", "at", "the_town_meeting", "she", "certified", "it", "without", "much_confidence."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 6], ds, {s: ["The_town_clerk", "tried_to", "certify", "the_building_certificate", "for", "the_public,", "but", "at", "the_town_meeting", "she", "spoke", "softly."]}, Separator, {}, ds, {s: ["The_professional_dog_trainer", "certified", "his_method", "was", "reliable", "for", "his_clients."]}, q, {q: "Is the dog trainer confident?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "would", "be", "difficult", "to", "handle,", "but", "at", "the_meeting", "he", "didn't."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "would", "be", "difficult", "to", "handle,", "but", "at", "the_meeting", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "would", "be", "difficult", "to", "handle,", "but", "at", "the_meeting", "he", "advised", "the_client", "would", "be", "manageable."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "would", "be", "difficult", "to", "handle,", "but", "at", "the_meeting", "he", "became", "cranky."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "for", "his_next_project,", "but", "at", "the_meeting", "he", "didn't."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "for", "his_next_project,", "but", "at", "the_meeting", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "for", "his_next_project,", "but", "at", "the_meeting", "he", "advised", "the_client", "immediately."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 7], ds, {s: ["The_lawyer", "hoped_to", "advise", "the_famous_client", "for", "his_next_project,", "but", "at", "the_meeting", "he", "became", "cranky."]}, Separator, {}, ds, {s: ["The_accountant", "advised", "the_company", "was", "soon", "going", "to", "fail."]}, q, {q: "Did the accountant have bad news?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "was", "likely", "to", "hold", "up,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "was", "likely", "to", "hold", "up,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "was", "likely", "to", "hold", "up,", "but", "in_the_end", "she", "corroborated", "it", "was", "only", "plausible."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the_evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "was", "likely", "to", "hold", "up,", "but", "in_the_end", "she", "lost", "confidence."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the_evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "during", "the_trial,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "during", "the_trial,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the_evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "during", "the_trial,", "but", "in_the_end", "she", "corroborated", "it", "only", "to", "her_client."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the_evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 8], ds, {s: ["The_lawyer", "was_expected_to", "corroborate", "the_defense", "during", "the_trial,", "but", "in_the_end", "she", "lost", "confidence."]}, Separator, {}, ds, {s: ["The_witness", "corroborated", "the_evidence", "was", "somewhat", "misleading", "during", "the_trial."]}, q, {q: "Did the witness disagree with the evidence?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "was", "unconstitutional,", "but", "in_the_end", "they", "didn't."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "was", "unconstitutional,", "but", "in_the_end", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "was", "unconstitutional,", "but", "in_the_end", "they", "protested", "it", "was", "just", "unethical."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "was", "unconstitutional,", "but", "in_the_end", "they", "went", "home."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "in", "the_streets,", "but", "in_the_end", "they", "didn't."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "in", "the_streets,", "but", "in_the_end", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "in", "the_streets,", "but", "in_the_end", "they", "protested", "it", "outside", "the_court."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 9], ds, {s: ["The_citizens", "wanted_to", "protest", "the_new_law", "in", "the_streets,", "but", "in_the_end", "they", "went", "home."]}, Separator, {}, ds, {s: ["The_demonstrator", "protested", "the_court's_decision", "was", "completely", "out", "of", "line."]}, q, {q: "Was the demonstrator upset?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "was", "crucial,", "but", "after", "the_group_meeting", "she", "didn't."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "was", "crucial,", "but", "after", "the_group_meeting", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "was", "crucial,", "but", "after", "the_group_meeting", "she", "emphasized", "it", "was", "less", "important", "than", "she", "thought."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "was", "crucial,", "but", "after", "the_group_meeting", "she", "wasn't", "optimistic."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "with", "enthusiasm,", "but", "after", "the_group_meeting", "she", "didn't."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "with", "enthusiasm,", "but", "after", "the_group_meeting", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "with", "enthusiasm,", "but", "after", "the_group_meeting", "she", "emphasized", "it", "less", "than", "expected."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 10], ds, {s: ["The_social_worker", "was_supposed_to", "emphasize", "her_commitment", "with", "enthusiasm,", "but", "after", "the_group_meeting", "she", "wasn't", "optimistic."]}, Separator, {}, ds, {s: ["The_charity", "emphasized", "the_benefit_of_donation", "was", "not", "limited", "to", "tax_write-offs."]}, q, {q: "Was the charity seeking financial support?", hasCorrect: 0}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "was", "impending,", "but", "ultimately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "was", "impending,", "but", "ultimately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "was", "impending,", "but", "ultimately", "he", "guaranteed", "it", "was", "unlikely."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "was", "impending,", "but", "ultimately", "he", "seemed", "unreliable."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "enthusiastically,", "but", "ultimately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "enthusiastically,", "but", "ultimately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "enthusiastically,", "but", "ultimately", "he", "guaranteed", "it", "with", "some", "caution."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 11], ds, {s: ["The_coach", "hoped_to", "guarantee", "a_victory", "enthusiastically,", "but", "ultimately", "he", "seemed", "unreliable."]}, Separator, {}, ds, {s: ["The_stock_broker", "guaranteed", "a_profit", "was", "ready", "to", "be", "made."]}, q, {q: "Was the broker pessimistic?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "was", "eternal,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "was", "eternal,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "was", "eternal,", "but", "in_the_end", "he", "professed", "it", "was", "just", "very", "strong."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "was", "eternal,", "but", "in_the_end", "he", "backed", "down."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "in", "a_sonnet,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "in", "a_sonnet,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "in", "a_sonnet,", "but", "in_the_end", "he", "professed", "it", "in", "a_limerick", "."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 12], ds, {s: ["The_poet", "wanted_to", "profess", "his_love", "in", "a_sonnet,", "but", "in_the_end", "he", "backed", "down."]}, Separator, {}, ds, {s: ["The_mayor", "professed", "her_commitment", "was", "completely", "sincere", "to", "the_public."]}, q, {q: "Did the mayor admit to dishonesty?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "was", "going", "to", "be", "pleasant,", "but", "unfortunately", "she", "didn't."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "was", "going", "to", "be", "pleasant,", "but", "unfortunately", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "was", "going", "to", "be", "pleasant,", "but", "unfortunately", "she", "foretold", "it", "was", "going", "to", "be", "bleak."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "was", "going", "to", "be", "pleasant,", "but", "unfortunately", "she", "seemed", "anxious."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "for", "the_crowd,", "but", "unfortunately", "she", "didn't."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "for", "the_crowd,", "but", "unfortunately", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "for", "the_crowd,", "but", "unfortunately", "she", "foretold", "it", "only", "for", "herself."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 13], ds, {s: ["The_oracle", "hoped_to", "foretell", "the_future", "for", "the_crowd,", "but", "unfortunately", "she", "seemed", "anxious."]}, Separator, {}, ds, {s: ["The_weatherman", "foretold", "the_thunderstorm", "was", "going", "to", "come", "at", "midnight."]}, q, {q: "Was the thunderstorm going to be in the early afternoon?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "was", "a_priority,", "but", "ultimately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "was", "a_priority,", "but", "ultimately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "was", "a_priority,", "but", "ultimately", "he", "preached", "it", "was", "of", "secondary_importance."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "was", "a_priority,", "but", "ultimately", "he", "sat", "down."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "at", "the_service,", "but", "ultimately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "at", "the_service,", "but", "ultimately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "at", "the_service,", "but", "ultimately", "he", "preached", "it", "ineffectively."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 14], ds, {s: ["The_congregation_leader", "planned_to", "preach", "the_golden_rule", "at", "the_service,", "but", "ultimately", "he", "sat", "down."]}, Separator, {}, ds, {s: ["The_organization's_president", "preached", "his_opinion", "was", "the_correct_opinion", "in", "front", "of", "the_board."]}, q, {q: "Was the president uncertain about his opinion?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "would", "be", "a_bit", "late,", "but", "due", "to", "a_mistake", "she", "didn't."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "would", "be", "a_bit", "late,", "but", "due", "to", "a_mistake", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "would", "be", "a_bit", "late,", "but", "due", "to", "a_mistake", "she", "announced", "it", "would", "be", "on", "time."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "would", "be", "a_bit", "late,", "but", "due", "to", "a_mistake", "she", "was", "defensive."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "once", "she", "got", "there,", "but", "due", "to", "a_mistake", "she", "didn't."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "once", "she", "got", "there,", "but", "due", "to", "a_mistake", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the_same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "once", "she", "got", "there,", "but", "due", "to", "a_mistake", "she", "announced", "it", "to", "nobody."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 15], ds, {s: ["The_celebrity", "hoped_to", "announce", "her_arrival", "once", "she", "got", "there,", "but", "due", "to", "a_mistake", "she", "was", "defensive."]}, Separator, {}, ds, {s: ["The_treasury", "announced", "the_project's_budget", "was", "going", "to", "be", "revised."]}, q, {q: "Was the budget going to remain the same?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "was", "easy,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "was", "easy,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "was", "easy,", "but", "in_the_end", "she", "demonstrated", "it", "was", "difficult."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "was", "easy,", "but", "in_the_end", "she", "felt", "too", "nervous."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "in", "the_morning,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "in", "the_morning,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "in", "the_morning,", "but", "in_the_end", "she", "demonstrated", "it", "in", "the_afternoon."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 16], ds, {s: ["The_doctor", "tried_to", "demonstrate", "the_procedure", "in", "the_morning,", "but", "in_the_end", "she", "felt", "too", "nervous."]}, Separator, {}, ds, {s: ["The_magician", "demonstrated", "the_trick", "was", "stressful", "to", "pull", "off."]}, q, {q: "Could the trick be pulled off easily?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "was", "all", "from", "one_sponsor,", "but", "at", "the_rally", "they", "didn't."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "was", "all", "from", "one_sponsor,", "but", "at", "the_rally", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "was", "all", "from", "one_sponsor,", "but", "at", "the_rally", "they", "also", "concealed", "it", "was", "from", "out", "of", "state."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "was", "all", "from", "one_sponsor,", "but", "at", "the_rally", "they", "gave", "up."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "indefinitely,", "but", "at", "the_rally", "they", "didn't."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "indefinitely,", "but", "at", "the_rally", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "indefinitely,", "but", "at", "the_rally", "they", "concealed", "it", "no", "longer."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 17], ds, {s: ["The_politicians", "tried_to", "conceal", "the_funding", "indefinitely,", "but", "at", "the_rally", "they", "gave", "up."]}, Separator, {}, ds, {s: ["The_technician", "concealed", "the_tumor", "was", "inoperable", "without", "huge_expenses."]}, q, {q: "Was the technician completely honest?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "was", "too", "violent,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "was", "too", "violent,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "was", "too", "violent,", "but", "in_the_end", "she", "showed", "it", "was", "just", "inappropriate."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "was", "too", "violent,", "but", "in_the_end", "she", "was", "doubtful."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "on", "Wednesday,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "on", "Wednesday,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "on", "Wednesday,", "but", "in_the_end", "she", "showed", "it", "on", "Thursday."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 18], ds, {s: ["The_teacher", "wanted_to", "show", "the_film", "on", "Wednesday,", "but", "in_the_end", "she", "was", "doubtful."]}, Separator, {}, ds, {s: ["The_trapeze_artist", "showed", "the_trick", "was", "not", "that", "dangerous."]}, q, {q: "Was the trapeze artist afraid?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "was", "only", "visible", "in", "the_long_run,", "but", "afraid", "of", "losing", "clients", "she", "didn't."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "was", "only", "visible", "in", "the_long_run,", "but", "afraid", "of", "losing", "clients", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "was", "only", "visible", "in", "the_long_run,", "but", "afraid", "of", "losing", "clients", "she", "stressed", "it", "was", "visible", "right", "away."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "was", "only", "visible", "in", "the_long_run,", "but", "afraid", "of", "losing", "clients", "she", "lied."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "without", "exaggerating,", "but", "afraid", "of", "losing", "clients", "she", "didn't."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "without", "exaggerating,", "but", "afraid", "of", "losing", "clients", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "without", "exaggerating,", "but", "afraid", "of", "losing", "clients", "she", "stressed", "it", "more", "enthusiastically."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 19], ds, {s: ["The_therapist", "planned_to", "stress", "the_value_of_therapy", "without", "exaggerating,", "but", "afraid", "of", "losing", "clients", "she", "lied."]}, Separator, {}, ds, {s: ["The_professor", "stressed", "the_historical_fact", "was", "misrepresented", "in", "the_new_book."]}, q, {q: "Did the professor misrepresent the historical fact?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "would", "bring", "good", "to", "thousands,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "would", "bring", "good", "to", "thousands,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "would", "bring", "good", "to", "thousands,", "but", "unfortunately", "he", "explained", "it", "would", "bring", "good", "to", "no_one."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "would", "bring", "good", "to", "thousands,", "but", "unfortunately", "he", "was", "nervous."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "at", "a_conference,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "at", "a_conference,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "at", "a_conference,", "but", "unfortunately", "he", "explained", "it", "just", "at", "work."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 20], ds, {s: ["The_engineer", "was_supposed_to", "explain", "his_new_machinery", "at", "a_conference,", "but", "unfortunately", "he", "was", "nervous."]}, Separator, {}, ds, {s: ["The_principal", "explained", "the_new_dress_code", "was", "going", "to", "create", "a_better_learning_environment."]}, q, {q: "Was the principal lax about sartorial standards?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "was", "for", "profit,", "but", "in", "the_proposal", "they", "didn't."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "was", "for", "profit,", "but", "in", "the_proposal", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "was", "for", "profit", "but", "in", "the_proposal", "they", "disclosed", "it", "was", "only", "voluntary."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the_author impressed by her_compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "was", "for", "profit,", "but", "in", "the_proposal", "they", "lied."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the_author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "with", "complete_honesty,", "but", "in", "the_proposal", "they", "didn't."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her_compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "with", "complete_honesty,", "but", "in", "the_proposal", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "with", "complete_honesty,", "but", "in", "the_proposal", "they", "disclosed", "it", "without", "many_details."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 21], ds, {s: ["The_animal_researchers", "were", "asked_to", "disclose", "the_study", "with", "complete_honesty,", "but", "in", "the_proposal", "they", "lied."]}, Separator, {}, ds, {s: ["The_author", "disclosed", "the_amount_she_received", "was", "not", "actually", "that", "impressive."]}, q, {q: "Was the author impressed by her compensation?", hasCorrect: 1}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "was", "not", "surprising,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "was", "not", "surprising,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "was", "not", "surprising,", "but", "in_the_end", "he", "revealed", "it", "was", "a_hit."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "was", "not", "surprising,", "but", "in_the_end", "he", "was", "silent."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "in", "the_newspaper,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "in", "the_newspaper,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "in", "the_newspaper,", "but", "in_the_end", "he", "revealed", "it", "on", "television."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 22], ds, {s: ["The_director", "intended_to", "reveal", "the_movie's_ending", "in", "the_newspaper,", "but", "in_the_end", "he", "was", "silent."]}, Separator, {}, ds, {s: ["The_chef", "revealed", "the_dish's_secret", "was", "to", "use", "lots", "of", "butter."]}, q, {q: "Was the chef's dish unhealthy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "should", "be", "followed", "every_day,", "but", "eventually", "she", "didn't."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "should", "be", "followed", "every_day,", "but", "eventually", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "should", "be", "followed", "every_day,", "but", "eventually", "she", "repeated", "it", "should", "be", "followed", "less", "often."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "should", "be", "followed", "every_day,", "but", "eventually", "she", "was", "unconvincing."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "in", "the_library,", "but", "eventually", "she", "didn't."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "in", "the_library,", "but", "eventually", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "in", "the_library,", "but", "eventually", "she", "repeated", "it", "in", "the_lobby."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 23], ds, {s: ["The_tutor", "intended_to", "repeat", "the_instruction", "in", "the_library,", "but", "eventually", "she", "was", "unconvincing."]}, Separator, {}, ds, {s: ["The_coach", "repeated", "the_training_protocol", "was", "not", "hard", "to", "follow."]}, q, {q: "Did the coach think the training protocol was easy?", hasCorrect: 0}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "was", "only", "temporary,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "was", "only", "temporary,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "was", "only", "temporary,", "but", "in_the_end", "he", "rationalized", "it", "was", "necessary."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "was", "only", "temporary,", "but", "in_the_end", "he", "was", "apathetic."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "to", "his_family,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "to", "his_family,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "to", "his_family,", "but", "in_the_end", "he", "rationalized", "it", "only", "to", "himself."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 24], ds, {s: ["The_politician", "tried_to", "rationalize", "his_campaign_strategy", "to", "his_family,", "but", "in_the_end", "he", "was", "apathetic."]}, Separator, {}, ds, {s: ["The_governor", "rationalized", "the_budget_cut", "was", "necessary", "for", "the_economy."]}, q, {q: "Does the governor like to spend money?", hasCorrect: 1}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "was", "going", "to", "go", "to", "jail,", "but", "because", "of", "the_camera", "he", "didn't."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "was", "going", "to", "go", "to", "jail,", "but", "because", "of", "the_camera", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "was", "going", "to", "go", "to", "jail,", "but", "because", "of", "the_camera", "he", "threatened", "the_man", "was", "only", "going", "to", "pay", "a_fine."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "was", "going", "to", "go", "to", "jail,", "but", "because", "of", "the_camera", "he", "calmed", "down."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "in", "the_street,", "but", "because", "of", "the_camera", "he", "didn't."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "in", "the_street,", "but", "because", "of", "the_camera", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "in", "the_street,", "but", "because", "of", "the_camera", "he", "threatened", "the_man", "behind", "the_alley."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 25], ds, {s: ["The_cop", "wanted_to", "threaten", "the_civilian", "in", "the_street,", "but", "because", "of", "the_camera", "he", "calmed", "down."]}, Separator, {}, ds, {s: ["The_boss", "threatened", "the_employee", "was", "going", "to", "get", "fired."]}, q, {q: "Did the boss try to intimidate the employee?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "would", "be", "at", "seven,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "would", "be", "at", "seven,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "would", "be", "at", "seven,", "but", "unfortunately", "he", "confirmed", "it", "would", "be", "at", "nine."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "would", "be", "at", "seven,", "but", "unfortunately", "he", "was", "mistaken."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "online,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "online,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "online,", "but", "unfortunately", "he", "confirmed", "it", "on", "the_phone."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 26], ds, {s: ["The_guest", "attempted_to", "confirm", "the_reservation", "online,", "but", "unfortunately", "he", "was", "mistaken."]}, Separator, {}, ds, {s: ["The_hotel_clerk", "confirmed", "the_deposit", "was", "successful", "to", "the_client."]}, q, {q: "Did the deposit work?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "was", "going", "to", "be", "delayed,", "but", "ultimately", "they", "didn't."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "was", "going", "to", "be", "delayed,", "but", "ultimately", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "was", "going", "to", "be", "delayed,", "but", "ultimately", "they", "accepted", "it", "was", "going", "to", "be", "delivered", "soon."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "was", "going", "to", "be", "delayed,", "but", "ultimately", "they", "felt", "too", "uncomfortable."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "with", "ease,", "but", "eventually", "they", "didn't."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "with", "ease,", "but", "eventually", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "with", "ease,", "but", "eventually", "they", "accepted", "it", "with", "hesitation."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 27], ds, {s: ["The_public", "was", "told_to", "accept", "the_truth", "with", "ease,", "but", "eventually", "they", "felt", "too", "uncomfortable."]}, Separator, {}, ds, {s: ["The_father", "accepted", "his_son", "was", "planning", "to", "choose", "another_career."]}, q, {q: "Did the son go against his father's initial wishes?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "was", "so", "life-changing,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "was", "so", "life-changing,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "was", "so", "life-changing,", "but", "in_the_end", "she", "forgot", "it", "had", "ever", "happened."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "was", "so", "life-changing,", "but", "in_the_end", "she", "remained", "anxious."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "through", "meditation,", "but", "in_the_end", "she", "didn't."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "through", "meditation,", "but", "in_the_end", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "through", "meditation,", "but", "in_the_end", "she", "forgot", "it", "automatically."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 28], ds, {s: ["The_victim", "tried_to", "forget", "the_trauma", "through", "meditation,", "but", "in_the_end", "she", "remained", "anxious."]}, Separator, {}, ds, {s: ["The_intern", "forgot", "her_briefcase", "was", "still", "at", "home."]}, q, {q: "Was the briefcase at the intern's house?", hasCorrect: 0}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "was", "the_best", "option,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "was", "the_best", "option,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "was", "the_best", "option,", "but", "in_the_end", "he", "proposed", "it", "was", "not", "ideal."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "was", "the_best", "option,", "but", "in_the_end", "he", "was", "unconvincing."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "at", "the_meeting,", "but", "in_the_end", "he", "didn't."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "at", "the_meeting,", "but", "in_the_end", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "at", "the_meeting,", "but", "in_the_end", "he", "proposed", "it", "over", "the_phone."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 29], ds, {s: ["The_consultant", "wanted_to", "propose", "his_idea", "at", "the_meeting,", "but", "in_the_end", "he", "was", "unconvincing."]}, Separator, {}, ds, {s: ["The_attorney", "proposed", "his_explanation", "was", "more", "than", "compelling."]}, q, {q: "Did the attorney lack confidence?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "was", "still", "ongoing,", "but", "at", "the_conference", "he", "didn't."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "was", "still", "ongoing,", "but", "at", "the_conference", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "was", "still", "ongoing,", "but", "at", "the_conference", "he", "cited", "it", "was", "a_continuation", "of", "previous_work."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "was", "still", "ongoing,", "but", "at", "the_conference", "he", "was", "interrupted."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "during", "his_talk,", "but", "at", "the_conference", "he", "didn't."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "during", "his_talk,", "but", "at", "the_conference", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "during", "his_talk,", "but", "at", "the_conference", "he", "cited", "it", "during", "the_coffee", "break."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 30], ds, {s: ["The_scientist", "planned_to", "cite", "the_project", "during", "his_talk,", "but", "at", "the_conference", "he", "was", "interrupted."]}, Separator, {}, ds, {s: ["The_student", "cited", "the_paper", "was", "written", "by", "a_famous_researcher."]}, q, {q: "Did the student write the paper?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "was", "safe", "on", "highways,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "was", "safe", "on", "highways,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "was", "safe", "on", "highways", "but", "unfortunately", "he", "insured", "it", "was", "only", "safe", "in", "town."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "was", "safe", "on", "highways,", "but", "unfortunately", "he", "was", "disappointed."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "in", "September,", "but", "unfortunately", "he", "didn't."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "in", "September,", "but", "unfortunately", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "in", "September,", "but", "unfortunately", "he", "insured", "it", "in", "October."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 31], ds, {s: ["The_taxi_driver", "needed_to", "insure", "his_car", "in", "September,", "but", "unfortunately", "he", "was", "disappointed."]}, Separator, {}, ds, {s: ["The_real-estate_agent", "insured", "the_house", "was", "structurally", "sound", "during", "the_tour."]}, q, {q: "Did the real-estate agent have doubts about the house?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "would", "be", "rather", "high,", "but", "after", "looking", "at", "the_plan", "he", "didn't."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "would", "be", "rather", "high,", "but", "after", "looking", "at", "the_plan", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "would", "be", "rather", "high,", "but", "after", "looking", "at", "the_plan", "he", "estimated", "it", "would", "be", "quite", "reasonable."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_costs", "would", "be", "rather", "high,", "but", "after", "looking", "at", "the_plan", "he", "relaxed."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "with", "little_information,", "but", "after", "looking", "at", "the_plan", "he", "didn't."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "with", "little_information,", "but", "after", "looking", "at", "the_plan", "he", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "with", "little_information,", "but", "after", "looking", "at", "the_plan", "he", "estimated", "it", "precisely."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],

[["Exp", 32], ds, {s: ["The_contractor", "was_expected_to", "estimate", "the_building_cost", "with", "little_information,", "but", "after", "looking", "at", "the_plan", "he", "relaxed."]}, Separator, {}, ds, {s: ["The_scientist", "estimated", "the_asteroid's_arrival", "was", "going", "to", "be", "delayed."]}, q, {q: "Was the arrival expected to be on time?", hasCorrect: 1}, Separator, {}],


["f", ds, {s: ["The_critic", "was_hoping_to", "find", "the_film", "was", "entertaining,", "but", "after", "watching", "it", "once", "she", "didn't."]}, q, {q:"Was the critic bored with the film?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_librarian", "found", "the_book", "after", "looking", "on", "the_shelf."]}, Separator, {}],

["f", ds, {s: ["The_organization's_leader", "tried_to", "dictate", "a_speech", "was", "necessary,", "but", "once", "her_secretary", "was", "in", "the_office", "she", "didn't", "do_it."]}, q, {q:"Did the leader write a speech?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_town_residents", "dictated", "the_rules_about", "curfew", "at", "the_beginning", "of", "the_year."]}, Separator, {}],

["f", ds, {s: ["The_tennis_player", "was_asked_to", "assume", "his_place", "on", "the_court", "was", "on", "the_right,", "but", "instead", "he", "assumed", "it", "was", "on", "the_left."]}, q, {q:"Did the tennis player step onto the court?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_math_students", "assumed", "a_few_basic_axioms", "for", "their_test."]}, q, {q:"Did the students study math?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_guests", "were_asked_to", "affirm", "their_attendance", "at", "the_party", "was", "certain,", "but", "within", "a_week", "they", "still", "hadn't", "called."]}, q, {q:"Did the guests forget to RSVP?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_pet_owner", "affirmed", "his_love_for_his_sheepdog", "to", "the_neighbors."]}, q, {q:"Did pet owner hate his pet?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_author", "wanted_to", "paraphrase", "a_well-known_story", "at", "the", "beginning", "of", "the_chapter,", "but", "after", "writing", "it", "she", "didn't."]}, q, {q:"Was the story known widely?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_teacher", "paraphrased", "the_student's", "paper", "in", "a_few_sentences."]}, q, {q:"Did the teacher read the student's paper?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_visitors", "were_told_to", "believe", "the_tour_guide", "without", "question,", "but", "once", "they", "saw", "him", "they", "didn't.", "The_journalist", "believed", "the_people_she_interviewed", "until", "she", "found", "disconfirming_evidence."]}, q, {q:"Did the journalist do interviews?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_movie_theater_patrons", "were_likely_to", "feel", "the_film", "was", "too", "violent,", "but", "after", "seeing", "it", "they", "felt", "it", "was", "too", "scary."]}, Separator, {}, ds, {s: ["The_doctor", "felt", "the_patient's_forehead", "to", "check", "for", "a_fever."]}, q, {q:"Did the doctor see a patient?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_counselor", "tried_to", "understand", "her_patients", "carefully,", "but", "after", "listening", "to", "them", "she", "was", "unsuccessful."]}, q, {q:"Did the counselor interact with her patients?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_test_taker", "understood", "the_instructions", "before", "starting", "the_test."]}, q, {q:"Did the test taker read the instructions?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_nun", "tried_to", "say", "a_prayer", "was", "needed,", "but", "after", "she", "cleared", "her_head", "she", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_congressman", "said", "empty_words", "during", "his_speech."]}, q, {q:"Was the congressman sincere?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_news_organization", "was_required_to", "print", "the_story", "was", "coming,", "but", "when", "the_tabloids", "started", "doing", "it", "instead", "they", "didn't", "do_it."]}, Separator, {}, ds, {s: ["The_customer", "printed", "her_train_ticket", "before", "getting", "on", "the_train."]}, q, {q:"Did the customer have an airplane ticket?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_journalist", "hoped_to", "print", "the_photo", "was", "a_fake,", "but", "after", "she", "had", "some_evidence", "she", "printed", "it", "was", "real."]}, Separator, {}, ds, {s: ["The_press", "printed", "the_news_report", "in", "the_morning."]}, q, {q:"Did the press refuse to print the report?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_writer", "hoped_to", "learn", "the_foreign_language", "would", "be", "easy,", "but", "after", "she", "moved", "abroad", "she", "gave_up."]}, q, {q:"Did the writer learn the foreign language easily?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_therapist", "learned", "relaxation_techniques", "to", "use", "on", "patients."]}, q, {q:"Did the therapist learn something new?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_student", "hoped_to", "secure", "an_internship", "easily,", "but", "after", "she", "had", "a_couple_interviews", "she", "didn't."]}, q, {q:"Did the student get a job easily?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_intern", "secured", "a_permanent_position", "for", "the_entire_summer."]}, Separator, {}],

["f", ds, {s: ["The_gangster", "tried_to", "threaten", "his_lawyer,", "but", "after", "he", "was", "detained", "he", "didn't", "do_it."]}, q, {q:"Did the gangster have a lawyer?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_drug_dealer", "threatened", "his_customer", "when", "he", "was", "late", "with", "his_payment."]}, Separator, {}],

["f", ds, {s: ["The_scientist", "wanted_to", "entertain", "the_hypothesis", "for", "a_minute,", "but", "when", "she", "thought", "about", "it", "she", "entertained", "it", "for", "much", "longer."]}, q, {q:"Did the scientist abandon the idea?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_comedian", "entertained", "his_friends", "even", "though", "he", "was", "tired."]}, Separator, {}],

["f", ds, {s: ["The_tutor", "hoped_to", "understand", "the_student's_problems", "easily,", "but", "after", "she", "met", "him", "she", "lost", "hope."]}, q, {q:"Did the tutor lose faith in the student?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_curator", "understood", "the_artist's_vision", "after", "considering", "it."]}, Separator, {}],

["f", ds, {s: ["The_intern", "hoped_to", "learn", "her_coworker's_name", "was", "easy", "to", "pronounce,", "but", "after", "she", "met", "her", "she", "didn't."]}, q, {q:"Did the intern ignore her coworker?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_engineer", "learned", "a_new_programming_language", "in", "a_very_short_time."]}, q, {q:"Was the engineer fast?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_activist", "tried_to", "maintain", "her_position", "was", "helpful", "to", "everyone,", "but", "when", "she", "gave", "a_speech", "she", "didn't", "do_it."]}, q, {q:"Did the activist forget to give a speech?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_custodian", "maintained", "a_steady_income", "throughout", "her_career."]}, q, {q:"Was the custodian losing money?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_salesperson", "wanted_to", "entertain", "the_idea", "was", "a_good_one,", "but", "when", "she", "thought", "about", "it", "she", "entertained", "it", "lacked", "evidence."]}, q, {q:"Did the salesperson believe the idea?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_event_planner", "entertained", "her_clients", "at", "the_party."]}, q, {q:"Was the event planner entertaining?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_student", "wanted_to", "cite", "a_philosopher,", "but", "when", "she", "wrote", "her_essay", "she", "hesitated."]}, q, {q:"Did the student write an essay?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_economist", "cited", "recent_history", "in", "an_article."]}, q, {q:"Did the economist cite ancient events?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_car_salesman", "tried_to", "indicate", "the_price,", "but", "when", "he", "remembered", "what", "it", "was", "he", "didn't."]}, Separator, {}, ds, {s: ["The_dictator", "indicated", "his_idol", "during", "a_momentous_speech."]}, q, {q:"Did the dictator admire someone?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_filmmaker", "tried_to", "believe", "her_actors", "with", "confidence,", "but", "when", "she", "saw", "them", "practicing", "she", "didn't", "do_it."]}, q, {q:"The the filmmaker lose confidence in her actors?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_child", "believed", "her_parents", "despite", "their_recent_trickery."]}, q, {q:"Was the child trusting?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_florist", "hoped_to", "affirm", "the", "decision", "in", "the_shop,", "but", "after", "she", "saw", "the_flowers", "she", "affirmed", "it", "after", "fixing", "them."]}, q, {q:"Did the florist fix the flowers first?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_security_guard", "affirmed", "his_superiority", "by", "blocking", "the_door."]}, q, {q:"Was the security guard confident?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_tourists", "wanted_to", "find", "the_monument", "on", "the_hill,", "but", "when", "they", "saw", "it", "they", "walked", "back", "down."]}, q, {q:"Did the tourists forget to see the monument?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_plumber", "found", "a_new_apartment", "after", "being", "evicted."]}, q, {q:"Was the plumber looking for a boat?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_speaker", "attempted_to", "argue", "her_point", "was", "correct,", "but", "after", "thinking", "it", "through", "she", "didn't."]}, q, {q:"Did the speaker defend herself?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_student", "argued", "his_point_of_view", "in", "the_essay."]}, q, {q:"Did the student defend himself?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_party_leader", "was_required_to", "reaffirm", "his_commitment", "was", "genuine,", "but", "during", "a_speech", "he", "didn't", "do_it."]}, q, {q:"Did the leader fail to reaffirm his commitment?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_horticulturalist", "reaffirmed", "his_love_of_nature", "by", "planting", "some_new_items."]}, q, {q:"Does the horticulturalist dislike the outdoors?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_student", "was_told_to", "assert", "her_opinion", "was", "valid,", "but", "in_the_end", "she", "asserted", "it", "was", "only", "worth", "considering."]}, q, {q:"Did the student lack confidence?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_queen", "asserted", "her_reign", "over", "the_land."]}, q, {q:"Did the queen want control over the land?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_meteorologist", "was_expected_to", "predict", "the_weather", "was", "going", "to", "be", "rainy,", "but", "ultimately", "he", "was", "unsure."]}, q, {q:"Did the meteorologist lose confidence in the prediction?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_oracle", "predicted", "the", "future", "with", "utter_accuracy."]}, q, {q:"Was the oracle wrong?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_father", "wanted_to", "suggest", "a_movie", "to", "his_daughter,", "but", "once", "it", "got", "too", "late", "he", "didn't."]}, q, {q:"Did they watch a movie?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_shop_owner", "suggested", "a_new_lamp", "to", "the_customer."]}, q, {q:"Did the shop owner suggest a vacuum cleaner?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_plaintiff", "was_expected_to", "deny", "the", "accusation", "immediately,", "but", "when", "the_trial", "started", "they", "didn't", "do_it."]}, q, {q:"Did the plaintiff deny the accusation?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_university", "denied", "admission", "to", "the_applicant", "with", "regret."]}, q, {q:"Was the university satisfied with its decision?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_journalist", "hoped_to", "report", "the_murder_case", "in", "the_paper,", "but", "once", "the_editor", "saw", "it", "she", "reported", "it", "online", "instead."]}, q, {q:"Did the journalist report the case in print?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_bystander", "reported", "the_crime", "to", "the_police."]}, q, {q:"Was the bystander silent?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_teacher", "hoped_to", "conclude", "the", "lecture", "by", "noon,", "but", "since", "it", "went", "slowly", "she", "concluded", "it", "by", "twelve-thirty", "instead."]}, q, {q:"Did the teacher conclude on time?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_pianist", "concluded", "the", "piece", "with", "a_lot", "of", "enthusiasm."]}, q, {q:"Was the pianist bored at the end of the piece?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_vase", "fell", "off", "the_kitchen", "table,", "and", "the_napkins", "fell", "too."]}, q, {q:"Did the vase fall off the kitchen table?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_old", "man", "fell", "off", "his_chair."]}, q, {q:"Did the old man fall off a piece of furniture?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_anchor", "sank", "to", "the_bottom", "of", "the_ocean,", "and", "one", "of", "the_nets", "sank", "with", "it."]}, q, {q:"Did the anchor sink to the bottom of the ocean?", hasCorrect: 0}, Separator, {}, ds, {s: ["The_man's", "stomach", "sank."]}, q, {q:"Did the man get a feeling in his stomach?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_radiator", "broke", "from", "too_much_use,", "and", "then", "the_air_conditioner", "broke", "too."]}, Separator, {}, ds, {s: ["The_hockey_player's", "ankle", "broke."]}, q, {q:"Did the hockey player injure his ankle?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_townsfolk", "swam", "in", "the_lake", "until", "winter,", "and", "then", "only", "the_fish", "swam."]}, Separator, {}, ds, {s: ["The_patient", "swims", "twice_a_week", "for", "physical_therapy."]}, q, {q:"Does the patient exercise?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_lake", "freezes", "over", "when", "it", "gets", "cold,", "and", "the_nearby_pond", "freezes", "too."]}, q, {q:"Does the lake resist freezing?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_ice-cream", "froze", "completely", "after", "four_hours."]}, q, {q:"Was the ice-cream cold?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_onions", "reeked", "throughout", "the_house,", "and", "the_garlic", "reeked", "too."]}, q, {q:"Does the onions' smell stay contained?", hasCorrect: 1}, Separator, {}, ds, {s: ["The_old", "food", "reeked", "after", "a_few_days."]}, q, {q:"Did the food go bad?", hasCorrect: 0}, Separator, {}],

["f", ds, {s: ["The_dog", "ran", "until", "it", "got", "tired,", "and", "its_owner", "ran", "after", "it."]}, Separator, {}, ds, {s: ["The_athlete", "runs", "for", "miles", "at", "a_time."]}, q, {q:"Does the athlete have low stamina?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_baby", "slept", "after", "a_long_day,", "and", "the_mother", "slept", "too."]}, Separator, {}, ds, {s: ["The_cat", "slept", "on", "the_porch."]}, q, {q:"Did the cat only sleep inside?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_children", "played", "on", "the_jungle_bars,", "and", "the_dogs", "played", "on", "the_grass."]}, Separator, {}, ds, {s: ["The_puppy", "played", "on", "the_couch."]}, q, {q:"Did a cat play on the couch?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_mouse", "scurried", "around", "the_corner,", "and", "the_cat", "scurried", "after", "it."]}, Separator, {}, ds, {s: ["The_bus", "boy", "scurried", "to", "the_kitchen."]}, q, {q:"Did the bus boy wait on a table?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_sun", "rose", "over", "the_forest,", "and", "clouds", "rose", "too."]}, Separator, {}, ds, {s: ["The_balloon", "rose", "into", "the_sky."]}, q, {q:"Did the balloon stay nearby?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_man", "shouted", "into", "the_microphone,", "and", "the_audience", "shouted", "too."]}, Separator, {}, ds, {s: ["The_police", "officer", "shouted", "at", "the_speeding", "driver."]}, q, {q:"Was the officer friendly?", hasCorrect: 1}, Separator, {}],

["f", ds, {s: ["The_old_vacuum_cleaner", "only", "worked", "for", "three_days,", "and", "the_new_one", "only", "worked", "for", "two."]}, Separator, {}, ds, {s: ["The_car", "didn't", "work", "after", "the_exhaust_pipe", "broke."]}, Separator, {}],

["f", ds, {s: ["The_plant", "slid", "off", "the_chair,", "and", "then", "it", "slid", "off", "the_balcony."]}, Separator, {}, ds, {s: ["The_skater", "slid", "on", "the_ice."]}, Separator, {}],

["f", ds, {s: ["The_snow", "melted", "in", "the_sun,", "and", "then", "the_ice", "melted."]}, Separator, {}, ds, {s: ["The_ice_sculpture", "melted", "before", "the_party", "was", "over."]}, Separator, {}],

["f", ds, {s: ["The_intermission", "ended", "very", "suddenly,", "and", "then", "the_play", "ended", "an_hour", "later."]}, Separator, {}, ds, {s: ["The_school_year", "ended", "after", "the_last_exams", "were", "done."]}, Separator, {}]

];
