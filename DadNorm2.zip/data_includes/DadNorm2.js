var shuffleSequence = seq("setcounter", "Intro", "Demog", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: false,
        instructions: "Use number keys or click choice to answer.",
        randomOrder: true,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],
    
  





/*
Subjects only see 6 items, but there are 9 conditions. Want them to see as varied as possible - i.e., 2 of each
context type and two of each antecedent type.

Condition key:

a unavailable exophoric
b available unmodified
c salient modified
d unavailable unmodified
e available modified
f salient exophoric
g unavailable modified
h available exophoric
i salient unmodified

z filler

*/









["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> An invitation</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/exp_images/example_1.png" height="50%"</center><p></p><p><big><b><i> Host:</i> The party is on Friday at 7.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The host will definitely invite their friend to the party.","The host will not invite their friend to the party."]}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, the comic strip and what the host said after the strip make it seem likely that the host will invite their friend to the party. You probably selected that the host would 'definitely' invite their friend."],
["p", "Press any key to continue."]
]}],

["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> An invitation</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/exp_images/example_2.png" height="50%"</center>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The host will ask their friend to bring a main dish.","The host will ask their friend to bring a dessert."]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it's not very clear from the scenario which answer is correct. In cases like this, it's OK to go with your first instinct, or just guess."],
["p", "Press any key to continue."]
]}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    
    
    
    
    
    
    
    



[["q1a", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1b", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1c", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1d", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1e", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1f", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1g", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy five candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1h", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1i", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.png" height="90%"</center> <p></p><p><big><b><i> Son: </i>I want to buy candy bars!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],












[["q2a", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2b", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2c", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2d", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2e", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2f", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2g", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take four candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2h", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],

[["q2i", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.png" height="90%"</center> <p></p><p><big><b><i> Standing worker: </i>I\'m going to take candies!</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The standing worker wants candy, but he doesn't care how many pieces.","The standing worker wants a specific number of pieces of candy."]}],









[["q3a", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3b", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3c", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3d", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3e", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3f", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3g", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add four peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3h", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],

[["q3i", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.png" height="90%"</center> <p></p><p><big><b><i> Student: </i>Now I\'m going to add peppers.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The student is planning to add peppers, but she doesn't care how many.","The student is planning to add a specific number of peppers."]}],










[["q4a", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4b", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4c", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4d", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4e", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4f", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4g", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get four charms for my bracelet.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4h", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],

[["q4i", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.png" height="90%"</center> <p></p><p><big><b><i> Wife: </i>I want to get charms for my bracelet.</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The wife wants to buy some charms, but she doesn't care how many.","The wife wants to buy a specific number of charms."]}],









[["q5a", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5b", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5c", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5d", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5e", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5f", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5g", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy three shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5h", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5i", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.png" height="90%"</center> <p></p><p><big><b><i> Clerk: </i>I think you should buy shirts today.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],








[["q6a", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6b", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6c", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6d", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6e", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6f", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6g", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy three princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6h", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6i", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.png" height="90%"</center> <p></p><p><big><b><i> Daughter: </i>I want to buy princess dresses!</b></big></p> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],






















[["q7z", 7], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_1.png" height="90%"</center> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The man will accept the martini.","The man will ask for a beer."]}],

[["q8z", 8], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_2.png" height="90%"</center> <p></p><p><big><b><i> Host: </i>Do you want a piece of cake?</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The man will take a small piece of cake.","The man will take a big piece of cake."]}],

[["q9z", 9], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a liquor store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_5.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The couple will buy cola.","The couple will buy wine."]}],

[["q10z", 10], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a bake sale</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_7.png" height="90%"</center> <p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The woman picked up a pie.","The woman picked up a bag of cookies."], hasCorrect: true, randomOrder: true}],

[["q11z", 11], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Writing</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_10.png" height="90%"</center> <p></p><p><big><b><i> Person on right: </i>Oops, I broke my pencil.</b></big></p><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The woman broke the tip of a pencil.","The woman broke the table."], hasCorrect: true, randomOrder: true}],

[["q12z", 12], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Opening a lock</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_8.png" height="90%"</center><p></p>'}, q: "Based on the scenario above, which of the following do you think is most likely?", as: ["The woman could not open the lock.","The woman opened the lock on the first try."], hasCorrect: true, randomOrder: true}]





/*comma*/


    
    




];