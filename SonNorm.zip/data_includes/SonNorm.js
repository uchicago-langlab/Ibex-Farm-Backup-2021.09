var shuffleSequence = seq("setcounter", "Intro", "Demog", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: false,
        instructions: "Use number keys or click choice to answer.",
        randomOrder: true,
        hasCorrect: false
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Demog", "Form", {consentRequired: true, html: {include: "Demog.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],
    
    
/*Condition key

a unavailable strip "neutral"
b available strip "unmod"
c salient strip "mod"

f filler

*/












["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> An invitation</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/exp_images/example_1.png" height="50%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The host will definitely invite their friend to the party.","The host might invite their friend to the party.","The host will not invite their friend to the party."]}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it seems likely that the host will invite their friend, so you probably selected that the host would 'definitely' or 'might' invite their friend."],
["p", "Press any key to continue."]
]}],

["practice", "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> An invitation</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/exp_images/example_2.png" height="50%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The host will ask their friend to bring a main dish.","The host will ask their friend to bring a side dish.","The host will ask their friend to bring a dessert."]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it's not very clear from the comic strip which answer is correct. In cases like this, it's OK to go with your first instinct, or just guess."],
["p", "Press any key to continue."]
]}],


["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    
    
    
    
    
    
    
    



[["q1a", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The son does not want to buy any candy bars.","The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1b", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The son does not want to buy any candy bars.","The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],

[["q1c", 1], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The son does not want to buy any candy bars.","The son wants to buy candy bars, but doesn't care how many.","The son wants to buy a specific number of candy bars."]}],





[["q2a", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man does not want any candy.","The man wants candy, but he doesn't care how many pieces.","The man wants a specific number of pieces of candy."]}],

[["q2b", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man does not want any candy.","The man wants candy, but he doesn't care how many pieces.","The man wants a specific number of pieces of candy."]}],

[["q2c", 2], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man does not want any candy.","The man wants candy, but he doesn't care how many pieces.","The man wants a specific number of pieces of candy."]}],






[["q3a", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man is not planning to add any peppers.","The man is planning to add peppers, but he doesn't care how many.","The man is planning to add a specific number of peppers."]}],

[["q3b", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man is not planning to add any peppers.","The man is planning to add peppers, but he doesn't care how many.","The man is planning to add a specific number of peppers."]}],

[["q3c", 3], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man is not planning to add any peppers.","The man is planning to add peppers, but he doesn't care how many.","The man is planning to add a specific number of peppers."]}],





[["q4a", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman does not want to buy any charms.","The woman wants to buy some charms, but she doesn't care how many.","The woman wants to buy a specific number of charms."]}],

[["q4b", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman does not want to buy any charms.","The woman wants to buy some charms, but she doesn't care how many.","The woman wants to buy a specific number of charms."]}],

[["q4c", 4], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman does not want to buy any charms.","The woman wants to buy some charms, but she doesn't care how many.","The woman wants to buy a specific number of charms."]}],






[["q5a", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The clerk doesn't think the man should buy any shirts.","The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5b", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The clerk doesn't think the man should buy any shirts.","The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],

[["q5c", 5], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The clerk doesn't think the man should buy any shirts.","The clerk thinks the man should buy shirts, but doesn't care how many.","The clerk thinks the man should buy a specific number of shirts."]}],







[["q6a", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The daughter does not want to buy any dresses.","The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6b", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The daughter does not want to buy any dresses.","The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],

[["q6c", 6], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The daughter does not want to buy any dresses.","The daughter wants to buy dresses, but she doesn't care how many.","The daughter wants to buy a specific number of dresses."]}],






[["q7f", 7], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_1.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man will accept the drink.","The man will decline the drink.","The man will ask for a different drink."]}],

[["q8f", 8], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_2.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The man will ask for the smaller piece of cake.","The man will ask for the larger piece of cake.","The man won't take any cake."]}],

[["q9f", 9], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> In a liquor store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_5.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The couple will buy beer.","The couple will buy cola.","The couple will buy wine."]}],

[["q10f", 10], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> At a bake sale</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_7.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman picked up a pie.","The woman picked up a bag of cookies.","The woman did not pick anything up."], hasCorrect: true, randomOrder: true}],

[["q11f", 11], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Writing</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_10.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman broke the tip of a pencil.","The woman broke a pen.","The woman broke the table."], hasCorrect: true, randomOrder: true}],

[["q12f", 12], "AcceptabilityJudgment", {s: {html: '<h><b><center><font size="5"> Opening a lock</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_8.png" height="90%"</center>'}, q: "Based on the comic strip above, which of the following do you think is most likely?", as: ["The woman could not open the lock.","The woman opened the lock on the first try.","The woman successfully opened the lock after several tries."], hasCorrect: true, randomOrder: true}]





/*comma*/


    
    




];