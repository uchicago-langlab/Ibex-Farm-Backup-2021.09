//var shuffleSequence = seq("setcounter", "intro", "intro1", "intro2", "intro3", "intro4", "practicestarts", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("c"), startsWith("f")))), "exit");

var shuffleSequence = seq("introSTOP");

var practiceItemTypes = ["practice"];

var showProgressBar = true;

var defaults = [
    "Separator", {
        transfer: 750,
        normalMessage: " ",
        errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: " ",
        leftComment: "Inaceptable", rightComment: "Aceptable"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Clickeá para continuar"
    }
];

var items = [

    ["setcounter", "__SetCounter__", { }],

    ["sep", "Separator", { }],

    ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }}],

    ["practiceover", "Form", {consentRequired: true, html: {include: "practiceover.html" }}],

    ["practicestarts", "Form", {consentRequired: true, html: {include: "practicestarts.html" }}],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html" }}],

    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }}],

    ["intro3", "Form", {consentRequired: true, html: {include: "intro3.html" }}],

    ["intro4", "Form", {consentRequired: true, html: {include: "intro4.html" }}],

    ["introSTOP", "Form", {consentRequired: true, html: {include: "introSTOP.html" }}],

    ["exit", "Form", {consentRequired: true, html: {include: "exit.html" }}],

    //
    // Three practice items for the Acceptability Judgment task:
    //
    ["practice", "AcceptabilityJudgment", {s: "Juan vio a los estudiantes que hablaron con el director después de clase."}],
    ["practice", "AcceptabilityJudgment", {s: "Los periodistas entrevistaron al actor que el director de la obra viajó a Berlín."}],
    ["practice", "AcceptabilityJudgment", {s: "El médico ayudó a la enfermera que el paciente golpeó al policía a la salida del hospital."}],

    //
    // 36 experimental sets (critical items)
    // This is a 6x2 design: 12 conditions: 
    // Keys: c = critical item; N = non-island; W = whether island; WH = wh-island; C = CNP island; A = adjunct island; R = RC island

    [["c.N.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que escuchó que Sonia contrató a Matías."}],
    [["c.N.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías escuchó que Pedro contrató."}],
    [["c.W.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que preguntó si Sonia contrató a Matías."}],
    [["c.W.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías preguntó si Sonia contrató."}],
    [["c.WH.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que preguntó quién contrató a Matías."}],
    [["c.WH.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías preguntó quién contrató."}],
    [["c.C.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que escuchó el rumor de que Sonia contrató a Matías."}],
    [["c.C.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías escuchó el rumor de que Pedro contrató."}],
    [["c.A.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor se alegró cuando Sonia contrató a Matías."}],
    [["c.A.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías se alegró cuando Pedro contrató."}],
    [["c.R.M",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que escuchó que los empleados que contrataron a Matías renunciaron ayer."}],
    [["c.R.E",1], "AcceptabilityJudgment", {s: "Laura vio al profesor que Matías escuchó que los empleados que contrataron renunciaron ayer."}],


	[["c.N.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que escuchó que Karina citó a Fernando."}],
    [["c.N.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando escuchó que Karina citó."}],
    [["c.W.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que preguntó si Karina citó a Fernando."}],
    [["c.W.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando preguntó si Karina citó."}],
    [["c.WH.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que preguntó quién citó a Fernando."}],
    [["c.WH.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando preguntó quién citó."}],
    [["c.C.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que escuchó el rumor de que Karina citó a Fernando."}],
    [["c.C.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando escuchó el rumor de que Karina citó."}],
    [["c.A.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que se alegró cuando Karina citó a Fernando."}],
    [["c.A.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando se alegró cuando Karina citó."}],
    [["c.R.M",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que escuchó que los médicos que citaron a Fernando renunciaron ayer."}],
    [["c.R.E",2], "AcceptabilityJudgment", {s: "Bruno llamó al enfermero que Fernando escuchó que los médicos que citaron renunciaron ayer."}],


	[["c.N.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que escuchó que Teresa hirió a Susana."}],
    [["c.N.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana escuchó que Teresa hirió."}],
    [["c.W.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que preguntó si Teresa hirió a Susana."}],
    [["c.W.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana preguntó si Teresa hirió."}],
    [["c.WH.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que preguntó quién hirió a Susana."}],
    [["c.WH.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana preguntó quién hirió."}],
    [["c.C.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que escuchó el rumor de que Teresa hirió a Susana."}],
    [["c.C.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana escuchó el rumor de que Teresa hirió."}],
    [["c.A.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que se alegró cuando Teresa hirió a Susana."}],
    [["c.A.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana se alegró cuando Teresa hirió."}],
    [["c.R.M",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que escuchó que los profesores que hirieron a Susana renunciaron ayer."}],
    [["c.R.E",3], "AcceptabilityJudgment", {s: "Juan atacó al empleado que Susana escuchó que los profesores que hirieron renunciaron ayer."}],


	[["c.N.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que escuchó que Mariano rescató a Andrés."}],
    [["c.N.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés escuchó que Mariano rescató."}],
    [["c.W.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que preguntó si Mariano rescató a Andrés."}],
    [["c.W.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés preguntó si Mariano rescató."}],
    [["c.WH.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que preguntó quién rescató a Andrés."}],
    [["c.WH.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés preguntó quién rescató."}],
    [["c.C.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que escuchó el rumor de que Mariano rescató a Andrés."}],
    [["c.C.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés escuchó el rumor de que Mariano rescató."}],
    [["c.A.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que se alegró cuando Mariano rescató a Andrés."}],
    [["c.A.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés se alegró cuando Mariano rescató."}],
    [["c.R.M",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que escuchó que los bomberos que rescataron a Andrés renunciaron ayer."}],
    [["c.R.E",4], "AcceptabilityJudgment", {s: "Elena eligió al estudiante que Andrés escuchó que los bomberos que rescataron renunciaron ayer."}],


	[["c.N.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que escuchó que Rodrigo golpeó a Carlos."}],
    [["c.N.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos escuchó que Rodrigo golpeó."}],
    [["c.W.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que preguntó si Rodrigo golpeó a Carlos."}],
    [["c.W.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos preguntó si Rodrigo golpeó."}],
    [["c.Wh.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que preguntó quién golpeó a Carlos."}],
    [["c.WH.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos preguntó quién golpeó."}],
    [["c.C.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que escuchó el rumor de que Rodrigo golpeó a Carlos."}],
    [["c.C.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos escuchó el rumor de que Rodrigo golpeó."}],
    [["c.A.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que se alegró cuando Rodrigo golpeó a Carlos."}],
    [["c.A.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos se alegró cuando Rodrigo golpeó."}],
    [["c.R.M",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que escuchó que los profesores que golpearon a Carlos renunciaron ayer."}],
    [["c.R.E",5], "AcceptabilityJudgment", {s: "Marina empujó al chico que Carlos escuchó que los profesores que golpearon renunciaron ayer."}],


	[["c.N.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que escuchó que Ana echó a Mauricio."}],
    [["c.N.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio escuchó que Ana echó."}],
    [["c.W.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que preguntó si Ana echó a Mauricio."}],
    [["c.W.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio preguntó si Ana echó."}],
    [["c.Wh.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que preguntó quién echó a Mauricio."}],
    [["c.WH.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio preguntó quién echó."}],
    [["c.C.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que escuchó el rumor de que Ana echó a Mauricio."}],
    [["c.C.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio escuchó el rumor de que Ana echó."}],
    [["c.A.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que se alegró cuando Ana echó a Mauricio."}],
    [["c.A.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio se alegró cuando Ana echó."}],
    [["c.R.M",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que escuchó que los productores que echaron a Mauricio renunciaron ayer."}],
    [["c.R.E",6], "AcceptabilityJudgment", {s: "Pablo conoció al periodista que Mauricio escuchó que los productores que echaron renunciaron ayer."}],


	[["c.N.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que escuchó que Cristina llamó a Ernesto."}],
    [["c.N.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto escuchó que Cristina llamó."}],
    [["c.W.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que preguntó si Cristina llamó a Ernesto."}],
    [["c.W.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto preguntó si Cristina llamó."}],
    [["c.Wh.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que preguntó quién llamó a Ernesto."}],
    [["c.WH.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto preguntó quién llamó."}],
    [["c.C.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que escuchó el rumor de que Cristina llamó a Ernesto."}],
    [["c.C.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto escuchó el rumor de que Cristina llamó."}],
    [["c.A.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que se alegró cuando Cristina llamó a Ernesto."}],
    [["c.A.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto se alegró cuando Cristina llamó."}],
    [["c.R.M",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que escuchó que los médicos que llamaron a Ernesto renunciaron ayer."}],
    [["c.R.E",7], "AcceptabilityJudgment", {s: "José cuidó al paciente que Ernesto escuchó que los médicos que llamaron renunciaron ayer."}],


	[["c.N.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que escuchó que Aníbal persiguió a Lucía."}],
    [["c.N.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía escuchó que Aníbal persiguió."}],
    [["c.W.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que preguntó si Aníbal persiguió a Lucía."}],
    [["c.W.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía preguntó si Aníbal persiguió."}],
    [["c.Wh.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que preguntó quién persiguió a Lucía."}],
    [["c.WH.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía preguntó quién persiguió."}],
    [["c.C.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que escuchó el rumor de que Aníbal persiguió a Lucía."}],
    [["c.C.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía escuchó el rumor de que Aníbal persiguió."}],
    [["c.A.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que se alegró cuando Aníbal persiguió a Lucía."}],
    [["c.A.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía se alegró cuando Aníbal persiguió."}],
    [["c.R.M",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que escuchó que los fiscales que persiguieron a Lucía renunciaron ayer."}],
    [["c.R.E",8], "AcceptabilityJudgment", {s: "Camila ayudó al policía que Lucía escuchó que los fiscales que persiguieron renunciaron ayer."}],


	[["c.N.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que escuchó que Paula salvó a Diego."}],
    [["c.N.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego escuchó que Paula salvo."}],
    [["c.W.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que preguntó si Paula salvó a Diego."}],
    [["c.W.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego preguntó si Paula salvó."}],
    [["c.Wh.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que preguntó quién salvó a Diego."}],
    [["c.WH.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego preguntó quién salvó."}],
    [["c.C.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que escuchó el rumor de que Paula salvó a Diego."}],
    [["c.C.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego escuchó el rumor de que Paula salvo."}],
    [["c.A.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que se alegró cuando Paula salvó a Diego."}],
    [["c.A.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego se alegró cuando Paula salvo."}],
    [["c.R.M",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que escuchó que los actores que salvaron a Diego renunciaron ayer."}],
    [["c.R.E",9], "AcceptabilityJudgment", {s: "Eugenia entrevistó al pintor que Diego escuchó que los actores que salvaron renunciaron ayer."}],


	[["c.N.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que escuchó que Martín denunció a Sofía."}],
    [["c.N.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía escuchó que Martín denunció."}],
    [["c.W.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que preguntó si Martín denunció a Sofía."}],
    [["c.W.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía preguntó si Martín denunció."}],
    [["c.Wh.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que preguntó quién denunció a Sofía."}],
    [["c.WH.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía preguntó quién denunció."}],
    [["c.C.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que escuchó el rumor de que Martín denunció a Sofía."}],
    [["c.C.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía escuchó el rumor de que Martín denunció."}],
    [["c.A.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que se alegró cuando Martín denunció a Sofía."}],
    [["c.A.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía se alegró cuando Martín denunció."}],
    [["c.R.M",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que escuchó que los periodistas que denunciaron a Sofía renunciaron ayer."}],
    [["c.R.E",10], "AcceptabilityJudgment", {s: "Jorge hirió al hombre que Sofía escuchó que los periodistas que denunciaron renunciaron ayer."}],


	[["c.N.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que escuchó que Diego empujó a Sonia."}],
    [["c.N.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al medico que Sonia escuchó que Diego empujó."}],
    [["c.W.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que preguntó si Diego empujó a Sonia."}],
    [["c.W.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que Sonia preguntó si Diego empujó."}],
    [["c.Wh.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que preguntó quién empujó a Sonia."}],
    [["c.WH.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que Sonia preguntó quién empujó."}],
    [["c.C.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que escuchó el rumor de que Diego empujó a Sonia."}],
    [["c.C.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al medico que Sonia escuchó el rumor de que Diego empujó."}],
    [["c.A.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que se alegró cuando Diego empujó a Sonia."}],
    [["c.A.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al medico que Sonia se alegró cuando Diego empujó."}],
    [["c.R.M",11], "AcceptabilityJudgment", {s: "Jesica visitó al médico que escuchó que los enfermeros que empujaron a Sonia renunciaron ayer."}],
    [["c.R.E",11], "AcceptabilityJudgment", {s: "Jesica visitó al medico que Sonia escuchó que los enfermeros que empujaron renunciaron ayer."}],


	[["c.N.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que escuchó que Florencia felicitó a Marcelo."}],
    [["c.N.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo escuchó que Florencia felicitó."}],
    [["c.W.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que preguntó si Florencia felicitó a Marcelo."}],
    [["c.W.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo preguntó si Florencia felicitó."}],
    [["c.Wh.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que preguntó quién felicitó a Marcelo."}],
    [["c.WH.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo preguntó quién felicitó."}],
    [["c.C.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que escuchó el rumor de que Florencia felicitó a Marcelo."}],
    [["c.C.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo escuchó el rumor de que Florencia felicitó."}],
    [["c.A.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que se alegró cuando Florencia felicitó a Marcelo."}],
    [["c.A.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo se alegró cuando Florencia felicitó."}],
    [["c.R.M",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que escuchó que los guionistas que felicitaron a Marcelo renunciaron ayer."}],
    [["c.R.E",12], "AcceptabilityJudgment", {s: "Esteban contrató al actor que Marcelo escuchó que los guionistas que felicitaron renunciaron ayer."}],


	[["c.N.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que escuchó que Pedro acusó a Mariano."}],
    [["c.N.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano escuchó que Pedro acusó."}],
    [["c.W.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que preguntó si Pedro acusó a Mariano."}],
    [["c.W.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano preguntó si Pedro acusó."}],
    [["c.Wh.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que preguntó quién acusó a Mariano."}],
    [["c.WH.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano preguntó quién acusó."}],
    [["c.C.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que escuchó el rumor de que Pedro acusó a Mariano."}],
    [["c.C.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano escuchó el rumor de que Pedro acusó."}],
    [["c.A.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que se alegró cuando Pedro acusó a Mariano."}],
    [["c.A.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano se alegró cuando Pedro acusó."}],
    [["c.R.M",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que escuchó que los profesores que acusaron a Mariano renunciaron ayer."}],
    [["c.R.E",13], "AcceptabilityJudgment", {s: "Marta echó a la secretaria que Mariano escuchó que los profesores que acusaron renunciaron ayer."}],


	[["c.N.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que escuchó que María defendió a Julián."}],
    [["c.N.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián escuchó que María defendió."}],
    [["c.W.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que preguntó si María defendió a Julián."}],
    [["c.W.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián preguntó si María defendió."}],
    [["c.Wh.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que preguntó quién defendió a Julián."}],
    [["c.WH.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián preguntó quién defendió."}],
    [["c.C.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que escuchó el rumor de que María defendió a Julián."}],
    [["c.C.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián escuchó el rumor de que María defendió."}],
    [["c.A.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que se alegró cuando María defendió a Julián."}],
    [["c.A.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián se alegró cuando María defendió."}],
    [["c.R.M",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que escuchó que los maestros que defendieron a Julián renunciaron ayer."}],
    [["c.R.E",14], "AcceptabilityJudgment", {s: "Juan premió a la estudiante que Julián escuchó que los maestros que defendieron renunciaron ayer."}],


	[["c.N.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que escuchó que Luciano insultó a Laura."}],
    [["c.N.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura escuchó que Luciano insultó."}],
    [["c.W.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que preguntó si Luciano insultó a Laura."}],
    [["c.W.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura preguntó si Luciano insultó."}],
    [["c.Wh.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que preguntó quién insultó a Laura."}],
    [["c.WH.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura preguntó quién insultó."}],
    [["c.C.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que escuchó el rumor de que Luciano insultó a Laura."}],
    [["c.C.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura escuchó el rumor de que Luciano insultó."}],
    [["c.A.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que se alegró cuando Luciano insultó a Laura."}],
    [["c.A.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura se alegró cuando Luciano insultó."}],
    [["c.R.M",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que escuchó que los médicos que insultaron a Laura renunciaron ayer."}],
    [["c.R.E",15], "AcceptabilityJudgment", {s: "Sonia golpeó a la enfermera que Laura escuchó que los médicos que insultaron renunciaron ayer."}],


	[["c.N.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que escuchó que Clara interrogó a Víctor."}],
    [["c.N.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor escuchó que Clara interrogó."}],
    [["c.W.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que preguntó si Clara interrogó a Víctor."}],
    [["c.W.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor preguntó si Clara interrogó."}],
    [["c.Wh.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que preguntó quién interrogó a Víctor."}],
    [["c.WH.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor preguntó quién interrogó."}],
    [["c.C.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que escuchó el rumor de que Clara interrogó a Víctor."}],
    [["c.C.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor escuchó el rumor de que Clara interrogó."}],
    [["c.A.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que se alegró cuando Clara interrogó a Víctor."}],
    [["c.A.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor se alegró cuando Clara interrogó."}],
    [["c.R.M",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que escuchó que los directivos que interrogaron a Víctor renunciaron ayer."}],
    [["c.R.E",16], "AcceptabilityJudgment", {s: "Daniel denunció a la profesora que Víctor escuchó que los directivos que interrogaron renunciaron ayer."}],


	[["c.N.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que escuchó que Matías lastimó a Carlos."}],
    [["c.N.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos escuchó que Matías lastimó."}],
    [["c.W.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que preguntó si Matías lastimó a Carlos."}],
    [["c.W.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos preguntó si Matías lastimó."}],
    [["c.Wh.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que preguntó quién lastimó a Carlos."}],
    [["c.WH.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos preguntó quién lastimó."}],
    [["c.C.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que escuchó el rumor de que Matías lastimó a Carlos."}],
    [["c.C.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos escuchó el rumor de que Matías lastimó."}],
    [["c.A.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que se alegró cuando Matías lastimó a Carlos."}],
    [["c.A.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos se alegró cuando Matías lastimó."}],
    [["c.R.M",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que escuchó que los policías que lastimaron a Carlos renunciaron ayer."}],
    [["c.R.E",17], "AcceptabilityJudgment", {s: "Valeria persiguió a la empleada que Carlos escuchó que los policías que lastimaron renunciaron ayer."}],


	[["c.N.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que escuchó que Andrés protegió a Raúl."}],
    [["c.N.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl escuchó que Andrés protegió."}],
    [["c.W.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que preguntó si Andrés protegió a Raúl."}],
    [["c.W.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl preguntó si Andrés protegió."}],
    [["c.Wh.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que preguntó quién protegió a Raúl."}],
    [["c.WH.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl preguntó quién protegió."}],
    [["c.C.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que escuchó el rumor de que Andrés protegió a Raúl."}],
    [["c.C.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl escuchó el rumor de que Andrés protegió."}],
    [["c.A.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que se alegró cuando Andrés protegió a Raúl."}],
    [["c.A.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl se alegró cuando Andrés protegió."}],
    [["c.R.M",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que escuchó que los abogados que protegieron a Raúl renunciaron ayer."}],
    [["c.R.E",18], "AcceptabilityJudgment", {s: "Florencia interrogó al juez que Raúl escuchó que los abogados que protegieron renunciaron ayer."}],


	[["c.N.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que escuchó que Daniel avergonzó a Susana."}],
    [["c.N.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana escuchó que Daniel avergonzó."}],
    [["c.W.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que preguntó si Daniel avergonzó a Susana."}],
    [["c.W.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana preguntó si Daniel avergonzó."}],
    [["c.Wh.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que preguntó quién avergonzó a Susana."}],
    [["c.WH.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana preguntó quién avergonzó."}],
    [["c.C.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que escuchó el rumor de que Daniel avergonzó a Susana."}],
    [["c.C.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana escuchó el rumor de que Daniel avergonzó."}],
    [["c.A.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que se alegró cuando Daniel avergonzó a Susana."}],
    [["c.A.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana se alegró cuando Daniel avergonzó."}],
    [["c.R.M",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que escuchó que los actores que avergonzaron a Susana renunciaron ayer."}],
    [["c.R.E",19], "AcceptabilityJudgment", {s: "Ernesto amenazó al periodista que Susana escuchó que los actores que avergonzaron renunciaron ayer."}],


	[["c.N.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que escuchó que Jesica ayudó a Sebastián."}],
    [["c.N.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián escuchó que Jesica ayudó."}],
    [["c.W.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que preguntó si Jesica ayudó a Sebastián."}],
    [["c.W.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián preguntó si Jesica ayudó."}],
    [["c.Wh.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que preguntó quién ayudó a Sebastián."}],
    [["c.WH.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián preguntó quién ayudó."}],
    [["c.C.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que escuchó el rumor de que Jesica ayudó a Sebastián."}],
    [["c.C.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián escuchó el rumor de que Jesica ayudó."}],
    [["c.A.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que se alegró cuando Jesica ayudó a Sebastián."}],
    [["c.A.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián se alegró cuando Jesica ayudó."}],
    [["c.R.M",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que escuchó que los enfermeros que ayudaron a Sebastián renunciaron ayer."}],
    [["c.R.E",20], "AcceptabilityJudgment", {s: "Cristina reconoció a la chica que Sebastián escuchó que los enfermeros que ayudaron renunciaron ayer."}],


	[["c.N.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que escuchó que Santiago entrevistó a Paula."}],
    [["c.N.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula escuchó que Santiago entrevistó."}],
    [["c.W.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que preguntó si Santiago entrevistó a Paula."}],
    [["c.W.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula preguntó si Santiago entrevistó."}],
    [["c.Wh.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que preguntó quién entrevistó a Paula."}],
    [["c.WH.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula preguntó quién entrevistó."}],
    [["c.C.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que escuchó el rumor de que Santiago entrevistó a Paula."}],
    [["c.C.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula escuchó el rumor de que Santiago entrevistó."}],
    [["c.A.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que se alegró cuando Santiago entrevistó a Paula."}],
    [["c.A.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula se alegró cuando Santiago entrevistó."}],
    [["c.R.M",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que escuchó que los periodistas que entrevistaron a Paula renunciaron ayer."}],
    [["c.R.E",21], "AcceptabilityJudgment", {s: "Mariana felicitó a la cantante que Paula escuchó que los periodistas que entrevistaron renunciaron ayer."}],


	[["c.N.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que escuchó que Lucio atacó a Federico."}],
    [["c.N.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico escuchó que Lucio atacó."}],
    [["c.W.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que preguntó si Lucio atacó a Federico."}],
    [["c.W.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico preguntó si que Lucio atacó."}],
    [["c.Wh.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que preguntó si Lucio atacó a Federico."}],
    [["c.WH.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico preguntó si que Lucio atacó."}],
    [["c.C.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que escuchó el rumor de que Lucio atacó a Federico."}],
    [["c.C.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico escuchó el rumor de que Lucio atacó."}],
    [["c.A.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que se alegró cuando Lucio atacó a Federico."}],
    [["c.A.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico se alegró cuando Lucio atacó."}],
    [["c.R.M",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que escuchó que los policías que atacaron a Federico renunciaron ayer."}],
    [["c.R.E",22], "AcceptabilityJudgment", {s: "Teresa acusó a la mujer que Federico escuchó que los policías que atacaron renunciaron ayer."}],


	[["c.N.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que escuchó que Laura elogió a Rodrigo."}],
    [["c.N.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo escuchó que Laura elogió."}],
    [["c.W.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que preguntó si Laura elogió a Rodrigo."}],
    [["c.W.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo preguntó si Laura elogió."}],
    [["c.Wh.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que preguntó quién elogió a Rodrigo."}],
    [["c.WH.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo preguntó quién elogió."}],
    [["c.C.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que escuchó el rumor de que Laura elogió a Rodrigo."}],
    [["c.C.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo escuchó el rumor de que Laura elogió."}],
    [["c.A.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que se alegró cuando Laura elogió a Rodrigo."}],
    [["c.A.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo se alegró cuando Laura elogió."}],
    [["c.R.M",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que escuchó que los directivos que elogiaron a Rodrigo renunciaron ayer."}],
    [["c.R.E",23], "AcceptabilityJudgment", {s: "Paula insultó a la profesora que Rodrigo escuchó que los directivos que elogiaron renunciaron ayer."}],


	[["c.N.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que escuchó que Florencia visitó a Camila."}],
    [["c.N.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila escuchó que Florencia visitó."}],
    [["c.W.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que preguntó si Florencia visitó a Camila."}],
    [["c.W.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila preguntó si Florencia visitó."}],
    [["c.Wh.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que preguntó quién visitó a Camila."}],
    [["c.WH.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila preguntó quién visitó."}],
    [["c.C.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que escuchó el rumor de que Florencia visitó a Camila."}],
    [["c.C.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila escuchó el rumor de que Florencia visitó."}],
    [["c.A.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que se alegró cuando Florencia visitó a Camila."}],
    [["c.A.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila se alegró cuando Florencia visitó."}],
    [["c.R.M",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que escuchó que los jueces que visitaron a Camila renunciaron ayer."}],
    [["c.R.E",24], "AcceptabilityJudgment", {s: "Mario criticó al abogado que Camila escuchó que los jueces que visitaron renunciaron ayer."}],


	[["c.N.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que escuchó que Aníbal besó a Marta."}],
    [["c.N.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta escuchó que Aníbal besó."}],
    [["c.W.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que preguntó si Aníbal besó a Marta."}],
    [["c.W.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta preguntó si Aníbal besó."}],
    [["c.Wh.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que preguntó quién besó a Marta."}],
    [["c.WH.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta preguntó quién besó."}],
    [["c.C.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que escuchó el rumor de que Aníbal besó a Marta."}],
    [["c.C.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta escuchó el rumor de que Aníbal besó."}],
    [["c.A.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que se alegró cuando Aníbal besó a Marta."}],
    [["c.A.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta se alegró cuando Aníbal besó."}],
    [["c.R.M",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que escuchó que los actores que besaron a Marta renunciaron ayer."}],
    [["c.R.E",25], "AcceptabilityJudgment", {s: "Santiago defendió a la periodista que Marta escuchó que los actores que besaron renunciaron ayer."}],

 
	[["c.N.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que escuchó que Bruno buscó a Martín."}],
    [["c.N.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín escuchó que Bruno buscó."}],
    [["c.W.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que preguntó si Bruno buscó a Martín."}],
    [["c.W.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín preguntó si Bruno buscó."}],
    [["c.Wh.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que preguntó quién buscó a Martín."}],
    [["c.WH.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín preguntó quién buscó."}],
    [["c.C.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que escuchó el rumor de que Bruno buscó a Martín."}],
    [["c.C.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín escuchó el rumor de que Bruno buscó."}],
    [["c.A.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que se alegró cuando Bruno buscó a Martín."}],
    [["c.A.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín se alegró cuando Bruno buscó."}],
    [["c.R.M",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que escuchó que los periodistas que buscaron a Martín renunciaron ayer."}],
    [["c.R.E",26], "AcceptabilityJudgment", {s: "Paula salvó a la chica que Martín escuchó que los periodistas que buscaron renunciaron ayer."}],


	[["c.N.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que escuchó que Julián vio a María."}],
    [["c.N.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María escuchó que Julián vio."}],
    [["c.W.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que preguntó si Julián vio a María."}],
    [["c.W.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María preguntó si Julián vio."}],
    [["c.Wh.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que preguntó quién vio a María."}],
    [["c.WH.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María preguntó quién vio."}],
    [["c.C.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que escuchó el rumor de que Julián vio a María."}],
    [["c.C.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María escuchó el rumor de que Julián vio."}],
    [["c.A.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que se alegró cuando Julián vio a María."}],
    [["c.A.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María se alegró cuando Julián vio."}],
    [["c.R.M",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que escuchó que los estudiantes que vieron a María renunciaron ayer."}],
    [["c.R.E",27], "AcceptabilityJudgment", {s: "Franco rescató a la empleada que María escuchó que los estudiantes que vieron renunciaron ayer."}],

 
	[["c.N.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que escuchó que Adrián reconoció a Julia."}],
    [["c.N.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia escuchó que Adrián reconoció."}],
    [["c.W.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que preguntó si Adrián reconoció a Julia."}],
    [["c.W.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia preguntó si Adrián reconoció."}],
    [["c.Wh.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que preguntó quién reconoció a Julia."}],
    [["c.WH.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia preguntó quién reconoció."}],
    [["c.C.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que escuchó el rumor de que Adrián reconoció a Julia."}],
    [["c.C.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia escuchó el rumor de que Adrián reconoció."}],
    [["c.A.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que se alegró cuando Adrián reconoció a Julia."}],
    [["c.A.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia se alegró cuando Adrián reconoció."}],
    [["c.R.M",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que escuchó que los periodistas que reconocieron a Julia renunciaron ayer."}],
    [["c.R.E",28], "AcceptabilityJudgment", {s: "Pedro citó a la actriz que Julia escuchó que los periodistas que reconocieron renunciaron ayer."}],

 
	[["c.N.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que escuchó que Jesica apoyó a Laura."}],
    [["c.N.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura escuchó que Jesica apoyó."}],
    [["c.W.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que preguntó si Jesica apoyó a Laura."}],
    [["c.W.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura preguntó si Jesica apoyó."}],
    [["c.Wh.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que preguntó quién apoyó a Laura."}],
    [["c.WH.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura preguntó quién apoyó."}],
    [["c.C.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que escuchó el rumor de que Jesica apoyó a Laura."}],
    [["c.C.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura escuchó el rumor de que Jesica apoyó."}],
    [["c.A.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que se alegró cuando Jesica apoyó a Laura."}],
    [["c.A.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura se alegró cuando Jesica apoyó."}],
    [["c.R.M",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que escuchó que los supervisores que apoyaron a Laura renunciaron ayer."}],
    [["c.R.E",29], "AcceptabilityJudgment", {s: "Diego lastimó al profesor que Laura escuchó que los supervisores que apoyaron renunciaron ayer."}],


	[["c.N.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que escuchó que Sergio amenazó a Martín."}],
    [["c.N.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín escuchó que Sergio amenazó."}],
    [["c.W.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que preguntó si Sergio amenazó a Martín."}],
    [["c.W.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín preguntó si Sergio amenazó."}],
    [["c.Wh.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que preguntó quién amenazó a Martín."}],
    [["c.WH.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín preguntó quién amenazó."}],
    [["c.C.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que escuchó el rumor de que Sergio amenazó a Martín."}],
    [["c.C.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín escuchó el rumor de que Sergio amenazó."}],
    [["c.A.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que se alegró cuando Sergio amenazó a Martín."}],
    [["c.A.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín se alegró cuando Sergio amenazó."}],
    [["c.R.M",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que escuchó que los profesores que amenazaron a Martín renunciaron ayer."}],
    [["c.R.E",30], "AcceptabilityJudgment", {s: "Sonia protegió al estudiante que Martín escuchó que los profesores que amenazaron renunciaron ayer."}],


	[["c.N.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que escuchó que Manuel criticó a Elena."}],
    [["c.N.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena escuchó que Manuel criticó."}],
    [["c.W.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que preguntó si Manuel criticó a Elena."}],
    [["c.W.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena preguntó si Manuel criticó."}],
    [["c.Wh.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que preguntó quién criticó a Elena."}],
    [["c.WH.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena preguntó quién criticó."}],
    [["c.C.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que escuchó el rumor de que Manuel criticó a Elena."}],
    [["c.C.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena escuchó el rumor de que Manuel criticó."}],
    [["c.A.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que se alegró cuando Manuel criticó a Elena."}],
    [["c.A.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena se alegró cuando Manuel criticó."}],
    [["c.R.M",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que escuchó que los enfermeros que criticaron a Elena renunciaron ayer."}],
    [["c.R.E",31], "AcceptabilityJudgment", {s: "Paula abrazó a la mujer que Elena escuchó que los enfermeros que criticaron renunciaron ayer."}],


	[["c.N.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que escuchó que Martín apoyó a Simón."}],
    [["c.N.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón escuchó que Martín apoyó."}],
    [["c.W.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que preguntó si Martín apoyó a Simón."}],
    [["c.W.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón preguntó si Martín apoyó."}],
    [["c.Wh.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que preguntó quién apoyó a Simón."}],
    [["c.WH.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón preguntó quién apoyó."}],
    [["c.C.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que escuchó el rumor de que Martín apoyó a Simón."}],
    [["c.C.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón escuchó el rumor de que Martín apoyó."}],
    [["c.A.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que se alegró cuando Martín apoyó a Simón."}],
    [["c.A.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón se alegró cuando Martín apoyó."}],
    [["c.R.M",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que escuchó que los profesores que apoyaron a Simón renunciaron ayer."}],
    [["c.R.E",32], "AcceptabilityJudgment", {s: "Andrés aprobó al estudiante que Simón escuchó que los profesores que apoyaron a Simón renunciaron ayer."}],


	[["c.N.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que escuchó que Pablo premió a Karina."}],
    [["c.N.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina escuchó que Pablo premió."}],
    [["c.W.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que preguntó si Pablo premió a Karina."}],
    [["c.W.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina preguntó si Pablo premió."}],
    [["c.Wh.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que preguntó si Pablo premió a Karina."}],
    [["c.WH.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina preguntó si Pablo premió."}],
    [["c.C.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que escuchó el rumor de que Pablo premió a Karina."}],
    [["c.C.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina escuchó el rumor de que Pablo premió."}],
    [["c.A.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que se alegró cuando Pablo premió a Karina."}],
    [["c.A.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina se alegró cuando Pablo premió."}],
    [["c.R.M",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que escuchó que los productores que premiaron a Karina renunciaron ayer."}],
    [["c.R.E",33], "AcceptabilityJudgment", {s: "Laura apoyó a la cantante que Karina escuchó que los productores que premiaron renunciaron ayer."}],


	[["c.N.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que escuchó que Camila abrazó a Mario."}],
    [["c.N.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario escuchó que Camila abrazó."}],
    [["c.W.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que preguntó si Camila abrazó a Mario."}],
    [["c.W.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario preguntó si Camila abrazó."}],
    [["c.Wh.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que preguntó quién abrazó a Mario."}],
    [["c.WH.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario preguntó quién abrazó."}],
    [["c.C.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que escuchó el rumor de que Camila abrazó a Mario."}],
    [["c.C.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario escuchó el rumor de que Camila abrazó."}],
    [["c.A.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que se alegró cuando Camila abrazó a Mario."}],
    [["c.A.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario se alegró cuando Camila abrazó."}],
    [["c.R.M",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que escuchó que los empleados que abrazaron a Mario renunciaron ayer."}],
    [["c.R.E",34], "AcceptabilityJudgment", {s: "Sonia avergonzó al profesor que Mario escuchó que los empleados que abrazaron renunciaron ayer."}],


	[["c.N.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que escuchó que Teresa cuidó a Carolina."}],
    [["c.N.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina escuchó que Teresa cuidó."}],
    [["c.W.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que preguntó si Teresa cuidó a Carolina."}],
    [["c.W.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina preguntó si Teresa cuidó."}],
    [["c.Wh.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que preguntó quién cuidó a Carolina."}],
    [["c.WH.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina preguntó quién cuidó."}],
    [["c.C.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que escuchó el rumor de que Teresa cuidó a Carolina."}],
    [["c.C.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina escuchó el rumor de que Teresa cuidó."}],
    [["c.A.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que se alegró cuando Teresa cuidó a Carolina."}],
    [["c.A.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina se alegró cuando Teresa cuidó."}],
    [["c.R.M",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que escuchó que los maestros que cuidaron a Carolina renunciaron ayer."}],
    [["c.R.E",35], "AcceptabilityJudgment", {s: "Marcos desaprobó al chico que Carolina escuchó que los maestros que cuidaron renunciaron ayer."}],


	[["c.N.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que escuchó que Matías estafó a Sofía."}],
    [["c.N.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía escuchó que Matías estafó."}],
    [["c.W.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que preguntó si Matías estafó a Sofía."}],
    [["c.W.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía preguntó si Matías estafó."}],
    [["c.Wh.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que preguntó quién estafó a Sofía."}],
    [["c.WH.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía preguntó quién estafó."}],
    [["c.C.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que escuchó el rumor de que Matías estafó a Sofía."}],
    [["c.C.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía escuchó el rumor de que Matías estafó."}],
    [["c.A.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que se alegró cuando Matías estafó a Sofía."}],
    [["c.A.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía se alegró cuando Matías estafó."}],
    [["c.R.M",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que escuchó que los profesores que estafaron a Sofía renunciaron ayer."}],
    [["c.R.E",36], "AcceptabilityJudgment", {s: "Marcelo buscó al estudiante que Sofía escuchó que los profesores que estafaron renunciaron ayer."}],


    //
    // 36 Fillers
    // 18 Good Fillers; 18 Bad Fillers
    // Keys: f = filler; G = Good Filler; B = Bad Filler

	["f.G.37", "AcceptabilityJudgment", {s: "Romina habló con el profesor de Biología que corrió una maratón el mes pasado."}],
	["f.G.38", "AcceptabilityJudgment", {s: "Tamara habló con las enfermeras que ganaron un premio por sus servicios en el hospital."}],
    ["f.G.39", "AcceptabilityJudgment", {s: "Federico habló con los estudiantes que escribieron un ensayo sobre el calentamiento global."}],
    ["f.G.40", "AcceptabilityJudgment", {s: "Martín no sabe si Romina vio al paciente que salió del hospital después de la operación."}],
    ["f.G.41", "AcceptabilityJudgment", {s: "Esteban no sabe si Susana habló con los profesores que viajaron a París el mes pasado."}],
    ["f.G.42", "AcceptabilityJudgment", {s: "Marcelo no sabe si Jesica felicitó a los científicos que descubrieron un nuevo planeta."}],
    ["f.G.43", "AcceptabilityJudgment", {s: "Ricardo preguntó quién contrató al profesor que llegó tarde a la entrevista de trabajo."}],
    ["f.G.44", "AcceptabilityJudgment", {s: "Laura preguntó quién habló con los periodistas que publicaron una noticia falsa."}],
    ["f.G.45", "AcceptabilityJudgment", {s: "Rodrigo preguntó quién desaprobó a los estudiantes que faltaron a clase una semana."}],
    ["f.G.46", "AcceptabilityJudgment", {s: "Tamara se alegró cuando Marcela ganó un premio por sus servicios en el hospital."}],
    ["f.G.47", "AcceptabilityJudgment", {s: "Federico se alegró cuando Martín escribió un ensayo sobre el calentamiento global."}],
    ["f.G.48", "AcceptabilityJudgment", {s: "Marcelo se alegró cuando los científicos descubrieron un nuevo planeta."}],
    ["f.G.49", "AcceptabilityJudgment", {s: "Los médicos que salvaron a Susana viajaron a París en un avión privado."}],
    ["f.G.50", "AcceptabilityJudgment", {s: "Las periodistas que entrevistaron a Carlos ganaron un premio el mes pasado."}],
    ["f.G.51", "AcceptabilityJudgment", {s: "Las actrices que criticaron a Fabio llegaron tarde al estreno de la película."}],
    ["f.G.52", "AcceptabilityJudgment", {s: "Romina habló con el profesor de biología que desaprobó a Carlos el mes pasado."}],
    ["f.G.53", "AcceptabilityJudgment", {s: "Tamara habló con la enfermera que ayudó a Francisco después de la operación."}],
    ["f.G.54", "AcceptabilityJudgment", {s: "Federico habló con el estudiante que empujó a Sonia a la salida del colegio."}],

    ["f.B.55", "AcceptabilityJudgment", {s: "Pedro ayudó a la médica que Susana habló con el director del hospital en la reunión."}],
    ["f.B.56", "AcceptabilityJudgment", {s: "Bruno esperó a los estudiantes que Mario aprobó a todos en el examen de Historia."}],
    ["f.B.57", "AcceptabilityJudgment", {s: "Hugo criticó al gerente que Fabiana despidió a la secretaria por llegar tarde al trabajo."}],
    ["f.B.58", "AcceptabilityJudgment", {s: "Carina vio al secretario que Ricardo ayudó al paciente después de la operación."}],
    ["f.B.59", "AcceptabilityJudgment", {s: "Adriana contrató al abogado que Jorge vio al juez el sábado a la tarde."}],
    ["f.B.60", "AcceptabilityJudgment", {s: "Marcos cuidó al chico que Luciano empujó al estudiante en el parque."}],
    ["f.B.61", "AcceptabilityJudgment", {s: "Martín vio al paciente que Romina no sabe si la operación fue exitosa."}],
    ["f.B.62", "AcceptabilityJudgment", {s: "Esteban vio al actor que Mariano no sabe si la serie saldrá el año que viene."}],
    ["f.B.63", "AcceptabilityJudgment", {s: "Laura amenazó al empleado que Marcelo no sabe si el banco rechazó el cheque."}],
    ["f.B.64", "AcceptabilityJudgment", {s: "Adrián ayudó al médico que Paula no sabe si el procedimiento tuvo complicaciones."}],
    ["f.B.65", "AcceptabilityJudgment", {s: "Ricardo preguntó que Romina contrató al profesor que llegó tarde."}],
    ["f.B.66", "AcceptabilityJudgment", {s: "Laura preguntó que Tomás habló con los periodistas la semana pasada."}],
    ["f.B.67", "AcceptabilityJudgment", {s: "Rodrigo preguntó que Mariana desaprobó a todos los estudiantes."}],
    ["f.B.68", "AcceptabilityJudgment", {s: "Sonia preguntó que Juan vio a los chicos que viajaron a París."}],
    ["f.B.69", "AcceptabilityJudgment", {s: "Los médicos que Susana vio a Marta viajaron a París la semana pasada."}],
    ["f.B.70", "AcceptabilityJudgment", {s: "Las periodistas que Hugo entrevistó a Carlos ganaron un premio el mes pasado."}],
    ["f.B.71", "AcceptabilityJudgment", {s: "Las actrices que Clara criticó a Fabio llegaron tarde al estreno de la película."}],
    ["f.B.72", "AcceptabilityJudgment", {s: "Los estudiantes que Sergio empujó a Carla desaprobaron el examen de Historia."}] // NOTE NO COMMA LAST SENTECE

];
