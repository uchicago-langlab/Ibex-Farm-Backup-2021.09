var shuffleSequence = seq('consent', 'intro', 'practice1', 'practice2', 'end_practice', rshuffle(startsWith('item-')), 'questionnaire', 'exit');

// rshuffle(rshuffle(startsWith('shape_')), rshuffle(startsWith('artifact_')))

var showProgressBar = false;
var pageTitle = "Mechanical Turk Experiment";
// "The results were successfully sent to the server.
// You can now validate your participation on Mechanical Turk. Thanks!"
var completionMessage = "your results have been submitted -- thank you!";
// "There was an error sending the results to the server.
var completionErrorMessage = "something went wrong";

var defaults = [
    "Separator", {
        transfer: 350,
        normalMessage: "+",
        errorMessage: "+",
        ignoreFailure: true
    },
    "Message", {
        hideProgressBar: false,
        transfer: "keypress"
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true
    },
];


var items = [

    ["sep", "Separator", { }],

    ["consent", "Form", {
        consentRequired: true,
        html: {include: "consent.html"}
    }],

    ["intro", "Form", {
        html: {include: "instructions.html"},
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    }],

    ["questionnaire", "Form", {
        html: {include: "questionnaire.html"},
        continueMessage: "click here to obtain an MTurk validation code"
    }],

    ["exit", "Form", {
        html: {include: "exit.html"},
        continueMessage: "click here to submit your reults!"
    }],

    ["practice1", "PictureSelect", {
         html: {include: "practice1.html"},
         prompt: 'Speaker: I saw a flower. It was colorful.<br/><br/>Make a guess: How colorful was the flower that the speaker saw? Choose one image from below.'
    }],
                
    ["end_practice", "Message", {
                consentRequired: false,
                transfer: "click",
                continueMessage: "Click here to begin the experiment.",
                html: "<div><p>You have finished the practice section.</p><p>For the rest of the study, for each sentence you will see, please <b>read the question carefully. </b></p>",
    }],
                
               
     // Beer
    [["item-full",1], "PictureSelect", {html: {include: "item_artifact_empty_full_beer.html"}, prompt: 'Speaker: I saw a glass of beer. It was full.<br/><br/>Make a guess: How full was the beer that the speaker saw? Choose one image from below.'}],
    [["item-empty",1], "PictureSelect", {html: {include: "item_artifact_empty_full_beer.html"}, prompt: 'Speaker: I saw a glass of beer. It was empty.<br/><br/>Make a guess: How empty was the beer that the speaker saw? Choose one image from below.'}],

     // Trash
    [["item-full",2], "PictureSelect", {html: {include: "item_artifact_empty_full_trash.html"}, prompt: 'Speaker: I saw a garbage truck. It was full.<br/><br/>Make a guess: How full was the garbage truck that the speaker saw? Choose one image from below.'}],
    [["item-empty", 2],"PictureSelect", {html: {include: "item_artifact_empty_full_trash.html"}, prompt: 'Speaker: I saw a garbage truck. It was empty.<br/><br/>Make a guess: How empty was the garbage truck that the speaker saw? Choose one image from below.'}],
     
     // Rod
    [["item-bent", 3],"PictureSelect", {html: {include: "item_artifact_straight_bent_straightrod.html"}, prompt: 'Speaker: I saw a rod. It was bent.<br/><br/>Make a guess: How bent was the rod that the speaker saw? Choose one image from below.'}],
    [["item-straight", 3],"PictureSelect", {html: {include: "item_artifact_straight_bent_straightrod.html"}, prompt: 'Speaker: I saw a rod. It was straight.<br/><br/>Make a guess: How straight was the rod that the speaker saw? Choose one image from below.'}],
              
    // Nail     
    [["item-bent",4], "PictureSelect", {html: {include: "item_artifact_straight_bent_bentnail.html"}, prompt: 'Speaker: I saw a nail. It was bent.<br/><br/>Make a guess: How bent was the nail that the speaker saw? Choose one image from below.'}],
    [["item-straight",4], "PictureSelect", {html: {include: "item_artifact_straight_bent_bentnail.html"}, prompt: 'Speaker: I saw a nail. It was straight.<br/><br/>Make a guess: How straight was the nail that the speaker saw? Choose one image from below.'}],
    
    // Boat
    [["item-big", 5],"PictureSelect", {html: {include: "item_artifact_small_big_boat.html"}, prompt: 'Speaker: I saw a boat. It was big.<br/><br/>Make a guess: How big was the boat that the speaker saw? Choose one image from below.'}],
    [["item-small",5], "PictureSelect", {html: {include: "item_artifact_small_big_boat.html"}, prompt: 'Speaker: I saw a boat. It was small.<br/><br/>Make a guess: How small was the boat that the speaker saw? Choose one image from below.'}],
    
    // Snowman         
    [["item-big", 6],"PictureSelect", {html: {include: "item_artifact_small_big_snowman.html"}, prompt: 'Speaker: I saw a snowman. It was big.<br/><br/>Make a guess: How big was the snowman that the speaker saw? Choose one image from below.'}],
    [["item-small",6], "PictureSelect", {html: {include: "item_artifact_small_big_snowman.html"}, prompt: 'Speaker: I saw a snowman. It was small.<br/><br/>Make a guess: How small was the snowman that the speaker saw? Choose one image from below.'}],
    
    // Bridge 1
    [["item-wide", 7],"PictureSelect", {html: {include: "item_artifact_narrow_wide_bridge.html"}, prompt: 'Speaker: I saw a bridge. It was wide.<br/><br/>Make a guess: How wide was the bridge that the speaker saw? Choose one image from below.'}],
    [["item-narrow",7], "PictureSelect", {html: {include: "item_artifact_narrow_wide_bridge.html"}, prompt: 'Speaker: I saw a bridge. It was narrow.<br/><br/>Make a guess: How narrow was the bridge that the speaker saw? Choose one image from below.'}],

    // Sofa
    [["item-wide", 8],"PictureSelect", {html: {include: "item_artifact_narrow_wide_sofa.html"}, prompt: 'Speaker: I saw a sofa. It was wide.<br/><br/>Make a guess: How wide was the sofa that the speaker saw? Choose one image from below.'}],
    [["item-narrow",8], "PictureSelect", {html: {include: "item_artifact_narrow_wide_sofa.html"}, prompt: 'Speaker: I saw a sofa. It was narrow.<br/><br/>Make a guess: How narrow was the sofa that the speaker saw? Choose one image from below.'}],
               
    // Fish
    [["item-striped",9],"PictureSelect", {html: {include: "item_artifact_plain_striped_bw_stripe_fish.html"}, prompt: 'Speaker: I saw a fish. It was striped.<br/><br/>Make a guess: How striped was the fish that the speaker saw? Choose one image from below.'}],
    [["item-plain",9], "PictureSelect", {html: {include: "item_artifact_plain_striped_bw_stripe_fish.html"}, prompt: 'Speaker: I saw a fish. It was plain.<br/><br/>Make a guess: How plain was the fish that the speaker saw? Choose one image from below.'}],
    
    // Shirt 
    [["item-striped",10], "PictureSelect", {html: {include: "item_artifact_plain_striped_shirt.html"}, prompt: 'Speaker: I saw a shirt. It was striped.<br/><br/>Make a guess: How striped was the shirt that the speaker saw? Choose one image from below.'}],
    [["item-plain",10], "PictureSelect", {html: {include: "item_artifact_plain_striped_shirt.html"}, prompt: 'Speaker: I saw a shirt. It was plain.<br/><br/>Make a guess: How plain was the shirt that the speaker saw? Choose one image from below.'}],
    
    // Candle         
    [["item-tall", 11],"PictureSelect", {html: {include: "item_artifact_short_tall_candle.html"}, prompt: 'Speaker: I saw a candle. It was tall.<br/><br/>Make a guess: How tall was the candle that the speaker saw? Choose one image from below.'}],
    [["item-short", 11],"PictureSelect", {html: {include: "item_artifact_short_tall_candle.html"}, prompt: 'Speaker: I saw a candle. It was short.<br/><br/>Make a guess: How short was the candle that the speaker saw? Choose one image from below.'}],
    
    // Stack of books
    [["item-tall",12], "PictureSelect", {html: {include: "item_artifact_short_tall_stack.html"}, prompt: 'Speaker: I saw a stack of books. It was tall.<br/><br/>Make a guess: How tall was the stack of books that the speaker saw? Choose one image from below.'}],
    [["item-short",12], "PictureSelect", {html: {include: "item_artifact_short_tall_stack.html"}, prompt: 'Speaker: I saw a stack of books. It was short.<br/><br/>Make a guess: How short was the stack of books that the speaker saw? Choose one image from below.'}],
                 
    // Chips
    [["item-open", 13],"PictureSelect", {html: {include: "item_artifact_closed_open_chips.html"}, prompt: 'Speaker: I saw a bag of chips. It was open.<br/><br/>Make a guess: How open was the bag of chips that the speaker saw? Choose one image from below.'}],
    [["item-closed",13], "PictureSelect", {html: {include: "item_artifact_closed_open_chips.html"}, prompt: 'Speaker: I saw a bag of chips. It was closed.<br/><br/>Make a guess: How closed was the bag of chips that the speaker saw? Choose one image from below.'}],
    
    // Garage
    [["item-open", 14],"PictureSelect", {html: {include: "item_artifact_closed_open_garagedoor.html"}, prompt: 'Speaker: I saw a garage door. It was open.<br/><br/>Make a guess: How open was the garage door that the speaker saw? Choose one image from below.'}],
    [["item-closed",14], "PictureSelect", {html: {include: "item_artifact_closed_open_garagedoor.html"}, prompt: 'Speaker: I saw a garage door. It was closed.<br/><br/>Make a guess: How closed was the garage door that the speaker saw? Choose one image from below.'}],
    
    // Bridge 2
    [["item-curved",15], "PictureSelect", {html: {include: "item_artifact_straight_curved_curvedbridge.html"}, prompt: 'Speaker: I saw a bridge. It was curved.<br/><br/>Make a guess: How curved was the bridge that the speaker saw? Choose one image from below.'}],
    [["item-straight",15], "PictureSelect", {html: {include: "item_artifact_straight_curved_curvedbridge.html"}, prompt: 'Speaker: I saw a bridge. It was straight.<br/><br/>Make a guess: How straight was the bridge that the speaker saw? Choose one image from below.'}],
    
    // Palm
    [["item-curved",16], "PictureSelect", {html: {include: "item_artifact_straight_curved_palm.html"}, prompt: 'Speaker: I saw a palm tree. It was curved.<br/><br/>Make a guess: How curved was the palm tree that the speaker saw? Choose one image from below.'}],
    [["item-straight",16], "PictureSelect", {html: {include: "item_artifact_straight_curved_palm.html"}, prompt: 'Speaker: I saw a palm tree. It was straight.<br/><br/>Make a guess: How straight was the palm tree that the speaker saw? Choose one image from below.'}],
    
    // Ladybug
    [["item-spotted",17], "PictureSelect", {html: {include: "item_artifact_plain_spotted_ladybug.html"}, prompt: 'Speaker: I saw a ladybug. It was spotted.<br/><br/>Make a guess: How spotted was the ladybug that the speaker saw? Choose one image from below.'}],
    [["item-plain", 17],"PictureSelect", {html: {include: "item_artifact_plain_spotted_ladybug.html"}, prompt: 'Speaker: I saw a ladybug. It was plain.<br/><br/>Make a guess: How plain was the ladybug that the speaker saw? Choose one image from below.'}],
    
    // Pillow    
    [["item-spotted",18], "PictureSelect", {html: {include: "item_artifact_plain_spotted_pillow.html"}, prompt: 'Speaker: I saw a pillow. It was spotted.<br/><br/>Make a guess: How spotted was the pillow that the speaker saw? Choose one image from below.'}],
    [["item-plain",18], "PictureSelect", {html: {include: "item_artifact_plain_spotted_pillow.html"}, prompt: 'Speaker: I saw a pillow. It was plain.<br/><br/>Make a guess: How plain was the pillow that the speaker saw? Choose one image from below.'}],
    
    // Marker
    [["item-thick", 19],"PictureSelect", {html: {include: "item_artifact_thin_thick_marker.html"}, prompt: 'Speaker: I saw a marker. It was thick.<br/><br/>Make a guess: How thick was the marker that the speaker saw? Choose one image from below.'}],
    [["item-thin", 19],"PictureSelect", {html: {include: "item_artifact_thin_thick_marker.html"}, prompt: 'Speaker: I saw a marker. It was thin.<br/><br/>Make a guess: How thin was the marker that the speaker saw? Choose one image from below.'}],

    // Book
    [["item-thick",20], "PictureSelect", {html: {include: "item_artifact_thin_thick_thick.html"}, prompt: 'Speaker: I saw a book. It was thick.<br/><br/>Make a guess: How thick was the book that the speaker saw? Choose one image from below.'}],
    [["item-thin",20], "PictureSelect", {html: {include: "item_artifact_thin_thick_thick.html"}, prompt: 'Speaker: I saw a book. It was thin.<br/><br/>Make a guess: How thin was the book that the speaker saw? Choose one image from below.'}],

    // Noodle
    [["item-long", 21],"PictureSelect", {html: {include: "item_artifact_short_long_noodle.html"}, prompt: 'Speaker: I saw a noodle. It was long.<br/><br/>Make a guess: How long was the noodle that the speaker saw? Choose one image from below.'}],
    [["item-short",21], "PictureSelect", {html: {include: "item_artifact_short_long_noodle.html"}, prompt: 'Speaker: I saw a noodle. It was short.<br/><br/>Make a guess: How short was the noodle that the speaker saw? Choose one image from below.'}],
   
    // Table
    [["item-long", 22],"PictureSelect", {html: {include: "item_artifact_short_long_table.html"}, prompt: 'Speaker: I saw a table. It was long.<br/><br/>Make a guess: How long was the table that the speaker saw? Choose one image from below.'}],
    [["item-short",22], "PictureSelect", {html: {include: "item_artifact_short_long_table.html"}, prompt: 'Speaker: I saw a table. It was short.<br/><br/>Make a guess: How short was the table that the speaker saw? Choose one image from below.'}],

    // Shoe     
    [["item-bumpy",23], "PictureSelect", {html: {include: "item_artifact_smooth_bumpy_shoe.html"}, prompt: 'Speaker: I saw a shoe sole. It was bumpy.<br/><br/>Make a guess: How bumpy was the shoe sole that the speaker saw? Choose one image from below.'}],
    [["item-smooth",23], "PictureSelect", {html: {include: "item_artifact_smooth_bumpy_shoe.html"}, prompt: 'Speaker: I saw a shoe sole. It was smooth.<br/><br/>Make a guess: How smooth was the shoe sole that the speaker saw? Choose one image from below.'}],
    
                
    // Squash
    [["item-bumpy",24], "PictureSelect", {html: {include: "item_artifact_smooth_bumpy_squash.html"}, prompt: 'Speaker: I saw a squash. It was bumpy.<br/><br/>Make a guess: How bumpy was the squash that the speaker saw? Choose one image from below.'}],
    [["item-smooth", 24],"PictureSelect", {html: {include: "item_artifact_smooth_bumpy_squash.html"}, prompt: 'Speaker: I saw a squash. It was smooth.<br/><br/>Make a guess: How smooth was the squash that the speaker saw? Choose one image from below.'}]
    
   
 ];





// TIM NOTES AREA:
//
// > **MX:** to elicit item specific priors, here is one possibility:
// "Imagine you have a cube in front of you. It could be filled with color or have nothing in it. How likely do you think you will see a cube like this one?" (we present just one out of the 5 tokens from the same scale)
// "Imagine you have a boat in front of you. It could come in different sizes. How likely do you think you will see a boat like this one?"
//
// - we can use a sliding bar to get the judgments. The problem with this that it doesn't seem to me that the percentages we get in the end for the 5 tokens on the same scale will add up to 1. So the alternative is to ask:
// - "Imagine you will see a cube in front of you. It could be filled with color or have nothing in it. Which one among the following do you think it will be?" (give them the 5 tokens and they pick one)
// - this will make sure the ultimate proportions will add up to 1. But this way of asking doesn't distinguish the antonyms, like tall-short, empty-full. After a second thought, I dont think the priors should not make a distinction between tall vs. short anyway, since it should just about height distributions.
//
// - "Imagine you will see a cube in front of you. It could be filled with color or have nothing in it. Which one among the following do you think it will be?" (give them the 5 tokens and they pick one)
// - this will make sure the ultimate proportions will add up to 1. But this way of asking doesn't distinguish the antonyms, like tall-short, empty-full. After a second thought, I dont think the priors should not make a distinction between tall vs. short anyway, since it should just about height distributions.

