var shuffleSequence = seq(anyType);


var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Unlikely)", 
        rightComment: "(Likely)"
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

["Intro", "Form", {consentRequired: true, html: {include: "example_intro.html" }} ],
    

["q1", "PictureScale", {
html:'<h><b><center><font size="5"> Title</font></center></b></h> <p></p> <img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/practice_1.gif"/>',
s: {html: '<center><p>Utterance 1</p> <p>Utterance 2</p> <p>Prompt</p><p>Meaning</p></center> '}}]


 
];
