define_ibex_controller({
    name: "DoubleMessage",
    jqueryWidget: {
        _init: function () {
            this.options.transfer = "keypress"; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [0,1],
                children: [           
                            "Message",  this.options,
                            "Message2",  this.options,  
                          
                ]
            });
        }
    },
    properties: {obligatory: ["html","html2"]}
});