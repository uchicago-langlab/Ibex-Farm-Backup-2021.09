/*
--Toronto-Psycholinguistics-Experiments--

Template that gives examples of everything Ibex can do for experiments
*/

var shuffleSequence = seq(anyType);
var centerItems = true;


var defaults = [

    "Message", {
        //"html" option is obligatory
        consentRequired: false,
        hideProgressBar: false,
        transfer: "keypress"
    },

    "DashedSentence", {
        //"s" option is obligatory
        mode: "self-paced reading"
          //other option: "speeded acceptability"
    },

    "Question", {
        //"as" option is obligatory
        as: ["Yes", "No"],
        hasCorrect: true
          //if a question has a correct answer,
            //keep it as the first element of the "as" option
    },


    //These settings are needed for audio Type 1
    "AcceptabilityJudgment", {
        //"s" option is obligatory
        //"q" option is obligatory
        //"as" option is obligatory
        as: ["OK"],
        //writing the "as" option here means that this is the default for
        //all AcceptabilityJudgment items
        presentAsScale: true, //presents the "as" option as a scale
        instructions: "Use number keys or click boxes to answer.",
        // leftComment: "(Bad)", //displayed on the left side of the scale
        // rightComment: "(Good)", //displayed on the right side of the scale
        //only two audio options available so far
        audioMessage: { html: "<u>Click here to play audio</u>" },
        audioTrigger: "click"
        //do not change this
        //click, we do have another option at this point of time
    },

    "DashedAcceptabilityJudgment", {
        //combination of AcceptabilityJudgment and DashedSentence
        //"s" option is obligatory
        //"q" option is obligatory
        //"as" option is obligatory
        hasCorrect: false
    },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    /*
    ===================
    INTRODUCTION
    Can include files for Questionnaires, consent forms etc...
    ===================
    */

    //name of controller
    ["intro",
      //type
      "Form",
      //obligatory option that includes a HTML file that is a questionnaire
      {html: { include: "example_intro.html" },
      //fields that need to have the right format when taking input from user
      validators: {
        //age has to be a number
        age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],
    
 
  
    
    //Kate: Make sure you are coding each of the items to be presented in a Latin Square Design
    
   
    [ "q1", 
      "DoubleMessage", {html: {include: "sound_display.html"}, html2: "<p>words and sentences</p>"},
      "DashedSentence", { s:  "The nurse replied that 100 patients were currently waitlisted."} ,  
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"] }],

    [ "q2", 
      "DoubleMessage", {html: {include: "sound_display.html"},html2: "<p>words and sentences</p>"},
      "DashedSentence", { s:  "The nurse replied that 100 patients were currently waitlisted."} , 
      "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}]
    
    

]; 
    
   