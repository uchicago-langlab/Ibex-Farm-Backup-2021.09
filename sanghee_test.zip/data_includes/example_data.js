define_ibex_controller({
    name: "MyController",

    jqueryWidget: {
        _init: function () {
            this.options.transfer = null; // Remove 'click to continue message'.
            this.element.VBox({
                options: this.options,
                triggers: [1],
                children: [
                    "Form", this.options,
                    "AcceptabilityJudgment", this.options,
                ]
            });
        }
    },

    properties: { }
});

var shuffleSequence = seq("practice", rshuffle("arc_both","arc_main","arc_null","rrc_main","rrc_null"));
var practiceItemTypes = ["practice"];

// var shuffleSequence = seq("setcounter", sepWith("sep", seq("practice", "practiceover", rshuffle("arc_both","arc_main","arc_null","rrc_main","rrc_null"))));
// var shuffleSequence = seq("setcounter", rshuffle("arc_both","arc_main","arc_null","rrc_main","rrc_null"));
// var shuffleSequence = seq("setcounter", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))), "payment");


var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        //errorMessage: "Wrong. Please wait for the next sentence."
        ignoreFailure: "true"
    },
    "Question", {
        randomOrder: false,
        showNumbers: true,
        presentHorizontally: false,
        hasCorrect: false,
        instructions: null
    },
    "AcceptabilityJudgment", {
        randomOrder: true,
        showNumbers: true,
        presentHorizontally: false,
        presentAsScale: false,
        hasCorrect: false,
        instructions: "Use number keys or click the word(s) to answer."
    },
    "FlashSentence", {
        timeout: null
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];




var items = [

    // ["sep", "Separator", { }],

    // ["setcounter", "__SetCounter__", { }],

    // ["intro", "Form", {continueMessage: "click to continue", consentRequired: true, html: {include: "consent.html" }} ],
    // ["intro", "Form", {
    //     continueMessage: "click to continue",
    //     html: { include: "intro.html" },
    //     validators: {
    //         age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
    //     }
    // } ],
    // ["intro", "Form", {continueMessage: "click to continue", consentRequired: true, html: {include: "instruction1.html" }} ],
    // ["intro", "Form", {continueMessage: "click to continue", consentRequired: true, html: {include: "instruction2.html" }} ],
    // ["payment", "Form", {continueMessage: "click to continue", consentRequired: false, html: {include: "payment.html" }} ],

    // ["practiceover", "Message", {html:
    //     ["div",
    //     ["p", "This is the end of the practice."],
    //     ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions."]
    //     ],
    //     continueMessage:"Click here to continue."
    //     }
    // ],
    
    ["practice", "AcceptabilityJudgment", {s: "this is the sentence", q: "what do you think is ...?", as: ["Ryan", "scultors"], randomOrder: true}],
    ["practice", "AcceptabilityJudgment", {s: "Alex trusted the accountant who the administrator depends on to balance the books.", q: "What do you think 'who' refers to?",as: ["Alex","the accountant"], randomOrder: true}],
    ["practice", "AcceptabilityJudgment", {s: "Amber rewarded the dancers who the host applauds so frequently at each performance.", q: "What do you think 'who' refers to?",as: ["Amber","the dancers"], randomOrder: true}],
    ["practice", "AcceptabilityJudgment", {s: "Maria greeted the comedians, who the prisoner finds so entertaining to watch.", q: "What do you think 'who' refers to?",as: ["Maria","the comedians"], randomOrder: true}],


    ["practice", "DashedSentence", {s: ["It appears that those clerks and coordinator...."]}, "Question", {q: "Did the clerks and coordinators organize the calendar?", as: [["f","yes"],["j","no"]], hasCorrect: 0}],
                       
    ["practice", "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotMy friend Sophie, a classical violinist, performed a piece by Mozart.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["Sophie isn't a classical violinist.","Sophie didn't perform a piece by Mozart.","Both options above are possible."]}],
    ["practice", "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotCharlie took care of his wife, who had lung cancer.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["Charlie didn't take care of his wife.","Charlie's wife didn't have lung cancer.","Both options above are possible."]}],

    [["arc_both", 1], "MyController", {html: "<p style = 'font-family: Arial';>A detective is investigating a crime scene at a restaurant, and he is interviewing two witnesses.</p><p style = 'font-family: Arial';>Detective: &quotWhat did you say about the waitress? Tell me everything about her.&quot<br>Witness A: &quotThe waitress, who sat near the girl, unsurprisingly was unhappy about all the noise.&quot<br>Witness B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Witness B means?",as: ["The waitress didn't sit near the girl.","The waitress wasn't unhappy.","Both options above are possible."]}],
    [["arc_main", 1], "MyController", {html: "<p style = 'font-family: Arial';>A detective is investigating a crime scene at a restaurant, and he is interviewing two witnesses.</p><p style = 'font-family: Arial';>Detective: &quotDid the waitress look unhappy?&quot<br>Witness A: &quotThe waitress, who sat near the girl, unsurprisingly was unhappy about all the noise.&quot<br>Witness B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Witness B means?",as: ["The waitress didn't sit near the girl.","The waitress wasn't unhappy.","Both options above are possible."]}],
    [["arc_null", 1], "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotThe waitress, who sat near the girl, unsurprisingly was unhappy about all the noise.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["The waitress didn't sit near the girl.","The waitress wasn't unhappy.","Both options above are possible."]}],
    [["arc_both", 2], "MyController", {html: "<p style = 'font-family: Arial';>Matt and Dan are brothers, and they are telling their mother what they saw in the park today.</p><p style = 'font-family: Arial';>Mom: &quotWhat did you say about the dog? Tell me everything about it.&quot<br>Matt: &quotThe dog, which dug in the hole, unfortunately was covered in mud all over.&quot<br>Dan: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Dan means?",as: ["The dog didn't dig in the hole.","The dog wasn't covered in mud all over.","Both options above are possible."]}],
    [["arc_main", 2], "MyController", {html: "<p style = 'font-family: Arial';>Matt and Dan are brothers, and they are telling their mother what they saw in the park today.</p><p style = 'font-family: Arial';>Mom: &quotDid the dog get covered in mud?&quot<br>Matt: &quotThe dog, which dug in the hole, unfortunately was covered in mud all over.&quot<br>Dan: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Dan means?",as: ["The dog didn't dig in the hole.","The dog wasn't covered in mud all over.","Both options above are possible."]}],
    [["arc_null", 2], "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotThe dog, which dug in the hole, unfortunately was covered in mud all over.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["The dog didn't dig in the hole.","The dog wasn't covered in mud all over.","Both options above are possible."]}],
    [["arc_both", 3], "MyController", {html: "<p style = 'font-family: Arial';>A police officer is investigating abduction cases, and he is interviewing two kindergarten teachers.</p><p style = 'font-family: Arial';>Police officer: &quotWhat did you say about the boy? Tell me everything about him.&quot<br>Teacher A: &quotThe boy, who played in the game, apparently was more competitive than ever before.&quot<br>Teacher B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Teacher B means?",as: ["The boy didn't play in the game.","The boy wasn't more competitive than ever before.","Both options above are possible."]}],
    [["arc_main", 3], "MyController", {html: "<p style = 'font-family: Arial';>A police officer is investigating abduction cases, and he is interviewing two kindergarten teachers.</p><p style = 'font-family: Arial';>Police officer: &quotDid the boy look competitive?&quot<br>Teacher A: &quotThe boy, who played in the game, apparently was more competitive than ever before.&quot<br>Teacher B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Teacher B means?",as: ["The boy didn't play in the game.","The boy wasn't more competitive than ever before.","Both options above are possible."]}],
    [["arc_null", 3], "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotThe boy, who played in the game, apparently was more competitive than ever before.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["The boy didn't play in the game.","The boy wasn't more competitive than ever before.","Both options above are possible."]}],
    [["arc_both", 4], "MyController", {html: "<p style = 'font-family: Arial';>Silvia and Julie are teachers, and they are telling Peter about the parent-teacher interview they had today.</p><p style = 'font-family: Arial';>Peter: &quotWhat did you say about the mom? Tell me everything about her.&quot<br>Silvia: &quotThe mom, who drove with the kid, unsurprisingly was tired of all the bickering in the car.&quot<br>Julie: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Julie means?",as: ["The mom didn't drive with the kid.","The mom wasn't tired of all the bickering in the car.","Both options above are possible."]}],
    [["arc_main", 4], "MyController", {html: "<p style = 'font-family: Arial';>Silvia and Julie are teachers, and they are telling Peter about the parent-teacher interview they had today.</p><p style = 'font-family: Arial';>Peter: &quotDid the mom look tired?&quot<br>Silvia: &quotThe mom, who drove with the kid, unsurprisingly was tired of all the bickering in the car.&quot<br>Julie: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Julie means?",as: ["The mom didn't drive with the kid.","The mom wasn't tired of all the bickering in the car.","Both options above are possible."]}],
    [["arc_null", 4], "MyController", {html: "<p style = 'font-family: Arial';>Speaker A: &quotThe mom, who drove with the kid, unsurprisingly was tired of all the bickering in the car.&quot<br>Speaker B: &quotNo, that's not true.&quot</p>",s: " ",q: "What do you think Speaker B means?",as: ["The mom didn't drive with the kid.","The mom wasn't tired of all the bickering in the car.","Both options above are possible."]}]

];