define_ibex_controller({
    name: "PictureScale",
    jqueryWidget: {
        _init: function () {
            this.options.transfer = null; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [1],
                children: [           
                            "Message",  this.options,
                             "Form",  {html: 'Please make a sentence based on this picture. The sentences you create needs to include the words above. <input type="text" name="sentence" size = "150" class = "obligatory">'},      
                ]
            });
        }
    },
    properties: {obligatory: ["html"]}
});
