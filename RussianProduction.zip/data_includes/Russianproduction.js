var shuffleSequence = seq("Intro", "setcounter", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Unlikely)", 
        rightComment: "(Likely)"
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],
    

/*
[["q1a",1] or "practice", "PictureScale", {
html:'<h><b><center><font size="5"> Title</font></center></b></h> <p></p> <center><img src = "imglink.jpg" height="10%"</center>',
s: {html: '<center><p>Utterance 1</p> <p>Utterance 2</p> <p>Prompt</p><p>Meaning</p></center> '}}],
*/
  

["practice", "PictureScale", {
html:'<h><b><center><font size="5"></font></center></b></h> <p></p> <center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/Practice-picture.jpg" height="55%"<center>',}],  

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "Remember to make your sentence match the picture."],
["p", "Press any key to continue."]
]}],
    
["practice", "PictureScale", {
html:'<h><b><center><font size="5"></font></center></b></h> <p></p> <center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/Practice-picture-2.jpg" height="55%"</center>',}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "Good, remember to use all the words provided."],
["p", "Press any key to continue."]
]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    




[["q1a", 1], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/1-2.jpg" height="55%"</center>',}],

[["q1a", 2], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/2-2.jpg" height="55%"</center>',}],

[["q1a", 3], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/3.jpg" height="55%"</center>',}],

[["q1a", 4], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/4-1.jpg" height="55%"</center>',}],

[["q1a", 5], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/5-1.jpg" height="55%"</center>',}],

[["q1a", 6], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/6.jpg" height="55%"</center>',}],

[["q1a", 7], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/7.jpg" height="55%"</center>',}],

[["q1a", 8], "PictureScale", {html:'<center>><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/8.jpg" height="55%"</center>',}],

[["q1a", 9], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/9.jpg" height="55%"</center>',}],

[["q1a", 10], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/10.jpg" height="55%"</center>',}],

[["q1a", 11], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/11.jpg" height="55%"</center>',}],

[["q1a", 12], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/12.jpg" height="55%"</center>',}],

[["q1a", 13], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/13.jpg" height="55%"</center>',}],

[["q1a", 14], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/14.jpg" height="55%"</center>',}],

[["q1a", 15], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/15.jpg" height="55%"</center>',}],

[["q1a", 16], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/16.jpg" height="55%"</center>',}],

[["q1a", 17], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/17.jpg" height="55%"</center>',}],

[["q1a", 18], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/18.jpg" height="55%"</center>',}],

[["q1a", 19], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/19.jpg" height="55%"</center>',}],

[["q1a", 20], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/20.jpg" height="55%"</center>',}],

[["q1a", 21], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/21.jpg" height="55%"</center>',}],

[["q1a", 22], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/22.jpg" height="55%"</center>',}],

[["q1a", 23], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/23.jpg" height="55%"</center>',}],

[["q1a", 24], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/24.jpg" height="55%"</center>',}],

[["q1a", 25], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/25.jpg" height="55%"</center>',}],

[["q1a", 26], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/26.jpg" height="55%"</center>',}],

[["q1a", 27], "PictureScale", {html:'<center><img src = "https://lucian.uchicago.edu/blogs/lpl/files/2019/11/27.jpg" height="55%"</center>',}],




];


