var shuffleSequence = seq("intro","Practice", "presep", sepWith("sep", rshuffle(startsWith("RP"), "f")), "exit");

var counterOverride = 3;
var ds = DashedSentence;
var q = Question;



var defaults = [
    Separator,{ignoreFailure: true},
    q,{hasCorrect: 0, randomOrder: ["f","j"], presentHorizontally: true},
    ds,{mode: "self-paced reading", display: "dashed"}
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

["sep", Separator, { }],

["Practice", ds, {s: ["This is just a practice sentence to get you used to the method of presentation."]}, q, {q:"Was that sentence easy?", as: ["Yes","No"] }, Separator, { }],
["Practice", ds, {s: ["This is another practice sentence which is longer and a little more complicated than the one you just read."]}, q, {q:"Did you read that at a normal pace?",as: ["Yes","No"]  }],
                        
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all there is to it! Let's try some practice sentences more like the ones you'll be seeing in the experiment:"]
                           ]}],
                           
["Practice", ds, {s: ["Elias told Martha that the attractive lifeguard on the pier who is dating Tracy's sister saved a little boy from being swept out to sea by a rip-tide yesterday."]}, q,{q: "Who did the lifeguard save?", as: ["the little boy","Tracy's sister"], hasCorrect: 0}],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Some sentences, like the one you just read, are fairly long and complex. How did you do on the comprehension question? You should have responded that the lifeguard saved the little boy."],
                          ["p", "Try your hand at these next few sentences. Don't overthink your response: go with your gut feeling or intuition!"]
                          ]}],
    

["Practice", ds, {s: ["The pop star sang herself hoarse at the concert last night."]}, q, {q: "When was the concert?", as: ["last night","last year"]}, Separator, { }],
["Practice", ds, {s: ["The tall nurse swore that the elderly widow had never mistreated hospital staff."]}, q, {q:"Was the widow elderly?", as: ["Yes","No"]}, Separator, { }],
["Practice", ds, {s: ["The plumber working in the bathroom cursed himself for forgetting his wrench."]}, q, {q: "Where was the plumber working?", as: ["the bathroom","the kitchen"]}],
                           
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. REMEMBER: it will last approximately 15 minutes, and will require your full attention throughout that period. Thank you for your help!"]
                           ]}],
                           
["presep", Separator, { transfer: 3000, normalMessage: "Get your hands in position, and get ready to begin!" }],

[ [ "RP-a", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that the girl who sells ripped carpets deceived. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-b", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that the girl who sells ripped carpets deceived her. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-c", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that they told me that the girl who sells ripped carpets deceived. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-d", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that they told me that the girl who sells ripped carpets deceived her. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-e", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that the girl who deceived sells ripped carpets. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-f", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that the girl who deceived her sells ripped carpets. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-g", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that they told me that the girl who deceived sells ripped carpets. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-h", 6 ], ds, { s:  ["At the flea marked the most incredible transactions take place.  What happened yesterday is a good example. This is the gentleman that they told me that the girl who deceived her sells ripped carpets. "]  } , "Question", {q: "Who was deceived?", as: [ "The gentleman", "The girl" ] } ],
[ [ "RP-a", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that the defendant who will get a softer punishment helped out by revealing the truth. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-b", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that the defendant who will get a softer punishment helped him out by revealing the truth. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-c", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that they say that the defendant who will get a softer punishment helped out by revealing the truth. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-d", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that they say that the defendant who will get a softer punishment helped him out by revealing the truth. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-e", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that the defendant who helped out by revealing the truth will get a softer punishment. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-f", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that the defendant who helped him out by revealing the truth will get a softer punishment. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-g", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that they say that the defendant who helped out by revealing the truth will get a softer punishment. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-h", 15 ], ds, { s:  ["Yesterday there was a critical turn of events in the trial. This is the judge that they say that the defendant who helped him out by revealing the truth will get a softer punishment. "]  } , "Question", {q: "Who was helped out?", as: ["The judge", "The defendant" ] } ],
[ [ "RP-a", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the sergeant who wanted to show his gratitude awarded with a medal. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-b", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the sergeant who wanted to show his gratitude awarded him with a medal. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-c", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the newspaper says that the sergeant who wanted to show his gratitude awarded with a medal. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-d", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the newspaper says that the sergeant who wanted to show his gratitude awarded him with a medal. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-e", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the sergeant who awarded with a medal wanted to show his gratitude. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-f", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the sergeant who awarded him with a medal wanted to show his gratitude. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-g", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the newspaper says that the sergeant who awarded with a medal wanted to show his gratitude. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-h", 24 ], ds, { s:  ["War veterans are often seen as heroes by society and by their colleagues in the army. This is the veteran that the newspaper says that the sergeant who awarded him with a medal wanted to show his gratitude. "]  } , "Question", {q: "Who was awarded a medal", as: [ "The sergeant", "The veteran" ] } ],
[ [ "RP-a", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that the nurse who is extremely patient and sweet took out for lunch. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-b", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that the nurse who is extremely patient and sweet took him out for lunch. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-c", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that I heard that the nurse who is extremely patient and sweet took out for lunch. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-d", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that I heard that the nurse who is extremely patient and sweet took him out for lunch. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-e", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that the nurse who took out for lunch is extremely patient and sweet. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-f", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that the nurse who took him out for lunch is extremely patient and sweet. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-g", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that I heard that the nurse who took out for lunch is extremely patient and sweet. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ [ "RP-h", 33 ], ds, { s:  ["In retirement homes the personnel are trained to treat their residents with great care. This is the elderly man that I heard that the nurse who took him out for lunch is extremely patient and sweet. "]  } , "Question", {q: "Who was taken out for lunch?", as: [ "The elderly man", "The nurse" ] } ],
[ "f", ds, { s:  ["In hospitals the standards for hygiene are very high.  This is the nurse that the doctor reproached because she was not wearing gloves."]  } , "Question", {q: "Who was reproached", as: [ "The doctor", "The nurse" ] } ],
[ "f", ds, { s:  ["In the last month the police arrested many people for evading taxes.  This is the businessman that was arrested while he was on vacation in Aspen."]  } , "Question", {q: "Who was arrested?", as: [ "The policeman", "The businessman" ] } ],
[ "f", ds, { s:  ["Over the summer there are a lot of music contests throughout the city.  This is the singer that was awarded the most prizes over the season."]  } , "Question", {q: "Who was awarded the most prizes?", as: [ "The singer", "The artist" ] } ],
[ "f", ds, { s:  ["'Bite and win' is a competition in which candidates have to eat a pizza in as few bites as they can.  This is the size of the pizza that the winner devoured without any hesitation."]  } , "Question", {q: "What is 'Bite and Win'?", as: [ "A pizza eating competition", "A race" ] } ],
[ "f", ds, { s:  ["Cats like sweets and candy, and they seem to absolutely adore cupcakes.  This is the cupcake that our cat stole from the table."]  } , "Question", {q: "Where did the cat stole the cupcake from", as: [ "The kitchen", "The table" ] } ],
[ "f", ds, { s:  ["During the campaign for the election of the new mayor, there is always a lot of tension between the press and the politicians.  This is the reporter that one of the candidates sued for libel."]  } , "Question", {q: "Who was sued for libel?", as: [ "The candidate", "The reporter" ] } ],
[ "f", ds, { s:  ["When you leave food in the basement for a long time, bad things can happen.  This is the rat that devoured half of the block of cheese that was left on the floor."]  } , "Question", {q: "Who was the piece of cheese devoured by?", as: [ "The rat", "The dog" ] } ],
[ "f", ds, { s:  ["Heavy snowfalls can cause trouble for every city, even those best prepared to handle them.  This is the list of the roads that the Chicago mayor closed due to snow accumulation during the blizzard."]  } , "Question", {q: "Who decided to close the road in Chicago?", as: [ "The Mayor", "The Alderman" ] } ],
[ "f", ds, { s:  ["People wear the weirdest costumes at Halloween.  This is the girl who dressed up as a hot dog and put mustard on her hair to look more realistic."]  } , "Question", {q: "Who dressed up like a hot dog?", as: [ "The girl", "The teacher" ] } ],
[ "f", ds, { s:  ["During pool parties, there is always someone who ends up having a surprise swim.  This is the guy that was thrown in the water while everyone was laughing."]  } , "Question", {q: "Who was thrown in the water?", as: [ "The girl", "The guy" ] } ],
[ "f", ds, { s:  ["Whenever someone on this team plays well, some fans get raucous.  This is the player to whom some supporters dedicated a long standing ovation at the end of the game."]  } , "Question", {q: "Who received a standing ovation?", as: [ "The player", "The singer" ] } ],
[ "f", ds, { s:  ["As summer approaches, people are consuming more ice-cream and cavities are increasing.  This is the kid whose mom had to spend over 300 dollars to pay his dental bill."]  } , "Question", {q: "Who spent over 300 dollars to pay the dentist bill?", as: [ "The father", "The mother" ] } ],
[ "f", ds, { s:  ["The richer people are, the more absurd ways they find to spend their money.  This is the engineer whom the baroness has asked to renovate her bathroom for the fourth time in a month."]  } , "Question", {q: "Who was asked to renovate the bathroom?", as: [ "The engineer", "The baroness" ] } ],
[ "f", ds, { s:  ["Cooperation between classmates can be an effective way of subverting school rules.  This is the student to whom classmates whispered the answers to the Latin test without being caught by the teacher."]  } , "Question", {q: "Who wispered the answer to the Latin test?", as: [ "The teacher", "The students" ] } ],
[ "f", ds, { s:  ["The relationship between coach and players is sometimes very straightforward.  This is the player whom the coach gave a kick in the behind after a defensive mistake."]  } , "Question", {q: "Who received a kick in the behind?", as: [ "The coach", "The player" ] } ],
[ "f", ds, { s:  ["Police are often criticized, but one must admit that they are often really effective.  This is the police chief to whom the cops turned over two thieves caught during a bank robbery downtown."]  } , "Question", {q: "Who were the thieves turned over to?", as: [ "The Detective", "The Police Chief" ] } ],
[ "f", ds, { s:  ["When rich tourists from Eastern Europe come in, the income of small businesses in touristy locations doubles.  This is the Russian billionaire to whom a store manager in Aspen sold more than 120 cashmere sweaters."]  } , "Question", {q: "Who were the sweaters sold to?", as: [ "An American rockstar", "A Russian billionaire" ] } ],
[ "f", ds, { s:  ["When it comes to stealing money, the most basic ethical norms are infringed.  This is the priest from whom a bunch of idiots stole the money that was destined for charitable organizations."]  } , "Question", {q: "Who stole the money?", as: [ "A bunch of idiots", "A bunch of teenagers" ] } ],
[ "f", ds, { s:  ["If you marry the wrong person, you can ruin your life forever.  That is the accountant from whom his ex-wife has taken most of the assets after their divorce."]  } , "Question", {q: "Who took the accountant's assets?", as: [ "The IRS", "The ex-wife" ] } ],
[ "f", ds, { s:  ["Before giving someone a present, one should think about the consequences of the gift.  This is the child that received a water pistol for Christmas and that keeps shooting at everyone in the street."]  } , "Question", {q: "What did the child receive for Christmas?", as: [ "A water pistol", "A bicycle" ] } ],
[ "f", ds, { s:  ["Many rich people in the world have done next to nothing to earn their wealth.  This is the sultan’s daughter who inherited more than two billion dollars and a huge yacht from her father."]  } , "Question", {q: "What did the girl inherit?", as: [ "A villa", "A yacht" ] } ],
[ "f", ds, { s:  ["In small towns, political decisions are often determined by connections and interpersonal relations.  This is the house that the mayor ordered destroyed for personal revenge."]  } , "Question", {q: "Who decided to order the house destroyed?", as: [ "The Mayor", "The County Sheriff" ] } ],
[ "f", ds, { s:  ["Music teachers are well known for being quirky, and my son’s teacher is no exception.  This is the door that my son told me his teacher smashed because a student was making too many mistakes during his flute performance."]  } , "Question", {q: "Who was smashed?", as: [ "The teacher", "The student" ] } ],
[ "f", ds, { s:  ["Something horrible happened near our house.  This is the bank that the radio said two masked thieves just robbed armed with handguns."]  } , "Question", {q: "Who robbed the bank?", as: [ "Thieves armed with handguns", "Thieves armed with knives" ] } ],
[ "f", ds, { s:  ["Sometimes plastic cups are better than crystal glasses, even though they are not as classy.  This is the glass that my mother said my brother destroyed while he was trying to dust it off."]  } , "Question", {q: "Who destroyed the glass?", as: [ "My brother", "My mother" ] } ],
[ "f", ds, { s:  ["Animal crossings represent serious dangers for those who love driving on mountain roads.  This is the deer that a hunter told me he ran over while driving down a mountain road 7,000 feet above sea level."]  } , "Question", {q: "What did the driver hit?", as: [ "A mountain lion", "A deer" ] } ],
[ "f", ds, { s:  ["The relationship between townspeople and local policemen can be quite problematic.  This is the cop that the radio said a driver beat up after his third parking fine in three days."]  } , "Question", {q: "Who beat up the cop?", as: [ "A thief", "An angry driver" ] } ],
[ "f", ds, { s:  ["Often people take advantage of their social status to influence other people’s behavior.  This is the secretary that Lucy said that the lawyer in the nearby office tried to have sex with multiple times last month."]  } , "Question", {q: "Who did the laywer try to have sex with?", as: [ "The ex wife", "The secretary" ] } ],
[ "f", ds, { s:  ["Some people enjoy messing around with people that are too weak to defend themselves.  This is the nun that Mark said a friend of his hit with a water balloon just outside of the convent."]  } , "Question", {q: "Who was hit by a water baloon?", as: [ "A priest", "A nun" ] } ],
[ "f", ds, { s:  ["In some countries such as Italy people are exposed to alcohol since the first months of their lives.  This is the child that I heard that was ordered by his father to take a sip of wine after Christmas dinner."]  } , "Question", {q: "What did the father order the child to do?", as: [ "Take a sip of wine", "Go to bed" ] } ],
[ "f", ds, { s:  ["In certain states the death penalty is still legal, and only a last minute decision by the governor can save someone's life.  This is the governor that the newspaper reports didn’t want to pardon a prisoner on death row, even though he was proven to be innocent."]  } , "Question", {q: "Who wasn't given pardon?", as: [ "A terrorist", "An innocent prisoner" ] } ],
[ "f", ds, { s:  ["The reason why super rich football players bet on games is a total mystery.  That is the player that the radio said was condemned to 8 months suspension for having illegally gambled on games."]  } , "Question", {q: "What did the football player do?", as: [ "Fell asleep during practice", "Gamble on games" ] } ],
[ "f", ds, { s:  ["Training pets is an extremely popular activity among elderly people.  This is the dog that my uncle said he trained to greet people by moving its tail and legs at the same time."]  } , "Question", {q: "What kind of animal does this sentence talk about?", as: [ "A cat", "A dog" ] } ],
[ "f", ds, { s:  ["Among many greedy people, luckily there is usually someone who thinks about those who are suffering instead of getting richer.  This is the homeless man to whom I saw a waiter from a nearby restaurant bring a huge serving of lobster for free."]  } , "Question", {q: "Who was served a free lobster dinner?", as: [ "A homeless", "An orphan" ] } ]

];
