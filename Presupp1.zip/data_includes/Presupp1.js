var shuffleSequence = seq("setcounter","Consent","Demographics","Instructions", sepWith("sep", rshuffle(startsWith("Q"))),"Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        leftComment: "Less natural",
        rightComment: "More natural",
        instructions: " ",
        randomOrder: false,
        hasCorrect: false,
        as: ["1","2","3","4","5","6","7"]
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

["setcounter", "__SetCounter__", { }],

["Consent", "Form", {consentRequired: true, html: {include: "Consent.html" }} ],    
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions1.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions2.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],

    
  
["sep", "Separator", {hideProgressBar: true, transfer: 500, normalMessage: " "}],
  
  
  
  
  




    
    
      
  
["Practice", "Message", {hideProgressBar: true, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">How nice of you.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {hideProgressBar: true, s: { html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/nice.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the pronunciation of the sentence seemed fairly typical. You probably selected a high number, like 5, 6, or 7.</p><p>Press any key to continue.</p>'}],  
  
  
["Practice", "Message", {hideProgressBar: true, consentRequired: false, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">If he calls, ask him to leave a message.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/message.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the sentence was not pronounced in a typical way. You probably selected a lower number, like 1, 2, or 3.</p><p>Press any key to continue.</p>'}],       
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],  
  







[["Q01NN", 1], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Eliza delayed Shirley, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q01NO", 2], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Samantha delayed Mary, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q01RN", 3], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Patty entertained Shirley, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q01RO", 4], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Asher entertained Mary, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q01ON", 5], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Tiffany amused Shirley, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q01OO", 6], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The kids rode the bus to the movies yesterday.</font></p><p><font size="4">Jessica amused Mary, and Will amused Mary, too.</font></p><p><font size="4">They all agreed it was a great time.</font></p></center>', transfer: "click"}],
[["Q02NN", 7], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">Carolyn guided Gary, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q02NO", 8], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">Amanda guided Anna, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q02RN", 9], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">Dylan aggravated Gary, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q02RO", 10], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">James aggravated Anna, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q02ON", 11], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">Elena annoyed Gary, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q02OO", 12], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The trip to the corn maze was not so successful.</font></p><p><font size="4">Abigail annoyed Anna, and Lynn annoyed Anna, too.</font></p><p><font size="4">At least no one got lost!</font></p></center>', transfer: "click"}],
[["Q03NN", 13], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Elijah rebuffed Eric, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q03NO", 14], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Andrea rebuffed Laura, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q03RN", 15], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Elizabeth hugged Eric, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q03RO", 16], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Veronica hugged Laura, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q03ON", 17], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Oliver embraced Eric, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q03OO", 18], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a great time at our college reunion.</font></p><p><font size="4">Christina embraced Laura, and Ron embraced Laura, too.</font></p><p><font size="4">We\'re looking forward to the next one.</font></p></center>', transfer: "click"}],
[["Q04NN", 19], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Sebastian punished Justin, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q04NO", 20], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Gabriel punished Amy, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q04RN", 21], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Bradley astounded Justin, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q04RO", 22], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Ethan astounded Amy, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q04ON", 23], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Julian surprised Justin, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q04OO", 24], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My brother\'s birthday party got rowdy last week.</font></p><p><font size="4">Benjamin surprised Amy, and Nan surprised Amy, too.</font></p><p><font size="4">At least there\'s leftover cake to enjoy.</font></p></center>', transfer: "click"}],
[["Q05NN", 25], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Adrian refused Ezra, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q05NO", 26], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Joshua refused Ryan, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q05RN", 27], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Susan idolized Ezra, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q05RO", 28], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Levi idolized Ryan, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q05ON", 29], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Dominic admired Ezra, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q05OO", 30], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The huge line at the book signing went out the door.</font></p><p><font size="4">Susan admired Ryan, and Neil admired Ryan, too.</font></p><p><font size="4">I don\'t know if I\'ll go to another one.</font></p></center>', transfer: "click"}],
[["Q06NN", 31], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">Ashley rejected Brenda, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q06NO", 32], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">David rejected Emma, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q06RN", 33], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">Rick recommended Brenda, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q06RO", 34], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">Mike recommended Emma, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q06ON", 35], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">Zachary endorsed Brenda, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q06OO", 36], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We had a tough time picking a job applicant.</font></p><p><font size="4">Mateo endorsed Emma, and Len endorsed Emma, too.</font></p><p><font size="4">We finally picked someone in the end, though.</font></p></center>', transfer: "click"}],
[["Q07NN", 37], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Isabella dressed Felix, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q07NO", 38], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Alexander dressed Larry, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q07RN", 39], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Mohammed annoyed Felix, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q07RO", 40], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Elliot annoyed Larry, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q07ON", 41], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Avery harassed Felix, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q07OO", 42], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Things were chaotic in my house the other day.</font></p><p><font size="4">Everett harassed Larry, and Ray harassed Larry, too.</font></p><p><font size="4">Luckily, the kids all made it to school on time.</font></p></center>', transfer: "click"}],
[["Q08NN", 43], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Matilda offended Griffin, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q08NO", 44], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Madeline offended Noah, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q08RN", 45], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Maximilian charmed Griffin, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q08RO", 46], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Angelina charmed Noah, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q08ON", 47], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Marissa seduced Griffin, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q08OO", 48], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The dance was just as crazy as we expected.</font></p><p><font size="4">Jocelyn seduced Noah, and Al seduced Noah, too.</font></p><p><font size="4">They should have more chaperones next time.</font></p></center>', transfer: "click"}],
[["Q09NN", 49], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Brennan protected Cathy, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q09NO", 50], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Helen protected Allie, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q09RN", 51], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Kelsey misinformed Cathy, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q09RO", 52], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Betty misinformed Allie, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q09ON", 53], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Savannah deceived Cathy, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q09OO", 54], "Message", {hideProgressBar: true, html:'<center><p><font size="4">We were all shocked by the drama at the hearing.</font></p><p><font size="4">Natalie deceived Allie, and Roy deceived Allie, too.</font></p><p><font size="4">We\'re still waiting to hear the verdict.</font></p></center>', transfer: "click"}],
[["Q10NN", 55], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Ashley upstaged Alex, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q10NO", 56], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Vanesa upstaged Ollie, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q10RN", 57], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Olivia caught Alex, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q10RO", 58], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Valentina caught Ollie, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q10ON", 59], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Serena exposed Alex, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q10OO", 60], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The police interrupted the school musical.</font></p><p><font size="4">Teresa exposed Ollie, and May exposed Ollie, too.</font></p><p><font size="4">We didn\'t even get to see the second act!</font></p></center>', transfer: "click"}],
[["Q11NN", 61], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Maddison released Isaac, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q11NO", 62], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Miranda released Ernie, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q11RN", 63], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Sloan tolerated Isaac, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q11RO", 64], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Ruth tolerated Ernie, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q11ON", 65], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Mallory condoned Isaac, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q11OO", 66], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Bad behavior at the office reached new levels.</font></p><p><font size="4">Rebecca condoned Ernie, and Lee condoned Ernie, too.</font></p><p><font size="4">Hopefully we can get back to normal soon.</font></p></center>', transfer: "click"}],
[["Q12NN", 67], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Harrison involved Carol, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}],
[["Q12NO", 68], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Fiona involved Aaron, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}],
[["Q12RN", 69], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Betsy avoided Carol, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}],
[["Q12RO", 70], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Jacob avoided Aaron, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}],
[["Q12ON", 71], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Jeremy disliked Carol, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}],
[["Q12OO", 72], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The work mixer was surprisingly eventful.</font></p><p><font size="4">Lucia disliked Aaron, and Wayne disliked Aaron, too.</font></p><p><font size="4">I\'m glad we have the day off today.</font></p></center>', transfer: "click"}]














  
  /*
  
Known file issues:

(1)

Male subject didn't record one sentence - Item 36, old verb old object (deaccented).
That means the following files weren't available:

36newVoldOdacM
36oldVoldOaccM
36oldVoldOdacM
36relVoldOdacM

They were all replaced with the file 36newVoldOaccM.wav and the sentence in the preview message controller was changed to match.
But, the code at the beginning of the line shows the condition they *should* be in, so these lines need to be subset out before analaysis.


(2)

In the files 15oldVnewOaccM.wav and 15oldVnewOdacM.wav, the male subject misread the first clause verb as
"admonished" instead of "astonished". The preview sentence was changed to match, but these trials should
be subset out before analysis because the verb does not license the correct (repeated) relation.

  
  

  
  
  */
  
  


















/*
Fillers/attention trials. The files zoo, apple, homework, movies, and contact should get high ratings.
buy, rainbow, room, eggs, and voice should get low ratings.
*/












/*comma*/


    
    




];










