define_ibex_controller({
    name: "ProductionPrompt",
    jqueryWidget: {
        _init: function () {
           // this.options.transfer = null; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [0],
                children: [           
                            "FourImages",  this.options,
                            "Form",  {continueMessage: "Next", html: 'Click on the... <input type="text" name="sentence" size = "150" class = "obligatory">'},      
                ]
            });
        }
    },
    properties: {obligatory: []}
});