/* This software is licensed under a BSD license; see the LICENSE file for details. */

//
// TODO: Replace this controller with something that's not such a horrible mess!
//

(function () {

var __Question_callback__ = null;
var __Questions_answers__ = null;

define_ibex_controller({
name: "FourImages",

jqueryWidget: {
    _init: function () {
        this.cssPrefix = this.options._cssPrefix;
        this.utils = this.options._utils;
        this.finishedCallback = this.options._finishedCallback;

        var questionField = "Question (NULL if none).";
        var answerField = "Answer";
        var correctField = "Whether or not answer was correct (NULL if N/A)";
        var timeField = "Time taken to answer.";

        this.answers = this.options.images;
        this.arrow = dget(this.options, "arrow", "");
        this.question = dget(this.options, "q");

        this.showNumbers = dget(this.options, "showNumbers", true);
        this.presentAsScale = dget(this.options, "presentAsScale", false);
        this.randomOrder = dget(this.options, "randomOrder", ! (this.hasCorrect === false || this.presentAsScale));

        this.timeout = dget(this.options, "timeout", null);
        this.instructions = dget(this.options, "instructions");
        this.leftComment = dget(this.options, "leftComment");
        this.rightComment = dget(this.options, "rightComment");
        this.autoFirstChar = dget(this.options, "autoFirstChar", false);
        this.presentHorizontally = dget(this.options, "presentHorizontally", false);

        if (this.randomOrder) {
            assert(typeof(this.answers[0]) != "object",
                  "Cannot set 'randomOrder' option to a list of keys when keys are included with the 'as' option.");
            assert(typeof(this.answers[0]) != "object" || this.answers.length == this.randomOrder.length,
                   "Length of 'randomOrder' doesn't match length of 'as'.");

            this.orderedAnswers = new Array(this.answers.length);
            for (var i = 0; i < this.answers.length; ++i)
                this.orderedAnswers[i] = this.answers[i];
            fisherYates(this.orderedAnswers);
        }
        else {
            this.orderedAnswers = this.answers;
        }

        this.setFlag = function(correct) {
            if (! correct) {
                this.utils.setValueForNextElement("failed", true);
            }
        }

        if (this.question) {
            this.qp = $(document.createElement("p"))
            .addClass(this.cssPrefix + "question-text")
            .css('text-align', conf_centerItems ? 'center' : 'left')
            .append(this.question);
        }

        for (var j = 0; j < this.orderedAnswers.length/2; ++j) {

            this.xl = $(document.createElement(((!this.presentAsScale && !this.presentHorizontally) && this.showNumbers) ? "ol" : "ul"))
                .css('margin-left', "2em").css('padding-left', 0);

            if ((this.presentAsScale || this.presentHorizontally) && this.leftComment) {
                var lcd = $(document.createElement("li"))
                          .addClass(this.cssPrefix + "scale-comment-box")
                          .append(this.leftComment);
                this.xl.append(lcd);
            }

            for(var i = 0; i < 2; i++) {

                var pos = i + this.orderedAnswers.length/2 * j;

                var li;
                li = $(document.createElement("li"));
                if (this.presentAsScale || this.presentHorizontally) {
                    li.addClass(this.cssPrefix + "scale-box");
                    var t = this;
                }
                else {
                    li.addClass(this.cssPrefix + "normal-answer");
                }

                var ans = typeof(this.orderedAnswers[i]) == "string" ? this.orderedAnswers[pos] : this.orderedAnswers[pos][1];
                var t = this; // 'this' doesn't behave as a lexically scoped variable so can't be
                              // captured in the closure defined below.
                var a = $(document.createElement("img"));
                a.attr("src", ans);
                a.attr("width", 200);
                console.log(a);

                this.xl.append(li.append(a));
            }

            if ((this.presentAsScale || this.presentHorizontally) && this.rightComment) {
                this.xl.append($(document.createElement("li"))
                           .addClass(this.cssPrefix + 'scale-comment-box')
                           .append(this.rightComment));
            }

            var table = $("<table" + (conf_centerItems ? " align='center'" : "") + ">");
            var tr = $(document.createElement("tr"));
            var td = $("<td" + (conf_centerItems ? " align='center'" : "") + ">")
            if (conf_centerItems)
                td.attr('align', 'center');

            this.element.append(table.append(tr.append(td.append(this.xl))));

            if(j == 0 && i == 2) {
                var table = $("<table" + (conf_centerItems ? " align='center'" : "") + ">");
                var tr = $(document.createElement("tr"));
                var td = $("<td" + (conf_centerItems ? " align='center'" : "") + ">")
                if (conf_centerItems)
                    td.attr('align', 'center');

                var temp = $(document.createElement(((!this.presentAsScale && !this.presentHorizontally) && this.showNumbers) ? "ol" : "ul"))
                    .css('margin-left', "2em").css('padding-left', 0);

                var p;
                p = $(document.createElement("p"));

                p.html(this.arrow);
                this.element.append(table.append(tr.append(td.append(temp.append(p)))));
            }
        }
        
        if (! (this.qp === undefined))
            this.element.append(this.qp);

        if (this.instructions) {
            this.element.append($(document.createElement("p"))
                                .addClass(this.cssPrefix + "instructions-text")
                                .css('text-align', conf_centerItems ? 'center' : 'left')
                                .text(this.instructions));
        }

        // Store the time when this was first displayed.
        this.creationTime = new Date().getTime();
    }
},

properties: {
    obligatory: ["images"],
    htmlDescription: function(opts) {
        return $(document.createElement("div")).text(opts.q || "");
    }
}
});

})();