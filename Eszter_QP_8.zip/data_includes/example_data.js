//var shuffleSequence = seq("intro", "sst1", rshuffle("sst", "ssf", "ssu", "ext", "exf", "exu"));
//var randomCode = Math.random().toString(36).substr(2,9);
//var completionCode = String("QUANT-" + randomCode);
//var completionMessage = "Thank you for your participation. The results were successfully transmitted. Your participation code is: "+ completionCode;
var shuffleSequence=seq("setcounter","consent","intro", "realexperiment",rshuffle(startsWith("e"),startsWith("fill")),"exit");
//var shuffleSequence=seq("setcounter","consent","intro", "realexperiment",rshuffle(startsWith("e")),"exit");
//rshuffle(startsWith("e"),startsWith("fill"))
//var shuffleSequence = seq("practicea1","exit");
//var shuffleSequence = seq("practiceb1",rshuffle(startsWith("quant")));

//var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: "keypress",
        normalMessage: "Press the space bar to continue.",
        errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: true
    },
//    "Message", {
//        hideProgressBar: true
//    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        countsForProgressBar: true,
      //  continueMessage: "Press return to continue."
    },
    "Message", {
      hideProgressBar: true,
      transfer: "keypress"
    }];

var items = [
    ["sep", "Separator", { }],
    ["setcounter", "__SetCounter__", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
    ["intro", "Form", {html: { include: "example_intro0.html" }, validators: {},continueMessage:"Click here to continue."} ],
    ["realexperiment", "Form", {html: { include: "example_intro3.html" },validators: {},continueMessage:"Click here to continue."} ],
    ["exit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to continue."} ],


[["e.SRC.local.A",1], "DashedSentence", {s: ["A diktátor,", "aki", "megutálta", "a szakadárt", "a közelmúlt", "eseményeit", "követően,", "beszédet", "mondott", "az ülésen."]}, "Question", {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt","a szakadár a diktátort"], hasCorrect: 0, randomOrder: true}],
[["e.SRC.nonlocal.A",1], "DashedSentence", {s: ["A diktátor,", "aki", "a szakadárt", "megutálta", "a közelmúlt", "eseményeit", "követően,", "beszédet", "mondott", "az ülésen."]}, "Question", {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt","a szakadár a diktátort"], hasCorrect: 0, randomOrder: true}],
//[["e.ORC.nonlocal.A",1], "DashedSentence", {s: ["A diktátor,", "akit", "a szakadár", "megutált", "a közelmúlt", "eseményeit", "követően,", "beszédet", "mondott", "az ülésen."]}, "Question", {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt","a szakadár a diktátort"], hasCorrect: 1, randomOrder: true}],
//[["e.ORC.local.A",1], "DashedSentence", {s: ["A diktátor,", "akit", "megutált", "a szakadár", "a közelmúlt", "eseményeit", "követően,", "beszédet", "mondott", "az ülésen."]}, "Question", {q: "Ki utált meg kit?", as: ["a diktátor a szakadárt","a szakadár a diktátort"], hasCorrect: 1, randomOrder: true}],
["filler", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "az iskolavezetés", "komoly", "problémákkal", "küzd."]}, "Question", {q: "Milyen problémákkal küzd az iskolavezetés?", as: ["a súlyos","komoly"], hasCorrect: 1, randomOrder: true}],
["filler", "DashedSentence", {s: ["Nyilvánvaló", "volt,", "hogy", "az időjárás", "jelentés", "ellenére", "idén", "karácsonykor", "sem", "fog", "esni", "a hó."]}, "Question", {q: "Az időjárás jelentés szerint fog esni a hó?", as: ["igen","nem"], hasCorrect: 0, randomOrder: true}]


];



function blank(a, b) {
   var sentence = b ? b : a;
   var n = b ? a : null;

   var seq = [""];
   var inBlank = false;
   for (var i = 0; i < sentence.length; ++i) {
       var c = sentence.charAt(i)
       if (inBlank) {
           if (c == '_')
               (seq[seq.length-1])++;
           else {
               seq.push(c);
               inBlank = true;
           }
       }
       else {
           if (c != '_')
               seq[seq.length-1] += c
           else {
               seq.push(1);
               inBlank = true;
           }
       }
   }

   var ihtml = "";
   var bcount = 0;
   for (var i = 0; i < seq.length; ++i) {
       if (typeof(seq[i]) == "number") {
           ++bcount;
           var input = " <input type='text' name='blank-" + bcount + "' size='" + (n ? n : seq[i]) + "'></input> ";
           ihtml += input;
       }
       else {
           ihtml += $("<div>").text(seq[i])[0].innerHTML;
       }
   }

   var e = "<p>";
   var validators = { };
   var bcount = 0;
   for (var i = 0; i < seq.length; ++i) {
       if (typeof(seq[i]) == "number") {
           ++bcount;
           e += "<label class='error' for='blank-" + bcount + "'></label>";
           validators['blank-' + bcount] = function (s) { if (s && ! s.match(/^\s*$/)) return true; else return "You must fill in the blank."; }
       }
   }
   e += "</p>"

   return {
       html: "<p>" + ihtml+ "</p>" + e,
       validators: validators
   };
   //return "<p>" + ihtml+ "</p>" + e
}
