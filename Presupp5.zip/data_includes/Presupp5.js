var shuffleSequence = seq("setcounter","Consent","Instructions", sepWith("sep", rshuffle(startsWith("Q"))), "Repetition", rshuffle(startsWith("Z")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        leftComment: "Less natural",
        rightComment: "More natural",
        instructions: " ",
        randomOrder: false,
        hasCorrect: false,
        as: ["1","2","3","4","5","6","7"]
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

["setcounter", "__SetCounter__", { }],

["Consent", "Form", {consentRequired: true, html: {include: "Consent.html" }} ],    
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions1.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions2.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions3.html" }} ],
["Repetition", "Form", {consentRequired: true, html: {include: "Instructions4.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],

    
  
["sep", "Separator", {hideProgressBar: true, transfer: 500, normalMessage: " "}],
  
  
  
  
  














[["Q23NN", 133], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Rosalie drew Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],

[["Q23RN", 135], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Pete reminded Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],

[["Q23ON", 137], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The parents brought their children for a fun playdate. </font></p><p><font size="4">Marina nagged Bella, and Mira nagged Phoebe, too. </font></p><p><font size="4">The parents scheduled another one for next Saturday. </font></p></center>', transfer: "click"}],



[["Q48NO", 284], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">August controlled Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],

[["Q48RO", 286], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Maximus approached Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],

[["Q48OO", 288], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Abraham greeted Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],



[["Q26NO", 152], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Dan replaced Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],

[["Q26RO", 154], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Max watched Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],

[["Q26OO", 156], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The players on the sidelines viewed the World Cup match. </font></p><p><font size="4">Angus saw Abby, and Leo saw Abby, too.</font></p><p><font size="4">If only the coach put the benchwarmers on the field. </font></p></center>', transfer: "click"}],



[["Q31NO", 182], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Elijah duped Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],

[["Q31RO", 184], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Lukas supported Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],

[["Q31OO", 186], "Message", {hideProgressBar: true, html:'<center><p><font size="4">After the scandal, reputations were in doubt.</font></p><p><font size="4">Aaron defended Daniel, and Lee defended Daniel, too. </font></p><p><font size="4">I don\'t know if we\'ll be able to clear everyone\'s names. </font></p></center>', transfer: "click"}],











[["Z01", 1001], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">At the zoo, we saw rhinos, apes, and wolves.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/zoo.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z02", 1002], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Buy me an apple.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/apple.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z03", 1003], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Have you finished your homework yet?</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/homework.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z04", 1004], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Who did you see at the movies?</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/movies.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z05", 1005], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">If you have any problems, just contact us.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/contact.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z06", 1006], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Did you see the rainbow yesterday?</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/rainbow.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z07", 1007], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">What did you decide to buy?</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/buy.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z08", 1008], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Go clean your room.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/room.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z09", 1009], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">Yesterday I bought eggs, milk, and cheese.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/eggs.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z10", 1010], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">What a beautiful voice!</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/voice.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z11", 1011], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">How nice of you!</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/nice.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}],

[["Z12", 1012], "Message", {hideProgressBar: true, html:'<center><p>Click the link below to hear the speaker say:</p><p><i><font size="4" color="#ed1300">If he calls, ask him to leave a message.</font></i></p></center></font>', transfer: "click"}, "Message", {hideProgressBar: true, html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/message.wav" autoplay="autoplay"></audio><p>Read the sentence aloud, imitating the speaker, and then click below to continue.</p>', transfer: "click"}]
  


  



/*




*/






  
  /*
  
Known file issues:

(1)

Male subject didn't record one sentence - Item 36, old verb old object (deaccented).
That means the following files weren't available:

36newVoldOdacM
36oldVoldOaccM
36oldVoldOdacM
36relVoldOdacM

They were all replaced with the file 36newVoldOaccM.wav and the sentence in the preview message controller was changed to match.
But, the code at the beginning of the line shows the condition they *should* be in, so these lines need to be subset out before analaysis.


(2)

In the files 15oldVnewOaccM.wav and 15oldVnewOdacM.wav, the male subject misread the first clause verb as
"admonished" instead of "astonished". The preview sentence was changed to match, but these trials should
be subset out before analysis because the verb does not license the correct (repeated) relation.

  
  

  
  
  */
  
  


















/*
Fillers/attention trials. The files zoo, apple, homework, movies, and contact should get high ratings.
buy, rainbow, room, eggs, and voice should get low ratings.
*/












/*comma*/


    
    




];










