var shuffleSequence = seq("intro","setcounter","practice", "presep", sepWith("sep", rshuffle(startsWith("VMM"),startsWith("EP"),"f")), "exit");
var practiceItemTypes = ["practice"];

//var progressBarText = "Your current progress"
//var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
    },
    
    "DashedAcceptabilityJudgment", {
        mode: "self-paced reading",
        display: "dashed",
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "On a 1-7 scale, how acceptable is this sentence? Cick a box above or press a number key to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Is this an acceptable sentence? Cick boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
   
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var aj = "DashedAcceptabilityJudgment";
var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],


["setcounter", "__SetCounter__", { }],


["sep", Separator, { }],
   ["practice", aj, {s: ["This is", "just a practice sentence", "to get you used to the method of presentation."]}],
 
    ["practice", aj, {s: ["The cleaning lady", "working", "in the bathroom", "cursed himself", "for", "forgetting his wrench."]}],
    
    ["practice", aj, {s: ["The pop star", "sang", "herself", "hoarse", "at the concert", "last night."]}],
 
    ["practice", "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The practice session is over now. You will start the experiment now. Pleae press the spacebar to continue"],
                          ]}],
    
   
    ["presep", Separator, { transfer: 2000, normalMessage: "Please get ready. We will start. Please wait..." }],


[["VMM_a",1], aj, {s: ["Rick", "labeled", "the jar.", "Tim", "did too,", "because", "Tim", "liked", "jars."]}],
[["VMM_b",1], aj, {s: ["Rick", "labeled", "the jar.", "The bowl", "was too,", "because", "the bowl", "needed",  "labels." ]}],
[["VMM_c",1], aj, {s: ["The jar", "was labeled", "by Rick.", "The bowl", "was too,", "because", "the bowl", "needed", "labels."]}],
[["VMM_d",1], aj, {s: ["The jar", "was labeled", "by Rick.",  "Tim", "did too,", "because", "Tim", "liked", "jars."]}],    
[["VMM_e",1], aj, {s: ["The jar", "lured", "Rick.", "The bowl", "did too,", "because", "the bowl", "contained", "honey."]}],
[["VMM_f",1], aj, {s: ["The jar", "lured", "Rick.", "Tim", "was too,", "because", "Tim", "liked", "honey."]}],
[["VMM_g",1], aj, {s: ["Rick", "was lured", "by the jar.", "Tim", "was too,", "because", "Tim", "liked", "honey."]}],   
[["VMM_h",1], aj, {s: ["Rick", "was lured", "by the jar.", "The bowl", "did too,", "because", "the bowl", "contained", "honey."]}],
    
[["VMM_a",2], aj, {s: ["Joanna", "completed", "the puzzle.", "Madeleine", "did too,", "because", "Madeleine", "enjoyed", "puzzles."]}],
[["VMM_b",2], aj, {s: ["Joanna", "completed", "the puzzle.", "The crossword", "was too,", "because", "the crossword", "was", "unfinished."]}],
[["VMM_c",2], aj, {s: ["The puzzle", "was completed", "by Joanna.", "The crossword", "was too,", "because", "the crossword", "was", "unfinished."]}],
[["VMM_d",2], aj, {s: ["The puzzle", "was completed", "by Joanna.", "Madeleine", "did too,", "because", "Madeleine", "enjoyed", "puzzles."]}],    
[["VMM_e",2], aj, {s: ["The puzzle", "amused", "Joanna.", "The crossword", "did too,", "because", "the crossword", "involved", "rabbits."]}],
[["VMM_f",2], aj, {s: ["The puzzle", "amused", "Joanna.", "Madeleine", "was too,", "because", "Madeleine", "enjoyed", "puzzles."]}],
[["VMM_g",2], aj, {s: ["Joanna", "was amused", "by the puzzle.", "Madeleine", "was too,", "because", "Madeleine", "enjoyed", "puzzles."]}],   
[["VMM_h",2], aj, {s: ["Joanna", "was amused", "by the puzzle.", "The crossword", "did too,", "because", "the crossword", "involved", "rabbits."]}],
    
[["VMM_a",3], aj, {s: ["Katie", "altered", "the plan.", "Carissa", "did too,", "because", "Carissa", "didn't", "like", "the original plan."]}],
[["VMM_b",3], aj, {s: ["Katie", "altered", "the plan.", "The directions", "were too,", "because", "the directions", "worked", "badly."]}],
[["VMM_c",3], aj, {s: ["The plan", "was altered", "by Katie.", "The directions", "were too,", "because", "the directions", "worked", "badly."]}],
[["VMM_d",3], aj, {s: ["The plan", "was altered", "by Katie.", "Carissa", "did too,", "because", "Carissa", "didn't", "like", "the original plan."]}],    
[["VMM_e",3], aj, {s: ["The plan", "delighted", "Katie.", "The directions", "did too,", "because", "the directions", "were", "well-organized."]}],
[["VMM_f",3], aj, {s: ["The plan", "delighted", "Katie.", "Carissa", "was too,", "because", "Carissa", "wanted", "to go out", "that night."]}],
[["VMM_g",3], aj, {s: ["Katie", "was delighted", "by the plan.", "Carissa", "was too,", "because", "Carissa", "wanted", "to go out", "that night."]}],   
[["VMM_h",3], aj, {s: ["Katie", "was delighted", "by the plan.", "The directions", "did too,", "because", "the directions", "were", "well-organized."]}],
    
    
[["VMM_a",4], aj, {s: ["Julia", "finished", "the ritual.", "Audrey", "did too,", "because", "Audrey", "wanted", "to leave."]}],
[["VMM_b",4], aj, {s: ["Julia", "finished", "the ritual.", "The ceremony", "was too,", "because", "the ceremony", "was", "interesting."]}],
[["VMM_c",4], aj, {s: ["The ritual", "was finished", "by Julia.", "The ceremony", "was too,", "because", "the ceremony", "was", "interesting."]}],
[["VMM_d",4], aj, {s: ["The ritual", "was finished", "by Julia.", "Audrey", "did too,", "because", "Audrey", "wanted", "to leave."]}],    
[["VMM_e",4], aj, {s: ["The ritual", "bored", "Julia.", "The ceremony", "did too,", "because", "the ceremony", "was", "boring."]}],
[["VMM_f",4], aj, {s: ["The ritual", "bored", "Julia.", "Audrey", "was too,", "because", "Audrey", "had", "other things", "to do."]}],
[["VMM_g",4], aj, {s: ["Julia", "was bored", "by the ritual.", "Audrey", "was too,", "because", "Audrey", "had", "other things", "to do."]}],   
[["VMM_h",4], aj, {s: ["Julia", "was bored", "by the ritual.", "The ceremony", "did too,", "because", "the ceremony", "was", "boring."]}],
 
[["VMM_a",5], aj, {s: ["Maya", "muted", "the song.", "Kristen", "did too,", "because", "Kristen", "wanted", "silence."]}],
[["VMM_b",5], aj, {s: ["Maya", "muted", "the song.", "The static", "was too,", "because", "the static", "lasted", "too long."]}],
[["VMM_c",5], aj, {s: ["The song", "was muted", "by Maya.", "The static", "was too,", "because", "the static", "lasted", "too long."]}],
[["VMM_d",5], aj, {s: ["The song", "was muted", "by Maya.", "Kristen", "did too,", "because", "Kristen", "wanted", "silence."]}],    
[["VMM_e",5], aj, {s: ["The song", "annoyed", "Maya.", "The static", "did too,", "because", "the static", "was", "obnoxious."]}],
[["VMM_f",5], aj, {s: ["The song", "annoyed", "Maya.", "Kristen", "was too,", "because", "Kristen", "disliked", "pop music."]}],
[["VMM_g",5], aj, {s: ["Maya", "was annoyed", "by the song.", "Kristen", "was too,", "because", "Kristen", "disliked", "pop music."]}],   
[["VMM_h",5], aj, {s: ["Maya", "was annoyed", "by the song.", "The static", "did too,", "because", "the static", "was", "obnoxious."]}],
 
 
[["VMM_a",6], aj, {s: ["Alana", "evaded", "the cliff.", "Evelyn", "did too,", "because", "Evelyn", "feared", "heights."]}],
[["VMM_b",6], aj, {s: ["Alana", "evaded", "the cliff.", "The gorge", "was too,", "because", "the gorge", "was", "too steep."]}],
[["VMM_c",6], aj, {s: ["The cliff", "was evaded", "by Alana.", "The gorge", "was too,", "because", "the gorge", "was", "too steep."]}],
[["VMM_d",6], aj, {s: ["The cliff", "was evaded", "by Alana.", "Evelyn", "did too,", "because", "Evelyn", "feared", "heights."]}],    
[["VMM_e",6], aj, {s: ["The cliff", "impressed", "Alana.", "The gorge", "did too,", "because", "the gorge", "was",  "a landmark."]}],
[["VMM_f",6], aj, {s: ["The cliff", "impressed", "Alana.", "Evelyn", "was too,", "because", "Evelyn", "liked", "steep cliffs."]}],
[["VMM_g",6], aj, {s: ["Alana", "was impressed", "by the cliff.", "Evelyn", "was too,", "because", "Evelyn", "liked", "steep cliffs."]}],   
[["VMM_h",6], aj, {s: ["Alana", "was impressed", "by the cliff.", "The gorge", "did too,", "because", "the gorge", "was", "a landmark."]}],
 
[["VMM_a",7], aj, {s: ["Mia", "escorted", "the parade.", "Olivia", "did too,", "because", "Olivia", "patrolled", "the street."]}],
[["VMM_b",7], aj, {s: ["Mia", "escorted", "the parade.", "The procession", "was too,", "because", "the procession", "needed", "protection."]}],
[["VMM_c",7], aj, {s: ["The parade", "was escorted", "by Mia.", "The procession", "was too,", "because", "the procession", "needed", "protection."]}],
[["VMM_d",7], aj, {s: ["The parade", "was escorted", "by Mia.", "Olivia", "did too,", "because", "Olivia", "patrolled", "the street."]}],    
[["VMM_e",7], aj, {s: ["The parade", "frustrated", "Mia.", "The procession", "did too,", "because", "the procession", "blocked", "the road."]}],
[["VMM_f",7], aj, {s: ["The parade", "frustrated", "Mia.", "Olivia", "was too,", "because", "Olivia", "wanted", "to pass through."]}],
[["VMM_g",7], aj, {s: ["Mia", "was frustrated", "by the parade.", "Olivia", "was too,", "because", "Olivia", "wanted", "to pass through."]}],   
[["VMM_h",7], aj, {s: ["Mia", "was frustrated", "by the parade.", "The procession", "did too,", "because", "the procession", "blocked", "the road."]}],
 
[["VMM_a",8], aj, {s: ["Sarah", "heeded", "the warning.", "Abbie", "did too,", "because", "Abbie", "was", "superstitious."]}],
[["VMM_b",8], aj, {s: ["Sarah", "heeded", "the warning.", "The omen", "was too,", "because", "the omen", "seemed", "credible."]}],
[["VMM_c",8], aj, {s: ["The warning", "was heeded", "by Sarah.", "The omen", "was too,", "because", "the omen", "seemed", "credible."]}],
[["VMM_d",8], aj, {s: ["The warning", "was heeded", "by Sarah.", "Abbie", "did too,", "because", "Abbie", "was", "superstitious."]}],    
[["VMM_e",8], aj, {s: ["The warning", "disturbed", "Sarah.", "The omen", "did too,", "because", "the omen", "foretold", "doom."]}],
[["VMM_f",8], aj, {s: ["The warning", "disturbed", "Sarah.", "Abbie", "was too,", "because", "Abbie", "feared", "failure."]}],
[["VMM_g",8], aj, {s: ["Sarah", "was disturbed", "by the warning.", "Abbie", "was too,", "because", "Abbie", "feared", "failure."]}],   
[["VMM_h",8], aj, {s: ["Sarah", "was disturbed", "by the warning.", "The omen", "did too,", "because", "the omen", "foretold", "doom."]}],
 
[["VMM_a",9], aj, {s: ["Marina", "rejected", "the compliment.", "Kayla", "did too,", "because", "Kayla", "thought", "she", "didn't", "do well."]}],
[["VMM_b",9], aj, {s: ["Marina", "rejected", "the compliment.", "The suggestion", "was too,", "because", "the suggestion", "sounded", "ridiculous."]}],
[["VMM_c",9], aj, {s: ["The compliment", "was rejected", "by Marina.", "The suggestion", "was too,", "because", "the suggestion", "sounded", "ridiculous."]}],
[["VMM_d",9], aj, {s: ["The compliment", "was rejected", "by Marina.", "Kayla", "did too,", "because", "Kayla", "thought", "she", "didn't", "do well."]}],    
[["VMM_e",9], aj, {s: ["The compliment", "excited", "Marina.", "The suggestion", "did too,", "because", "the suggestion", "sounded", "wonderful."]}],
[["VMM_f",9], aj, {s: ["The compliment", "excited", "Marina.", "Kayla", "was too,", "because", "Kayla", "liked", "compliments."]}],
[["VMM_g",9], aj, {s: ["Marina", "was excited", "by the compliment.", "Kayla", "was too,", "because", "Kayla", "liked", "compliments."]}],   
[["VMM_h",9], aj, {s: ["Marina", "was excited", "by the compliment.", "The suggestion", "did too,", "because", "the suggestion", "sounded", "wonderful."]}],
 
[["VMM_a",10], aj, {s: ["Hannah", "weighed", "the necklace.", "Emily", "did too,", "because", "Emily", "doubted", "the label."]}],
[["VMM_b",10], aj, {s: ["Hannah", "weighed", "the necklace.", "The talisman", "was too,", "because", "the talisman", "needed", "recording."]}],
[["VMM_c",10], aj, {s: ["The necklace", "was weighed", "by Hannah.", "The talisman", "was too,", "because", "the talisman", "needed", "recording."]}],
[["VMM_d",10], aj, {s: ["The necklace", "was weighed", "by Hannah.", "Emily", "did too,", "because", "Emily", "doubted", "the label."]}],    
[["VMM_e",10], aj, {s: ["The necklace", "soothed", "Hannah.", "The talisman", "did too,", "because", "the talisman", "were", "conforting."]}],
[["VMM_f",10], aj, {s: ["The necklace", "soothed", "Hannah.", "Emily", "was too,", "because", "Emily", "had been", "afraid."]}],
[["VMM_g",10], aj, {s: ["Hannah", "was soothed", "by the necklace.", "Emily", "was too,", "because", "Emily", "had been", "afraid."]}],   
[["VMM_h",10], aj, {s: ["Hannah", "was soothed", "by the necklace.", "The talisman", "did too,", "because", "the talisman", "were", "comforting."]}],

[["VMM_a",11], aj, {s: ["Jack", "wrote", "the advertisement.", "David", "did too,", "because", "David", "enjoyed", "marketing."]}],
[["VMM_b",11], aj, {s: ["Jack", "wrote", "the advertisement.", "The quote", "was too,", "because", "the quote", "used", "strong language."]}],
[["VMM_c",11], aj, {s: ["The advertisement", "was written", "by Jack.", "The quote", "was too,", "because", "the quote", "used", "strong language."]}],
[["VMM_d",11], aj, {s: ["The advertisement", "was written", "by Jack.", "David", "did too,", "because", "David", "enjoyed", "marketing."]}],    
[["VMM_e",11], aj, {s: ["The advertisement", "angered", "Jack.", "The quote", "did too,", "because", "the quote", "was", "badly worded."]}],
[["VMM_f",11], aj, {s: ["The advertisement", "angered", "Jack.", "David", "was too,", "because", "David", "hated", "the message."]}],
[["VMM_g",11], aj, {s: ["Jack", "was angered", "by the advertisement.", "David", "was too,", "because", "David", "hated", "the message."]}],   
[["VMM_h",11], aj, {s: ["Jack", "was angered", "by the advertisement.", "The quote", "did too,", "because", "the quote", "was", "badly worded."]}],
 
[["VMM_a",12], aj, {s: ["Camille", "built", "the pyramid.", "Sophia", "did too,", "because", "Sophia", "enjoyed", "building."]}],
[["VMM_b",12], aj, {s: ["Camille", "built", "the pyramid.", "The monument", "was too,", "because", "the monument", "needed", "construction."]}],
[["VMM_c",12], aj, {s: ["The pyramid", "was built", "by Camille.", "The monument", "was too,", "because", "the monument", "needed", "construction."]}],
[["VMM_d",12], aj, {s: ["The pyramid", "was built", "by Camille.", "Sophia", "did too,", "because", "Sophia", "enjoyed", "building."]}],    
[["VMM_e",12], aj, {s: ["The pyramid", "awed", "Camille.", "The monument", "did too,", "because", "the monument", "was", "massive."]}],
[["VMM_f",12], aj, {s: ["The pyramid", "awed", "Camille.", "Sophia", "was too,", "because", "Sophia", "loved", "monuments."]}],
[["VMM_g",12], aj, {s: ["Camille", "was awed", "by the pyramid.", "Sophia", "was too,", "because", "Sophia", "loved", "monuments."]}],   
[["VMM_h",12], aj, {s: ["Camille", "was awed", "by the pyramid.", "The monument", "did too,", "because", "the monument", "was", "massive."]}],
 
[["VMM_a",13], aj, {s: ["Cristina", "recorded", "the criticism.", "Michelle", "did too,", "because", "Michelle", "wanted", "to improve."]}],
[["VMM_b",13], aj, {s: ["Cristina", "recorded", "the criticism.", "The question", "was too,", "because", "the question", "sounded", "important."]}],
[["VMM_c",13], aj, {s: ["The criticism", "was recorded", "by Cristina.", "The question", "was too,", "because", "the question", "sounded", "important."]}],
[["VMM_d",13], aj, {s: ["The criticism", "was recorded", "by Cristina.", "Michelle", "did too,", "because", "Michelle", "wanted", "to improve."]}],    
[["VMM_e",13], aj, {s: ["The criticism", "disappointed", "Cristina.", "The question", "did too,", "because", "the question", "didn't", "seem", "relevant."]}],
[["VMM_f",13], aj, {s: ["The criticism", "disappointed", "Cristina.", "Michelle", "was too,", "because", "Michelle", "deserved", "better."]}],
[["VMM_g",13], aj, {s: ["Cristina", "was disappointed", "by the criticism.", "Michelle", "was too,", "because", "Michelle", "deserved", "better."]}],   
[["VMM_h",13], aj, {s: ["Cristina", "was disappointed", "by the criticism.", "The question", "did too,", "because", "the question", "didn't", "seem", "relevant."]}],
 
[["VMM_a",14], aj, {s: ["Cindy", "embraced", "the doll.", "Deirdre", "did too,", "because", "Deirdre", "loved", "dolls."]}],
[["VMM_b",14], aj, {s: ["Cindy", "embraced", "the doll.", "The dress", "was too,", "because", "the dress", "was", "high quality."]}],
[["VMM_c",14], aj, {s: ["The doll", "was embraced", "by Cindy.", "The dress", "was too,", "because", "the dress", "was", "high quality."]}],
[["VMM_d",14], aj, {s: ["The doll", "was embraced", "by Cindy.", "Deirdre", "did too,", "because", "Deirdre", "loved", "dolls."]}],    
[["VMM_e",14], aj, {s: ["The doll", "interested", "Cindy.", "The dress", "did too,", "because", "the dress", "seemed", "fashionable."]}],
[["VMM_f",14], aj, {s: ["The doll", "interested", "Cindy.", "Deirdre", "was too,", "because", "Deirdre", "loved", "dolls."]}],
[["VMM_g",14], aj, {s: ["Cindy", "was interested", "by the doll.", "Deirdre", "was too,", "because", "Deirdre", "loved", "dolls."]}],   
[["VMM_h",14], aj, {s: ["Cindy", "was interested", "by the doll.", "The dress", "did too,", "because", "the dress", "seemed", "fashionable."]}],
 
[["VMM_a",15], aj, {s: ["Nikki", "edited", "the article.", "Margaret", "did too,", "because", "Margaret", "edited", "the newspaper."]}],
[["VMM_b",15], aj, {s: ["Nikki", "edited", "the article.", "The headline", "was too,", "because", "the headline", "was", "poorly worded."]}],
[["VMM_c",15], aj, {s: ["The article", "was edited", "by Nikki.", "The headline", "was too,", "because", "the headline", "was", "poorly worded."]}],
[["VMM_d",15], aj, {s: ["The article", "was edited", "by Nikki.", "Margaret", "did too,", "because", "Margaret", "edited", "the newspaper."]}],
[["VMM_e",15], aj, {s: ["The article", "alarmed", "Nikki.", "The headline", "did too,", "because", "the headline", "mentioned", "tornados."]}],
[["VMM_f",15], aj, {s: ["The article", "alarmed", "Nikki.", "Margaret", "was too,", "because", "Margaret", "worried", "too much."]}],
[["VMM_g",15], aj, {s: ["Nikki", "was alarmed", "by the article.", "Margaret", "was too,", "because", "Margaret", "worried", "too much."]}],   
[["VMM_h",15], aj, {s: ["Nikki", "was alarmed", "by the article.", "The headline", "did too,", "because", "the headline", "mentioned", "tornados."]}],
 
[["VMM_a",16], aj, {s: ["Rebecca", "released", "the announcement.", "Emma", "did too,", "because", "Emma", "wrote", "the announcement."]}],
[["VMM_b",16], aj, {s: ["Rebecca", "released", "the announcement.", "The result", "was too,", "because", "the result", "was", "relevant."]}],
[["VMM_c",16], aj, {s: ["The announcement", "was released", "by Rebecca.", "The result", "was too,", "because", "the result", "was", "relevant."]}],
[["VMM_d",16], aj, {s: ["The announcement", "was released", "by Rebecca.", "Emma", "did too,", "because", "Emma", "wrote", "the announcement."]}],    
[["VMM_e",16], aj, {s: ["The announcement", "bothered", "Rebecca.", "The result", "did too,", "because", "the result", "disappointed", "her."]}],
[["VMM_f",16], aj, {s: ["The announcement", "bothered", "Rebecca.", "Emma", "was too,", "because", "Emma", "disliked", "the announcement."]}],
[["VMM_g",16], aj, {s: ["Rebecca", "was bothered", "by the announcement.", "Emma", "was too,", "because", "Emma", "disliked", "the announcement."]}],   
[["VMM_h",16], aj, {s: ["Rebecca", "was bothered", "by the announcement.", "The result", "did too,", "because", "the result", "disappointed", "her."]}],
 
[["VMM_a",17], aj, {s: ["Isabel", "controlled", "the plane.", "Helen", "did too,", "because", "Helen", "flies", "planes."]}],
[["VMM_b",17], aj, {s: ["Isabel", "controlled", "the plane.", "The robot", "was too,", "because", "the robot", "had", "instructions."]}],
[["VMM_c",17], aj, {s: ["The plane", "was controlled", "by Isabel.", "The robot", "was too,", "because", "the robot", "had", "instructions."]}],
[["VMM_d",17], aj, {s: ["The plane", "was controlled", "by Isabel.", "Helen", "did too,", "because", "Helen", "flies", "planes."]}],    
[["VMM_e",17], aj, {s: ["The plane", "amazed", "Isabel.", "The robot", "did too,", "because", "the robot", "was", "from the future."]}],
[["VMM_f",17], aj, {s: ["The plane", "amazed", "Isabel.", "Helen", "was too,", "because", "Helen", "loved",  "planes."]}],
[["VMM_g",17], aj, {s: ["Isabel", "was amazed", "by the plane.", "Helen", "was too,", "because", "Helen", "loved", "planes."]}],   
[["VMM_h",17], aj, {s: ["Isabel", "was amazed", "by the plane.", "The robot", "did too,", "because", "the robot", "was", "from the future."]}],
 
[["VMM_a",18], aj, {s: ["Lisa", "scratched", "the label.", "Claudette", "did too,", "because", "Claudette", "needed", "the code underneath."]}],
[["VMM_b",18], aj, {s: ["Lisa", "scratched", "the label.", "The sign", "was too,", "because", "the sign", "stuck", "to the wall."]}],
[["VMM_c",18], aj, {s: ["The label", "was scratched", "by Lisa.", "The sign", "was too,", "because", "the sign", "stuck", "to the wall."]}],
[["VMM_d",18], aj, {s: ["The label", "was scratched", "by Lisa.", "Claudette", "did too,", "because", "Claudette", "needed", "the code underneath."]}],    
[["VMM_e",18], aj, {s: ["The label", "tempted", "Lisa.", "The sign", "did too,", "because", "the sign", "showed", "honey."]}],
[["VMM_f",18], aj, {s: ["The label", "tempted", "Lisa.", "Claudette", "was too,", "because", "Claudette", "loved", "honey."]}],
[["VMM_g",18], aj, {s: ["Lisa", "was tempted", "by the label.", "Claudette", "was too,", "because", "Claudette", "loved", "honey."]}],   
[["VMM_h",18], aj, {s: ["Lisa", "was tempted", "by the label.", "The sign", "did too,", "because", "the sign", "showed", "honey."]}],
 
[["VMM_a",19], aj, {s: ["Brian", "reproduced", "the experiment.", "Roger", "did too,", "because", "Roger", "wanted", "the results."]}],
[["VMM_b",19], aj, {s: ["Brian", "reproduced", "the experiment.", "The tests", "were too,", "because", "the tests", "had", "important results."]}],
[["VMM_c",19], aj, {s: ["The experiment", "was reproduced", "by Brian.", "The tests", "were too,", "because", "the tests", "had", "important results."]}],
[["VMM_d",19], aj, {s: ["The experiment", "was reproduced", "by Brian.", "Roger", "did too,", "because", "Roger", "wanted", "the results."]}],    
[["VMM_e",19], aj, {s: ["The experiment", "convinced", "Brian.", "The tests", "did too,", "because", "the tests", "produced", "strong results."]}],
[["VMM_f",19], aj, {s: ["The experiment", "convinced", "Brian.", "Roger", "was too,", "because", "Roger", "understood", "the results."]}],
[["VMM_g",19], aj, {s: ["Brian", "was convinced", "by the experiment.", "Roger", "was too,", "because", "Roger",  "understood", "the results."]}],   
[["VMM_h",19], aj, {s: ["Brian", "was convinced", "by the experiment.", "The tests", "did too,", "because", "the tests", "produced", "strong results."]}],
 
[["VMM_a",20], aj, {s: ["Louis", "neglected", "the castle.", "John", "did too,", "because", "John", "went", "abroad."]}],
[["VMM_b",20], aj, {s: ["Louis", "neglected", "the castle.", "The house", "was too,", "because", "the house", "were", "isolated."]}],
[["VMM_c",20], aj, {s: ["The castle", "was neglected", "by Louis.", "The house", "was too,", "because", "the house", "were", "isolated."]}],
[["VMM_d",20], aj, {s: ["The castle", "was neglected", "by Louis.", "John", "did too,", "because", "John", "went", "abroad."]}],    
[["VMM_e",20], aj, {s: ["The castle", "astounded", "Louis.", "The house", "did too,", "because", "the house", "had", "towers."]}],
[["VMM_f",20], aj, {s: ["The castle", "astounded", "Louis.", "John", "was too,", "because", "John", "studied", "castles."]}],
[["VMM_g",20], aj, {s: ["Louis", "was astounded", "by the castle.", "John", "was too,", "because", "John", "studied", "castles."]}],   
[["VMM_h",20], aj, {s: ["Louis", "was astounded", "by the castle.", "The house", "did too,", "because", "the house", "had", "towers."]}],

[["VMM_a",21], aj, {s: ["Mark", "denounced", "the story.", "Tommy", "did too,", "because", "Tommy", "didn't", "believe", "the storyteller."]}],
[["VMM_b",21], aj, {s: ["Mark", "denounced", "the story.", "The sermon", "was too,", "because", "the sermon", "offended", "him."]}],
[["VMM_c",21], aj, {s: ["The story", "was denounced", "by Mark.", "The sermon", "was too,", "because", "the sermon", "offended", "him."]}],
[["VMM_d",21], aj, {s: ["The story", "was denounced", "by Mark.", "Tommy", "did too,", "because", "Tommy", "didn't", "believe", "the storyteller."]}],    
[["VMM_e",21], aj, {s: ["The story", "provoked", "Mark.", "The sermon", "did too,", "because", "the sermon", "insulted", "Mark's mother."]}],
[["VMM_f",21], aj, {s: ["The story", "provoked", "Mark.", "Tommy", "was too,", "because", "Tommy", "hated", "the ending."]}],
[["VMM_g",21], aj, {s: ["Mark", "was provoked", "by the story.", "Tommy", "was too,", "because", "Tommy", "hated", "the ending."]}],   
[["VMM_h",21], aj, {s: ["Mark", "was provoked", "by the story.", "The sermon", "did too,", "because", "the sermon", "insulted", "Mark's mother."]}],
 
[["VMM_a",22], aj, {s: ["Jeremy", "authorized", "the interview.", "Phillip", "did too,", "because", "Phillip", "managed", "the talk show."]}],
[["VMM_b",22], aj, {s: ["Jeremy", "authorized", "the interview.", "The broadcast", "was too,", "because", "the broadcast", "drew", "large audiences."]}],
[["VMM_c",22], aj, {s: ["The interview", "was authorized", "by Jeremy.", "The broadcast", "was too,", "because", "the broadcast",  "drew", "large audiences."]}],
[["VMM_d",22], aj, {s: ["The interview", "was authorized", "by Jeremy.", "Phillip", "did too,", "because", "Phillip", "managed", "the talk show."]}],    
[["VMM_e",22], aj, {s: ["The interview", "embarrassed", "Jeremy.", "The broadcast", "did too,", "because", "the broadcast", "discussed", "his childhood stories."]}],
[["VMM_f",22], aj, {s: ["The interview", "embarrassed", "Jeremy.", "Phillip", "was too,", "because", "Phillip", "were asked", "awkward questions."]}],
[["VMM_g",22], aj, {s: ["Jeremy", "was embarrassed", "by the interview.", "Phillip", "was too,", "because", "Phillip", "were asked", "awkward questions."]}],   
[["VMM_h",22], aj, {s: ["Jeremy", "was embarrassed", "by the interview.", "The broadcast", "did too,", "because", "the broadcast", "discussed", "his childhood stories."]}],
 
[["VMM_a",23], aj, {s: ["Liam", "taped", "the fight.", "Mason", "did too,", "because", "Mason", "had", "a camera."]}],
[["VMM_b",23], aj, {s: ["Liam", "taped", "the fight.", "The argument", "was too,", "because", "the argument", "drew", "crowds."]}],
[["VMM_c",23], aj, {s: ["The fight", "was taped", "by Liam.", "The argument", "was too,", "because", "the argument", "drew", "crowds."]}],
[["VMM_d",23], aj, {s: ["The fight", "was taped", "by Liam.", "Mason", "did too,", "because", "Mason", "had", "a camera."]}],    
[["VMM_e",23], aj, {s: ["The fight", "frightened", "Liam.", "The argument", "did too,", "because", "the argument", "was", "violent."]}],
[["VMM_f",23], aj, {s: ["The fight", "frightened", "Liam.", "Mason", "was too,", "because", "Mason", "feared", "violence."]}],
[["VMM_g",23], aj, {s: ["Liam", "was frightened", "by the fight.", "Mason", "was too,", "because", "Mason", "feared", "violence."]}],   
[["VMM_h",23], aj, {s: ["Liam", "was frightened", "by the fight.", "The argument", "did too,", "because", "the argument", "was", "violent."]}],
 
[["VMM_a",24], aj, {s: ["Isaac", "lost", "the script.", "Theodore", "did too,", "because", "Theodore", "forgot", "his bag."]}],
[["VMM_b",24], aj, {s: ["Isaac", "lost", "the script.", "The letter", "was too,", "because", "the letter", "fell", "out the window."]}],
[["VMM_c",24], aj, {s: ["The script", "was lost", "by Isaac.", "The letter", "was too,", "because", "the letter", "fell", "out the window."]}],
[["VMM_d",24], aj, {s: ["The script", "was lost", "by Isaac.", "Theodore", "did too,", "because", "Theodore", "forgot", "his bag."]}],    
[["VMM_e",24], aj, {s: ["The script", "demoralized", "Isaac.", "The letter", "did too,", "because", "the letter", "was", "very long."]}],
[["VMM_f",24], aj, {s: ["The script", "demoralized", "Isaac.", "Theodore", "was too,", "because", "Theodore", "wanted", "more lines."]}],
[["VMM_g",24], aj, {s: ["Isaac", "was demoralized", "by the script.", "Theodore", "was too,", "because", "Theodore", "wanted", "more lines."]}],   
[["VMM_h",24], aj, {s: ["Isaac", "was demoralized", "by the script.", "The letter", "did too,", "because", "the letter", "was", "very long."]}],
 
[["VMM_a",25], aj, {s: ["Jackson", "removed", "the dust.", "Scott", "did too,", "because", "Scott", "disliked", "dust."]}],
[["VMM_b",25], aj, {s: ["Jackson", "removed", "the dust.", "The mold", "was too,", "because", "the mold", "looked", "dirty."]}],
[["VMM_c",25], aj, {s: ["The dust", "was removed", "by Jackson.", "The mold", "was too,", "because", "the mold", "looked", "dirty."]}],
[["VMM_d",25], aj, {s: ["The dust", "was removed", "by Jackson.", "Scott", "did too,", "because", "Scott", "disliked",  "dust."]}],    
[["VMM_e",25], aj, {s: ["The dust", "shocked", "Jackson.", "The mold", "did too,", "because", "the mold", "filled", "the house."]}],
[["VMM_f",25], aj, {s: ["The dust", "shocked", "Jackson.", "Scott", "was too,", "because", "Scott", "liked", "cleanliness."]}],
[["VMM_g",25], aj, {s: ["Jackson", "was shocked", "by the dust.", "Scott", "was too,", "because", "Scott", "liked", "cleanliness."]}],   
[["VMM_h",25], aj, {s: ["Jackson", "was shocked", "by the dust.", "The mold", "did too,", "because", "the mold", "filled", "the house."]}],
 
[["VMM_a",26], aj, {s: ["Solomon", "timed", "the match.", "Samuel", "did too,", "because", "Samuel", "had to", "keep time."]}],
[["VMM_b",26], aj, {s: ["Solomon", "timed", "the match.", "The game", "was too,", "because", "the game", "had", "a time limit."]}],
[["VMM_c",26], aj, {s: ["The match", "was timed", "by Solomon.", "The game", "was too,", "because", "the game", "had", "a time limit."]}],
[["VMM_d",26], aj, {s: ["The match", "was timed", "by Solomon.", "Samuel", "did too,", "because", "Samuel", "had to", "keep time."]}],    
[["VMM_e",26], aj, {s: ["The match", "thrilled", "Solomon.", "The game", "did too,", "because", "the game", "was", "exciting."]}],
[["VMM_f",26], aj, {s: ["The match", "thrilled", "Solomon.", "Samuel", "was too,", "because", "Samuel", "loved", "soccer."]}],
[["VMM_g",26], aj, {s: ["Solomon", "was thrilled", "by the match.", "Samuel", "was too,", "because", "Samuel", "loved", "soccer."]}],   
[["VMM_h",26], aj, {s: ["Solomon", "was thrilled", "by the match.", "The game", "did too,", "because", "the game", "was", "exciting."]}],

[["VMM_a",27], aj, {s: ["Kevin", "praised", "the book.", "Will", "did too,", "because", "Will", "enjoyed", "the book."]}],
[["VMM_b",27], aj, {s: ["Kevin", "praised", "the book.", "The essay", "was too,", "because", "the essay", "won", "awards."]}],
[["VMM_c",27], aj, {s: ["The book", "was praised", "by Kevin.", "The essay", "was too,", "because", "the essay", "won", "awards."]}],
[["VMM_d",27], aj, {s: ["The book", "was praised", "by Kevin.", "Will", "did too,", "because", "Will", "enjoyed", "the book."]}],    
[["VMM_e",27], aj, {s: ["The book", "pleased", "Kevin.", "The essay", "did too,", "because", "the essay", "was", "well-written."]}],
[["VMM_f",27], aj, {s: ["The book", "pleased", "Kevin.", "Will", "was too,", "because", "Will", "liked", "science fiction."]}],
[["VMM_g",27], aj, {s: ["Kevin", "was pleased", "by the book.", "Will", "was too,", "because", "Will", "liked", "science fiction."]}],   
[["VMM_h",27], aj, {s: ["Kevin", "was pleased", "by the book.", "The essay", "did too,", "because", "the essay", "was", "well-written."]}],

[["VMM_a",28], aj, {s: ["Zach", "analyzed", "the finances.", "Alexander", "did too,", "because", "Alexander", "watched", "stocks."]}],
[["VMM_b",28], aj, {s: ["Zach", "analyzed", "the finances.", "The reports", "were too,", "because", "the reports", "had", "errors."]}],
[["VMM_c",28], aj, {s: ["The finances", "were analyzed", "by Zach.", "The reports", "were too,", "because", "the reports", "had", "errors."]}],
[["VMM_d",28], aj, {s: ["The finances", "were analyzed", "by Zach.", "Alexander", "did too,", "because", "Alexander", "watched", "stocks."]}],    
[["VMM_e",28], aj, {s: ["The finances", "upset", "Zach.", "The reports", "did too,", "because", "the reports", "showed", "failure."]}],
[["VMM_f",28], aj, {s: ["The finances", "upset", "Zach.", "Alexander", "was too,", "because", "Alexander", "wanted", "to lose debt."]}],
[["VMM_g",28], aj, {s: ["Zach", "was upset", "by the finances.", "Alexander", "was too,", "because", "Alexander", "wanted", "to lose debt."]}],   
[["VMM_h",28], aj, {s: ["Zach", "was upset", "by the finances.", "The reports", "did too,", "because", "the reports", "showed", "failure."]}],
 
[["VMM_a",29], aj, {s: ["Christian", "cut", "the ropes.", "Anthony", "did too,", "because", "Anthony", "wanted", "freedom."]}],
[["VMM_b",29], aj, {s: ["Christian", "cut", "the ropes.", "The restraints", "were too,", "because", "the restraints", "were", "too tight."]}],
[["VMM_c",29], aj, {s: ["The ropes", "were cut", "by Christian.", "The restraints", "were too,", "because", "the restraints", "were", "too tight."]}],
[["VMM_d",29], aj, {s: ["The ropes", "were cut", "by Christian.", "Anthony", "did too,", "because", "Anthony", "wanted", "freedom."]}],    
[["VMM_e",29], aj, {s: ["The ropes", "terrified", "Christian.", "The restraints", "did too,", "because", "the restraints", "looked", "scary."]}],
[["VMM_f",29], aj, {s: ["The ropes", "terrified", "Christian.", "Anthony", "was too,", "because", "Anthony", "hated", "ropes."]}],
[["VMM_g",29], aj, {s: ["Christian", "was terrified", "by the ropes.", "Anthony", "was too,", "because", "Anthony", "hated", "ropes."]}],   
[["VMM_h",29], aj, {s: ["Christian", "was terrified", "by the ropes.", "The restraints", "did too,", "because", "the restraints", "looked", "scary."]}],
 
[["VMM_a",30], aj, {s: ["James", "interrupted", "the lecture.", "Ian", "did too,", "because", "Ian", "disagreed", "with the speaker."]}],
[["VMM_b",30], aj, {s: ["James", "interrupted", "the lecture.", "The speech", "was too,", "because", "the speech", "lasted", "too long."]}],
[["VMM_c",30], aj, {s: ["The lecture", "was interrupted", "by James.", "The speech", "was too,", "because", "the speech", "lasted", "too long."]}],
[["VMM_d",30], aj, {s: ["The lecture", "was interrupted", "by James.", "Ian", "did too,", "because", "Ian", "disagreed", "with the speaker."]}],    
[["VMM_e",30], aj, {s: ["The lecture", "discouraged", "James.", "The speech", "did too,", "because", "the speech", "discussed", "math."]}],
[["VMM_f",30], aj, {s: ["The lecture", "discouraged", "James.", "Ian", "was too,", "because", "Ian", "understood", "nothing."]}],
[["VMM_g",30], aj, {s: ["James", "was discouraged", "by the lecture.", "Ian", "was too,", "because", "Ian", "understood", "nothing."]}],   
[["VMM_h",30], aj, {s: ["James", "was discouraged", "by the lecture.", "The speech", "did too,", "because", "speech", "discussed", "math."]}],
 
[["VMM_a",31], aj, {s: ["Steve", "identified", "the flash.", "Brayden", "did too,", "because", "Brayden", "had", "the same camera."]}],
[["VMM_b",31], aj, {s: ["Steve", "identified", "the flash.", "The glow", "was too,", "because", "the glow", "came", "from the same place."]}],
[["VMM_c",31], aj, {s: ["The flash", "was identified", "by Steve.", "The glow", "was too,", "because", "the glow", "came", "from the same place."]}],
[["VMM_d",31], aj, {s: ["The flash", "was identified", "by Steve.", "Brayden", "did too,", "because", "Brayden", "had", "the same camera."]}],    
[["VMM_e",31], aj, {s: ["The flash", "scared", "Steve.", "The glow", "did too,", "because", "the glow", "looked", "creepy."]}],
[["VMM_f",31], aj, {s: ["The flash", "scared", "Steve.", "Brayden", "was too,", "because", "Brayden", "was", "still a little boy."]}],
[["VMM_g",31], aj, {s: ["Steve", "was scared", "by the flash.", "Brayden", "was too,", "because", "Brayden", "was", "still a little boy."]}],   
[["VMM_h",31], aj, {s: ["Steve", "was scared", "by the flash.", "The glow", "did too,", "because", "the glow", "looked", "creepy."]}],
 
[["VMM_a",32], aj, {s: ["Christopher", "concealed", "the jewel.", "Robert", "did too,", "because", "Robert", "wanted", "the gem."]}],
[["VMM_b",32], aj, {s: ["Christopher", "concealed", "the jewel.", "The ring", "was too,", "because", "the ring", "was", "valuable."]}],
[["VMM_c",32], aj, {s: ["The jewel", "was concealed", "by Christopher.", "The ring", "was too,", "because", "the ring", "was", "valuable."]}],
[["VMM_d",32], aj, {s: ["The jewel", "was concealed", "by Christopher.", "Robert", "did too,", "because", "Robert", "wanted", "the gem."]}],    
[["VMM_e",32], aj, {s: ["The jewel", "stunned", "Christopher.", "The ring", "did too,", "because", "the ring", "belonged", "to kings."]}],
[["VMM_f",32], aj, {s: ["The jewel", "stunned", "Christopher.", "Robert", "was too,", "because", "Robert", "studied", "gemstones."]}],
[["VMM_g",32], aj, {s: ["Christopher", "was stunned", "by the jewel.", "Robert", "was too,", "because", "Robert", "studied", "gemstones."]}],   
[["VMM_h",32], aj, {s: ["Christopher", "was stunned", "by the jewel.", "The ring", "did too,", "because", "the ring", "belonged", "to kings."]}],


[["EP_a",33], aj, {s: ["Daniel", "planned to", "send", "his mother", "a note."]}],
[["EP_b",33], aj, {s: ["Daniel", "planned to", "send", "a note", "to","his mother."]}],

[["EP_a",34], aj, {s: ["The pastor", "wanted to", "serve", "the visitors", "some food."]}],
[["EP_b",34], aj, {s: ["The pastor", "wanted to", "serve", "some food", "to the visitors."]}],

[["EP_a",35], aj, {s: ["The clerk", "said", "she", "would charge", "the businessman", "full price."]}],
[["EP_b",35], aj, {s: ["The clerk", "said", "she", "would charge", "full price", "to the businessman."]}],

[["EP_a",36], aj, {s: ["The representative", "said", "the company", "would", "ship the customers", "a replacement."]}],
[["EP_b",36], aj, {s: ["The representative", "said", "the company", "would ship", "a replacement", "to the customers."]}],

[["EP_a",37], aj, {s: ["Deanna", "usually", "feeds", "her dog", "a treat", "on Wednesdays."]}],
[["EP_b",37], aj, {s: ["Deanna", "usually", "feeds", "a treat", "to her dog","on Wednesdays."]}],

[["EP_a",38], aj, {s: ["Robin", "said", "he", "would", "lend the gambler", "some money."]}],
[["EP_b",38], aj, {s: ["Robin", "said", "he", "would", "lend some money", "to the gambler."]}],

[["EP_a",39], aj, {s: ["The board", "wanted to", "allocate us", "some funds."]}],
[["EP_b",39], aj, {s: ["The board", "wanted to", "allocate", "some funds", "to us."]}],

[["EP_a",40], aj, {s: ["Jason", "was told", "to repay", "the bank", "the money."]}],
[["EP_b",40], aj, {s: ["Jason", "was told", "to repay", "the money", "to the bank."]}],

[["EP_a",41], aj, {s: ["Reginald", "asked", "Georgette", "to wire", "him", "some money."]}],
[["EP_b",41], aj, {s: ["Reginald", "asked", "Georgette", "to wire", "some money", "to him."]}],

[["EP_a",42], aj, {s: ["The rescue worker", "needed to", "throw", "the stranded explorer", "the heavy rope."]}],
[["EP_b",42], aj, {s: ["The rescue worker", "needed to", "throw", "the heavy rope", "to the stranded explorer."]}],

[["EP_a",43], aj, {s: ["The casino owner", "wanted to", "deal the gamblers", "the fake card."]}],
[["EP_b",43], aj, {s: ["The casino owner", "wanted to", "deal the fake card", "to the gamblers."]}],

[["EP_a",44], aj, {s: ["The foundation", "planned to", "award the university", "a grant."]}],
[["EP_b",44], aj, {s: ["The foundation", "planned to", "award a grant", "to the university."]}],

[["f",45], aj, {s: ["This is the father", "that", "the son", "who", "betrayed", "him", "has", "always been", "very unfair."]}],
[["f",46], aj, {s: ["This is the boy", "that", "the newspaper", "reports", "that the cop", "who beat him up", "was leading", "the operation."]}],
[["f",47], aj, {s: ["This is the striker", "that I heard", "that", "the defender", "who punched", "in the face", "was kicked out of", "the game."]}],
[["f",48], aj, {s: ["This is the customer", "that", "the waiter", "who is famous", "for being unfriendly", "hit him."]}],
[["f",49], aj, {s: ["This is the gentleman", "that", "the girl", "who", "sells", "ripped carpets", "deceived her."]}],
[["f",50], aj, {s: ["This is the guy", "that", "the man", "who", "could be imprisoned", "for", "reckless driving", "ran him over."]}],
[["f",51], aj, {s: ["This is the clerk", "that", "the manager", "who", "downgraded him", "has always been", "really mean."]}],
[["f",52], aj, {s: ["This is the engineer", "that", "the manager", "who", "has always", "had", "trust", "in young people", "hired him."]}]  

];

