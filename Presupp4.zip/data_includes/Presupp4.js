var shuffleSequence = seq("setcounter","Consent","Demographics","Instructions", sepWith("sep", rshuffle(startsWith("Q"))),"Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        presentAsScale: true,
        leftComment: "Less natural",
        rightComment: "More natural",
        instructions: " ",
        randomOrder: false,
        hasCorrect: false,
        as: ["1","2","3","4","5","6","7"]
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];




/*
AcceptabilityJudgment flashes a sentence "s"
	s can have an html argument
It asks a text question "q"
And presents the subject with a set of answers "as"

Options:
instructions - Text instructions for answering, displayed below
hasCorrect - t/f is there a correct answer. If true, first answer is default correct, or can give integer index in "as" list starting at 0
asutoFirstChar - t/f select answer using first letter of answer
showNumbers - t/f number answers and participants can use number keys
randomOrder - t/f answers are displayed in random order
presentAsScale - t/f answers are displayed left to right - e.g. numbers. If 0-9, subjects can use number keys
leftComment - text for left end of scale if presented as scale
rightComment - text for right end of scale if presented as scale
timeout - time in ms subject has to answer (null if not specified)
*/








var items = [

["setcounter", "__SetCounter__", { }],

["Consent", "Form", {consentRequired: true, html: {include: "Consent.html" }} ],    
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions1.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions2.html" }} ],
["Instructions", "Form", {consentRequired: true, html: {include: "Instructions3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],

    
  
["sep", "Separator", {hideProgressBar: true, transfer: 500, normalMessage: " "}],
  
  
  
  
  




    
    
      
  
["Practice", "Message", {hideProgressBar: true, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">How nice of you.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {hideProgressBar: true, s: { html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/nice.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the pronunciation of the sentence seemed fairly typical. You probably selected a high number, like 5, 6, or 7.</p><p>Press any key to continue.</p>'}],  
  
  
["Practice", "Message", {hideProgressBar: true, consentRequired: false, html:'<center><p>The sentence you will hear is:</p><p><i><font size="4" color="#ed1300">If he calls, ask him to leave a message.</font></i></p><p>Press any key to hear the sentence.</p></center></font>', transfer: "keypress"}, "AcceptabilityJudgment", {s: {html: '<audio src="http://home.uchicago.edu/~jgeiger/sounds/EBsplices/message.wav" autoplay="autoplay"></audio><p>On a scale from 1 to 7, where 1 is the least natural and 7 is the most natural, how natural did you find the "melody" or "tune" of this sentence?</p>'}, q:" "}],
  
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: '<p>In this case, the sentence was not pronounced in a typical way. You probably selected a lower number, like 1, 2, or 3.</p><p>Press any key to continue.</p>'}],       
  
["Practice", Message, {hideProgressBar: true, consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],  
  







[["Q37NN", 217], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Julius strengthened Maya, and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q37NO", 218], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Emily strengthened Mia, and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q37RN", 219], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Alana captured Maya, and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q37RO", 220], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Delilah capturedMia , and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q37ON", 221], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Ben apprehended Maya, and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q37OO", 222], "Message", {hideProgressBar: true, html:'<center><p><font size="4">My kids played war with our neighbors\' in the backyard. </font></p><p><font size="4">Tim apprehended Mia, and Sid apprehended Mia, too.</font></p><p><font size="4">All of them ended up with bruises and scrapes afterwards. </font></p></center>', transfer: "click"}],
[["Q38NN", 223], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Matthew scared Alex, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q38NO", 224], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Alli scared Ivy, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q38RN", 225], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Smith released Alex, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q38RO", 226], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Sue released Ivy, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q38ON", 227], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Eric freed Alex, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q38OO", 228], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The troops broke into the prisoner of war camp. </font></p><p><font size="4">Hunter freed Ivy, and Terra freed Ivy, too.</font></p><p><font size="4">Many of the soldiers cried after gaining their freedom. </font></p></center>', transfer: "click"}],
[["Q39NN", 229], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Steph supported Jack, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q39NO", 230], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Ray supported Jake, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q39RN", 231], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Jerry dodged Jack, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q39RO", 232], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Christine dodged Jake, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q39ON", 233], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Ted evaded Jack, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q39OO", 234], "Message", {hideProgressBar: true, html:'<center><p><font size="4">Multiple contestants entered the boxing ring. </font></p><p><font size="4">Scott evaded Jake, and Mike evaded Jake, too.</font></p><p><font size="4">This slugfest would go down in history. </font></p></center>', transfer: "click"}],
[["Q40NN", 235], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Katherine surprised Helen, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q40NO", 236], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Melissa surprised Ryan, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q40RN", 237], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Hannah pacified Helen, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q40RO", 238], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Laura pacified Ryan, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q40ON", 239], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Peter quieted Helen, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q40OO", 240], "Message", {hideProgressBar: true, html:'<center><p><font size="4">At the theater, a sad part of the movie came. </font></p><p><font size="4">Harold quieted Ryan, and Danny quieted Ryan, too.</font></p><p><font size="4">The audience reacted to the scene pretty strongly!</font></p></center>', transfer: "click"}],
[["Q41NN", 241], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Harry taunted Ronald, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q41NO", 242], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Kevin taunted Kenneth, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q41RN", 243], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Gary soothed Ronald, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q41RO", 244], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Maxwell soothed Kenneth, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q41ON", 245], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Camille calmed Ronald, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q41OO", 246], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The New York team was losing to Los Angeles. </font></p><p><font size="4">Nancy calmed Kenneth, and Dillon calmed Kenneth, too.</font></p><p><font size="4">The scores were not very close at all. </font></p></center>', transfer: "click"}],
[["Q42NN", 247], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Edward contacted Michelle, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q42NO", 248], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Samson contacted Halley, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q42RN", 249], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Jason detested Michelle, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q42RO", 250], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Ashley detested Halley, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q42ON", 251], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Angela hated Michelle, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q42OO", 252], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The United Nations diplomats met. </font></p><p><font size="4">Pamela hated Halley, and Virginia hated Halley, too. </font></p><p><font size="4">Thankfully they were able to agree on something. </font></p></center>', transfer: "click"}],
[["Q43NN", 253], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Tyler telephoned Tony, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q43NO", 254], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Cooper telephoned Gavin, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q43RN", 255], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Zachary subdued Tony, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q43RO", 256], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Arianna subdued Gavin, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q43ON", 257], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Chase overpowered Tony, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q43OO", 258], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The superhero entered the bad guys\' hideout. </font></p><p><font size="4">Jace overpowered Gavin, and Adam overpowered Gavin, too.</font></p><p><font size="4">The world was safe, for today at least. </font></p></center>', transfer: "click"}],
[["Q44NN", 259], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Nathaniel telephoned Roman, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q44NO", 260], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Leonardo rescued Austin, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q44RN", 261], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Elias influenced Roman, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q44RO", 262], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Dominic influenced Austin, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q44ON", 263], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Cole manipulated Roman, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q44OO", 264], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The secret agents infiltrated the prison. </font></p><p><font size="4">Cal manipulated Austin, and Nolan manipulated Austin, too.</font></p><p><font size="4">The agency would reward the agents for accomplishing their mission. </font></p></center>', transfer: "click"}],
[["Q45NN", 265], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Joel represented Oscar, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q45NO", 266], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Finn represented Sarah, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q45RN", 267], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Elliot adored Oscar, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q45RO", 268], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Melanie adored Sarah, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q45ON", 269], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Alejandro loved Oscar, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q45OO", 270], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The Hollywood bigshots held exclusive mixers.</font></p><p><font size="4">Emmanuel loved Sarah, and Victor loved Sarah, too.</font></p><p><font size="4">One of those parties should be made into a movie!</font></p></center>', transfer: "click"}],
[["Q46NN", 271], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Faith concerned Ashe, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q46NO", 272], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Clare concerned Gale, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q46RN", 273], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Riley praised Ashe, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q46RO", 274], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Julie praised Gale, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q46ON", 275], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Val flattered Ashe, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q46OO", 276], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The actors gathered after the last performance. </font></p><p><font size="4">Graham flattered Gale, and Cora flattered Gale, too.</font></p><p><font size="4">The actors thought they had done an excellent job. </font></p></center>', transfer: "click"}],
[["Q47NN", 277], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Grant described Luna, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q47NO", 278], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Quinn described Gia, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q47RN", 279], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Hayden fooled Luna, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q47RO", 280], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Ruby fooled Gia, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q47ON", 281], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Kylie conned Luna, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q47OO", 282], "Message", {hideProgressBar: true, html:'<center><p><font size="4">The magicians brought their show into town Tuesday. </font></p><p><font size="4">Brian conned Gia, and Peyton conned Gia, too.</font></p><p><font size="4">The mayor won\'t let the magic show back into town ever again. </font></p></center>', transfer: "click"}],
[["Q48NN", 283], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Jasper controlled Eden, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],
[["Q48NO", 284], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">August controlled Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],
[["Q48RN", 285], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Athena approached Eden, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],
[["Q48RO", 286], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Maximus approached Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],
[["Q48ON", 287], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Ariel greeted Eden, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}],
[["Q48OO", 288], "Message", {hideProgressBar: true, html:'<center><p><font size="4">One of my old friends hosted a birthday party. </font></p><p><font size="4">Abraham greeted Jesse, and Dean greeted Jesse, too. </font></p><p><font size="4">It was nice to see everyone again after so long. </font></p></center>', transfer: "click"}]








  
  /*
  
Known file issues:

(1)

Male subject didn't record one sentence - Item 36, old verb old object (deaccented).
That means the following files weren't available:

36newVoldOdacM
36oldVoldOaccM
36oldVoldOdacM
36relVoldOdacM

They were all replaced with the file 36newVoldOaccM.wav and the sentence in the preview message controller was changed to match.
But, the code at the beginning of the line shows the condition they *should* be in, so these lines need to be subset out before analaysis.


(2)

In the files 15oldVnewOaccM.wav and 15oldVnewOdacM.wav, the male subject misread the first clause verb as
"admonished" instead of "astonished". The preview sentence was changed to match, but these trials should
be subset out before analysis because the verb does not license the correct (repeated) relation.

  
  

  
  
  */
  
  


















/*
Fillers/attention trials. The files zoo, apple, homework, movies, and contact should get high ratings.
buy, rainbow, room, eggs, and voice should get low ratings.
*/












/*comma*/


    
    




];










