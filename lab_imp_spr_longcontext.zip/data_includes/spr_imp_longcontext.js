var shuffleSequence = seq("intro","Practice", "presep", sepWith("sep", rshuffle(startsWith("imp"), startsWith("f"))),"exit");

//var counterOverride = 3;
var ds = DashedSentence;
var q = Question;



var defaults = [
    Separator,{ignoreFailure: true},
    q,{hasCorrect: true, randomOrder: true},
    ds,{mode: "self-paced reading", display: "dashed"},
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Click boxes to answer.",
        leftComment: "(Highly Unlikely)", rightComment: "(Highly Likely)"
    },
    "Message", {
        hideProgressBar: true
    }
   
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],

["sep", Separator, { }],

["Practice", ds, {s: "This is just a practice sentence to get you used to the method of presentation."}, q, {q:"Was that sentence easy?", as: ["Yes","No"] }, Separator, { }],
                       
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all there is to it! Let's try some practice sentences more like the ones you'll be seeing in the experiment:"]
                           ]}],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Chris and Patt had been tirelessly rehearsing for their Broadway musical audition all week."],
                          
                          ]},
                    ds, { s:  "After so many rehearsals, Patt sang herself hoarse."} , "Question", {q: "What were Chris and Patt rehearsing for? ", as: ["An audition","An opera", "A recital"]}, Separator, { }],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Upon receiving a job offer from a company based in New york, Mandy was debating whether she was willing to relocate to such a big city."],
                          
                          ]},
                    ds, { s:  "Her friend Lucy told her that she had loved living in New York."} , "Question", {q: "Why is Mandy considering moving to New York?", as: ["Work","Family","Friends"]}, Separator, { }],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "In preparation for his trip to Myanmar, Preston went to the bookstore to buy a couple of travel guides."],
                          
                          ]},
                    ds, { s:  "Preston went back home with more guides than he would be able to read before his trip."} , "Question", {q: "Where is Preston travelling?", as: ["Myanmar","Laos", "Cambodia"]}, Separator, { }],
                               
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. REMEMBER: it will last approximately 30 minutes, and will require your full attention throughout that period. Thank you for your help!"]
                           ]}],
                           
["presep", Separator, { transfer: 3000, normalMessage: "Get your hands in position, and get ready to begin!" }],


[ [ "impr_a", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 10 patients were currently waitlisted."} , "Question", {q: "What agency were the nurse and the doctor filling forms for?", as: ["FDA", "NSA", "FBI"]}],
 
[ [ "impr_b", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 100 patients were currently waitlisted."} , "Question", {q: "What agency were the nurse and the doctor filling forms for?", as: ["FDA", "NSA", "FBI"]}],

[ [ "impr_c", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The doctor and the nurse were filling out the FDA forms for their most recent clinical trial. The doctor told the nurse that they needed to report the number of patients that ended up in the waitlist to the FDA, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 1,000 patients were currently waitlisted."} , "Question", {q: "What agency were the nurse and the doctor filling forms for?", as: ["FDA", "NSA", "FBI"]}],

[ [ "impr_d", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 10 patients were currently waitlisted."} , "Question", {q: "Where were the doctor and the nurse heading?", as: ["Home", "OR", "Conference room"]}],
 
[ [ "impr_e", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 100 patients were currently waitlisted."} , "Question", {q: "Where were the doctor and the nurse heading?", as: ["Home", "OR", "Conference room"]}],

[ [ "impr_f", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While leaving the hospital on the way home, the doctor and the nurse were chatting about their latest clinical trial. The doctor told the nurse that she was thinking of piloting a new study with some of the patients in the waitlist, so she asked the nurse how many patients were currently waitlisted."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 1,000 patients were currently waitlisted."} , "Question", {q: "Where were the doctor and the nurse heading?", as: ["Home", "OR", "Conference room"]}],
                    
[ [ "impr_a", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 200 dollars less per year."} , "Question", {q: "How long had Peet been living paycheck to pay check?", as: ["One year", "Two years", "Three years"]}],
   
                    
[ [ "impr_b", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 2,000 dollars less per year."} , "Question", {q: "How long had Peet been living paycheck to pay check?", as: ["One year", "Two years", "Three years"]}], 
                                       
[ [ "impr_c", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo cuts, Peet worried very much. He immediately called his boss and explained to him that he had been living paycheck to paycheck for the past year, so he told his boss that he absolutely needed to know what his yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 20,000 dollars less per year."} , "Question", {q: "How long had Peet been living paycheck to pay check?", as: ["One year", "Two years", "Three years"]}],  
                    
[ [ "impr_d", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 200 dollars less per year."} , "Question", {q: "When was Peet going to work for the new company?", as: ["Two months", "Six months", "One year"]}],
   
                    
[ [ "impr_e", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 2,000 dollars less per year."} , "Question", {q: "When was Peet going to work for the new company?", as: ["Two months", "Six months", "One year"]}], 
                                       
[ [ "impr_f", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During his farewell party at the office, Peet's boss mentioned to him that the agency had announced cuts starting the coming month. Peet responded that thankfully the cuts would barely affect him, as he was about to start working for a different company, but he said that he was sort of curious about what the yearly salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 20,000 dollars less per year."} , "Question", {q: "When was Peet going to work for the new company?", as: ["Two months", "Six months", "One year"]}],  
                  
[ [ "impr_a", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} , "Question", {q: "What did Tom wanted to buy besides a toaster?", as: ["Suitcase","Microwave","Kettle"]}],
                    
                  
[ [ "impr_b", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} , "Question", {q: "What did Tom wanted to buy besides a toaster?", as: ["Suitcase","Microwave","Kettle"]}],
                    
                  
[ [ "impr_c", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom told Betsy that he would like to do the same, but he had to make sure that after buying the toaster, he would have sufficient points left to also buy a suitcase, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} , "Question", {q: "What did Tom wanted to buy besides a toaster?", as: ["Suitcase","Microwave","Kettle"]}],
                    
                  
[ [ "impr_d", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} , "Question", {q: "How many times did Tom buy something with credit card points?", as: ["Never","Once","Twice"]}],
                  
[ [ "impr_e", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} , "Question", {q: "How many times did Tom buy something with credit card points?", as: ["Never","Once","Twice"]}],
                                
[ [ "impr_f", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. When Betsy mentioned this in conversation, Tom replied that he had never done a purchase using credit card points before, and wanted to get a sense of what kind of deals were available, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} , "Question", {q: "How many times did Tom buy something with credit card points?", as: ["Never","Once","Twice"]}],
                  
[ [ "impr_a", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} , "Question", {q: "When did the inspection take place?", as: ["Morning", "Afternoon", "Evening"]}],
                 
[ [ "impr_b", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 500 gallons on a daily basis."} , "Question", {q: "When did the inspection take place?", as: ["Morning", "Afternoon", "Evening"]}],
                  
[ [ "impr_c", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "One morning, Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen told the farmer that the new regulations about milk production were stricter than ever, and that he now needed to report to the Department of Agriculture how many gallons of milk suitable for human consumption the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 5,000 gallons on a daily basis."} , "Question", {q: "When did the inspection take place?", as: ["Morning", "Afternoon", "Evening"]}],
                  
[ [ "impr_d", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 50 gallons on a daily basis."} , "Question", {q: "For how long did Stephen and the farmer know each other?", as: ["Ten years", "Twenty years", "Five years"]}],                                                            
                  
[ [ "impr_e", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 500 gallons on a daily basis."} , "Question", {q: "For how long did Stephen and the farmer know each other?", as: ["Ten years", "Twenty years", "Five years"]}],                                                            
                  
[ [ "impr_f", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. After the inspection, Stephen and the farmer, who had known each other for 10 years, were chatting while the farmer was taking care of one of his cows. The farmer complained to Stephen that it was getting harder and harder to make a living off of the farm's sales. While the farmer was giving the cow its medicine, Stephen asked how many gallons of milk the farm was currently producing."],
                          
                          ]},
                    ds, { s:  "The farmer replied that he was selling 5,000 gallons on a daily basis."} , "Question", {q: "For how long did Stephen and the farmer know each other?", as: ["Ten years", "Twenty years", "Five years"]}], 
                                                                                                    
[ [ "impr_a", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} , "Question", {q: "Who did Mary have to report the number of subscribers to?", as: ["Boss ", "Co-worker", "Employee"]}],
                                                                                                    
[ [ "impr_b", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} , "Question", {q: "Who did Mary have to report the number of subscribers to?", as: ["Boss ", "Co-worker", "Employee"]}],

                                                                                                    
[ [ "impr_c", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} , "Question", {q: "Who did Mary have to report the number of subscribers to?", as: ["Boss ", "Co-worker", "Employee"]}],
                                                                                                    
[ [ "impr_d", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} , "Question", {q: "What was Mary thinking of doing? ", as: ["Cancelling the newsletter", "Launch a sales campaign", "Charge for all shipments"]}],
                                                                                                 
[ [ "impr_e", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} , "Question", {q: "What was Mary thinking of doing? ", as: ["Cancelling the newsletter", "Launch a sales campaign", "Charge for all shipments"]}],
                                                                                                    
[ [ "impr_f", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Mary recently became the new PR manager of a successful e-shop. Mary told her assistant Jonathan that she needed to include specific statistics in the report that she was preparing for her boss, so she asked him to look up how many subscribers they currently had to their monthly newsletter."],
                          
                          ]},
                    ds, { s:  "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} , "Question", {q: "What was Mary thinking of doing? ", as: ["Cancelling the newsletter", "Launch a sales campaign", "Charge for all shipments"]}],
                                                                                                    
[ [ "impr_a", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."} , "Question", {q: "Which section did Erika write the wrong numbers in?", as: ["Six", "Five", "Seven"]}],
                                                                                                    
[ [ "impr_b", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."} , "Question", {q: "Which section did Erika write the wrong numbers in?", as: ["Six", "Five", "Seven"]}],
                                                                                                                    
[ [ "impr_c", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After she filed her taxes, Erika realized that she wrote the wrong numbers in section six and reported a gross annual income that was lower than her actual income. When she realized this, she called the IRS to amend the mistake and to ask how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."} , "Question", {q: "Which section did Erika write the wrong numbers in?", as: ["Six", "Five", "Seven"]}],
                                                                                                                    
[ [ "impr_d", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 400 dollars to the federal government."} , "Question", {q: "What taxes did Erika forgot to pay?", as: ["Estimated Federal Taxes", "Local Taxes", "Estimated State Taxes"]}],
                                                                                                                    
[ [ "impr_e", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 4,000 dollars to the federal government."} , "Question", {q: "What taxes did Erika forgot to pay?", as: ["Estimated Federal Taxes", "Local Taxes", "Estimated State Taxes"]}],
                                                                                                                                                     
[ [ "impr_f", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erika was talking to one of her friends, who was an IRS representative. The friend was talking about how a lot of people forget to pay their estimated federal taxes, and Erika realized she too forgot to pay her estimated federal taxes. In order to get an idea of how much she owed, she asked her friend how much money she should pay."],
                          
                          ]},
                    ds, { s:  "The IRS representative said that Erika owed 40,000 dollars to the federal government."} , "Question", {q: "What taxes did Erika forgot to pay?", as: ["Estimated Federal Taxes", "Local Taxes", "Estimated State Taxes"]}],
                                                                                                    
[ [ "impr_a", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 900 people had submitted their answers."} , "Question", {q: "What was Ryan applying for?", as: ["Corporate sponsorship", "Grant funding", "Ballot Access"]}],
                                                                                                    
[ [ "impr_b", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 9,000 people had submitted their answers."} , "Question", {q: "What was Ryan applying for?", as: ["Corporate sponsorship", "Grant funding", "Ballot Access"]}],
                                                                                                                                      
[ [ "impr_c", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was filling out a form to apply for corporate sponsorship for the presidential campaign he worked for. He had heard from his co-workers that applied for similar sponsorships that the most important part of the application was the poll numbers. Ryan wanted to make sure his numbers for the presidential poll were as current as possible, so he told his chief researcher that the poll numbers were a crucial part of his application and asked him how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 90,000 people had submitted their answers."} , "Question", {q: "What was Ryan applying for?", as: ["Corporate sponsorship", "Grant funding", "Ballot Access"]}],
                                                                                                                                      
[ [ "impr_d", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 900 people had submitted their answers."} , "Question", {q: "Who was Ryan talking to?", as: ["Chief researcher", "Personal assistant", "Statistician"]}],
                                                                                                                                      
[ [ "impr_e", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 9,000 people had submitted their answers."} , "Question", {q: "Who was Ryan talking to?", as: ["Chief researcher", "Personal assistant", "Statistician"]}],
                                                                                                                                             
[ [ "impr_f", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and was discussing with his chief researcher how many responses they needed in order to obtain representative results. They both agreed that they needed at least twice as many participants. To get an idea of how long it would take to reach that number, Ryan asked his chief researcher how many responses they had already received."],
                          
                          ]},
                    ds, { s:  "His chief researcher told him that 90,000 people had submitted their answers."} , "Question", {q: "Who was Ryan talking to?", as: ["Chief researcher", "Personal assistant", "Statistician"]}],
                                                                                                    
[ [ "impr_a", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 60 dollars the last time she played. "} , "Question", {q: "What did Connor ask Abigayle at the beginning of the interview?", as: ["Permission to record the meeting", "Sign a confidentiality agreement", "Abigayle's age"]}],
                                                                                                     
[ [ "impr_b", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 600 dollars the last time she played. "} , "Question", {q: "What did Connor ask Abigayle at the beginning of the interview?", as: ["Permission to record the meeting", "Sign a confidentiality agreement", "Abigayle's age"]}],
                                                                                                         
[ [ "impr_c", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was a Jeopardy fan and was currently in the process of writing a book about the history of the show. In order to document the show's most recent history, he contacted Abigayle, a retired Jeopardy champion to interview her for the book. When they met, Connor asked Abigayle permission to record the interview and proceeded with the questions. Among many other things, he asked her how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 6,000 dollars the last time she played. "} , "Question", {q: "What did Connor ask Abigayle at the beginning of the interview?", as: ["Permission to record the meeting", "Sign a confidentiality agreement", "Abigayle's age"]}],
                                                                                                         
[ [ "impr_d", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 60 dollars the last time she played. "} , "Question", {q: "What meal were Connor and Abigayle having while having this conversation?", as: ["Brunch", "Lunch", "Dinner"]}],
                                                                                                         
[ [ "impr_e", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 600 dollars the last time she played. "} , "Question", {q: "What meal were Connor and Abigayle having while having this conversation?", as: ["Brunch", "Lunch", "Dinner"]}],
                                                                                                                
[ [ "impr_f", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Connor was having brunch with Abigayle, a retired Jeopardy champion, and they were talking about her experience in the show. Abigayle mentioned that she was pretty good at the game but that her margins of victory varied a lot from show to show. Connor asked her what her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s:  "Abigayle said that she had won by 6,000 dollars the last time she played. "} , "Question", {q: "What meal were Connor and Abigayle having while having this conversation?", as: ["Brunch", "Lunch", "Dinner"]}],
                                                                                                    
[ [ "impr_a", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 70 people had voted there that day."} , "Question", {q: "What was Elsa worried about?", as: ["Careless mistakes", "Electoral fraud", "Time"]}],
                                                                                                    
[ [ "impr_b", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 700 people had voted there that day."} , "Question", {q: "What was Elsa worried about?", as: ["Careless mistakes", "Electoral fraud", "Time"]}],
                                                                                                                     
[ [ "impr_c", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she told everybody that they should be extra careful because she wanted to avoid any careless mistakes that would end up delaying the recount. At that point, Elsa turned to the precinct captain, gave him a very serious look and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 7,000 people had voted there that day."} , "Question", {q: "What was Elsa worried about?", as: ["Careless mistakes", "Electoral fraud", "Time"]}],
                                                                                                                     
[ [ "impr_d", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 70 people had voted there that day."} , "Question", {q: " How was Elsa described as?", as: ["Noisy", "Politically involved", "Stubborn"]}],
                                                                                                                     
[ [ "impr_e", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 700 people had voted there that day."} , "Question", {q: " How was Elsa described as?", as: ["Noisy", "Politically involved", "Stubborn"]}],
                                                                                                                         
[ [ "impr_f", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elsa went to her precinct's caucus to cast her vote at the very end of the day. Elsa had always been something of a nosy neighbor and despite seeing that the precinct captain and his team were incredibly busy working on tabulating the votes, she still went ahead and asked him how many people had cast votes in the caucus in that precinct that day."],
                          
                          ]},
                    ds, { s:  "The precinct captain said that 7,000 people had voted there that day."} , "Question", {q: " How was Elsa described as?", as: ["Noisy", "Politically involved", "Stubborn"]}],
                                                                                                    
[ [ "impr_a", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 10 pounds at the time."} , "Question", {q: "What was Carter doing at the police station?", as: ["Provide a written statement", "Wait for his lawyer", "Work as a clerk"]}],
                                                                                                    
[ [ "impr_b", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 100 pounds at the time."} , "Question", {q: "What was Carter doing at the police station?", as: ["Provide a written statement", "Wait for his lawyer", "Work as a clerk"]}],
                                                                                                        
[ [ "impr_c", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, after receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. The night before the raid, Carter went to the police station to provide a written statement. Among other questions, the police asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 1,000 pounds at the time."} , "Question", {q: "What was Carter doing at the police station?", as: ["Provide a written statement", "Wait for his lawyer", "Work as a clerk"]}],
                                                                                                        
[ [ "impr_d", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 10 pounds at the time."} , "Question", {q: "What was Carter planning on doing?", as: ["Move out of his apartment", "Report his neighbor to the police", "Sell cocaine"]}],
                                                                                                        
[ [ "impr_e", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 100 pounds at the time."} , "Question", {q: "What was Carter planning on doing?", as: ["Move out of his apartment", "Report his neighbor to the police", "Sell cocaine"]}],
                                                                                                                      
[ [ "impr_f", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", " Carter told his girlfriend that he was pretty set on moving out of his apartment, because he thought his neighbor was a drug dealer. When his girlfriend asked Carter why he thought that, he said that two days ago he had seen a lot of cocaine in his apartment. Surprised, Carter's girlfriend asked him how much cocaine his neighbor had on the day that he was in his apartment."],
                          
                          ]},
                    ds, { s:  "Carter said that his neighbor had 1,000 pounds at the time."} , "Question", {q: "What was Carter planning on doing?", as: ["Move out of his apartment", "Report his neighbor to the police", "Sell cocaine"]}],
                                                                                                    
[ [ "impr_a", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown. "],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."} , "Question", {q: "What was Emily excited about?", as: ["Participating in the national model rocket championship ", "Getting a scholarship to attend MIT", "Being the first girl to win the contest"]}],
                                                                                                    
[ [ "impr_b", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown. "],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."} , "Question", {q: "What was Emily excited about?", as: ["Participating in the national model rocket championship ", "Getting a scholarship to attend MIT", "Being the first girl to win the contest"]}],
                                                                                                      
[ [ "impr_c", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Emily won the state model rocket contest, she was approached by the organizer of the national model rocket championship. He told her that even though he had not been able to personally see her rocket fly that day, her rocket's performance might be sufficient for her to qualify for the national championship, which made Emily very excited. In order to make sure, he asked her how high her rocket had flown. "],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."} , "Question", {q: "What was Emily excited about?", as: ["Participating in the national model rocket championship ", "Getting a scholarship to attend MIT", "Being the first girl to win the contest"]}],
                                                                                                      
[ [ "impr_d", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 80 feet before falling back to the ground."} , "Question", {q: "What was Jonathan doing while Emily launched her model rocket?", as: ["Look at his cellphone", "Read a book", "Listen to music"]}],
                                                                                                      
[ [ "impr_e", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 800 feet before falling back to the ground."} , "Question", {q: "What was Jonathan doing while Emily launched her model rocket?", as: ["Look at his cellphone", "Read a book", "Listen to music"]}],
                                                                                                                 
[ [ "impr_f", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily enjoyed going to the field to launch her model rocket every weekend. Emily's older brother, Jonathan, hated it, because their parents forced him to go with her and wait until she was done. Emily could tell her brother was really bored when he asked, without even lifting his eyes from his cellphone, how high her rocket had flown."],
                          
                          ]},
                    ds, { s:  "Emily said that the rocket flew 8,000 feet before falling back to the ground."} , "Question", {q: "What was Jonathan doing while Emily launched her model rocket?", as: ["Look at his cellphone", "Read a book", "Listen to music"]}],
                                                                                                    
[ [ "impr_a", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 900 gallons had been spilled."} , "Question", {q: "Who did the project manager receive a letter from?", as: ["Boss", "Employee", "Government"]}],
                                                                                                    
[ [ "impr_b", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 9,000 gallons had been spilled."} , "Question", {q: "Who did the project manager receive a letter from?", as: ["Boss", "Employee", "Government"]}],
                                                                                                       
[ [ "impr_c", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager had just gotten a letter from his boss informing him that the company was going to be fined by the Government per gallon of oil spilled in the latest oil spill in the Gulf of Mexico. Thinking of how the losses would impact the company, which was already running on a tight budget, the project manager told the head engineer about his worries and told him that they needed to do some damage control. In order to anticipate how much they would have to pay, the project manager asked the head engineer to check their oil tanks exhaustively and report to him how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 90,000 gallons had been spilled."} , "Question", {q: "Who did the project manager receive a letter from?", as: ["Boss", "Employee", "Government"]}],
                                                                                                       
[ [ "impr_d", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 900 gallons had been spilled."} , "Question", {q: "Where did the oil spill take place?", as: ["Gulf of Mexico", "Coast of Brazil", "Caspian Sea"]}],
                                                                                                       
[ [ "impr_e", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 9,000 gallons had been spilled."} , "Question", {q: "Where did the oil spill take place?", as: ["Gulf of Mexico", "Coast of Brazil", "Caspian Sea"]}],
                                                                                                           
[ [ "impr_f", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After seeing the news on the TV, the head engineer of an oil platform in the Gulf of Mexico saw the project manager in the break room. He mentioned to the project manager that their main competitor in the area had just suffered an accidental oil spill. Wondering how big the spill was, the project manager asked how many gallons of oil had been released into the water."],
                          
                          ]},
                    ds, { s:  "The engineer said that 90,000 gallons had been spilled."} , "Question", {q: "Where did the oil spill take place?", as: ["Gulf of Mexico", "Coast of Brazil", "Caspian Sea"]}],
                                                                                                   
[ [ "impr_a", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 500 rows not including headers."} , "Question", {q: "With what accuracy was Erin hoping to predict the software's running time?", as: ["Milliseconds", "Seconds", "Nanoseconds"]}],
                                                                                                   
[ [ "impr_b", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 5,000 rows not including headers."} , "Question", {q: "With what accuracy was Erin hoping to predict the software's running time?", as: ["Milliseconds", "Seconds", "Nanoseconds"]}],
                                                                                                                          
[ [ "impr_c", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "For her computational linguistics final project, Erin was working on a program to process text files as quickly as possible. Erin was telling her professor that she was trying to predict down to the millisecond how long it would take for the program to process each of the assigned text files, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 50,000 rows not including headers."} , "Question", {q: "With what accuracy was Erin hoping to predict the software's running time?", as: ["Milliseconds", "Seconds", "Nanoseconds"]}],
                                                                                                                          
[ [ "impr_d", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 500 rows not including headers."} , "Question", {q: "What did Erin want to do during the break?", as: ["Get lunch", "Get coffee", "Go to the bathroom"]}],
                                                                                                                          
[ [ "impr_e", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 5,000 rows not including headers."} , "Question", {q: "What did Erin want to do during the break?", as: ["Get lunch", "Get coffee", "Go to the bathroom"]}],
                                                                                                                             
[ [ "impr_f", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was in the computer lab testing the software she had written for her computation linguistics final project. When the professor stopped by the lab, Erin told her she was not sure she had enough time to go get lunch and be back before the program finished processing the assigned text files, since she didn't know how big the files were, so she asked the professor how many lines each of the files contained."],
                          
                          ]},
                    ds, { s:  "The professor answered that the files contained 50,000 rows not including headers."} , "Question", {q: "What did Erin want to do during the break?", as: ["Get lunch", "Get coffee", "Go to the bathroom"]}],
                                                                                                   
[ [ "impr_a", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 200 was the age of the artifact."} , "Question", {q: "Who did Noah asked for help?", as: ["Archeologists", "Paleontologists", "Primatologists"]}],
                                                                                                                                                                                                                                   
[ [ "impr_b", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 2,000 was the age of the artifact."} , "Question", {q: "Who did Noah asked for help?", as: ["Archeologists", "Paleontologists", "Primatologists"]}],
                                                                                                                                
[ [ "impr_c", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was interning at the local History museum and was filling out the identification form of the new artifact found at a recent excavation. Noah couldn't figure out the age of the old artifact, but he was confident that the archeologists working at the museum could, so he went to the archeology lab and told the archeologists that artifact's file was almost complete, but that he had been unable to date it, so he needed help determining how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 20,000 was the age of the artifact."} , "Question", {q: "Who did Noah asked for help?", as: ["Archeologists", "Paleontologists", "Primatologists"]}],
                                                                                                                                
[ [ "impr_d", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 200 was the age of the artifact."} , "Question", {q: "To whom was the free tour of the museum addressed?", as: ["Children and adults", "Senior citizens", "Teenagers"]}],
                                                                                                                                
[ [ "impr_e", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 2,000 was the age of the artifact."} , "Question", {q: "To whom was the free tour of the museum addressed?", as: ["Children and adults", "Senior citizens", "Teenagers"]}],
                                                                                                                                         
[ [ "impr_f", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah was at his local museum open house, where one of the staff archeologists was giving a free tour of the museum for both adults and children. During the tour, one of the kids in the audience was intrigued by an old artifact and asked the archeologist how old it was."],
                          
                          ]},
                    ds, { s:  "The scientist said that 20,000 was the age of the artifact."} , "Question", {q: "To whom was the free tour of the museum addressed?", as: ["Children and adults", "Senior citizens", "Teenagers"]}],
                                                                                         
[ [ "impr_a", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 30 degrees was the target temperature."} , "Question", {q: "What could happen if Julie overheats her sample?", as: ["Explosion", "Release of deadly gas", "Melt materials"]}],
                                                                                                   
[ [ "impr_b", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 300 degrees was the target temperature."} , "Question", {q: "What could happen if Julie overheats her sample?", as: ["Explosion", "Release of deadly gas", "Melt materials"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
                                                                                                   
[ [ "impr_c", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "It was Julie's first day in the lab, and she knew the materials she was working with were extremely sensitive. She was mostly nervous about overheating them, since that could trigger an explosion. She mentioned her concern to her teacher, and asked her to please repeat how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 3,000 degrees was the target temperature."} , "Question", {q: "What could happen if Julie overheats her sample?", as: ["Explosion", "Release of deadly gas", "Melt materials"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
[ [ "impr_d", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 30 degrees was the target temperature."} , "Question", {q: "Who suggested that Julie heat her sample?", as: ["Supervisor", "Friend", "Co-Worker"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
[ [ "impr_e", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 300 degrees was the target temperature."} , "Question", {q: "Who suggested that Julie heat her sample?", as: ["Supervisor", "Friend", "Co-Worker"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             
[ [ "impr_f", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was taking her first chemistry class in high school, and the teacher started the class playing a video that showed a series of funny and spectacular chemical reactions. Julie was especially impressed with the last reaction in the video and wanted to know more about it so she raised her hand and asked the teacher how much the sample needed to be heated."],
                          
                          ]},
                    ds, { s:  "Her teacher said that 3,000 degrees was the target temperature."} , "Question", {q: "Who suggested that Julie heat her sample?", as: ["Supervisor", "Friend", "Co-Worker"]}],
                                                                           
[ [ "impr_a", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 700 clicks all within the United States. "} , "Question", {q: "What division was Susan the head of?", as: ["Marketing", "Data analysis", "Accounting"]}],
                                                                                                   
[ [ "impr_b", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States. "} , "Question", {q: "What division was Susan the head of?", as: ["Marketing", "Data analysis", "Accounting"]}],
                                                                                                         
[ [ "impr_c", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of her company. She was working on a presentation about the revenue generated by their website's publicity banners. Susan wanted to present a graph showing the increase in number of clicks received by the banners over the last six months, so she called Andrea at the data analysis department to tell her that she needed the most updated data for her presentation and that in particular, she needed to know how many clicks the publicity banners had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States. "} , "Question", {q: "What division was Susan the head of?", as: ["Marketing", "Data analysis", "Accounting"]}],
                                                                                                         
[ [ "impr_d", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 700 clicks all within the United States. "} , "Question", {q: "What department was Andrea working on?", as: ["Data analysis", "Marketing", "Sales"]}],
                                                                                                         
[ [ "impr_e", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 7,000 clicks all within the United States. "} , "Question", {q: "What department was Andrea working on?", as: ["Data analysis", "Marketing", "Sales"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
[ [ "impr_f", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan was the head of the marketing division of an online shop that sold clothes for both men and women. Susan was having lunch with Andrea, from the data analysis department, and they were talking about a recent spike in the clicks on the publicity banners on the women's section of the website. Susan told Andrea that she was wondering if the number of clicks were comparable to the men's section of the website, so she asked Andrea if she knew how many clicks the publicity banners of the men's section had received over the past month."],
                          
                          ]},
                    ds, { s:  "Andrea replied that the system had recorded 70,000 clicks all within the United States. "} , "Question", {q: "What department was Andrea working on?", as: ["Data analysis", "Marketing", "Sales"]}],
                                                                                                   
[ [ "impr_a", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 20 chairs in the main room."} , "Question", {q: "What did Jordan need to buy for the concert?", as: ["Chairs", "Speakers", "Water Bottles"]}],
                                                                                                   
[ [ "impr_b", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 200 chairs in the main room."} , "Question", {q: "What did Jordan need to buy for the concert?", as: ["Chairs", "Speakers", "Water Bottles"]}],
                                                                                                                  
[ [ "impr_c", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He still needed to order chairs, and the concert was dangerously close to being over budget due to the high demands of the band. He told Rachel that he wanted to make sure he didn't spend more on chairs than he absolutely needed to, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."} , "Question", {q: "What did Jordan need to buy for the concert?", as: ["Chairs", "Speakers", "Water Bottles"]}],
                                                                                                                  
[ [ "impr_d", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 20 chairs in the main room."} , "Question", {q: "What was Jordan worried about?", as: ["Not ordering enough chairs", "Ordering too many chairs", "Printing enough concert programs"]}],
                                                                                                                  
[ [ "impr_e", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 200 chairs in the main room."} , "Question", {q: "What was Jordan worried about?", as: ["Not ordering enough chairs", "Ordering too many chairs", "Printing enough concert programs"]}],
                                                                                                                    
[ [ "impr_f", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jordan was in charge of concert set-up. He was not sure whether he'd need to order extra chairs because he didn't know how many tickets had been actually sold. He told Rachel that he wanted to make sure that there were enough chairs that night for everyone, so he asked her how many tickets she sold, so he would know how many chairs to set up."],
                          
                          ]},
                    ds, { s:  "Rachel responded that they needed to set up 2,000 chairs in the main room."} , "Question", {q: "What was Jordan worried about?", as: ["Not ordering enough chairs", "Ordering too many chairs", "Printing enough concert programs"]}],
                                                                                                   
[ [ "impr_a", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} , "Question", {q: "What was Clara's job?", as: ["Room decorator", "Site manager", "Event coordinator"]}],
                                                                                                   
[ [ "impr_b", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} , "Question", {q: "What was Clara's job?", as: ["Room decorator", "Site manager", "Event coordinator"]}],
                                                                                                                           
[ [ "impr_c", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was the room decorator for Mr. Hilton's new hotel. Her team was working on figuring out how much money they could spend on each of the rooms in the hotel. In order to calculate an accurate budget, Clara called Mr. Hilton to tell him that they were about to finalize the budget and that in order to ensure they would have sufficient money for each room, she needed him to please confirm the amount of rooms that he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} , "Question", {q: "What was Clara's job?", as: ["Room decorator", "Site manager", "Event coordinator"]}],
                                                                                                                           
[ [ "impr_d", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} , "Question", {q: "Where did this conversation take place?", as: ["Hamptons", "Hollywood ", "Manhattan"]}],
                                                                                                                           
[ [ "impr_e", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} , "Question", {q: "Where did this conversation take place?", as: ["Hamptons", "Hollywood ", "Manhattan"]}],
                                                                                                                                               
[ [ "impr_f", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Clara was having cocktails with Mr. Hilton and some friends at a party in the Hamptons. Mr. Hilton mentioned to the group that he was thinking of building a new hotel in Dubai. Surprised, Clara asked him how many rooms he'd like the new hotel to have."],
                          
                          ]},
                    ds, { s:  "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} , "Question", {q: "Where did this conversation take place?", as: ["Hamptons", "Hollywood ", "Manhattan"]}],
                                                                                                   
[ [ "impr_a", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 80 Democrats would attend the event. "} , "Question", {q: "What was Julian ordering for the fundraiser?", as: ["Food", "Chairs", "Balloons"]}],
                                                                                                   
[ [ "impr_b", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 800 Democrats would attend the event. "} , "Question", {q: "What was Julian ordering for the fundraiser?", as: ["Food", "Chairs", "Balloons"]}],
                                                                                                        
[ [ "impr_c", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was volunteering at a fundraiser for Bernie Sanders' campaign, and he was working on a very tight budget. Julian had been in charge of ordering the personalized campaign gifts that each of the donors would receive at the end of the event. The campaign coordinator asked Julian to double-check that there was a gift for each of the event attendees. In order to make sure, Julian asked the coordinator to tell him again how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 8,000 Democrats would attend the event. "} , "Question", {q: "What was Julian ordering for the fundraiser?", as: ["Food", "Chairs", "Balloons"]}],
                                                                                                        
[ [ "impr_d", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 80 Democrats would attend the event. "} , "Question", {q: "Where did this conversation take place?", as: ["Over the phone", "Outside a mall", "In a Bernie Sanders local office"]}],
                                                                                                        
[ [ "impr_e", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 800 Democrats would attend the event. "} , "Question", {q: "Where did this conversation take place?", as: ["Over the phone", "Outside a mall", "In a Bernie Sanders local office"]}],
                                                                                                          
[ [ "impr_f", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian was a declared Bernie Sanders supporter and got very excited when one day he received a phone call from a local Bernie Sanders' campaign coordinator informing him of a fundraising event in the area. Wondering how big the event would be, Julian asked her how many attendees they were expecting."],
                          
                          ]},
                    ds, { s:  "The coordinator said that 8,000 Democrats would attend the event. "} , "Question", {q: "Where did this conversation take place?", as: ["Over the phone", "Outside a mall", "In a Bernie Sanders local office"]}],
                                                                                                   
[ [ "impr_a", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 60 stamps at a very good price."} , "Question", {q: "Where did Peet buy the stamps?", as: ["Online ", "Antique shop", "Stamp fair"]}],
                                                                                                   
[ [ "impr_b", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 600 stamps at a very good price."} , "Question", {q: "Where did Peet buy the stamps?", as: ["Online ", "Antique shop", "Stamp fair"]}],
                                                                                                                          
[ [ "impr_c", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet, an avid stamp collector, told Rowan that he was very happy because he had managed to buy a series of very valuable old stamps after tracking and bidding for them on ebay for two days. Intrigued, Rowan asked Peet how many stamps there were in the series and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 6,000 stamps at a very good price."} , "Question", {q: "Where did Peet buy the stamps?", as: ["Online ", "Antique shop", "Stamp fair"]}],
                                                                                                                          
[ [ "impr_d", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 60 stamps at a very good price."} , "Question", {q: "What was the box made of? ", as: ["Metal", "Wood", "Plastic"]}],
                                                                                                                          
[ [ "impr_e", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 600 stamps at a very good price."} , "Question", {q: "What was the box made of? ", as: ["Metal", "Wood", "Plastic"]}],
                                                                                                                                   
[ [ "impr_f", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Peet liked to go to the flea market in the weekends. When he came back home that Saturday, his roommate Rowan asked him if he had found anything interesting. Peet said that he had bought an old metal cookie box containing a bunch of stamps. Rowan asked him how many stamps there were in the bundle and how much they had cost."],
                          
                          ]},
                    ds, { s:  "Peet said that he acquired 6,000 stamps at a very good price."} , "Question", {q: "What was the box made of? ", as: ["Metal", "Wood", "Plastic"]}],
                                                                                                   
[ [ "impr_a", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 90 units had been contaminated."} , "Question", {q: "What had damaged the blood bank?", as: ["Flood", "Hurricane", "Earthquake"]}],
                                                                                                  
[ [ "impr_b", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 900 units had been contaminated."} , "Question", {q: "What had damaged the blood bank?", as: ["Flood", "Hurricane", "Earthquake"]}],
                                                                                                             
[ [ "impr_c", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the area got flooded, the hospital was trying to determine how many of the scheduled surgeries would have to be postponed, since the blood bank, which was in the basement of the hospital, was partially flooded. The head of the hospital immediately called the blood bank director to tell her about the emergency situation and to ask how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 9,000 units had been contaminated."} , "Question", {q: "What had damaged the blood bank?", as: ["Flood", "Hurricane", "Earthquake"]}],
                                                                                                             
[ [ "impr_d", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 90 units had been contaminated."} , "Question", {q: "What kind of media did the journalists work for?", as: ["TV", "Newspaper", "Radio"]}],
                                                                                                             
[ [ "impr_e", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 900 units had been contaminated."} , "Question", {q: "What kind of media did the journalists work for?", as: ["TV", "Newspaper", "Radio"]}],
                                                                                                                    
[ [ "impr_f", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Over the weekend, a flood had partially damaged the hospital's blood bank, which was in the basement of the building. A team of journalists working for a local television channel was reporting from the site and offered a short life interview with the blood bank director. Among other things, the interviewer asked how many units of blood had been lost in the flood."],
                          
                          ]},
                    ds, { s:  "The blood bank director said that 9,000 units had been contaminated."} , "Question", {q: "What kind of media did the journalists work for?", as: ["TV", "Newspaper", "Radio"]}],
                                                                                                   
[ [ "impr_a", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 60 accounts had been stolen."} , "Question", {q: " To whom was Joana reporting the cyberattack?", as: ["FBI", "CIA", "NSA"]}],
                                                                                                  
[ [ "impr_b", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 600 accounts had been stolen."} , "Question", {q: " To whom was Joana reporting the cyberattack?", as: ["FBI", "CIA", "NSA"]}],
                                                                                                                
[ [ "impr_c", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was reporting a cyberattack her company had suffered to the FBI. One of the questions they asked was how many accounts had been compromised by the attack. Joana answered that she was not sure and that she would get back to them with that information. As soon as she hung up, Joanna called the IT department manager to explain to him that the company needed to report to the FBI how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 6,000 accounts had been stolen."} , "Question", {q: " To whom was Joana reporting the cyberattack?", as: ["FBI", "CIA", "NSA"]}],
                                                                                                                
[ [ "impr_d", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 60 accounts had been stolen."} , "Question", {q: "Where were Joana and the IT department manager talking?", as: ["Break room", "Hallway", "Cafe"]}],
                                                                                                               
[ [ "impr_e", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 600 accounts had been stolen."} , "Question", {q: "Where were Joana and the IT department manager talking?", as: ["Break room", "Hallway", "Cafe"]}],
                                                                                                                         
[ [ "impr_f", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Joana was hanging out in the break room when the IT department manager came in. The manager complained that he would have to work overtime for the next few days because of the recent cyberattack. Joana hadn't heard about this cyberattack, so out of curiosity, she asked how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s:  "The manager said that information from 6,000 accounts had been stolen."} , "Question", {q: "Where were Joana and the IT department manager talking?", as: ["Break room", "Hallway", "Cafe"]}],
                                                                                                   
[ [ "impr_a", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 50 students had gotten the message."} , "Question", {q: "Why was the student suing the department?", as: ["Unfair grading", "Discrimination", "Breach of Contract"]}],
                                                                                                   
[ [ "impr_b", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 500 students had gotten the message."} , "Question", {q: "Why was the student suing the department?", as: ["Unfair grading", "Discrimination", "Breach of Contract"]}],
                                                                                                                    
[ [ "impr_c", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A student was suing the department because he felt that he had been unfairly graded. Part of his case involved neither him nor any of his classmates receiving an email about the new grading policies, so following the advice of his lawyer, the Dean called his secretary to tell her that his lawyer needed them to find out how many students did receive his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 5,000 students had gotten the message."} , "Question", {q: "Why was the student suing the department?", as: ["Unfair grading", "Discrimination", "Breach of Contract"]}],
                                                                                                                    
[ [ "impr_d", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 50 students had gotten the message."} , "Question", {q: "When was the dean chatting with his secretary?", as: ["After a department event", "Before a department event", "Before work"]}],
                                                                                                                    
[ [ "impr_e", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 500 students had gotten the message."} , "Question", {q: "When was the dean chatting with his secretary?", as: ["After a department event", "Before a department event", "Before work"]}],
                                                                                                                                                         
[ [ "impr_f", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean was chatting with his secretary after a department event that had not been very well attended by the student community. Worried that he had not properly advertised the event, the dean wondered whether the event's email announcement had reached enough students, so he asked the secretary how many students had received his email."],
                          
                          ]},
                    ds, { s:  "The secretary replied that 5,000 students had gotten the message."} , "Question", {q: "When was the dean chatting with his secretary?", as: ["After a department event", "Before a department event", "Before work"]}],
                                                                                                   
[ [ "impr_a", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 40 views from several countries."} , "Question", {q: "What is Pamela's relation to Matt?", as: ["Friend ", "Brother", "Cousin"]}],
                                                                                                   
[ [ "impr_b", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 400 views from several countries."} , "Question", {q: "What is Pamela's relation to Matt?", as: ["Friend ", "Brother", "Cousin"]}],
                                                                                                             
[ [ "impr_c", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt wanted his friend, Pamela, to present one of her YouTube videos to a YouTube video contest. Matt told her that if she wanted to participate, he would sign her up himself. While filling out the forms on the contest's website, Matt told Pamela to pull up the video so she could see the view counter and asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 4,000 views from several countries."} , "Question", {q: "What is Pamela's relation to Matt?", as: ["Friend ", "Brother", "Cousin"]}],
                                                                                                             
[ [ "impr_d", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 40 views from several countries."} , "Question", {q: "What was Pamela's video about?", as: ["Her Cat", "Her Dog", "Her Hedgehog"]}],
                                                                                                            
[ [ "impr_e", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 400 views from several countries."} , "Question", {q: "What was Pamela's video about?", as: ["Her Cat", "Her Dog", "Her Hedgehog"]}],
                                                                                                                 
[ [ "impr_f", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Matt and Pamela were co-workers, and Matt had overheard that one of her cat videos had gone viral. Matt was procrastinating on his work, so he went over to Pamela's desk. Pamela asked Matt what he wanted as she barely looked up from her work. Even though Pamela clearly didn't want to be bothered, Matt asked her how many views her video had gotten."],
                          
                          ]},
                    ds, { s:  "Pamela replied that her video had 4,000 views from several countries."} , "Question", {q: "What was Pamela's video about?", as: ["Her Cat", "Her Dog", "Her Hedgehog"]}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
[ [ "f_1", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Gertrude had been driving all day to visit her family in upstate New York. She had planned to get there by around dinner time, but she got lost, and it was now very late. While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was."],
                          
                          ]},
                    ds, { s: "The map showed that the nearest lodge was still several miles away."} , "Question", {q: "What was several miles way?", as: ["Lodge", "Hostel", "Cabin"]}],
                           
[ [ "f_1", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jhanelle had the flu, so she had been confined to her bed for the last few days. While she was in bed, she decided to marathon her favorite TV show, Avatar. She realized she was very far in the series, but wasn't sure how many episodes were left, so Jhanelle checked the list to see exactly how many episodes were left."],
                          
                          ]},
                    ds, { s: "The list showed that she still had a few episodes left."} , "Question", {q: "What show was Jhanelle watching?", as: ["Avatar", "Breaking Bad", "Spongebob"]}],                    
                    
[ [ "f_1", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Akash had been practicing basketball in all his free time, because he knew he had been committing a lot of turnovers in his recent games. This past game determined if his team made the playoffs in their division, and, even though some of the players played incredibly well, the team still lost. After this disappointing loss, Akash asked the basketball coach approximately how many turnovers he had committed."],
                          
                          ]},
                    ds, { s: "The coach said Akash had committed far too many turnovers."} , "Question", {q: "What was the couch's opinion about the amount of turnovers Akash committed?", as: ["Bad", "Good", "Indifferent"]}],

[ [ "f_1", 28 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Iz had been reading about various airplanes, and was fascinated when she found out that many airplanes could be identified simply by the noises they made. She soon taught herself the noise every airplane model made, and in order to see how much she learned, Iz went outside and tested herself to see exactly how many airplane noises she could identify."],
                          
                          ]},
                    ds, { s: "She found that she could identify every airplane noise."} , "Question", {q: "What type of sound is Iz identifying?", as: ["Airplane noises", "Car horns", "Train whistles"]}],

[ [ "f_1", 29 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "David had been juggling ever since he was a small boy, since both his parents were circus performers. David was currently doing a solo juggling act, and he juggled everything from fruit, to knives, and at the end, he juggled three chainsaws. The spectators were amazed by David's skill and asked him approximately how many knives he could juggle at once."],
                          
                          ]},
                    ds, { s: "David answered that he could juggle quite a few knives at one time."} , "Question", {q: "How many knives could David juggle at once?", as: ["Lots", "Few", "Not more than two"]}],

[ [ "f_1", 30 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Isabella was doing a report about the efficiency of all the major airports in the US for the new airline she was working for, so she needed to collect flight statistics. Since O'Hare is a major airport, Isabella called the air traffic controller and asked exactly how many planes would be flying through O'Hare that day."],
                          
                          ]},
                    ds, { s: "The air traffic controller replied that the airports would see an average number of flights that day."} , "Question", {q: "At what airport are statistics being collected?", as: ["O'Hare", "JFK", "Midway"]}],
 
[ [ "f_1", 31 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Bardia was sitting in his biology class, and soon realized that the subject they were going to be covering today, mitosis, was something he already knew about, so, naturally, Bardia got bored very quickly. Since he was so bored, he decided to count exactly how many tiles were on the floor of the lecture hall."],
                          
                          ]},
                    ds, { s: "He found that there were more tiles than he cared to count."} , "Question", {q: "Where was Bardia?", as: ["Lecture hall", "Kitchen", "Bathroom"]}],

[ [ "f_1", 32 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Kevin was doing a research paper about all the sucessful coups d'etat that had ever happened in history. As Kevin was doing his research, he noticed that he never saw any mention of America, so he became curious if America had ever had a successful coup d'etat. So Kevin went to the library to find out exactly how many successful coups d'etat there had been in American history."],
                          
                          ]},
                    ds, { s: "He learned that there had been none."} , "Question", {q: "How many coups d'etat have there been in American history?", as: ["Zero", "One", "Two"]}],

[ [ "f_1", 33 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Pat told his parents that he wanted to be a politician. His parents suggested that if he wanted to get involved in politics, a good way to start would be to help with another politician's campaign, so he signed up to be on Jim Gilmore's campaign team. Each day, members of the campaign team got various assignments, and his assignment was to go door to door to talk to people and convince them to vote for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day."],
                          
                          ]},
                    ds, { s: "Pat answered that he had knocked on an enormous number of doors."} , "Question", {q: "Who is Pat campaigning for?", as: ["Jim Gilmore", "Lincoln Chafee", "Lawrence Lessig"]}],

[ [ "f_1", 34 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Brian was talking with his friend, Carina, who was complaining that there were never enough spoons in the dining hall for her cereal. Brian was arguing that there always seemed to be a lot of spoons in the dining hall, but Carina insisted that they still had a shortage of spoons. In order to prove her wrong, Brian decided that he would count approximately how many spoons there were in the South Campus dining hall."],
                          
                          ]},
                    ds, { s: "He counted many, many spoons."} , "Question", {q: "Which dining hall did Brian investigate?", as: ["South", "Bartlett", "Pierce"]}],
 
[ [ "f_1", 35 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Nancy's boss had been getting complaints recently that some of the boxes of cereal had significantly less cereal than normal. At first, her boss just thought there may have been just one or two bad boxes, but when the complaints kept coming, her boss realized something needed to be done. In order to file a complaint, the boss needed to know how many pieces of cereal were in each box, so he told Nancy, a salesperson, to count up exactly how many pieces of cereal were in each box."],
                          
                          ]},
                    ds, { s: "Not surprisingly, she found that each box contained a lot of pieces of cereal."} , "Question", {q: "What is Nancy?", as: ["Salesperson", "Janitor", "Chef"]}],
    
[ [ "f_2", 36 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Dylan was giving his first presentation at the meeting today, and he was incredibly nervous because he didn't think he was very good at public speaking. He realized he would feel better if he knew ahead of time what the size of his audience would be, so Dylan asked his boss how many people definitely would show up to the meeting."],
                          
                          ]},
                    ds, { s: "His boss said that exactly 20 people would come."} , "Question", {q: "What is the event?", as: ["Meeting", "Funeral", "Wedding"]}],

[ [ "f_2", 37 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Gerri was excited when she got a call from Goldman-Sachs asking her to come in for an interview, since working for this company was her dream job. Gerri thought the interview had gone well, but when she was waiting outside, she saw there were at least thirty people also waiting to be interviewed for the same position. At the end of her interview, Gerri asked the Goldman-Sachs executive nervously how many other candidates there were for the position."],
                          
                          ]},
                    ds, { s: "He told her that approximately 50 other candidates were being interviewed."} , "Question", {q: "What company has Gerri applied to?", as: ["Goldman Sachs", "JP Morgan", "US Bank"]}], 
 
[ [ "f_2", 38 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Jay had been studying for his economics midterm for a week, but he still managed to fail. He had heard some of his classmates saying that they had also failed, and he was confused because during class, they always seemed to know what was going on. Jay was perplexed, and wondered constantly how many of his classmates had failed the economics midterm."],
                          
                          ]},
                    ds, { s: "It turned out that exactly 20 of Jay's classmates had failed the exam."} , "Question", {q: "What subject was Jay studying?", as: ["Economics", "Chemistry", "Physics"]}],

[ [ "f_2", 39 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Angelica called Nora to ask her if she could cover her shift at the strip club. Nora was already set to come in for a lot of hours that weekend, but she told Angelica she'd cover her shift as well, since she owed Angelica a favor. After she got off the phone, Nora wondered exasperatedly how many hours she would have to spend dancing that weekend."],
                          
                          ]},
                    ds, { s: "According to her schedule, she would dance for approximately 20 hours."} , "Question", {q: "What did Nora check?", as: ["Her schedule", "Her phone", "Her agenda"]}],
    
[ [ "f_2", 40 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Ryan had heard that the theology class had an exam at the end of the term, he became incredibly nervous because he had always suffered from terrible testing anxiety. During the final exam, his anxiety was particularly bad. He was looking at the essay question, which asked about the importance of each of the commandments. Ryan racked his brain, asking himself frustratedly how many commandments there were."],
                          
                          ]},
                    ds, { s: "He then recalled that there were exactly 10 commandments."} , "Question", {q: "What subject is Ryan studying?", as: ["Theology", "History", "Arabic"]}],

[ [ "f_2", 41 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Anyone who knew Nina at all knew she spoke many languages. She was always talking about the differences between various languages, and every time she was on the phone with one of her internet friends, she spoke a different language, so many of her acquaintances began to wonder fervently how many languages Nina spoke."],
                          
                          ]},
                    ds, { s: "She revealed one day that she spoke exactly 10 languages."} , "Question", {q: "What is the polyglot's name?", as: ["Nina", "Bill", "Ted"]}],

[ [ "f_2", 42 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Shannon's favorite animal was alpacas, and she always talked about how, when she grew up, she wanted to live on an alpaca farm. For her birthday, her parents surprised her with a trip to a nearby alpaca farm. On her visit to the alpaca farm, Shannon asked excitedly how many alpacas there were."],
                          
                          ]},
                    ds, { s: "She was informed that there were approximately 40 alpacas."} , "Question", {q: "What animal is Shannon seeing?", as: ["Alpacas", "Llamas", "Dromedaries"]}],

[ [ "f_2", 43 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Angela was talking to her friend, Elsa, and they were arguing about how many hours students spent procrastinating. Elsa was arguing that students spent a great deal of time procrastinating, and Angela thought, on average, students didn't spend that much time procrastinating, so Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating."],
                          
                          ]},
                    ds, { s: "She found that the average student procrastinates for approximately 20 hours per week."} , "Question", {q: "What did Angela study?", as: ["Procrastination", "Sleeping", "Eating"]}],

[ [ "f_2", 44 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elania was previously a dean at NYU, and considering relocating to Chicago. She had gotten an interview for a position in the University of Chicago's administration, and was scheduled to have her interview in a half hour. She had never been to Chicago before, and wasn't sure exactly where campus was in Hyde Park. Elaina was worried about not showing up to her interview on time and asked a pedestrian desperately how many blocks away the University of Chicago's campus was."],
                          
                          ]},
                    ds, { s: "The pedestrian said that the campus was approximately 10 blocks away."} , "Question", {q: "What campus is Elaina looking for?", as: ["University of Chicago", "Northwestern", "Harvard"]}],

[ [ "f_2", 45 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Finals were about two weeks away, and Zach just spilled a cup of coffee all over his laptop. He didn't have a lot of money saved, but he wouldn't be able to get through finals without his laptop with all of his notes and papers from this term. When he took his computer to the computer repair store, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop."],
                          
                          ]},
                    ds, { s: "The agent told him that it would cost exactly 500 dollars."} , "Question", {q: "What does Zach need repaired?", as: ["Laptop", "Refrigerator", "Car"]}],

[ [ "f_2", 46 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "William loved learning about different historical periods, and was currently reading about famous train heists. He knew Jesse James committed a major train heist, but he wasn't sure how much money he had stolen, so he looked up curiously how many dollars Jesse James had stolen in his robbery."],
                          
                          ]},
                    ds, { s: "He learned that approximately 3,000 dollars had been taken."} , "Question", {q: "Who is William studying?", as: ["Jesse James", "Walter White", "Al Capone"]}],
 
[ [ "f_3", 47 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "James and Karnika were talking to the caterers for their wedding and the caterers asked about how many guests they should prepare food for. They said they didn't know, James and Karnika asked the organizer how many people certainly would come to their wedding."],
                          
                          ]},
                    ds, { s: "The organizer replied that a large handful of people would come."} , "Question", {q: "How many people were invited to the wedding?", as: ["A lot", "Not a lot", "Ten"]}],

[ [ "f_3", 48 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Claire was part of the Chicago Symphony Orchestra, and noticed that her violin sounded slightly off. She was on a tight budget, and the violin strings she would have to order were going to be incredibly expensive. Claire examined her violin and  pondered carefully how many new strings she needed for her violin."],
                          
                          ]},
                    ds, { s: "She determined she needed several new strings."} , "Question", {q: "What does Claire play?", as: ["Violin", "Guitar", "Viola"]}],

[ [ "f_3", 49 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Remy was one of the judges for this year's scavenger hunt, and he was working on clues for the items since the fall. He was very proud of his work, and wanted to make sure that all of his friends participated so they could appreciate this thing that he had put so many hours into, along with his fellow judges. He asked his friends persistently how many of them would be participating in the scavenger hunt in the spring."],
                          
                          ]},
                    ds, { s: "He learned that few of his friends would participate."} , "Question", {q: "When does the scavenger hunt take place?", as: ["Spring", "Fall", "Winter"]}],
 
[ [ "f_3", 50 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rebecca was talking to a few of her friends, and mentioned how she was having a hard time finding people to volunteer at the phone bank because so far everyone she had asked said either there's no way they would call people they didn't know or they were already busy. Her friends replied that they might be willing to help, so Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday."],
                          
                          ]},
                    ds, { s: "They said they would be willing to make calls for a few hours."} , "Question", {q: "What kind of volunteer work were Rebecca's friends going to do?", as: ["Phone calls", "Tutoring", "Coaching"]}],
 
[ [ "f_3", 51 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Louis was very excited about finally moving into his own apartment. The only problem was, he had heard a lot of bad stories about the current residents who lived in the building his apartment was in. However, he had also heard rumors that a lot of the really bad residents were moving out, so in the course of preparing for move-in, Louis asked the housing officials curiously how many new residents there would be that year."],
                          
                          ]},
                    ds, { s: "The officials told him there would be many new residents."} , "Question", {q: "Who asked this question?", as: ["Louis", "Dustin", "Helen"]}],
 
[ [ "f_3", 52 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julie was writing up a budget for her vacation, and was trying to figure out how much money she should put aside for gas. She figured she would ask her friends, since they've all driven to Pasadena before, and she was seeing them before she left. When she saw them for brunch, Julie asked her friends how many gallons of gas probably would be needed to get her to Pasadena."],
                          
                          ]},
                    ds, { s: "They told her that only a few gallons would be necessary."} , "Question", {q: "How many gallons were necessary to make the trip?", as: ["A few", "A couple", "A full tank"]}], 

[ [ "f_3", 53 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Caleb had just had a long day, and he had forgotten to have lunch. He was going out for dinner with some work colleagues, so he didn't want to eat a full meal, but he desperately needed a snack. Caleb remembered there was a doughnut shop around the corner from his office, so he went to the doughnut shop and asked the salesperson hungrily how many doughnuts there were left."],
                          
                          ]},
                    ds, { s: "The salesperson answered that there was a donut shortage and that they had only a few doughnuts left."} , "Question", {q: "What was the problem?", as: ["Doughnut shortage", "No doughnuts had not been delivered that day", "All doughnuts were sold out"]}],  
 
[ [ "f_3", 54 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "From a young age, Erin loved reading, and, after writing a lot of essays that required a certain word count, was curious how many words were in some of her favorite books. She counted the words in some smaller books, like the first book in the Harry Potter series, but she wondered how many words were in her all time favorite book, 'War and Peace.'"],
                          
                          ]},
                    ds, { s: "She quickly discovered that it contained more words than she could count."} , "Question", {q: "For how long did Erin inspect the book?", as: ["Not for long", "She was not inspecting a book", "A year"]}],  
 
[ [ "f_3", 55 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ulysses had just been fired from his job and found out his girlfriend was cheating on him all on the same day. He was devestated and in a terrible mood, so his friend suggested he get some pizza, since that was his favorite food. He called the pizza place and ordered a spinach and feta pizza, but when he got there, his pizza still wasn't ready, so he demanded to know immediately how many minutes his pizza would need to cook."],
                          
                          ]},
                    ds, { s: "The waiter responded that the food would be ready in a few minutes."} , "Question", {q: "When was the pizza going to be ready?", as: ["In a few minutes", "In an hour", "In an hour and a half"]}],  
                    
[ [ "f_3", 56 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elaine was by far the nosiest person in her class. She had no problem asking anyone about anything, to the point that one time she asked her teacher if she was pregnant, to which the teacher replied that she wasn't. After hearing a few times that different members of the class were just like their siblings, Elaine asked her classmates nosily how many siblings they each had."],
                          
                          ]},
                    ds, { s: "She was informed that most of them had a few siblings."} , "Question", {q: "Whom did Elaine ask?", as: ["Classmates", "Neighbors", "Teachers"]}],  

[ [ "f_3", 57 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Frederick was trying to get back to his home in Columbus as quickly as possible after he heard that a meteor might hit the earth in two weeks and destroy all of North America. He had managed to get a ticket for one of the last flights before the airline would stop working, and he was very anxious about getting home. When a notification of delay came in, Frederick asked the gate attendant despondently how many hours his flight to Columbus would be delayed."],
                          
                          ]},
                    ds, { s: "The attendant reassured him that the delay was only a few minutes."} , "Question", {q: "How confident was the attendant about the length of the delay?", as: ["Very confident", "Not very confident", "Neutral"]}]

];