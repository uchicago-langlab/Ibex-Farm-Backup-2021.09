var shuffleSequence = seq("setcounter", "intro", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))), "payment");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "Question", {
        randomOrder: false,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var items = [

      // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
      // sequence to send results before the experiment has finished. This is NOT intended to allow
      // for incremental sending of results -- you should send results exactly once per experiment.
      // However, it does permit additional messages to be displayed to participants once the
      // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
      // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
      // otherwise, results are automatically sent at the end of the experiment.
      //
      //["sr", "__SendResults__", { }],

      ["sep", "Separator", { }],
       
      ["intro", "Form", {consentRequired: true, html: {include: "consent.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
      ["payment", "Form", {consentRequired: false, html: {include: "exit.html" }} ],
      //["practiceover", "Message", {html: ["div", ["p", "This is the end of the practice."],["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."]  ,continueMessage:"Click here to continue."}],

      ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
      ],continueMessage:"Click here to continue."}],


  

      // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
      // for latin square designs will be updated. (Previously, this was always updated upon completion
      // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
      // point in your running order. If given no options, the counter is incremented by one. If given
      // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
      // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
      //
      ["setcounter", "__SetCounter__", { }],

      // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
      // consent checkbox).

      //
      // 2 practice items for self-paced reading ( with a comprehension question).
      //
      ["practice", "DashedSentence", {s: ["The cat","and","the dog","that","belong to","the woman","ran","away."]},
                        "Question", {q: "Do the cat and the dog belong to the man?", as: ["yes","no"], hasCorrect: 1}],
      ["practice", "DashedSentence", {s: ["The fact","that","Leland","hates","frogs","concerned","his parents."]},
                        "Question", {q: "Does Leland hate frogs?", as: ["yes","no"], hasCorrect: 0}],

      //
      // 32 "real" (i.e. non-filler) self-paced reading items with corresponding comprehension questions
      // There are four conditions.
      //

      [["e.subj.comp",1], "DashedSentence",{s:["It seems","that","those lawyers","and judges","who","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those lawyers and judges who reprimanded Andy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",1], "DashedSentence",{s:["It seems","that","those judges","who","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those judges who reprimanded Andy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",1], "DashedSentence",{s:["It seems","that","those lawyers","and judges","who","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those lawyers and judges who reprimanded Andy?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",1], "DashedSentence",{s:["It seems","that","those judges","who","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those judges who reprimanded Andy?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",2], "DashedSentence",{s:["It appears","that","those designers","and decorators","who","inadvertently","angered","Amy","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those designers and decorators who angered Amy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",2], "DashedSentence",{s:["It appears","that","those decorators","who","inadvertently","angered","Amy","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those decorators who angered Amy?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",2], "DashedSentence",{s:["It appears","that","those designers","and decorators","who","Amy","inadvertently","angered","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those designers and decorators who angered Amy?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",2], "DashedSentence",{s:["It appears","that","those decorators","who","Amy","inadvertently","angered","yesterday","furnished","the mansion."]}, "Question",{q: "Was it those decorators who angered Amy?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",3], "DashedSentence",{s:["It seems","that","those biologists","and researchers","who","warmly","encouraged","Ben","last night","studied","the disease."]}, "Question",{q: "Was it those biologists and researchers who encouraged Ben?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",3], "DashedSentence",{s:["It seems","that","those researchers","who","warmly","encouraged","Ben","last night","studied","the disease."]}, "Question",{q: "Was it those researchers who encouraged Ben?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",3], "DashedSentence",{s:["It seems","that","those biologists","and researchers","who","Ben","warmly","encouraged","last night","studied","the disease."]}, "Question",{q: "Was it those biologists and researchers who encouraged Ben?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",3], "DashedSentence",{s:["It seems","that","those researchers","who","Ben","warmly","encouraged","last night","studied","the disease."]}, "Question",{q: "Was it those researchers who encouraged Ben?", as:["yes","no"], hasCorrect: 1}], 
      
      [["e.subj.comp",4], "DashedSentence",{s:["It appears","that","those publicists","and managers","who","diligently","represented","Luke","this morning","answered","the letter."]}, "Question",{q: "Was it those publicists and managers who represented Luke?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",4], "DashedSentence",{s:["It appears","that","those managers","who","diligently","represented","Luke","this morning","answered","the letter."]}, "Question",{q: "Was it those managers who represented Luke?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",4], "DashedSentence",{s:["It appears","that","those publicists","and managers","who","Luke","diligently","represented","this morning","answered","the letter."]}, "Question",{q: "Was it those publicists and managers who represented Luke?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",4], "DashedSentence",{s:["It appears","that","those managers","who","Luke","diligently","represented","this morning","answered","the letter."]}, "Question",{q: "Was it those managers who represented Luke?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",5], "DashedSentence",{s:["It seems","that","those singers","and dancers","who","mercilessly","derided","Kevin","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those singers and dancers who derided Kevin?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",5], "DashedSentence",{s:["It seems","that","those dancers","who","mercilessly","derided","Kevin","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those dancers who derided Kevin?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",5], "DashedSentence",{s:["It seems","that","those singers","and dancers","who","Kevin","mercilessly","derided","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those singers and dancers who derided Kevin?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",5], "DashedSentence",{s:["It seems","that","those dancers","who","Kevin","mercilessly","derided","this afternoon","sold","the tickets."]}, "Question",{q: "Was it those dancers who derided Kevin?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",6], "DashedSentence",{s:["It appears","that","those clerks","and coordinators","who","rudely","criticized","Leah","this evening","organized","the calendar."]}, "Question",{q: "Was it those clerks and coordinators who criticized Leah?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",6], "DashedSentence",{s:["It appears","that","those coordinators","who","rudely","criticized","Leah","this evening","organized","the calendar."]}, "Question",{q: "Was it those coordinators who criticized Leah?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",6], "DashedSentence",{s:["It appears","that","those clerks","and coordinators","who","Leah","rudely","criticized","this evening","organized","the calendar."]}, "Question",{q: "Was it those clerks and coordinators who criticized Leah?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",6], "DashedSentence",{s:["It appears","that","those coordinators","who","Leah","rudely","criticized","this evening","organized","the calendar."]}, "Question",{q: "Was it those coordinators who criticized Leah?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",7], "DashedSentence",{s:["It seems","that","those cashiers","and bussers","who","adequately","served","Jack","tonight","prepared","the food."]}, "Question",{q: "Was it those cashiers and bussers who served Jack?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",7], "DashedSentence",{s:["It seems","that","those bussers","who","adequately","served","Jack","tonight","prepared","the food."]}, "Question",{q: "Was it those bussers who served Jack?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",7], "DashedSentence",{s:["It seems","that","those cashiers","and bussers","who","Jack","adequately","served","tonight","prepared","the food."]}, "Question",{q: "Was it those cashiers and bussers who served Jack?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",7], "DashedSentence",{s:["It seems","that","those bussers","who","Jack","adequately","served","tonight","prepared","the food."]}, "Question",{q: "Was it those bussers who served Jack?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",8], "DashedSentence",{s:["It appears","that","those dieticians","and technicians","who","dutifully","assisted","Sophia","last week","administered","the test."]}, "Question",{q: "Was it those dieticians and technicians who assisted Sophia?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",8], "DashedSentence",{s:["It appears","that","those technicians","who","dutifully","assisted","Sophia","last week","administered","the test."]}, "Question",{q: "Was it those technicians who assisted Sophia?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",8], "DashedSentence",{s:["It appears","that","those dieticians","and technicians","who","Sophia","dutifully","assisted","last week","administered","the test."]}, "Question",{q: "Was it those dieticians and technicians who assisted Sophia?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",8], "DashedSentence",{s:["It appears","that","those technicians","who","Sophia","dutifully","assisted","last week","administered","the test."]}, "Question",{q: "Was it those technicians who assisted Sophia?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",9], "DashedSentence",{s:["It seems","that","those photographers","and journalists","who","loyally","aided","Matthew","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who was aided by those photographers and journalists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",9], "DashedSentence",{s:["It seems","that","those journalists","who","loyally","aided","Matthew","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who was aided by those journalists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",9], "DashedSentence",{s:["It seems","that","those photographers","and journalists","who","Matthew","loyally","aided","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who was aided by those photographers and journalists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",9], "DashedSentence",{s:["It seems","that","those journalists","who","Matthew","loyally","aided","on Monday","broke","the story."]}, "Question",{q: "Was it Matthew who was aided by those journalists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",10], "DashedSentence",{s:["It appears","that","those composers","and pianists","who","lovingly","comforted","Tom","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who was comforted by those composers and pianists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",10], "DashedSentence",{s:["It appears","that","those pianists","who","lovingly","comforted","Tom","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who was comforted by those pianists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",10], "DashedSentence",{s:["It appears","that","those composers","and pianists","who","Tom","lovingly","comforted","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who was comforted by those composers and pianists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",10], "DashedSentence",{s:["It appears","that","those pianists","who","Tom","lovingly","comforted","on Tuesday","wrote","the sonata."]}, "Question",{q: "Was it Tom who was comforted by those pianists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",11], "DashedSentence",{s:["It seems","that","those policemen","and firemen","who","swiftly","called","Stephanie","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who was called by those policemen and firemen?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",11], "DashedSentence",{s:["It seems","that","those firemen","who","swiftly","called","Stephanie","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who was called by those firemen?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",11], "DashedSentence",{s:["It seems","that","those policemen","and firemen","who","Stephanie","swiftly","called","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who was called by those policemen and firemen?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",11], "DashedSentence",{s:["It seems","that","those firemen","who","Stephanie","swiftly","called","on Wednesday","rescued","the dog."]}, "Question",{q: "Was it Stephanie who was called by those firemen?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",12], "DashedSentence",{s:["It appears","that","those psychologists","and psychiatrists","who","seriously","doubted","Becky","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who was doubted by those psychologists and psychiatrists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",12], "DashedSentence",{s:["It appears","that","those psychiatrists","who","seriously","doubted","Becky","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who was doubted by those psychiatrists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",12], "DashedSentence",{s:["It appears","that","those psychologists","and psychiatrists","who","Becky","seriously","doubted","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who was doubted by those psychologists and psychiatrists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",12], "DashedSentence",{s:["It appears","that","those psychiatrists","who","Becky","seriously","doubted","on Thursday","prescribed","the medication."]}, "Question",{q: "Was it Becky who was doubted by those psychiatrists?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",13], "DashedSentence",{s:["It seems","that","those painters","and framers","who","emphatically","denounced","Ellen","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who was denounced by those painters and framers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",13], "DashedSentence",{s:["It seems","that","those framers","who","emphatically","denounced","Ellen","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who was denounced by those framers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",13], "DashedSentence",{s:["It seems","that","those painters","and framers","who","Ellen","emphatically","denounced","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who was denounced by those painters and framers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",13], "DashedSentence",{s:["It seems","that","those framers","who","Ellen","emphatically","denounced","on Friday","completed","the artwork."]}, "Question",{q: "Was it Ellen who was denounced by those framers?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",14], "DashedSentence",{s:["It appears","that","those electricians","and plumbers","who","reluctantly","helped","Anna","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who was helped by those electricians and plumbers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",14], "DashedSentence",{s:["It appears","that","those plumbers","who","reluctantly","helped","Anna","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who was helped by those plumbers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",14], "DashedSentence",{s:["It appears","that","those electricians","and plumbers","who","Anna","reluctantly","helped","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who was helped by those electricians and plumbers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",14], "DashedSentence",{s:["It appears","that","those plumbers","who","Anna","reluctantly","helped","on Saturday","collected","the payment."]}, "Question",{q: "Was it Anna who was helped by those plumbers?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",15], "DashedSentence",{s:["It seems","that","those tailors","and seamstresses","who","halfheartedly","hired","Teddy","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who was hired by those tailors and seamstresses?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",15], "DashedSentence",{s:["It seems","that","those seamstresses","who","halfheartedly","hired","Teddy","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who was hired by those seamstresses?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",15], "DashedSentence",{s:["It seems","that","those tailors","and seamstresses","who","Teddy","halfheartedly","hired","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who was hired by those tailors and seamstresses?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",15], "DashedSentence",{s:["It seems","that","those seamstresses","who","Teddy","halfheartedly","hired","on Sunday","created","the clothing."]}, "Question",{q: "Was it Teddy who was hired by those seamstresses?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",16], "DashedSentence",{s:["It appears","that","those engineers","and contractors","who","eagerly","introduced","Alex","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who was introduced by those engineers and contractors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp",16], "DashedSentence",{s:["It appears","that","those contractors","who","eagerly","introduced","Alex","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who was introduced by those contractors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp",16], "DashedSentence",{s:["It appears","that","those engineers","and contractors","who","Alex","eagerly","introduced","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who was introduced by those engineers and contractors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp",16], "DashedSentence",{s:["It appears","that","those contractors","who","Alex","eagerly","introduced","today","renovated","the hotel."]}, "Question",{q: "Was it Alex who was introduced by those contractors?", as:["yes","no"], hasCorrect: 1}], 

      [["e.subj.comp",17], "DashedSentence",{s:["It seems","that","those teachers","and professors","who","affectionately","mentored","Zack","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who mentored those teachers and professors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",17], "DashedSentence",{s:["It seems","that","those professors","who","affectionately","mentored","Zack","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who mentored those professors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",17], "DashedSentence",{s:["It seems","that","those teachers","and professors","who","Zack","affectionately","mentored","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who mentored those teachers and professors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",17], "DashedSentence",{s:["It seems","that","those professors","who","Zack","affectionately","mentored","yesterday","started","the lesson."]}, "Question",{q: "Was it Zack who mentored those professors?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",18], "DashedSentence",{s:["It appears","that","those veterinarians","and zoologists","who","quickly","advised","Madeline","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who advised those veterinarians and zoologists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",18], "DashedSentence",{s:["It appears","that","those zoologists","who","quickly","advised","Madeline","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who advised those zoologists?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",18], "DashedSentence",{s:["It appears","that","those veterinarians","and zoologists","who","Madeline","quickly","advised","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who advised those veterinarians and zoologists?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",18], "DashedSentence",{s:["It appears","that","those zoologists","who","Madeline","quickly","advised","last night","treated","the animal."]}, "Question",{q: "Was it Madeline who advised those zoologists?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",19], "DashedSentence",{s:["It seems","that","those coaches","and directors","who","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those coaches and directors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",19], "DashedSentence",{s:["It seems","that","those directors","who","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those directors?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",19], "DashedSentence",{s:["It seems","that","those coaches","and directors","who","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those coaches and directors?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",19], "DashedSentence",{s:["It seems","that","those directors","who","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those directors?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",20], "DashedSentence",{s:["It appears","that","those bankers","and tellers","who","thoroughly","questioned","Fiona","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who questioned those bankers and tellers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",20], "DashedSentence",{s:["It appears","that","those tellers","who","thoroughly","questioned","Fiona","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who questioned those tellers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",20], "DashedSentence",{s:["It appears","that","those bankers","and tellers","who","Fiona","thoroughly","questioned","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who questioned those bankers and tellers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",20], "DashedSentence",{s:["It appears","that","those tellers","who","Fiona","thoroughly","questioned","this afternoon","counted","the cash."]}, "Question",{q: "Was it Fiona who questioned those tellers?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",21], "DashedSentence",{s:["It seems","that","those librarians","and volunteers","who","enthusiastically","guided","Ivan","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who guided those librarians and volunteers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",21], "DashedSentence",{s:["It seems","that","those volunteers","who","enthusiastically","guided","Ivan","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who guided those volunteers?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",21], "DashedSentence",{s:["It seems","that","those librarians","and volunteers","who","Ivan","enthusiastically","guided","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who guided those librarians and volunteers?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",21], "DashedSentence",{s:["It seems","that","those volunteers","who","Ivan","enthusiastically","guided","this evening","sorted","the books."]}, "Question",{q: "Was it Ivan who guided those volunteers?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",22], "DashedSentence",{s:["It appears","that","those witnesses","and defendants","who","frighteningly","interrogated","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who interrogated those witnesses and defendants?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",22], "DashedSentence",{s:["It appears","that","those defendants","who","frighteningly","interrogated","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who interrogated those defendants?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",22], "DashedSentence",{s:["It appears","that","those witnesses","and defendants","who","Isaac","frighteningly","interrogated","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who interrogated those witnesses and defendants?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",22], "DashedSentence",{s:["It appears","that","those defendants","who","Isaac","frighteningly","interrogated","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who interrogated those defendants?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",23], "DashedSentence",{s:["It seems","that","those clients","and patrons","who","hurriedly","commanded","Amy","last week","finished","the project."]}, "Question",{q: "Was it Amy who commanded those clients and patrons?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",23], "DashedSentence",{s:["It seems","that","those patrons","who","hurriedly","commanded","Amy","last week","finished","the project."]}, "Question",{q: "Was it Amy who commanded those patrons?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",23], "DashedSentence",{s:["It seems","that","those clients","and patrons","who","Amy","hurriedly","commanded","last week","finished","the project."]}, "Question",{q: "Was it Amy who commanded those clients and patrons?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",23], "DashedSentence",{s:["It seems","that","those patrons","who","Amy","hurriedly","commanded","last week","finished","the project."]}, "Question",{q: "Was it Amy who commanded those patrons?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",24], "DashedSentence",{s:["It appears","that","those repairmen","and mechanics","who","consciously","neglected","Ian","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who neglected those repairmen and mechanics?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",24], "DashedSentence",{s:["It appears","that","those mechanics","who","consciously","neglected","Ian","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who neglected those mechanics?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",24], "DashedSentence",{s:["It appears","that","those repairmen","and mechanics","who","Ian","consciously","neglected","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who neglected those repairmen and mechanics?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",24], "DashedSentence",{s:["It appears","that","those mechanics","who","Ian","consciously","neglected","on Monday","repaired","the bike."]}, "Question",{q: "Was it Ian who neglected those mechanics?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",25], "DashedSentence",{s:["It seems","that","those socialites","and influencers","who","snobbishly","excluded","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those socialites and influencers who were excluded by Rosie?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",25], "DashedSentence",{s:["It seems","that","those influencers","who","snobbishly","excluded","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those influencers who were excluded by Rosie?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",25], "DashedSentence",{s:["It seems","that","those socialites","and influencers","who","Rosie","snobbishly","excluded","on Tuesday","threw","the party."]}, "Question",{q: "Was it those socialites and influencers who were excluded by Rosie?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",25], "DashedSentence",{s:["It seems","that","those influencers","who","Rosie","snobbishly","excluded","on Tuesday","threw","the party."]}, "Question",{q: "Was it those influencers who were excluded by Rosie?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",26], "DashedSentence",{s:["It appears","that","those comedians","and performers","who","barely","recognized","Isabella","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those comedians and performers who were recognized by Isabella?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",26], "DashedSentence",{s:["It appears","that","those performers","who","barely","recognized","Isabella","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those performers who were recognized by Isabella?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",26], "DashedSentence",{s:["It appears","that","those comedians","and performers","who","Isabella","barely","recognized","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those comedians and performers who were recognized by Isabella?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",26], "DashedSentence",{s:["It appears","that","those performers","who","Isabella","barely","recognized","on Wednesday","coordinated","the show."]}, "Question",{q: "Was it those performers who were recognized by Isabella?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",27], "DashedSentence",{s:["It seems","that","those secretaries","and bosses","who","carefully","counseled","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those secretaries and bosses who were counseled by Jessica?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",27], "DashedSentence",{s:["It seems","that","those bosses","who","carefully","counseled","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those bosses who were counseled by Jessica?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",27], "DashedSentence",{s:["It seems","that","those secretaries","and bosses","who","Jessica","carefully","counseled","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those secretaries and bosses who were counseled by Jessica?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",27], "DashedSentence",{s:["It seems","that","those bosses","who","Jessica","carefully","counseled","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those bosses who were counseled by Jessica?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",28], "DashedSentence",{s:["It appears","that","those doctors","and nurses","who","previously","consulted","Tess","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those doctors and nurses who were consulted by Tess?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",28], "DashedSentence",{s:["It appears","that","those nurses","who","previously","consulted","Tess","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those nurses who were consulted by Tess?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",28], "DashedSentence",{s:["It appears","that","those doctors","and nurses","who","Tess","previously","consulted","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those doctors and nurses who were consulted by Tess?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",28], "DashedSentence",{s:["It appears","that","those nurses","who","Tess","previously","consulted","on Friday","diagnosed","the flu."]}, "Question",{q: "Was it those nurses who were consulted by Tess?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",29], "DashedSentence",{s:["It seems","that","those artists","and sculptors","who","cordially","welcomed","Keith","on Saturday","made","the piece."]}, "Question",{q: "Was it those artists and sculptors who were welcomed by Keith?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",29], "DashedSentence",{s:["It seems","that","those sculptors","who","cordially","welcomed","Keith","on Saturday","made","the piece."]}, "Question",{q: "Was it those sculptors who were welcomed by Keith?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",29], "DashedSentence",{s:["It seems","that","those artists","and sculptors","who","Keith","cordially","welcomed","on Saturday","made","the piece."]}, "Question",{q: "Was it those artists and sculptors who were welcomed by Keith?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",29], "DashedSentence",{s:["It seems","that","those sculptors","who","Keith","cordially","welcomed","on Saturday","made","the piece."]}, "Question",{q: "Was it those sculptors who were welcomed by Keith?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",30], "DashedSentence",{s:["It appears","that","those conductors","and accompanists","who","fully","prepared","Simon","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those conductors and accompanists who were prepared by Simon?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",30], "DashedSentence",{s:["It appears","that","those accompanists","who","fully","prepared","Simon","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those accompanists who were prepared by Simon?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",30], "DashedSentence",{s:["It appears","that","those conductors","and accompanists","who","Simon","fully","prepared","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those conductors and accompanists who were prepared by Simon?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",30], "DashedSentence",{s:["It appears","that","those accompanists","who","Simon","fully","prepared","on Sunday","practiced","the performance."]}, "Question",{q: "Was it those accompanists who were prepared by Simon?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",31], "DashedSentence",{s:["It seems","that","those medics","and EMTs","who","successfully","relieved","Elena","today","reached","the hospital."]}, "Question",{q: "Was it those medics and EMTs who were relieved by Elena?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",31], "DashedSentence",{s:["It seems","that","those EMTs","who","successfully","relieved","Elena","today","reached","the hospital."]}, "Question",{q: "Was it those EMTs who were relieved by Elena?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",31], "DashedSentence",{s:["It seems","that","those medics","and EMTs","who","Elena","successfully","relieved","today","reached","the hospital."]}, "Question",{q: "Was it those medics and EMTs who were relieved by Elena?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",31], "DashedSentence",{s:["It seems","that","those EMTs","who","Elena","successfully","relieved","today","reached","the hospital."]}, "Question",{q: "Was it those EMTs who were relieved by Elena?", as:["yes","no"], hasCorrect: 0}], 

      [["e.subj.comp",32], "DashedSentence",{s:["It appears","that","those therapists","and counselors","who","compassionately","consoled","Aliza","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those therapists and counselors who were consoled by Aliza?", as:["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp",32], "DashedSentence",{s:["It appears","that","those counselors","who","compassionately","consoled","Aliza","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those counselors who were consoled by Aliza?", as:["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp",32], "DashedSentence",{s:["It appears","that","those therapists","and counselors","who","Aliza","compassionately","consoled","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those therapists and counselors who were consoled by Aliza?", as:["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp",32], "DashedSentence",{s:["It appears","that","those counselors","who","Aliza","compassionately","consoled","yesterday","alleviated","the problem."]}, "Question",{q: "Was it those counselors who were consoled by Aliza?", as:["yes","no"], hasCorrect: 0}],   
 
      //
      // 32 self-paced-reading filler sentences with question.
      //

      ["filler.A.1", "DashedSentence",{s:["It was","those consumers","who","begrudgingly","contacted","Jack","last night."]}, "Question",{q: "Was it those consumers who contacted Jack?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.2", "DashedSentence",{s:["It was","those landlords","who","generously","paid","Ariana","this morning."]}, "Question",{q: "Was it Ariana who was paid by those landlords?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.3", "DashedSentence",{s:["It was","those builders","who","contentedly","contracted","Grant","this afternoon."]}, "Question",{q: "Was it Lynn who mocked those planners?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.4", "DashedSentence",{s:["It was","those administrators","who","devotedly","obeyed","Anne","this evening."]}, "Question",{q: "Was it those administrators who were obeyed by Anne?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.5", "DashedSentence",{s:["It was","those marathoners","who","Juliette","excessively","trained","tonight."]}, "Question",{q: "Was it those marathoners who trained Juliette?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.6", "DashedSentence",{s:["It was","those shareholders","who","William","steadfastly","trusted","last week."]}, "Question",{q: "Was it William who was trusted by those shareholders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.7", "DashedSentence",{s:["It was","those archaeologists","who","Abby","blindly","followed","on Monday."]}, "Question",{q: "Was it Abby who followed those archaeologists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.8", "DashedSentence",{s:["It was","those ministers","who","Katie","constantly","distracted","on Tuesday."]}, "Question",{q: "Was it those ministers who were distracted by Katie?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.B.1", "DashedSentence",{s:["The fact","that","those writers","beautifully","described","Sergio","this afternoon","was","unprecedented."]}, "Question",{q: "Was it those writers who described Sergio?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.2", "DashedSentence",{s:["The fact","that","those publishers","positively","endorsed","Thomas","this evening","was","rare."]}, "Question",{q: "Was it Thomas who was endorsed by those publishers?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.3", "DashedSentence",{s:["The fact","that","those chemists","arbitrarily","selected","Luis","tonight","was","unusual."]}, "Question",{q: "Was it Luis who selected those chemists?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.4", "DashedSentence",{s:["The fact","that","those planners","carelessly","mocked","Lynn","last week","was","normal."]}, "Question",{q: "Was it those planners who were mocked by Lynn?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.5", "DashedSentence",{s:["The fact","that","Jacob","negatively","rated","those recruiters","on Monday","was","surprising."]}, "Question",{q: "Was it those recruiters who rated Jacob?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.6", "DashedSentence",{s:["The fact","that","Terry","secretly","observed","those investigators","on Tuesday","was","astonishing."]}, "Question",{q: "Was it Terry who was observed by those investigators?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.7", "DashedSentence",{s:["The fact","that","Kacey","attentively","shadowed","those clinicians","on Wednesday","was","impressive."]}, "Question",{q: "Was it Kacey who shadowed those clinicians?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.8", "DashedSentence",{s:["The fact","that","Blythe","confidently","instructed","those artisans","on Thursday","was","bizarre."]}, "Question",{q: "Was it those artisans who were instructed by Blythe?", as:["yes","no"], hasCorrect: 0}],
      ["filler.C.1", "DashedSentence",{s:["It was","mind-boggling","that","those florists","nervously","notified","Nick","on Saturday."]}, "Question",{q: "Was it those florists who notified Nick?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.2", "DashedSentence",{s:["It was","uncanny","that","those orthodontists","graciously","forgave","Bennet","on Sunday."]}, "Question",{q: "Was it Bennet who was forgiven by those orthodontists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.3", "DashedSentence",{s:["It was","acceptable","that","those midwives","fearfully","alerted","Bill","today."]}, "Question",{q: "Was it Bill who alerted those midwives?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.4", "DashedSentence",{s:["It was","unacceptable","that","those marines","fiercely","attacked","Lucas","yesterday."]}, "Question",{q: "Was it those marines who were attacked by Lucas?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.5", "DashedSentence",{s:["It was","abnormal","that","Sadie","unethically","misinformed","those entrepreneurs","last night."]}, "Question",{q: "Was it those entrepreneurs who misinformed Sadie?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.6", "DashedSentence",{s:["It was","unbelievable","that","Xavier","accidentally","misled","those captains","this morning."]}, "Question",{q: "Was it Xavier who was misled by those captains?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.7", "DashedSentence",{s:["It was","incredible","that","Chad","foolishly","indulged","those cooks","this afternoon."]}, "Question",{q: "Was it Chad who indulged those cooks?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.8", "DashedSentence",{s:["It was","mind-blowing","that","Leland","severely","underpaid","those pedicurists","this evening."]}, "Question",{q: "Was it those pedicurists who were underpaid by Leland?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.1", "DashedSentence",{s:["The newspaper","confirmed","that","those senators","mistakenly","exposed","Tabitha","last week."]}, "Question",{q: "Was it those senators who exposed Tabitha?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.2", "DashedSentence",{s:["The article","acknowledged","that","those treasurers","incorrectly","chastised","Preston","on Monday."]}, "Question",{q: "Was it Preston who was chastised by those treasurers?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.3", "DashedSentence",{s:["The show","explained","that","those chancellors","publicly","honored","Sienna","on Tuesday."]}, "Question",{q: "Was it Sienna who honored those chancellors?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.4", "DashedSentence",{s:["The book","demonstrated","that","those landscapers","overtly","defended","Justin","on Wednesday."]}, "Question",{q: "Was it those landscapers who were defended by Justin?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.5", "DashedSentence",{s:["The journal","established","that","Selena","sincerely","complimented","those superintendents","on Thursday."]}, "Question",{q: "Was it those superintendents who complimented Selena?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.6", "DashedSentence",{s:["The evidence","proved","that","Taylor","maliciously","antagonized","those cobblers","on Friday."]}, "Question",{q: "Was it Taylor who was antagonized by those cobblers?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.7", "DashedSentence",{s:["The company","recognized","that","Ethan","arrogantly","corrected","those interpreters","on Saturday."]}, "Question",{q: "Was it Ethan who corrected those interpreters?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.8", "DashedSentence",{s:["The documentary","revealed","that","Hallie","loudly","lauded","those barbers","on Sunday."]}, "Question",{q: "Was it those barbers who were lauded by Hallie?", as:["yes","no"], hasCorrect: 0}]


];
