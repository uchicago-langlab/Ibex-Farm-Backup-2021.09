//var shuffleSequence = seq("setcounter","consent", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("m"),startsWith("z"),startsWith("f")))), "brexit");
var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Kérjük, várjon a következő mondatra.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(elfogadhatatlan)", rightComment: "(elfogadható)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
    ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Kattintson ide az eredmények elküldéséhez."} ],
    ["consent", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Kattintson ide a folytatáshoz."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Kattintson ide a gyakorláshoz."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],

//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "Vége a gyakorlásnak."],
                          ["p", "Most fog elkezdődni a valódi kísérlet, ahol ugyanaz lesz a feladata, mint eddig: két mondatot fog látni, és azt kell eldöntenie, mennyire elfogadható, természetes a második mondat az elsőt követően."] 
],continueMessage:"Kattintson ide a kísérlet elkezdéséhez."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Two practice items:
//
 
["practice", "AcceptabilityJudgment", {s: "Minden gyerek síelni ment februárban. De nem tudom, hogy mivé."}],
["practice", "AcceptabilityJudgment", {s: "Valaki feldíszítette a karácsonyfát. Találd ki, hogy ki volt az."}],
 
//
// 18 experimental sets for the multiple sluicing experiment.
// 6 conditions 
//
// Keys:
// m: experimental item for the Multiple sluicing experiment
// SP: Single Pair; PL: Pair List; E: Ellipsis (sluicing); NE: Non-Ellipsis; SF: Single Fronting; MF: Multiple Fronting
 
[["m.SP.E",1], "AcceptabilityJudgment", {s: "Valaki megcsókolt valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",1], "AcceptabilityJudgment", {s: "Mindenki megcsókolt valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",1], "AcceptabilityJudgment", {s: "Valaki megcsókolt valakit. De nem emlékszem, hogy ki csókolt meg kit."}],
[["m.PL.NE.SF",1], "AcceptabilityJudgment", {s: "Mindenki megcsókolt valakit. De nem emlékszem, hogy ki csókolt meg kit."}],
[["m.SP.NE.MF",1], "AcceptabilityJudgment", {s: "Valaki megcsókolt valakit. De nem emlékszem, hogy ki kit csókolt meg."}],
[["m.PL.NE.MF",1], "AcceptabilityJudgment", {s: "Mindenki megcsókolt valakit. De nem emlékszem, hogy ki kit csókolt meg."}],
 
[["m.SP.E",2], "AcceptabilityJudgment", {s: "Valaki megütött valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",2], "AcceptabilityJudgment", {s: "Mindenki megütött valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",2], "AcceptabilityJudgment", {s: "Valaki megütött valakit. De nem emlékszem, hogy ki ütött meg kit."}],
[["m.PL.NE.SF",2], "AcceptabilityJudgment", {s: "Mindenki megütött valakit. De nem emlékszem, hogy ki ütött meg kit."}],
[["m.SP.NE.MF",2], "AcceptabilityJudgment", {s: "Valaki megütött valakit. De nem emlékszem, hogy ki kit ütött meg."}],
[["m.PL.NE.MF",2], "AcceptabilityJudgment", {s: "Mindenki megütött valakit. De nem emlékszem, hogy ki kit ütött meg."}],
 
[["m.SP.E",3], "AcceptabilityJudgment", {s: "Valaki megijesztett valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",3], "AcceptabilityJudgment", {s: "Mindenki megijesztett valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",3], "AcceptabilityJudgment", {s: "Valaki megijesztett valakit. De nem emlékszem, hogy ki ijesztett meg kit."}],
[["m.PL.NE.SF",3], "AcceptabilityJudgment", {s: "Mindenki megijesztett valakit. De nem emlékszem, hogy ki ijesztett meg kit."}],
[["m.SP.NE.MF",3], "AcceptabilityJudgment", {s: "Valaki megijesztett valakit. De nem emlékszem, hogy ki kit ijesztett meg."}],
[["m.PL.NE.MF",3], "AcceptabilityJudgment", {s: "Mindenki megijesztett valakit. De nem emlékszem, hogy ki kit ijesztett meg."}],
 
[["m.SP.E",4], "AcceptabilityJudgment", {s: "Valaki meghívott valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",4], "AcceptabilityJudgment", {s: "Mindenki meghívott valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",4], "AcceptabilityJudgment", {s: "Valaki meghívott valakit. De nem tudom, hogy ki hívott meg kit."}],
[["m.PL.NE.SF",4], "AcceptabilityJudgment", {s: "Mindenki meghívott valakit. De nem tudom, hogy ki hívott meg kit."}],
[["m.SP.NE.MF",4], "AcceptabilityJudgment", {s: "Valaki meghívott valakit. De nem tudom, hogy ki kit hívott meg."}],
[["m.PL.NE.MF",4], "AcceptabilityJudgment", {s: "Mindenki meghívott valakit. De nem tudom, hogy ki kit hívott meg."}],
 
[["m.SP.E",5], "AcceptabilityJudgment", {s: "Valaki kinevetett valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",5], "AcceptabilityJudgment", {s: "Mindenki kinevetett valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",5], "AcceptabilityJudgment", {s: "Valaki kinevetett valakit. De nem emlékszem, hogy ki nevetett ki kit."}],
[["m.PL.NE.SF",5], "AcceptabilityJudgment", {s: "Mindenki kinevetett valakit. De nem emlékszem, hogy ki nevetett ki kit."}],
[["m.SP.NE.MF",5], "AcceptabilityJudgment", {s: "Valaki kinevetett valakit. De nem emlékszem, hogy ki kit nevetett ki."}],
[["m.PL.NE.MF",5], "AcceptabilityJudgment", {s: "Mindenki kinevetett valakit. De nem emlékszem, hogy ki kit nevetett ki."}],
 
[["m.SP.E",6], "AcceptabilityJudgment", {s: "Valaki leszidott valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",6], "AcceptabilityJudgment", {s: "Mindenki leszidott valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",6], "AcceptabilityJudgment", {s: "Valaki leszidott valakit. De nem emlékszem, hogy ki szidott le kit."}],
[["m.PL.NE.SF",6], "AcceptabilityJudgment", {s: "Mindenki leszidott valakit. De nem emlékszem, hogy ki szidott le kit."}],
[["m.SP.NE.MF",6], "AcceptabilityJudgment", {s: "Valaki leszidott valakit. De nem emlékszem, hogy ki kit szidott le."}],
[["m.PL.NE.MF",6], "AcceptabilityJudgment", {s: "Mindenki leszidott valakit. De nem emlékszem, hogy ki kit szidott le."}],
 
[["m.SP.E",7], "AcceptabilityJudgment", {s: "Valaki felidegesített valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",7], "AcceptabilityJudgment", {s: "Mindenki felidegesített valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",7], "AcceptabilityJudgment", {s: "Valaki felidegesített valakit. De nem emlékszem, hogy ki idegesített fel kit."}],
[["m.PL.NE.SF",7], "AcceptabilityJudgment", {s: "Mindenki felidegesített valakit. De nem emlékszem, hogy ki idegesített fel kit."}],
[["m.SP.NE.MF",7], "AcceptabilityJudgment", {s: "Valaki felidegesített valakit. De nem emlékszem, hogy ki kit idegesített fel."}],
[["m.PL.NE.MF",7], "AcceptabilityJudgment", {s: "Mindenki felidegesített valakit. De nem emlékszem, hogy ki kit idegesített fel."}],
 
[["m.SP.E",8], "AcceptabilityJudgment", {s: "Valaki átölelt valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",8], "AcceptabilityJudgment", {s: "Mindenki átölelt valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",8], "AcceptabilityJudgment", {s: "Valaki átölelt valakit. De nem emlékszem, hogy ki ölelt át kit."}],
[["m.PL.NE.SF",8], "AcceptabilityJudgment", {s: "Mindenki átölelt valakit. De nem emlékszem, hogy ki ölelt át kit."}],
[["m.SP.NE.MF",8], "AcceptabilityJudgment", {s: "Valaki átölelt valakit. De nem emlékszem, hogy ki kit ölelt át."}],
[["m.PL.NE.MF",8], "AcceptabilityJudgment", {s: "Mindenki átölelt valakit. De nem emlékszem, hogy ki kit ölelt át."}],
 
[["m.SP.E",9], "AcceptabilityJudgment", {s: "Valaki átvert valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",9], "AcceptabilityJudgment", {s: "Mindenki átvert valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",9], "AcceptabilityJudgment", {s: "Valaki átvert valakit. De nem tudom, hogy ki vert át kit."}],
[["m.PL.NE.SF",9], "AcceptabilityJudgment", {s: "Mindenki átvert valakit. De nem tudom, hogy ki vert át kit."}],
[["m.SP.NE.MF",9], "AcceptabilityJudgment", {s: "Valaki átvert valakit. De nem tudom, hogy ki kit vert át."}],
[["m.PL.NE.MF",9], "AcceptabilityJudgment", {s: "Mindenki átvert valakit. De nem tudom, hogy ki kit vert át."}],
 
[["m.SP.E",10], "AcceptabilityJudgment", {s: "Valaki meglökött valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",10], "AcceptabilityJudgment", {s: "Mindenki meglökött valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",10], "AcceptabilityJudgment", {s: "Valaki meglökött valakit. De nem tudom, hogy ki lökött meg kit."}],
[["m.PL.NE.SF",10], "AcceptabilityJudgment", {s: "Mindenki meglökött valakit. De nem tudom, hogy ki lökött meg kit."}],
[["m.SP.NE.MF",10], "AcceptabilityJudgment", {s: "Valaki meglökött valakit. De nem tudom, hogy ki kit lökött meg."}],
[["m.PL.NE.MF",10], "AcceptabilityJudgment", {s: "Mindenki meglökött valakit. De nem tudom, hogy ki kit lökött meg."}],
 
[["m.SP.E",11], "AcceptabilityJudgment", {s: "Valaki megkérdezett valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",11], "AcceptabilityJudgment", {s: "Mindenki megkérdezett valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",11], "AcceptabilityJudgment", {s: "Valaki megkérdezett valakit. De nem tudom, hogy ki kérdezett meg kit."}],
[["m.PL.NE.SF",11], "AcceptabilityJudgment", {s: "Mindenki megkérdezett valakit. De nem tudom, hogy ki kérdezett meg kit."}],
[["m.SP.NE.MF",11], "AcceptabilityJudgment", {s: "Valaki megkérdezett valakit. De nem tudom, hogy ki kit kérdezett meg."}],
[["m.PL.NE.MF",11], "AcceptabilityJudgment", {s: "Mindenki megkérdezett valakit. De nem tudom, hogy ki kit kérdezett meg."}],
 
[["m.SP.E",12], "AcceptabilityJudgment", {s: "Valaki bemutatott valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",12], "AcceptabilityJudgment", {s: "Mindenki bemutatott valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",12], "AcceptabilityJudgment", {s: "Valaki bemutatott valakit. De nem emlékszem, hogy ki mutatott be kit."}],
[["m.PL.NE.SF",12], "AcceptabilityJudgment", {s: "Mindenki bemutatott valakit. De nem emlékszem, hogy ki mutatott be kit."}],
[["m.SP.NE.MF",12], "AcceptabilityJudgment", {s: "Valaki bemutatott valakit. De nem emlékszem, hogy ki kit mutatott be."}],
[["m.PL.NE.MF",12], "AcceptabilityJudgment", {s: "Mindenki bemutatott valakit. De nem emlékszem, hogy ki kit mutatott be."}],
 
[["m.SP.E",13], "AcceptabilityJudgment", {s: "Valaki elfelejtett valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",13], "AcceptabilityJudgment", {s: "Mindenki elfelejtett valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",13], "AcceptabilityJudgment", {s: "Valaki elfelejtett valakit. De nem tudom, hogy ki felejtett el kit."}],
[["m.PL.NE.SF",13], "AcceptabilityJudgment", {s: "Mindenki elfelejtett valakit. De nem tudom, hogy ki felejtett el kit."}],
[["m.SP.NE.MF",13], "AcceptabilityJudgment", {s: "Valaki elfelejtett valakit. De nem tudom, hogy ki kit felejtett el."}],
[["m.PL.NE.MF",13], "AcceptabilityJudgment", {s: "Mindenki elfelejtett valakit. De nem tudom, hogy ki kit felejtett el."}],
 
[["m.SP.E",14], "AcceptabilityJudgment", {s: "Valaki előléptetett valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",14], "AcceptabilityJudgment", {s: "Mindenki előléptetett valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",14], "AcceptabilityJudgment", {s: "Valaki előléptetett valakit. De nem tudom, hogy ki léptetett elő kit."}],
[["m.PL.NE.SF",14], "AcceptabilityJudgment", {s: "Mindenki előléptetett valakit. De nem tudom, hogy ki léptetett elő kit."}],
[["m.SP.NE.MF",14], "AcceptabilityJudgment", {s: "Valaki előléptetett valakit. De nem tudom, hogy ki kit léptetett elő."}],
[["m.PL.NE.MF",14], "AcceptabilityJudgment", {s: "Mindenki előléptetett valakit. De nem tudom, hogy ki kit léptetett elő."}],
 
[["m.SP.E",15], "AcceptabilityJudgment", {s: "Valaki hazakísért valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",15], "AcceptabilityJudgment", {s: "Mindenki hazakísért valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",15], "AcceptabilityJudgment", {s: "Valaki hazakísért valakit. De nem tudom, hogy ki kísért haza kit."}],
[["m.PL.NE.SF",15], "AcceptabilityJudgment", {s: "Mindenki hazakísért valakit. De nem tudom, hogy ki kísért haza kit."}],
[["m.SP.NE.MF",15], "AcceptabilityJudgment", {s: "Valaki hazakísért valakit. De nem tudom, hogy ki kit kísért haza."}],
[["m.PL.NE.MF",15], "AcceptabilityJudgment", {s: "Mindenki hazakísért valakit. De nem tudom, hogy ki kit kísért haza."}],
 
[["m.SP.E",16], "AcceptabilityJudgment", {s: "Valaki kihasznált valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",16], "AcceptabilityJudgment", {s: "Mindenki kihasznált valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",16], "AcceptabilityJudgment", {s: "Valaki kihasznált valakit. De nem tudom, hogy ki használt ki kit."}],
[["m.PL.NE.SF",16], "AcceptabilityJudgment", {s: "Mindenki kihasznált valakit. De nem tudom, hogy ki használt ki kit."}],
[["m.SP.NE.MF",16], "AcceptabilityJudgment", {s: "Valaki kihasznált valakit. De nem tudom, hogy ki kit használt ki."}],
[["m.PL.NE.MF",16], "AcceptabilityJudgment", {s: "Mindenki kihasznált valakit. De nem tudom, hogy ki kit használt ki."}],
 
[["m.SP.E",17], "AcceptabilityJudgment", {s: "Valaki letartóztatott valakit. De nem tudom, hogy ki kit."}],
[["m.PL.E",17], "AcceptabilityJudgment", {s: "Mindenki letartóztatott valakit. De nem tudom, hogy ki kit."}],
[["m.SP.NE.SF",17], "AcceptabilityJudgment", {s: "Valaki letartóztatott valakit. De nem tudom, hogy ki tartóztatott le kit."}],
[["m.PL.NE.SF",17], "AcceptabilityJudgment", {s: "Mindenki letartóztatott valakit. De nem tudom, hogy ki tartóztatott le kit."}],
[["m.SP.NE.MF",17], "AcceptabilityJudgment", {s: "Valaki letartóztatott valakit. De nem tudom, hogy ki kit tartóztatott le."}],
[["m.PL.NE.MF",17], "AcceptabilityJudgment", {s: "Mindenki letartóztatott valakit. De nem tudom, hogy ki kit tartóztatott le."}],
 
[["m.SP.E",18], "AcceptabilityJudgment", {s: "Valaki lerajzolt valakit. De nem emlékszem, hogy ki kit."}],
[["m.PL.E",18], "AcceptabilityJudgment", {s: "Mindenki lerajzolt valakit. De nem emlékszem, hogy ki kit."}],
[["m.SP.NE.SF",18], "AcceptabilityJudgment", {s: "Valaki lerajzolt valakit. De nem emlékszem, hogy ki rajzolt le kit."}],
[["m.PL.NE.SF",18], "AcceptabilityJudgment", {s: "Mindenki lerajzolt valakit. De nem emlékszem, hogy ki rajzolt le kit."}],
[["m.SP.NE.MF",18], "AcceptabilityJudgment", {s: "Valaki lerajzolt valakit. De nem emlékszem, hogy ki kit rajzolt le."}],
[["m.PL.NE.MF",18], "AcceptabilityJudgment", {s: "Mindenki lerajzolt valakit. De nem emlékszem, hogy ki kit rajzolt le."}],
 
 
//
// 8 experimental sets for the case-(mis)matches pilot.
// 4 conditions 
//
// Keys:
// c: experimental item for the Case (mis)matches pilot
// NC: Nominative Correlate; AC: Accusative Correlate; NR: Nominative Remnant; AR: Accusative Remnant
 
[["z.NC.AR",19], "AcceptabilityJudgment", {s: "Valaki felhívta az egyik testvérem. De nem tudom, hogy melyiket."}],
[["z.AC.AR",19], "AcceptabilityJudgment", {s: "Valaki felhívta az egyik testvéremet. De nem tudom, hogy melyiket."}],
[["z.NC.NR",19], "AcceptabilityJudgment", {s: "Valaki felhívta az egyik testvérem. De nem tudom, hogy melyik."}],
[["z.AC.NR",19], "AcceptabilityJudgment", {s: "Valaki felhívta az egyik testvéremet. De nem tudom, hogy melyik."}],
 
[["z.NC.AR",20], "AcceptabilityJudgment", {s: "Mari ismeri az egyik barátnőm. De nem emlékszem, hogy melyiket."}],
[["z.AC.AR",20], "AcceptabilityJudgment", {s: "Mari ismeri az egyik barátnőmet. De nem emlékszem, hogy melyiket."}],
[["z.NC.NR",20], "AcceptabilityJudgment", {s: "Mari ismeri az egyik barátnőm. De nem emlékszem, hogy melyik."}],
[["z.AC.NR",20], "AcceptabilityJudgment", {s: "Mari ismeri az egyik barátnőmet. De nem emlékszem, hogy melyik."}],
 
[["z.NC.AR",21], "AcceptabilityJudgment", {s: "Elütötték az egyik macskám. De nem tudom, hogy melyiket."}],
[["z.AC.AR",21], "AcceptabilityJudgment", {s: "Elütötték az egyik macskámat. De nem tudom, hogy melyiket."}],
[["z.NC.NR",21], "AcceptabilityJudgment", {s: "Elütötték az egyik macskám. De nem tudom, hogy melyik."}],
[["z.AC.NR",21], "AcceptabilityJudgment", {s: "Elütötték az egyik macskámat. De nem tudom, hogy melyik."}],
 
[["z.NC.AR",22], "AcceptabilityJudgment", {s: "Valakinek kölcsönadtam az egyik könyvem. De nem emlékszem, hogy melyiket."}],
[["z.AC.AR",22], "AcceptabilityJudgment", {s: "Valakinek kölcsönadtam az egyik könyvemet. De nem emlékszem, hogy melyiket."}],
[["z.NC.NR",22], "AcceptabilityJudgment", {s: "Valakinek kölcsönadtam az egyik könyvem. De nem emlékszem, hogy melyik."}],
[["z.AC.NR",22], "AcceptabilityJudgment", {s: "Valakinek kölcsönadtam az egyik könyvemet. De nem emlékszem, hogy melyik."}],
 
[["z.NC.AR",23], "AcceptabilityJudgment", {s: "János utálja az egyik szomszédod. De nem emlékszem, hogy melyiket."}],
[["z.AC.AR",23], "AcceptabilityJudgment", {s: "János utálja az egyik szomszédodat. De nem emlékszem, hogy melyiket."}],
[["z.NC.NR",23], "AcceptabilityJudgment", {s: "János utálja az egyik szomszédod. De nem emlékszem, hogy melyik."}],
[["z.AC.NR",23], "AcceptabilityJudgment", {s: "János utálja az egyik szomszédodat. De nem emlékszem, hogy melyik."}],
 
[["z.NC.AR",24], "AcceptabilityJudgment", {s: "Meg fogom látogatni az egyik rokonod. De nem tudom, hogy melyiket."}],
[["z.AC.AR",24], "AcceptabilityJudgment", {s: "Meg fogom látogatni az egyik rokonodat. De nem tudom, hogy melyiket."}],
[["z.NC.NR",24], "AcceptabilityJudgment", {s: "Meg fogom látogatni az egyik rokonod. De nem tudom, hogy melyik."}],
[["z.AC.NR",24], "AcceptabilityJudgment", {s: "Meg fogom látogatni az egyik rokonodat. De nem tudom, hogy melyik."}],
 
[["z.NC.AR",25], "AcceptabilityJudgment", {s: "Láttam az utcán az egyik diákod. De nem tudom, hogy melyiket."}],
[["z.AC.AR",25], "AcceptabilityJudgment", {s: "Láttam az utcán az egyik diákodat. De nem tudom, hogy melyiket."}],
[["z.NC.NR",25], "AcceptabilityJudgment", {s: "Láttam az utcán az egyik diákod. De nem tudom, hogy melyik."}],
[["z.AC.NR",25], "AcceptabilityJudgment", {s: "Láttam az utcán az egyik diákodat. De nem tudom, hogy melyik."}],
 
[["z.NC.AR",26], "AcceptabilityJudgment", {s: "Elolvastam az egyik cikked. De nem emlékszem, hogy melyiket."}],
[["z.AC.AR",26], "AcceptabilityJudgment", {s: "Elolvastam az egyik cikkedet. De nem emlékszem, hogy melyiket."}],
[["z.NC.NR",26], "AcceptabilityJudgment", {s: "Elolvastam az egyik cikked. De nem emlékszem, hogy melyik."}],
[["z.AC.NR",26], "AcceptabilityJudgment", {s: "Elolvastam az egyik cikkedet. De nem emlékszem, hogy melyik."}],
 
//
/// 10 fillers
//
// Keys:
// f: fillers
// B: unrelated Bad fillers; G: unrelated Good fillers
 
["f.B.1", "AcceptabilityJudgment", {s: "János találkozott egy lánnyal. De nem egyértelmű, hogy kit."}],
["f.B.2", "AcceptabilityJudgment", {s: "Megettem egy hatalmas süteményt. Találd ki, hogy meddig."}],
["f.B.3", "AcceptabilityJudgment", {s: "Megkérdeztél valamit valakitől. Szeretném tudni, hogy kivé."}],
["f.B.4", "AcceptabilityJudgment", {s: "Mindenki felelős valamiért. De nem egyértelmű, hogy kiket."}],
["f.B.5", "AcceptabilityJudgment", {s: "Valaki megismerkedett anyukáddal. De nem tudom, hogy miből."}],
["f.G.1", "AcceptabilityJudgment", {s: "Péter vásárolt egy új esőkabátot. De nem tudom, hogy mennyibe került."}],
["f.G.2", "AcceptabilityJudgment", {s: "István vett egy ajándékot Julinak. Szeretném tudni, hogy pontosan hol vette."}],
["f.G.3", "AcceptabilityJudgment", {s: "Valaki megtalálta a pénztárcámat. Találd ki, hogy hol."}],
["f.G.4", "AcceptabilityJudgment", {s: "Mindenkitől kaptam egy virágot. De nem emlékszem, hogy ki hozta a rózsát."}],
["f.G.5", "AcceptabilityJudgment", {s: "Anna megbukott matekból. Szeretném tudni, hogy ez hogy történhetett."}]


];
