var shuffleSequence = seq("setcounter", "intro", sepWith("sep", seq("practice", "practiceover", rshuffle(startsWith("e"),startsWith("f")))), "payment");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "Question", {
        randomOrder: false,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "Please press here to continue"
    }
];

var items = [

      // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
      // sequence to send results before the experiment has finished. This is NOT intended to allow
      // for incremental sending of results -- you should send results exactly once per experiment.
      // However, it does permit additional messages to be displayed to participants once the
      // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
      // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
      // otherwise, results are automatically sent at the end of the experiment.
      //
      //["sr", "__SendResults__", { }],

      ["sep", "Separator", { }],
       
      ["intro", "Form", {consentRequired: true, html: {include: "consent.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
      ["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
      ["payment", "Form", {consentRequired: false, html: {include: "exit.html" }} ],
      //["practiceover", "Message", {html: ["div", ["p", "This is the end of the practice."],["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."]  ,continueMessage:"Click here to continue."}],

      ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
      ],continueMessage:"Click here to continue."}],


  

      // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
      // for latin square designs will be updated. (Previously, this was always updated upon completion
      // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
      // point in your running order. If given no options, the counter is incremented by one. If given
      // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
      // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
      //

      ["setcounter", "__SetCounter__", { }],

      // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
      // consent checkbox).

      //
      // 2 practice items for self-paced reading ( with a comprehension question).
      //

      ["practice", "DashedSentence", {s: ["The cat","and","the dog","that","belong to","the woman","ran","away."]},
                        "Question", {q: "Do the cat and the dog belong to the man?", as: ["yes","no"], hasCorrect: 1}],
      ["practice", "DashedSentence", {s: ["The fact","that","Leland","hates","frogs","concerned","his parents."]},
                        "Question", {q: "Does Leland hate frogs?", as: ["yes","no"], hasCorrect: 0}],

      //
      // 32 "real" (i.e. non-filler) self-paced reading items with corresponding comprehension questions
      // There are four conditions.
      //

      [["e.subj.comp.nr",1], "DashedSentence",{s:["Those","federal","prison","wardens,","who","harshly","reprimanded","Andy","today,","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",1], "DashedSentence",{s:["Those","wardens,","who","harshly","reprimanded","Andy","today,","admitted","the error."]}, "Question",{q: "Was it those wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",1], "DashedSentence",{s:["Those","federal","prison","wardens,","who","Andy","harshly","reprimanded","today,","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",1], "DashedSentence",{s:["Those","wardens,","who","Andy","harshly","reprimanded","today,","admitted","the error."]}, "Question",{q: "Was it those wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",1], "DashedSentence",{s:["Those","federal","prison","wardens","who","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",1], "DashedSentence",{s:["Those","wardens","who","harshly","reprimanded","Andy","today","admitted","the error."]}, "Question",{q: "Was it those wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",1], "DashedSentence",{s:["Those","federal","prison","wardens","who","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those federal prison wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",1], "DashedSentence",{s:["Those","wardens","who","Andy","harshly","reprimanded","today","admitted","the error."]}, "Question",{q: "Was it those wardens who reprimanded Andy?", as :["yes","no"], hasCorrect: 1}],

      [["e.subj.comp.nr",2], "DashedSentence",{s:["Those","condemned","political","prisoners,","who","accidentally","angered","Amy","yesterday,","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",2], "DashedSentence",{s:["Those","prisoners,","who","accidentally","angered","Amy","yesterday,","escaped","the compound."]}, "Question",{q: "Was it those prisoners who angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",2], "DashedSentence",{s:["Those","condemned","political","prisoners,","who","Amy","accidentally","angered","yesterday,","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who angered Amy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",2], "DashedSentence",{s:["Those","prisoners,","who","Amy","accidentally","angered","yesterday,","escaped","the compound."]}, "Question",{q: "Was it those prisoners who angered Amy?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",2], "DashedSentence",{s:["Those","condemned","political","prisoners","who","accidentally","angered","Amy","yesterday","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",2], "DashedSentence",{s:["Those","prisoners","who","accidentally","angered","Amy","yesterday","escaped","the compound."]}, "Question",{q: "Was it those prisoners who angered Amy?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",2], "DashedSentence",{s:["Those","condemned","political","prisoners","who","Amy","accidentally","angered","yesterday","escaped","the compound."]}, "Question",{q: "Was it those condemned political prisoners who angered Amy?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",2], "DashedSentence",{s:["Those","prisoners","who","Amy","accidentally","angered","yesterday","escaped","the compound."]}, "Question",{q: "Was it those prisoners who angered Amy?", as :["yes","no"], hasCorrect: 1}],
      
      [["e.subj.comp.nr",3], "DashedSentence",{s:["Those","experienced","stage","choreographers,","who","warmly","encouraged","Ben","last night,","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",3], "DashedSentence",{s:["Those","choreographers,","who","warmly","encouraged","Ben","last night,","created","the routine."]}, "Question",{q: "Was it those choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",3], "DashedSentence",{s:["Those","experienced","stage","choreographers,","who","Ben","warmly","encouraged","last night,","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",3], "DashedSentence",{s:["Those","choreographers,","who","Ben","warmly","encouraged","last night,","created","the routine."]}, "Question",{q: "Was it those choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",3], "DashedSentence",{s:["Those","experienced","stage","choreographers","who","warmly","encouraged","Ben","last night","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",3], "DashedSentence",{s:["Those","choreographers","who","warmly","encouraged","Ben","last night","created","the routine."]}, "Question",{q: "Was it those choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",3], "DashedSentence",{s:["Those","experienced","stage","choreographers","who","Ben","warmly","encouraged","last night","created","the routine."]}, "Question",{q: "Was it those experienced stage choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",3], "DashedSentence",{s:["Those","choreographers","who","Ben","warmly","encouraged","last night","created","the routine."]}, "Question",{q: "Was it those choreographers who encouraged Ben?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",4], "DashedSentence",{s:["Those","sleazy","car","salespeople,","who","deviously","tricked","Luke","this morning,","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",4], "DashedSentence",{s:["Those","salespeople,","who","deviously","tricked","Luke","this morning,","left","the company."]}, "Question",{q: "Was it those salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",4], "DashedSentence",{s:["Those","sleazy","car","salespeople,","who","Luke","deviously","tricked","this morning,","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",4], "DashedSentence",{s:["Those","salespeople,","who","Luke","deviously","tricked","this morning,","left","the company."]}, "Question",{q: "Was it those salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",4], "DashedSentence",{s:["Those","sleazy","car","salespeople","who","deviously","tricked","Luke","this morning","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",4], "DashedSentence",{s:["Those","salespeople","who","deviously","tricked","Luke","this morning","left","the company."]}, "Question",{q: "Was it those salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",4], "DashedSentence",{s:["Those","sleazy","car","salespeople","who","Luke","deviously","tricked","this morning","left","the company."]}, "Question",{q: "Was it those sleazy car salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",4], "DashedSentence",{s:["Those","salespeople","who","Luke","deviously","tricked","this morning","left","the company."]}, "Question",{q: "Was it those salespeople who tricked Luke?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",5], "DashedSentence",{s:["Those","graceful","ballet","dancers,","who","wholeheartedly","praised","Kevin","this afternoon,","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",5], "DashedSentence",{s:["Those","dancers,","who","wholeheartedly","praised","Kevin","this afternoon,","won","the competition."]}, "Question",{q: "Was it those dancers who praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",5], "DashedSentence",{s:["Those","graceful","ballet","dancers,","who","Kevin","wholeheartedly","praised","this afternoon,","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who praised Kevin?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",5], "DashedSentence",{s:["Those","dancers,","who","Kevin","wholeheartedly","praised","this afternoon,","won","the competition."]}, "Question",{q: "Was it those dancers who praised Kevin?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",5], "DashedSentence",{s:["Those","graceful","ballet","dancers","who","wholeheartedly","praised","Kevin","this afternoon","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",5], "DashedSentence",{s:["Those","dancers","who","wholeheartedly","praised","Kevin","this afternoon","won","the competition."]}, "Question",{q: "Was it those dancers who praised Kevin?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",5], "DashedSentence",{s:["Those","graceful","ballet","dancers","who","Kevin","wholeheartedly","praised","this afternoon","won","the competition."]}, "Question",{q: "Was it those graceful ballet dancers who praised Kevin?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",5], "DashedSentence",{s:["Those","dancers","who","Kevin","wholeheartedly","praised","this afternoon","won","the competition."]}, "Question",{q: "Was it those dancers who praised Kevin?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",6], "DashedSentence",{s:["Those","wounded","American","soldiers,","who","graciously","commended","Leah","this evening,","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",6], "DashedSentence",{s:["Those","soldiers,","who","graciously","commended","Leah","this evening,","organized","the march."]}, "Question",{q: "Was it those soldiers who commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",6], "DashedSentence",{s:["Those","wounded","American","soldiers,","who","Leah","graciously","commended","this evening,","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who commended Leah?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",6], "DashedSentence",{s:["Those","soldiers,","who","Leah","graciously","commended","this evening,","organized","the march."]}, "Question",{q: "Was it those soldiers who commended Leah?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",6], "DashedSentence",{s:["Those","wounded","American","soldiers","who","graciously","commended","Leah","this evening","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",6], "DashedSentence",{s:["Those","soldiers","who","graciously","commended","Leah","this evening","organized","the march."]}, "Question",{q: "Was it those soldiers who commended Leah?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",6], "DashedSentence",{s:["Those","wounded","American","soldiers","who","Leah","graciously","commended","this evening","organized","the march."]}, "Question",{q: "Was it those wounded American soldiers who commended Leah?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",6], "DashedSentence",{s:["Those","soldiers","who","Leah","graciously","commended","this evening","organized","the march."]}, "Question",{q: "Was it those soldiers who commended Leah?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians,","who","thoroughly","entertained","Jack","tonight,","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",7], "DashedSentence",{s:["Those","comedians,","who","thoroughly","entertained","Jack","tonight,","sold","the tickets."]}, "Question",{q: "Was it those comedians who entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians,","who","Jack","thoroughly","entertained","tonight,","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who entertained Jack?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",7], "DashedSentence",{s:["Those","comedians,","who","Jack","thoroughly","entertained","tonight,","sold","the tickets."]}, "Question",{q: "Was it those comedians who entertained Jack?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians","who","thoroughly","entertained","Jack","tonight","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",7], "DashedSentence",{s:["Those","comedians","who","thoroughly","entertained","Jack","tonight","sold","the tickets."]}, "Question",{q: "Was it those comedians who entertained Jack?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",7], "DashedSentence",{s:["Those","hilarious","stand-up","comedians","who","Jack","thoroughly","entertained","tonight","sold","the tickets."]}, "Question",{q: "Was it those hilarious stand-up comedians who entertained Jack?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",7], "DashedSentence",{s:["Those","comedians","who","Jack","thoroughly","entertained","tonight","sold","the tickets."]}, "Question",{q: "Was it those comedians who entertained Jack?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",8], "DashedSentence",{s:["Those","emotional","crash","survivors,","who","dutifully","assisted","Sophia","last week,","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",8], "DashedSentence",{s:["Those","survivors,","who","dutifully","assisted","Sophia","last week,","joined","the meeting."]}, "Question",{q: "Was it those survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",8], "DashedSentence",{s:["Those","emotional","crash","survivors,","who","Sophia","dutifully","assisted","last week,","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",8], "DashedSentence",{s:["Those","survivors,","who","Sophia","dutifully","assisted","last week,","joined","the meeting."]}, "Question",{q: "Was it those survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",8], "DashedSentence",{s:["Those","emotional","crash","survivors","who","dutifully","assisted","Sophia","last week","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",8], "DashedSentence",{s:["Those","survivors","who","dutifully","assisted","Sophia","last week","joined","the meeting."]}, "Question",{q: "Was it those survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",8], "DashedSentence",{s:["Those","emotional","crash","survivors","who","Sophia","dutifully","assisted","last week","joined","the meeting."]}, "Question",{q: "Was it those emotional crash survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",8], "DashedSentence",{s:["Those","survivors","who","Sophia","dutifully","assisted","last week","joined","the meeting."]}, "Question",{q: "Was it those survivors who assisted Sophia?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks,","who","loyally","aided","Matthew","on Monday,","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",9], "DashedSentence",{s:["Those","monks,","who","loyally","aided","Matthew","on Monday,","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks,","who","Matthew","loyally","aided","on Monday,","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",9], "DashedSentence",{s:["Those","monks,","who","Matthew","loyally","aided","on Monday,","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those monks?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks","who","loyally","aided","Matthew","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",9], "DashedSentence",{s:["Those","monks","who","loyally","aided","Matthew","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those monks?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",9], "DashedSentence",{s:["Those","peaceful","Buddhist","monks","who","Matthew","loyally","aided","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those peaceful Buddhist monks?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",9], "DashedSentence",{s:["Those","monks","who","Matthew","loyally","aided","on Monday","repeated","the chants."]}, "Question",{q: "Was it Matthew who was aided by those monks?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",10], "DashedSentence",{s:["Those","conservative","US","senators,","who","carefully","interrogated","Tom","on Tuesday,","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",10], "DashedSentence",{s:["Those","senators,","who","carefully","interrogated","Tom","on Tuesday,","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",10], "DashedSentence",{s:["Those","conservative","US","senators,","who","Tom","carefully","interrogated","on Tuesday,","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",10], "DashedSentence",{s:["Those","senators,","who","Tom","carefully","interrogated","on Tuesday,","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those senators?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",10], "DashedSentence",{s:["Those","conservative","US","senators","who","carefully","interrogated","Tom","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",10], "DashedSentence",{s:["Those","senators","who","carefully","interrogated","Tom","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those senators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",10], "DashedSentence",{s:["Those","conservative","US","senators","who","Tom","carefully","interrogated","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those conservative US senators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",10], "DashedSentence",{s:["Those","senators","who","Tom","carefully","interrogated","on Tuesday","wrote","the bill."]}, "Question",{q: "Was it Tom who was interrogated by those senators?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",11], "DashedSentence",{s:["Those","victorious","four-star","generals,","who","profusely","thanked","Stephanie","on Wednesday,","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",11], "DashedSentence",{s:["Those","generals,","who","profusely","thanked","Stephanie","on Wednesday,","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",11], "DashedSentence",{s:["Those","victorious","four-star","generals,","who","Stephanie","profusely","thanked","on Wednesday,","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",11], "DashedSentence",{s:["Those","generals,","who","Stephanie","profusely","thanked","on Wednesday,","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those generals?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",11], "DashedSentence",{s:["Those","victorious","four-star","generals","who","profusely","thanked","Stephanie","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",11], "DashedSentence",{s:["Those","generals","who","profusely","thanked","Stephanie","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those generals?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",11], "DashedSentence",{s:["Those","victorious","four-star","generals","who","Stephanie","profusely","thanked","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those victorious four-star generals?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",11], "DashedSentence",{s:["Those","generals","who","Stephanie","profusely","thanked","on Wednesday","signed","the treaty."]}, "Question",{q: "Was it Stephanie who was thanked by those generals?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",12], "DashedSentence",{s:["Those","struggling","rock","musicians,","who","reluctantly","helped","Becky","on Thursday,","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",12], "DashedSentence",{s:["Those","musicians,","who","reluctantly","helped","Becky","on Thursday,","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",12], "DashedSentence",{s:["Those","struggling","rock","musicians,","who","Becky","reluctantly","helped","on Thursday,","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",12], "DashedSentence",{s:["Those","musicians,","who","Becky","reluctantly","helped","on Thursday,","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those musicians?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",12], "DashedSentence",{s:["Those","struggling","rock","musicians","who","reluctantly","helped","Becky","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",12], "DashedSentence",{s:["Those","musicians","who","reluctantly","helped","Becky","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those musicians?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",12], "DashedSentence",{s:["Those","struggling","rock","musicians","who","Becky","reluctantly","helped","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those struggling rock musicians?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",12], "DashedSentence",{s:["Those","musicians","who","Becky","reluctantly","helped","on Thursday","performed","the song."]}, "Question",{q: "Was it Becky who was helped by those musicians?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices,","who","vehemently","accused","Ellen","on Friday,","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",13], "DashedSentence",{s:["Those","accomplices,","who","vehemently","accused","Ellen","on Friday,","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices,","who","Ellen","vehemently","accused","on Friday,","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",13], "DashedSentence",{s:["Those","accomplices,","who","Ellen","vehemently","accused","on Friday,","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those accomplices?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices","who","vehemently","accused","Ellen","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",13], "DashedSentence",{s:["Those","accomplices","who","vehemently","accused","Ellen","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those accomplices?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",13], "DashedSentence",{s:["Those","alleged","bombing","accomplices","who","Ellen","vehemently","accused","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those alleged bombing accomplices?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",13], "DashedSentence",{s:["Those","accomplices","who","Ellen","vehemently","accused","on Friday","accepted","the charges."]}, "Question",{q: "Was it Ellen who was accused by those accomplices?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",14], "DashedSentence",{s:["Those","undercover","federal","agents,","who","secretly","confronted","Anna","on Saturday,","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",14], "DashedSentence",{s:["Those","agents,","who","secretly","confronted","Anna","on Saturday,","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",14], "DashedSentence",{s:["Those","undercover","federal","agents,","who","Anna","secretly","confronted","on Saturday,","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",14], "DashedSentence",{s:["Those","agents,","who","Anna","secretly","confronted","on Saturday,","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those agents?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",14], "DashedSentence",{s:["Those","undercover","federal","agents","who","secretly","confronted","Anna","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",14], "DashedSentence",{s:["Those","agents","who","secretly","confronted","Anna","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those agents?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",14], "DashedSentence",{s:["Those","undercover","federal","agents","who","Anna","secretly","confronted","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those undercover federal agents?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",14], "DashedSentence",{s:["Those","agents","who","Anna","secretly","confronted","on Saturday","refused","the deal."]}, "Question",{q: "Was it Anna who was confronted by those agents?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",15], "DashedSentence",{s:["Those","celebrity","hair","stylists,","who","hesitantly","hired","Teddy","on Sunday,","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",15], "DashedSentence",{s:["Those","stylists,","who","hesitantly","hired","Teddy","on Sunday,","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",15], "DashedSentence",{s:["Those","celebrity","hair","stylists,","who","Teddy","hesitantly","hired","on Sunday,","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",15], "DashedSentence",{s:["Those","stylists,","who","Teddy","hesitantly","hired","on Sunday,","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those stylists?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",15], "DashedSentence",{s:["Those","celebrity","hair","stylists","who","hesitantly","hired","Teddy","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",15], "DashedSentence",{s:["Those","stylists","who","hesitantly","hired","Teddy","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those stylists?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",15], "DashedSentence",{s:["Those","celebrity","hair","stylists","who","Teddy","hesitantly","hired","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those celebrity hair stylists?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",15], "DashedSentence",{s:["Those","stylists","who","Teddy","hesitantly","hired","on Sunday","closed","the store."]}, "Question",{q: "Was it Teddy who was hired by those stylists?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",16], "DashedSentence",{s:["Those","renowned","fashion","designers,","who","snidely","belittled","Alex","today,","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.nr",16], "DashedSentence",{s:["Those","designers,","who","snidely","belittled","Alex","today,","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.nr",16], "DashedSentence",{s:["Those","renowned","fashion","designers,","who","Alex","snidely","belittled","today,","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.nr",16], "DashedSentence",{s:["Those","designers,","who","Alex","snidely","belittled","today,","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those designers?", as :["yes","no"], hasCorrect: 1}],
      [["e.subj.comp.r",16], "DashedSentence",{s:["Those","renowned","fashion","designers","who","snidely","belittled","Alex","today","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.subj.simp.r",16], "DashedSentence",{s:["Those","designers","who","snidely","belittled","Alex","today","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those designers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.comp.r",16], "DashedSentence",{s:["Those","renowned","fashion","designers","who","Alex","snidely","belittled","today","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those renowned fashion designers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.simp.r",16], "DashedSentence",{s:["Those","designers","who","Alex","snidely","belittled","today","designed","the costume."]}, "Question",{q: "Was it Alex who was belittled by those designers?", as :["yes","no"], hasCorrect: 1}],
    
      [["e.subj.comp.nr",17], "DashedSentence",{s:["Those","senior","electrical","engineers,","who","affectionately","mentored","Zack","yesterday,","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",17], "DashedSentence",{s:["Those","engineers,","who","affectionately","mentored","Zack","yesterday,","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",17], "DashedSentence",{s:["Those","senior","electrical","engineers,","who","Zack","affectionately","mentored","yesterday,","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",17], "DashedSentence",{s:["Those","engineers,","who","Zack","affectionately","mentored","yesterday,","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those engineers?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",17], "DashedSentence",{s:["Those","senior","electrical","engineers","who","affectionately","mentored","Zack","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",17], "DashedSentence",{s:["Those","engineers","who","affectionately","mentored","Zack","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those engineers?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",17], "DashedSentence",{s:["Those","senior","electrical","engineers","who","Zack","affectionately","mentored","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those senior electrical engineers?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",17], "DashedSentence",{s:["Those","engineers","who","Zack","affectionately","mentored","yesterday","fixed","the machine."]}, "Question",{q: "Was it Zack who mentored those engineers?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",18], "DashedSentence",{s:["Those","famous","young","actors,","who","caringly","guided","Madeline","last night,","read","the script."]}, "Question",{q: "Was it Madeline who guided those famous young actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",18], "DashedSentence",{s:["Those","actors,","who","caringly","guided","Madeline","last night,","read","the script."]}, "Question",{q: "Was it Madeline who guided those actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",18], "DashedSentence",{s:["Those","famous","young","actors,","who","Madeline","caringly","guided","last night,","read","the script."]}, "Question",{q: "Was it Madeline who guided those famous young actors?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",18], "DashedSentence",{s:["Those","actors,","who","Madeline","caringly","guided","last night,","read","the script."]}, "Question",{q: "Was it Madeline who guided those actors?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",18], "DashedSentence",{s:["Those","famous","young","actors","who","caringly","guided","Madeline","last night","read","the script."]}, "Question",{q: "Was it Madeline who guided those famous young actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",18], "DashedSentence",{s:["Those","actors","who","caringly","guided","Madeline","last night","read","the script."]}, "Question",{q: "Was it Madeline who guided those actors?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",18], "DashedSentence",{s:["Those","famous","young","actors","who","Madeline","caringly","guided","last night","read","the script."]}, "Question",{q: "Was it Madeline who guided those famous young actors?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",18], "DashedSentence",{s:["Those","actors","who","Madeline","caringly","guided","last night","read","the script."]}, "Question",{q: "Was it Madeline who guided those actors?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters,","who","ruthlessly","drilled","Sasha","this morning,","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",19], "DashedSentence",{s:["Those","reporters,","who","ruthlessly","drilled","Sasha","this morning,","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters,","who","Sasha","ruthlessly","drilled","this morning,","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",19], "DashedSentence",{s:["Those","reporters,","who","Sasha","ruthlessly","drilled","this morning,","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those reporters?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters","who","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",19], "DashedSentence",{s:["Those","reporters","who","ruthlessly","drilled","Sasha","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those reporters?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",19], "DashedSentence",{s:["Those","hard-nosed","newspaper","reporters","who","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those hard-nosed newspaper reporters?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",19], "DashedSentence",{s:["Those","reporters","who","Sasha","ruthlessly","drilled","this morning","attended","the game."]}, "Question",{q: "Was it Sasha who drilled those reporters?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities,","who","continuously","questioned","Fiona","this afternoon,","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",20], "DashedSentence",{s:["Those","celebrities,","who","continuously","questioned","Fiona","this afternoon,","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities,","who","Fiona","continuously","questioned","this afternoon,","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",20], "DashedSentence",{s:["Those","celebrities,","who","Fiona","continuously","questioned","this afternoon,","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those celebrities?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities","who","continuously","questioned","Fiona","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",20], "DashedSentence",{s:["Those","celebrities","who","continuously","questioned","Fiona","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those celebrities?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",20], "DashedSentence",{s:["Those","wealthy","teen","celebrities","who","Fiona","continuously","questioned","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those wealthy teen celebrities?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",20], "DashedSentence",{s:["Those","celebrities","who","Fiona","continuously","questioned","this afternoon","wasted","the money."]}, "Question",{q: "Was it Fiona who questioned those celebrities?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",21], "DashedSentence",{s:["Those","corrupt","homicide","cops,","who","aggressively","accosted","Ivan","this evening,","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",21], "DashedSentence",{s:["Those","cops,","who","aggressively","accosted","Ivan","this evening,","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",21], "DashedSentence",{s:["Those","corrupt","homicide","cops,","who","Ivan","aggressively","accosted","this evening,","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",21], "DashedSentence",{s:["Those","cops,","who","Ivan","aggressively","accosted","this evening,","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those cops?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",21], "DashedSentence",{s:["Those","corrupt","homicide","cops","who","aggressively","accosted","Ivan","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",21], "DashedSentence",{s:["Those","cops","who","aggressively","accosted","Ivan","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those cops?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",21], "DashedSentence",{s:["Those","corrupt","homicide","cops","who","Ivan","aggressively","accosted","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those corrupt homicide cops?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",21], "DashedSentence",{s:["Those","cops","who","Ivan","aggressively","accosted","this evening","issued","the statement."]}, "Question",{q: "Was it Ivan who accosted those cops?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",22], "DashedSentence",{s:["Those","ruthless","military","dictators,","who","intentionally","ignored","Isaac","tonight,","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",22], "DashedSentence",{s:["Those","dictators,","who","intentionally","ignored","Isaac","tonight,","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",22], "DashedSentence",{s:["Those","ruthless","military","dictators,","who","Isaac","intentionally","ignored","tonight,","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",22], "DashedSentence",{s:["Those","dictators,","who","Isaac","intentionally","ignored","tonight,","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those dictators?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",22], "DashedSentence",{s:["Those","ruthless","military","dictators","who","intentionally","ignored","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",22], "DashedSentence",{s:["Those","dictators","who","intentionally","ignored","Isaac","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those dictators?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",22], "DashedSentence",{s:["Those","ruthless","military","dictators","who","Isaac","intentionally","ignored","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those ruthless military dictators?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",22], "DashedSentence",{s:["Those","dictators","who","Isaac","intentionally","ignored","tonight","skipped","the hearing."]}, "Question",{q: "Was it Isaac who ignored those dictators?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",23], "DashedSentence",{s:["Those","hardworking","factory","employees,","who","brutally","berated","Alma","last week,","finished","the project."]}, "Question",{q: "Was it Alma who berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",23], "DashedSentence",{s:["Those","employees,","who","brutally","berated","Alma","last week,","finished","the project."]}, "Question",{q: "Was it Alma who berated those employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",23], "DashedSentence",{s:["Those","hardworking","factory","employees,","who","Alma","brutally","berated","last week,","finished","the project."]}, "Question",{q: "Was it Alma who berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",23], "DashedSentence",{s:["Those","employees,","who","Alma","brutally","berated","last week,","finished","the project."]}, "Question",{q: "Was it Alma who berated those employees?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",23], "DashedSentence",{s:["Those","hardworking","factory","employees","who","brutally","berated","Alma","last week","finished","the project."]}, "Question",{q: "Was it Alma who berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",23], "DashedSentence",{s:["Those","employees","who","brutally","berated","Alma","last week","finished","the project."]}, "Question",{q: "Was it Alma who berated those employees?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",23], "DashedSentence",{s:["Those","hardworking","factory","employees","who","Alma","brutally","berated","last week","finished","the project."]}, "Question",{q: "Was it Alma who berated those hardworking factory employees?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",23], "DashedSentence",{s:["Those","employees","who","Alma","brutally","berated","last week","finished","the project."]}, "Question",{q: "Was it Alma who berated those employees?", as :["yes","no"], hasCorrect: 0}],
      
      [["e.subj.comp.nr",24], "DashedSentence",{s:["Those","cable","news","analysts,","who","purposely","neglected","Ian","on Monday,","published","the article."]}, "Question",{q: "Was it Ian who neglected those cable news analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",24], "DashedSentence",{s:["Those","analysts,","who","purposely","neglected","Ian","on Monday,","published","the article."]}, "Question",{q: "Was it Ian who neglected those analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",24], "DashedSentence",{s:["Those","cable","news","analysts,","who","Ian","purposely","neglected","on Monday,","published","the article."]}, "Question",{q: "Was it Ian who neglected those cable news analysts?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",24], "DashedSentence",{s:["Those","analysts,","who","Ian","purposely","neglected","on Monday,","published","the article."]}, "Question",{q: "Was it Ian who neglected those analysts?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",24], "DashedSentence",{s:["Those","cable","news","analysts","who","purposely","neglected","Ian","on Monday","published","the article."]}, "Question",{q: "Was it Ian who neglected those cable news analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",24], "DashedSentence",{s:["Those","analysts","who","purposely","neglected","Ian","on Monday","published","the article."]}, "Question",{q: "Was it Ian who neglected those analysts?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",24], "DashedSentence",{s:["Those","cable","news","analysts","who","Ian","purposely","neglected","on Monday","published","the article."]}, "Question",{q: "Was it Ian who neglected those cable news analysts?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",24], "DashedSentence",{s:["Those","analysts","who","Ian","purposely","neglected","on Monday","published","the article."]}, "Question",{q: "Was it Ian who neglected those analysts?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates,","who","cordially","welcomed","Rosie","on Tuesday,","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",25], "DashedSentence",{s:["Those","candidates,","who","cordially","welcomed","Rosie","on Tuesday,","threw","the party."]}, "Question",{q: "Was it those candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates,","who","Rosie","cordially","welcomed","on Tuesday,","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",25], "DashedSentence",{s:["Those","candidates,","who","Rosie","cordially","welcomed","on Tuesday,","threw","the party."]}, "Question",{q: "Was it those candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates","who","cordially","welcomed","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",25], "DashedSentence",{s:["Those","candidates","who","cordially","welcomed","Rosie","on Tuesday","threw","the party."]}, "Question",{q: "Was it those candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",25], "DashedSentence",{s:["Those","liberal","mayoral","candidates","who","Rosie","cordially","welcomed","on Tuesday","threw","the party."]}, "Question",{q: "Was it those liberal mayoral candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",25], "DashedSentence",{s:["Those","candidates","who","Rosie","cordially","welcomed","on Tuesday","threw","the party."]}, "Question",{q: "Was it those candidates who were welcomed by Rosie?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",26], "DashedSentence",{s:["Those","rich","European","tourists,","who","blindly","followed","Isabella","on Wednesday,","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",26], "DashedSentence",{s:["Those","tourists,","who","blindly","followed","Isabella","on Wednesday,","took","the photographs."]}, "Question",{q: "Was it those tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",26], "DashedSentence",{s:["Those","rich","European","tourists,","who","Isabella","blindly","followed","on Wednesday,","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",26], "DashedSentence",{s:["Those","tourists,","who","Isabella","blindly","followed","on Wednesday,","took","the photographs."]}, "Question",{q: "Was it those tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",26], "DashedSentence",{s:["Those","rich","European","tourists","who","blindly","followed","Isabella","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",26], "DashedSentence",{s:["Those","tourists","who","blindly","followed","Isabella","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",26], "DashedSentence",{s:["Those","rich","European","tourists","who","Isabella","blindly","followed","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those rich European tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",26], "DashedSentence",{s:["Those","tourists","who","Isabella","blindly","followed","on Wednesday","took","the photographs."]}, "Question",{q: "Was it those tourists who were followed by Isabella?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",27], "DashedSentence",{s:["Those","powerful","business","executives,","who","diligently","instructed","Jessica","on Thursday,","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",27], "DashedSentence",{s:["Those","executives,","who","diligently","instructed","Jessica","on Thursday,","hosted","the lunch."]}, "Question",{q: "Was it those executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",27], "DashedSentence",{s:["Those","powerful","business","executives,","who","Jessica","diligently","instructed","on Thursday,","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",27], "DashedSentence",{s:["Those","executives,","who","Jessica","diligently","instructed","on Thursday,","hosted","the lunch."]}, "Question",{q: "Was it those executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",27], "DashedSentence",{s:["Those","powerful","business","executives","who","diligently","instructed","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",27], "DashedSentence",{s:["Those","executives","who","diligently","instructed","Jessica","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",27], "DashedSentence",{s:["Those","powerful","business","executives","who","Jessica","diligently","instructed","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those powerful business executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",27], "DashedSentence",{s:["Those","executives","who","Jessica","diligently","instructed","on Thursday","hosted","the lunch."]}, "Question",{q: "Was it those executives who were instructed by Jessica?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",28], "DashedSentence",{s:["Those","influential","legal","advisors,","who","meticulously","counseled","Tess","on Friday,","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",28], "DashedSentence",{s:["Those","advisors,","who","meticulously","counseled","Tess","on Friday,","donated","the fund."]}, "Question",{q: "Was it those advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",28], "DashedSentence",{s:["Those","influential","legal","advisors,","who","Tess","meticulously","counseled","on Friday,","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",28], "DashedSentence",{s:["Those","advisors,","who","Tess","meticulously","counseled","on Friday,","donated","the fund."]}, "Question",{q: "Was it those advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",28], "DashedSentence",{s:["Those","influential","legal","advisors","who","meticulously","counseled","Tess","on Friday","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",28], "DashedSentence",{s:["Those","advisors","who","meticulously","counseled","Tess","on Friday","donated","the fund."]}, "Question",{q: "Was it those advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",28], "DashedSentence",{s:["Those","influential","legal","advisors","who","Tess","meticulously","counseled","on Friday","donated","the fund."]}, "Question",{q: "Was it those influential legal advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",28], "DashedSentence",{s:["Those","advisors","who","Tess","meticulously","counseled","on Friday","donated","the fund."]}, "Question",{q: "Was it those advisors who were counseled by Tess?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",29], "DashedSentence",{s:["Those","angry","taxi","drivers,","who","viciously","attacked","Keith","on Saturday,","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",29], "DashedSentence",{s:["Those","drivers,","who","viciously","attacked","Keith","on Saturday,","fled","the scene."]}, "Question",{q: "Was it those drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",29], "DashedSentence",{s:["Those","angry","taxi","drivers,","who","Keith","viciously","attacked","on Saturday,","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",29], "DashedSentence",{s:["Those","drivers,","who","Keith","viciously","attacked","on Saturday,","fled","the scene."]}, "Question",{q: "Was it those drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",29], "DashedSentence",{s:["Those","angry","taxi","drivers","who","viciously","attacked","Keith","on Saturday","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",29], "DashedSentence",{s:["Those","drivers","who","viciously","attacked","Keith","on Saturday","fled","the scene."]}, "Question",{q: "Was it those drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",29], "DashedSentence",{s:["Those","angry","taxi","drivers","who","Keith","viciously","attacked","on Saturday","fled","the scene."]}, "Question",{q: "Was it those angry taxi drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",29], "DashedSentence",{s:["Those","drivers","who","Keith","viciously","attacked","on Saturday","fled","the scene."]}, "Question",{q: "Was it those drivers who were attacked by Keith?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",30], "DashedSentence",{s:["Those","helpful","new","assistants,","who","calmly","ushered","Simon","on Sunday,","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",30], "DashedSentence",{s:["Those","assistants,","who","calmly","ushered","Simon","on Sunday,","decorated","the office."]}, "Question",{q: "Was it those assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",30], "DashedSentence",{s:["Those","helpful","new","assistants,","who","Simon","calmly","ushered","on Sunday,","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",30], "DashedSentence",{s:["Those","assistants,","who","Simon","calmly","ushered","on Sunday,","decorated","the office."]}, "Question",{q: "Was it those assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",30], "DashedSentence",{s:["Those","helpful","new","assistants","who","calmly","ushered","Simon","on Sunday","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",30], "DashedSentence",{s:["Those","assistants","who","calmly","ushered","Simon","on Sunday","decorated","the office."]}, "Question",{q: "Was it those assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",30], "DashedSentence",{s:["Those","helpful","new","assistants","who","Simon","calmly","ushered","on Sunday","decorated","the office."]}, "Question",{q: "Was it those helpful new assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",30], "DashedSentence",{s:["Those","assistants","who","Simon","calmly","ushered","on Sunday","decorated","the office."]}, "Question",{q: "Was it those assistants who were ushered by Simon?", as :["yes","no"], hasCorrect: 0}],
      
      [["e.subj.comp.nr",31], "DashedSentence",{s:["Those","dying","elderly","patients,","who","lovingly","comforted","Elena","today,","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",31], "DashedSentence",{s:["Those","patients,","who","lovingly","comforted","Elena","today,","received","the vaccine."]}, "Question",{q: "Was it those patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",31], "DashedSentence",{s:["Those","dying","elderly","patients,","who","Elena","lovingly","comforted","today,","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",31], "DashedSentence",{s:["Those","patients,","who","Elena","lovingly","comforted","today,","received","the vaccine."]}, "Question",{q: "Was it those patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",31], "DashedSentence",{s:["Those","dying","elderly","patients","who","lovingly","comforted","Elena","today","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",31], "DashedSentence",{s:["Those","patients","who","lovingly","comforted","Elena","today","received","the vaccine."]}, "Question",{q: "Was it those patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",31], "DashedSentence",{s:["Those","dying","elderly","patients","who","Elena","lovingly","comforted","today","received","the vaccine."]}, "Question",{q: "Was it those dying elderly patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",31], "DashedSentence",{s:["Those","patients","who","Elena","lovingly","comforted","today","received","the vaccine."]}, "Question",{q: "Was it those patients who were comforted by Elena?", as :["yes","no"], hasCorrect: 0}],
    
      [["e.subj.comp.nr",32], "DashedSentence",{s:["Those","trained","hospice","nurses,","who","painstakingly","watched","Aliza","yesterday,","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.nr",32], "DashedSentence",{s:["Those","nurses,","who","painstakingly","watched","Aliza","yesterday,","reached","the hospital."]}, "Question",{q: "Was it those nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.nr",32], "DashedSentence",{s:["Those","trained","hospice","nurses,","who","Aliza","painstakingly","watched","yesterday,","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.nr",32], "DashedSentence",{s:["Those","nurses,","who","Aliza","painstakingly","watched","yesterday,","reached","the hospital."]}, "Question",{q: "Was it those nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 0}],
      [["e.subj.comp.r",32], "DashedSentence",{s:["Those","trained","hospice","nurses","who","painstakingly","watched","Aliza","yesterday","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.subj.simp.r",32], "DashedSentence",{s:["Those","nurses","who","painstakingly","watched","Aliza","yesterday","reached","the hospital."]}, "Question",{q: "Was it those nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 1}], 
      [["e.obj.comp.r",32], "DashedSentence",{s:["Those","trained","hospice","nurses","who","Aliza","painstakingly","watched","yesterday","reached","the hospital."]}, "Question",{q: "Was it those trained hospice nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 0}], 
      [["e.obj.simp.r",32], "DashedSentence",{s:["Those","nurses","who","Aliza","painstakingly","watched","yesterday","reached","the hospital."]}, "Question",{q: "Was it those nurses who were watched by Aliza?", as :["yes","no"], hasCorrect: 0}],
     
      //
      // 32 self-paced-reading filler sentences with question.
      //

      ["filler.A.1", "DashedSentence",{s:["It was","those consumers","who","begrudgingly","contacted","Jack","last night."]}, "Question",{q: "Was it those consumers who contacted Jack?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.2", "DashedSentence",{s:["It was","those landlords","who","generously","paid","Ariana","this morning."]}, "Question",{q: "Was it Ariana who was paid by those landlords?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.3", "DashedSentence",{s:["It was","those builders","who","contentedly","contracted","Grant","this afternoon."]}, "Question",{q: "Was it Grant who contracted those builders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.4", "DashedSentence",{s:["It was","those administrators","who","devotedly","obeyed","Anne","this evening."]}, "Question",{q: "Was it those administrators who were obeyed by Anne?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.5", "DashedSentence",{s:["It was","those marathoners","who","Juliette","excessively","trained","tonight."]}, "Question",{q: "Was it those marathoners who trained Juliette?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.6", "DashedSentence",{s:["It was","those shareholders","who","William","steadfastly","trusted","last week."]}, "Question",{q: "Was it William who was trusted by those shareholders?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.A.7", "DashedSentence",{s:["It was","those archaeologists","who","Abby","eagerly","protested","on Monday."]}, "Question",{q: "Was it Abby who protested those archaeologists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.A.8", "DashedSentence",{s:["It was","those ministers","who","Katie","constantly","distracted","on Tuesday."]}, "Question",{q: "Was it those ministers who were distracted by Katie?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.B.1", "DashedSentence",{s:["Carlos","believes","that","the fact","that","those writers","beautifully","described","Sergio","this afternoon","was","unprecedented."]}, "Question",{q: "Was it those writers who described Sergio?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.2", "DashedSentence",{s:["Joe","claims","that","the fact","that","those publishers","positively","endorsed","Thomas","this evening","was","rare."]}, "Question",{q: "Was it Thomas who was endorsed by those publishers?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.3", "DashedSentence",{s:["Diego","thinks","that","the fact","that","those chemists","arbitrarily","selected","Luis","tonight","was","unusual."]}, "Question",{q: "Was it Luis who selected those chemists?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.4", "DashedSentence",{s:["Larry","says","that","the fact","that","those planners","carelessly","mocked","Lynn","last week","was","normal."]}, "Question",{q: "Was it those planners who were mocked by Lynn?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.5", "DashedSentence",{s:["Derrick","claims","that","the fact","that","Jacob","negatively","rated","those recruiters","on Monday","was","surprising."]}, "Question",{q: "Was it those recruiters who rated Jacob?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.6", "DashedSentence",{s:["Frank","thinks","that","the fact","that","Terry","surreptitiously","observed","those investigators","on Tuesday","was","astonishing."]}, "Question",{q: "Was it Terry who was observed by those investigators?", as:["yes","no"], hasCorrect: 1}],
      ["filler.B.7", "DashedSentence",{s:["Charlotte","says","that","the fact","that","Kacey","attentively","shadowed","those clinicians","on Wednesday","was","impressive."]}, "Question",{q: "Was it Kacey who shadowed those clinicians?", as:["yes","no"], hasCorrect: 0}],
      ["filler.B.8", "DashedSentence",{s:["Evelyn","believes","that","the fact","that","Blythe","confidently","taught","those artisans","on Thursday","was","bizarre."]}, "Question",{q: "Was it those artisans who were taught by Blythe?", as:["yes","no"], hasCorrect: 0}],
      ["filler.C.1", "DashedSentence",{s:["It was","mind-boggling","that","those florists","nervously","notified","Nick","on Saturday."]}, "Question",{q: "Was it those florists who notified Nick?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.2", "DashedSentence",{s:["It was","uncanny","that","those orthodontists","unconditionally","forgave","Bennet","on Sunday."]}, "Question",{q: "Was it Bennet who was forgiven by those orthodontists?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.3", "DashedSentence",{s:["It was","acceptable","that","those midwives","fearfully","alerted","Bill","today."]}, "Question",{q: "Was it Bill who alerted those midwives?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.4", "DashedSentence",{s:["It was","unacceptable","that","those marines","fiercely","assaulted","Lucas","yesterday."]}, "Question",{q: "Was it those marines who were assaulted by Lucas?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.5", "DashedSentence",{s:["It was","abnormal","that","Sadie","unethically","misinformed","those entrepreneurs","last night."]}, "Question",{q: "Was it those entrepreneurs who misinformed Sadie?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.6", "DashedSentence",{s:["It was","unbelievable","that","Xavier","unconsciously","misled","those captains","this morning."]}, "Question",{q: "Was it Xavier who was misled by those captains?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.C.7", "DashedSentence",{s:["It was","incredible","that","Chad","foolishly","indulged","those cooks","this afternoon."]}, "Question",{q: "Was it Chad who indulged those cooks?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.C.8", "DashedSentence",{s:["It was","mind-blowing","that","Leland","severely","underpaid","those pedicurists","this evening."]}, "Question",{q: "Was it those pedicurists who were underpaid by Leland?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.1", "DashedSentence",{s:["The newspaper","confirmed","that","those senators","mistakenly","exposed","Tabitha","last week."]}, "Question",{q: "Was it those senators who exposed Tabitha?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.2", "DashedSentence",{s:["The article","acknowledged","that","those treasurers","incorrectly","chastised","Preston","on Monday."]}, "Question",{q: "Was it Preston who was chastised by those treasurers?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.3", "DashedSentence",{s:["The show","explained","that","those chancellors","publicly","honored","Sienna","on Tuesday."]}, "Question",{q: "Was it Sienna who honored those chancellors?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.4", "DashedSentence",{s:["The book","demonstrated","that","those landscapers","overtly","defended","Justin","on Wednesday."]}, "Question",{q: "Was it those landscapers who were defended by Justin?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.5", "DashedSentence",{s:["The journal","established","that","Selena","sincerely","complimented","those superintendents","on Thursday."]}, "Question",{q: "Was it those superintendents who complimented Selena?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.6", "DashedSentence",{s:["The evidence","proved","that","Taylor","maliciously","antagonized","those cobblers","on Friday."]}, "Question",{q: "Was it Taylor who was antagonized by those cobblers?", as:["yes","no"], hasCorrect: 1}], 
      ["filler.D.7", "DashedSentence",{s:["The company","recognized","that","Ethan","arrogantly","corrected","those interpreters","on Saturday."]}, "Question",{q: "Was it Ethan who corrected those interpreters?", as:["yes","no"], hasCorrect: 0}], 
      ["filler.D.8", "DashedSentence",{s:["The documentary","revealed","that","Olivia","loudly","lauded","those barbers","on Sunday."]}, "Question",{q: "Was it those barbers who were lauded by Olivia?", as:["yes","no"], hasCorrect: 0}]


];
