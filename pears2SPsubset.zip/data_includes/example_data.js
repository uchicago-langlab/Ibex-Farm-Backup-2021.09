var shuffleSequence = seq("intro", "example_intro", "intro1", shuffle(randomize("SH"), randomize("SP"), randomize("HS"), randomize("PS")));

var defaults = ["Question", {as: ["1", "2", "3", "4", "5", "6", "7"], presentAsScale: true, leftComment: "No Relacionado", rightComment: "Muy Relacionado"}]


var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],

    
    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    //["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

    ["intro", "Form", {
        html: { include: "example_intro.html" },
        validators: {
            age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],
 ["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],

    

["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. pagar con un <b>billete</b> de d&oacute;lar americano </td><td> 2. el <b>billete</b> para volar en avi&oacute;n </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>muestra</b> de arte </td><td> 2. comer una <b>muestra</b> de comida </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. limpiar la <b>taza</b> del ba&ntilde;o </td><td> 2. una <b>taza</b> de caf&eacute; </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. jugo de <b>lima</b> </td><td> 2. una <b>lima</b> para pulir u&ntilde;as </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. llenar la <b>pipa</b> de tabaco </td><td> 2. comer una <b>pipa</b> de girasol </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>goma</b> del l&aacute;piz </td><td> 2. ligar el peri&oacute;dico con una <b>goma</b> </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. medir con una <b>regla</b> </td><td> 2. una <b>regla</b> del juego de f&uacute;tbol </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>t&iacute;tulo</b> del poema </td><td> 2. obtener el <b>t&iacute;tulo</b> de doctor </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. regar las <b>plantas</b> en el jard&iacute;n </td><td> 2. la secunda <b>planta</b> del edificio </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>cura</b> para el SIDA </td><td> 2. el <b>cura</b> en la iglesia </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>bater&iacute;a</b> del carro </td><td> 2. tocar la <b>bater&iacute;a</b> en un grupo de rock </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la puerta al final del <b>corredor</b> </td><td> 2. el <b>corredor</b> gan&oacute; la competencia </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. las vacas comen de una <b>bala</b> de paja </td><td> 2. una pistola y una <b>bala</b> </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la polic&iacute;a pone las <b>esposas</b> al ladr&oacute;n </td><td> 2. los hombres traen a sus <b>esposas</b> </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>cola</b> del caballo </td><td> 2. hacer <b>cola</b> en la tienda </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>lata</b> de leche condensada  </td><td> 2. es una <b>lata</b> limpiar la casa </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. beber agua de la <b>fuente</b> </td><td> 2. el diccionario es una <b>fuente</b> de informaci&oacute;n  </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comerse algunas <b>palomitas</b> durante la pel&iacute;cula </td><td> 2. las <b>palomitas</b> vuelan por la cuidad </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. los hermanos son <b>gemelos</b> </td><td> 2. ponerse los <b>gemelos</b> de plata en el pu&ntilde;o de la camisa </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>pila</b> de libros en el escritorio </td><td> 2. un juguete que usa una <b>pila</b>  </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tener el <b>juego</b> completo de tazas y platos </td><td> 2. los ni&ntilde;os juegan un <b>juego</b> divertido </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. un <b>gato</b> se sienta junto a la ventana </td><td> 2. levantar un coche ustilizando un <b>gato</b> hidr&aacute;ulico </td></tr></table></center>" }],
["SH","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>bomba</b> explot&oacute; afuera </td><td> 2. la <b>bomba</b> llena el tanque de agua  </td></tr></table></center>" }],



["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el dentista examina el <b>diente</b> </td><td> 2. un <b>diente</b> de ajo </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>faro</b> cerca del mar </td><td> 2. el <b>faro</b> izquierdo del coche </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>letra</b> Z </td><td> 2. la <b>letra</b> de la canci&oacute;n </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. descansar en la <b>sombra</b> </td><td> 2. ver pasar una <b>sombra</b> por la ventana </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. dieta baja en <b>grasa</b> </td><td> 2. poner <b>grasa</b> en los frenos del carro </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. escribir la <b>direcci&oacute;n</b> de la casa </td><td> 2. seguir la <b>direcci&oacute;n</b> hacia el norte </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. llegar a su <b>destino</b> por avi&oacute;n </td><td> 2. un <b>destino</b> decidido por Dios </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>historia</b> de las Am&eacute;ricas </td><td> 2. leer una <b>historia</b> a los ni&ntilde;os </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>vista</b> de las monta&ntilde;as </td><td> 2. perder su <b>vista</b> en su vejez </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>corriente</b> en el oc&eacute;ano </td><td> 2. siguen la <b>corriente</b> de la moda </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>caja</b> para empacar libros </td><td> 2. pagar en la <b>caja</b> de la tienda </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. beber zumo de <b>pi&ntilde;a</b> </td><td> 2. la  <b>pi&ntilde;a</b> del pino </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>espina</b> de cactus</td><td> 2. una <b>espina</b> de pescado </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>foco</b> sigui&oacute; el actor por el escenario </td><td> 2. el estudiante cambi&oacute; el <b>foco</b> de su ensayo </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comprar una <b>granada</b> en el supermercado</td><td> 2. una <b>granada</b> de mano en la zona de guerra </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. trabajar en el <b>departamento</b> legal de la compa&ntilde;&iacute;a</td><td> 2. un caj&oacute;n con varios <b>departamentos</b>  </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. apagar las velas con un <b>soplo</b> </td><td> 2. un <b>soplo</b> de aire fresco </td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tomar <b>caf&eacute;</b> por la ma&ntilde;ana</td><td> 2. un <b>caf&eacute;</b> hermosos y otros colores maravillosos en la pintura de Picasso</td></tr></table></center>" }],
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. usar el <b>coco</b> para pensar en nuevos ideas</td><td> 2. agua de <b>coco</b> </td></tr></table></center>" }],                
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. pasear al bebe un su <b>coche</b> por el parque</td><td> 2. conducir el <b>coche</b> por las calles de Madrid</td></tr></table></center>" }],                
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. hacer una <b>pausa</b> entre clases</td><td> 2. el orador y las <b>pausas</b> entre sus palabras</td></tr></table></center>" }],                
["SP","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>tela</b> de la ara&ntilde;a</td><td> 2. la <b>tela</b> de las cortinas</td></tr></table></center>" }],                                

["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. <b>inteligencia</b> militar </td><td> 2. la <b>inteligencia</b> del genio </td></tr></table></center>" }],
["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la mujer tiene una bonita <b>figura</b> </td><td> 2. un dibujo con varias formas y <b>figuras</b> </td></tr></table></center>" }],
["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>columna</b> en el peri&oacute;dico </td><td> 2. el edificio con dos <b>columnas</b> </td></tr></table></center>" }],
["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. escribir un <b>acento</b> en la vocal </td><td> 2. hablar con un <b>acento</b> extranjero </td></tr></table></center>" }],
["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la carne pesaba una <b>libra</b> </td><td> 2. costaba una <b>libra</b> Brit&aacute;nica </td></tr></table></center>" }],
["HS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>tronco</b> del &aacute;rbol </td><td> 2. sostener el <b>tronco</b> de tu cuerpo </td></tr></table></center>" }],

["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la nueva <b>estrella</b> en el concierto de cantantes </td><td> 2. la <b>estrella</b> en el cielo </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. sacar <b>sangre</b> en la cl&iacute;nica </td><td> 2. la realeza est&aacute; en tu <b>sangre</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. leer la <b>gu&iacute;a</b> antes de viajar </td><td> 2. preguntar a la <b>gu&iacute;a</b> del museo por informaci&oacute;n </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>l&iacute;nea</b> de pagar </td><td> 2. dibujar una <b>l&iacute;nea</b> en el papel </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. crecer la <b>menta</b> en el jard&iacute;n </td><td> 2. comerse una <b>menta</b> despu&eacute;s de almorzar </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tener <b>coraz&oacute;n</b> y compasi&oacute;n </td><td> 2. tener complicaciones de salud con el <b>coraz&oacute;n</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. romper el <b>brazo</b> en una ca&iacute;da </td><td> 2. el <b>brazo</b> de la silla </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>atm&oacute;sfera</b> contaminada alrededor de la tierra </td><td> 2. la tensa <b>atm&oacute;sfera</b> en el cuarto </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. detener su coche en la <b>barrera</b> </td><td> 2. una <b>barrera</b> en la vida </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>vaca</b> se come las hierbas </td><td> 2. ella esta hecha una <b>vaca</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comprar una <b>mu&ntilde;eca</b> en la tienda de juguetes </td><td> 2. la ni&ntilde;a es una <b>mu&ntilde;eca</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comprar verduras en el <b>mercado</b> </td><td> 2. el <b>mercado</b> de la vivienda esta vol&aacute;til </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>boca</b> del r&iacute;o </td><td> 2. poner comida en la <b>boca</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>cuello</b> de la botella </td><td> 2. tocarse el <b>cuello</b> con la mano </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tomarse el <b>vaso</b> de jugo entero </td><td> 2. lavar y secar el <b>vaso</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. un <b>cerdo</b> en la granja </td><td> 2. el se&ntilde;or es un <b>cerdo</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>escena</b> de la obra de teatro </td><td> 2. hacer una <b>escena</b> de enojo en la tienda </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>borrego</b> camina en el prado </td><td> 2. &eacute;l es un <b>borrego</b> bajo presi&oacute;n </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. lastimar tu <b>espalda</b> cargando cajas </td><td> 2. la <b>espalda</b> de la silla </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comerse una <b>naranja</b> </td><td> 2. un l&aacute;piz de color <b>naranja</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. un colorido <b>loro</b> en la selva </td><td> 2. &eacute;l es un <b>loro</b> que repite todas las malas palabras </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>pavo real</b> y sus plumas bonitas </td><td> 2. &eacute;l esta siendo un <b>pavo real</b> enfrente de las muchachas </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. hablar su <b>lengua</b> materna </td><td> 2. accidentalmente morderse la <b>lengua</b> mientras estas comiendo </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. los hombres de negocio son <b>buitres</b> </td><td> 2. el <b>buitre</b> se comi&oacute; el cuerpo del animal muerto </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. una <b>impresi&oacute;n</b> en la arena </td><td> 2. la pel&iacute;cula dej&oacute; una fuerte <b>impresi&oacute;n</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. flotar en el <b>espacio</b> y ver a la luna </td><td> 2. mantener tus art&iacute;culos en su propio <b>espacio</b> en tu escritorio </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>tierra</b> es un planeta </td><td> 2. remover la <b>tierra</b> para sacar a los gusanos </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>ala</b> de un p&aacute;jaro </td><td> 2. el <b>ala</b> de un avi&oacute;n </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. comerse un helado en un <b>cono</b> </td><td> 2. poner un <b>cono</b> anaranjado en la calle </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. echar la <b>mano</b> a alguien en necesidad </td><td> 2. hiri&oacute; su <b>mano</b> en el accidente </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>aire</b> contaminado </td><td> 2. aviones llenaron el <b>aire</b> </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>hoja</b> de un &aacute;rbol </td><td> 2. una <b>hoja</b> de papel </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. su <b>edad</b> avanzada </td><td> 2. literatura de la <b>edad</b> de bronce </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. un <b>payaso</b> en la fiesta de cumplea&ntilde;os </td><td> 2. &eacute;l es un <b>payaso</b> y bromea durante la clase </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tapar al beb&eacute; con una <b>manta</b> </td><td> 2. una <b>manta</b> de nieve cubre las casas </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. tu <b>posici&oacute;n</b> pol&iacute;tica </td><td> 2. tu <b>posici&oacute;n</b> de dormir en la cama </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>ra&iacute;z</b> de tu diente </td><td> 2. la <b>ra&iacute;z</b> del &aacute;rbol </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. rasp&oacute; su <b>piel</b> en la piedra </td><td> 2. la <b>piel</b> suave del melocot&iacute;n </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>tierra</b> cerca del r&iacute;o es f&eacute;rtil </td><td> 2. aterrizar en la <b>tierra</b> extranjera </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>arco</b> del viol&iacute;n </td><td> 2. disparar con un <b>arco</b> y una flecha </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>corriente</b> de agua </td><td> 2. la <b>corriente</b> de electricidad </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. la <b>energ&iacute;a</b> de la central nuclear </td><td> 2. la <b>energ&iacute;a</b> de los ni&ntilde;os que juegan </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>bronce</b> profundo de la pintura </td><td> 2. los metales de <b>bronce</b> y cobre </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>lanzamiento</b> del nuevo tel&eacute;fono celular en las tiendas </td><td> 2. el <b>lanzamiento</b> del cohete </td></tr></table></center>" }],
["PS","SimilaritySentence",{ html: "<center><table class='tbl'> <tr> <td> 1. el <b>puente</b> sobre el r&iacute;o </td><td> 2. el <b>puente</b> de su nariz </td></tr></table></center>" }]
           

];

