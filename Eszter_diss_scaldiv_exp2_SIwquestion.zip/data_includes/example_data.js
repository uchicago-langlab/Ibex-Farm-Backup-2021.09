define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("v"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a dialogue, and decide whether you can conclude something from the answer in that dialogue."] 
],continueMessage:"Click here to start the experiment."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 ["practice", "MyController", {html: "<p>Sue: <i>Is the wrestler weak?</i><br>Mary: <i>He is strong.</i></p><p> Would you conclude from this that, according to Mary, the wrestler is not weak?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Sue: <i>Did the spy discover the plan?</i><br>Mary: <i>She memorized it.</i></p><p> Would you conclude from this that, according to Mary, the spy did not discover the plan?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Sue: <i>Is the student brilliant?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//Experimental items
 
//["e1", "Question",       {q: "Mary: This student is intelligent. Would you conclude from this that, according to John, she is not brilliant?", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
// ["e1", "MyController",       {html: "<p>Sue: <i>Is this student brilliant?</i><br>Mary: <i>This student is intelligent.</i></p><p> Would you conclude from this that, according to Mary, this student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",1], "MyController",       {html: "<p>Sue: <i>Is the food good?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the food is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",1], "MyController",       {html: "<p>Sue: <i>Is the salary good?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the salary is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",1], "MyController",       {html: "<p>Sue: <i>Is the solution good?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the solution is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",1], "MyController",       {html: "<p>Sue: <i>Is the food adequate?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the food is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",1], "MyController",       {html: "<p>Sue: <i>Is the salary adequate?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the salary is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",1], "MyController",       {html: "<p>Sue: <i>Is the solution adequate?</i><br>Mary: <i>It is adequate.</i></p><p> Would you conclude from this that, according to Mary, the solution is not good?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",2], "MyController",       {html: "<p>Sue: <i>Is talking obligatory?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, talking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",2], "MyController",       {html: "<p>Sue: <i>Is drinking obligatory?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",2], "MyController",       {html: "<p>Sue: <i>Is copying obligatory?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, copying is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",2], "MyController",       {html: "<p>Sue: <i>Is talking allowed?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, talking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",2], "MyController",       {html: "<p>Sue: <i>Is drinking allowed?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",2], "MyController",       {html: "<p>Sue: <i>Is copying allowed?</i><br>Mary: <i>It is allowed.</i></p><p> Would you conclude from this that, according to Mary, copying is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",3], "MyController",       {html: "<p>Sue: <i>Is the nurse stunning?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the nurse is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",3], "MyController",       {html: "<p>Sue: <i>Is the model stunning?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",3], "MyController",       {html: "<p>Sue: <i>Is the singer stunning?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the singer is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",3], "MyController",       {html: "<p>Sue: <i>Is the nurse attractive?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the nurse is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",3], "MyController",       {html: "<p>Sue: <i>Is the model attractive?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",3], "MyController",       {html: "<p>Sue: <i>Is the singer attractive?</i><br>Mary: <i>She is attractive.</i></p><p> Would you conclude from this that, according to Mary, the singer is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",4], "MyController",       {html: "<p>Sue: <i>Does the student know it will work out?</i><br>Mary: <i>He believes it will work out.</i></p><p> Would you conclude from this that, according to Mary, the student doesn't know it will work out?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",4], "MyController",       {html: "<p>Sue: <i>Does the mother know it will happen?</i><br>Mary: <i>She believes it will happen.</i></p><p> Would you conclude from this that, according to Mary, the mother doesn't know it will happen?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",4], "MyController",       {html: "<p>Sue: <i>Does the teacher know it is true?</i><br>Mary: <i>She believes it is true.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",4], "MyController",       {html: "<p>Sue: <i>Does the student believe it will work out?</i><br>Mary: <i>He believes it will work out.</i></p><p> Would you conclude from this that, according to Mary, the student doesn't know it will work out?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",4], "MyController",       {html: "<p>Sue: <i>Does the mother believe it will happen?</i><br>Mary: <i>She believes it will happen.</i></p><p> Would you conclude from this that, according to Mary, the mother doesn't know it will happen?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",4], "MyController",       {html: "<p>Sue: <i>Does the teacher believe it is true?</i><br>Mary: <i>She believes it is true.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",5], "MyController",       {html: "<p>Sue: <i>Is the elephant enormous?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",5], "MyController",       {html: "<p>Sue: <i>Is the house enormous?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the house is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",5], "MyController",       {html: "<p>Sue: <i>Is the tree enormous?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the tree is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",5], "MyController",       {html: "<p>Sue: <i>Is the elephant big?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",5], "MyController",       {html: "<p>Sue: <i>Is the house big?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the house is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",5], "MyController",       {html: "<p>Sue: <i>Is the tree big?</i><br>Mary: <i>It is big.</i></p><p> Would you conclude from this that, according to Mary, the tree is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",6], "MyController",       {html: "<p>Sue: <i>Is the water free?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the water is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",6], "MyController",       {html: "<p>Sue: <i>Is the electricity free?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the electricity is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",6], "MyController",       {html: "<p>Sue: <i>Is the food free?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the food is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",6], "MyController",       {html: "<p>Sue: <i>Is the water cheap?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the water is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",6], "MyController",       {html: "<p>Sue: <i>Is the electricity cheap?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the electricity is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",6], "MyController",       {html: "<p>Sue: <i>Is the food cheap?</i><br>Mary: <i>It is cheap.</i></p><p> Would you conclude from this that, according to Mary, the food is not free?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",7], "MyController",       {html: "<p>Sue: <i>Is the child happy?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the child is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",7], "MyController",       {html: "<p>Sue: <i>Is the homemaker happy?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the homemaker is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",7], "MyController",       {html: "<p>Sue: <i>Is the musician happy?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the musician is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",7], "MyController",       {html: "<p>Sue: <i>Is the child content?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the child is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",7], "MyController",       {html: "<p>Sue: <i>Is the homemaker content?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the homemaker is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",7], "MyController",       {html: "<p>Sue: <i>Is the musician content?</i><br>Mary: <i>She is content.</i></p><p> Would you conclude from this that, according to Mary, the musician is not happy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",8], "MyController",       {html: "<p>Sue: <i>Is the air cold?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the air is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",8], "MyController",       {html: "<p>Sue: <i>Is the weather cold?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",8], "MyController",       {html: "<p>Sue: <i>Is the room cold?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the room is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",8], "MyController",       {html: "<p>Sue: <i>Is the air cool?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the air is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",8], "MyController",       {html: "<p>Sue: <i>Is the weather cool?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",8], "MyController",       {html: "<p>Sue: <i>Is the room cool?</i><br>Mary: <i>It is cool.</i></p><p> Would you conclude from this that, according to Mary, the room is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",9], "MyController",       {html: "<p>Sue: <i>Is the fabric black?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the fabric is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",9], "MyController",       {html: "<p>Sue: <i>Is the sky black?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",9], "MyController",       {html: "<p>Sue: <i>Is the shirt black?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",9], "MyController",       {html: "<p>Sue: <i>Is the fabric dark?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the fabric is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",9], "MyController",       {html: "<p>Sue: <i>Is the sky dark?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",9], "MyController",       {html: "<p>Sue: <i>Is the shirt dark?</i><br>Mary: <i>It is dark.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",10], "MyController",       {html: "<p>Sue: <i>Is the task impossible?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",10], "MyController",       {html: "<p>Sue: <i>Is the journey impossible?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the journey is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",10], "MyController",       {html: "<p>Sue: <i>Is the problem impossible?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the problem is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",10], "MyController",       {html: "<p>Sue: <i>Is the task difficult?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",10], "MyController",       {html: "<p>Sue: <i>Is the journey difficult?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the journey is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",10], "MyController",       {html: "<p>Sue: <i>Is the problem difficult?</i><br>Mary: <i>It is difficult.</i></p><p> Would you conclude from this that, according to Mary, the problem is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",11], "MyController",       {html: "<p>Sue: <i>Does the boy loathe broccoli?</i><br>Mary: <i>He dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the boy doesn't loathe broccoli?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",11], "MyController",       {html: "<p>Sue: <i>Does the teacher loathe fighting?</i><br>Mary: <i>He dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't loathe fighting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",11], "MyController",       {html: "<p>Sue: <i>Does the doctor loathe coffee?</i><br>Mary: <i>She dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",11], "MyController",       {html: "<p>Sue: <i>Does the boy dislike broccoli?</i><br>Mary: <i>He dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the boy doesn't loathe broccoli?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",11], "MyController",       {html: "<p>Sue: <i>Does the teacher dislike fighting?</i><br>Mary: <i>He dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the teacher doesn't loathe fighting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",11], "MyController",       {html: "<p>Sue: <i>Does the doctor dislike coffee?</i><br>Mary: <i>She dislikes it.</i></p><p> Would you conclude from this that, according to Mary, the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",12], "MyController",       {html: "Sue: <i>Did the biologist see none of the birds?</i><br>Mary: <i>She saw few of the birds.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the biologist saw none of the birds?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",12], "MyController",       {html: "Sue: <i>Did the cop see none of the children?</i><br>Mary: <i>He saw few of the children.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the cop saw none of the children?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",12], "MyController",       {html: "Sue: <i>Did the observer see none of the stars?</i><br>Mary: <i>He saw few of the stars.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the observer saw none of the stars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",12], "MyController",       {html: "Sue: <i>Did the biologist see few of the birds?</i><br>Mary: <i>She saw few of the birds.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the biologist saw none of the birds?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",12], "MyController",       {html: "Sue: <i>Did the cop see few of the children?</i><br>Mary: <i>He saw few of the children.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the cop saw none of the children?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",12], "MyController",       {html: "Sue: <i>Did the observer see few of the stars?</i><br>Mary: <i>He saw few of the stars.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the observer saw none of the stars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",13], "MyController", {html: "<p>Sue: <i>Is the joke hilarious?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the joke is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",13], "MyController", {html: "<p>Sue: <i>Is the play hilarious?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the play is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",13], "MyController", {html: "<p>Sue: <i>Is the movie hilarious?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",13], "MyController", {html: "<p>Sue: <i>Is the joke funny?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the joke is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",13], "MyController", {html: "<p>Sue: <i>Is the play funny?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the play is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",13], "MyController", {html: "<p>Sue: <i>Is the movie funny?</i><br>Mary: <i>It is funny.</i></p><p> Would you conclude from this that, according to Mary, the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",14], "MyController", {html: "<p>Sue: <i>Is the food excellent?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the food is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",14], "MyController", {html: "<p>Sue: <i>Is the movie excellent?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",14], "MyController", {html: "<p>Sue: <i>Is the sandwich excellent?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the sandwich is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",14], "MyController", {html: "<p>Sue: <i>Is the food good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the food is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",14], "MyController", {html: "<p>Sue: <i>Is the movie good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",14], "MyController", {html: "<p>Sue: <i>Is the sandwich good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the sandwich is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",15], "MyController", {html: "<p>Sue: <i>Is the layout perfect?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the layout is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",15], "MyController", {html: "<p>Sue: <i>Is the solution perfect?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the solution is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",15], "MyController", {html: "<p>Sue: <i>Is the answer perfect?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the answer is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",15], "MyController", {html: "<p>Sue: <i>Is the layout good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the layout is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",15], "MyController", {html: "<p>Sue: <i>Is the solution good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the solution is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",15], "MyController", {html: "<p>Sue: <i>Is the answer good?</i><br>Mary: <i>It is good.</i></p><p> Would you conclude from this that, according to Mary, the answer is not perfect?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",16], "MyController", {html: "<p>Sue: <i>Is the problem unsolvable?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",16], "MyController", {html: "<p>Sue: <i>Is the issue unsolvable?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the issue is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",16], "MyController", {html: "<p>Sue: <i>Is the puzzle unsolvable?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the puzzle is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",16], "MyController", {html: "<p>Sue: <i>Is the problem hard?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",16], "MyController", {html: "<p>Sue: <i>Is the issue hard?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the issue is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",16], "MyController", {html: "<p>Sue: <i>Is the puzzle hard?</i><br>Mary: <i>It is hard.</i></p><p> Would you conclude from this that, according to Mary, the puzzle is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",17], "MyController", {html: "<p>Sue: <i>Is the boy starving?</i><br>Mary: <i>He is hungry.</i></p><p> Would you conclude from this that, according to Mary, the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",17], "MyController", {html: "<p>Sue: <i>Is the dog starving?</i><br>Mary: <i>It is hungry.</i></p><p> Would you conclude from this that, according to Mary, the dog is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",17], "MyController", {html: "<p>Sue: <i>Is the elephant starving?</i><br>Mary: <i>It is hungry.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",17], "MyController", {html: "<p>Sue: <i>Is the boy hungry?</i><br>Mary: <i>He is hungry.</i></p><p> Would you conclude from this that, according to Mary, the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",17], "MyController", {html: "<p>Sue: <i>Is the dog hungry?</i><br>Mary: <i>It is hungry.</i></p><p> Would you conclude from this that, according to Mary, the dog is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",17], "MyController", {html: "<p>Sue: <i>Is the elephant hungry?</i><br>Mary: <i>It is hungry.</i></p><p> Would you conclude from this that, according to Mary, the elephant is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",18], "MyController", {html: "<p>Sue: <i>Is the dress unique?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the dress is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",18], "MyController", {html: "<p>Sue: <i>Is the painting unique?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the painting is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",18], "MyController", {html: "<p>Sue: <i>Is the necklace unique?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the necklace is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",18], "MyController", {html: "<p>Sue: <i>Is the dress special?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the dress is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",18], "MyController", {html: "<p>Sue: <i>Is the painting special?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the painting is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",18], "MyController", {html: "<p>Sue: <i>Is the necklace special?</i><br>Mary: <i>It is special.</i></p><p> Would you conclude from this that, according to Mary, the necklace is not unique?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",19], "MyController", {html: "<p>Sue: <i>Is the assistant brilliant?</i><br>Mary: <i>He is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",19], "MyController", {html: "<p>Sue: <i>Is the professor brilliant?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the professor is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",19], "MyController", {html: "<p>Sue: <i>Is the student brilliant?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",19], "MyController", {html: "<p>Sue: <i>Is the assistant intelligent?</i><br>Mary: <i>He is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",19], "MyController", {html: "<p>Sue: <i>Is the professor intelligent?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the professor is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",19], "MyController", {html: "<p>Sue: <i>Is the student intelligent?</i><br>Mary: <i>She is intelligent.</i></p><p> Would you conclude from this that, according to Mary, the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",20], "MyController", {html: "<p>Sue: <i>Does the princess love dancing?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that, according to Mary, the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",20], "MyController", {html: "<p>Sue: <i>Does the actress love the movie?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that, according to Mary, the actress doesn't love the movie?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",20], "MyController", {html: "<p>Sue: <i>Does the manager love spaghetti?</i><br>Mary: <i>He likes it.</i></p><p> Would you conclude from this that, according to Mary, the manager doesn't love spaghetti?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",20], "MyController", {html: "<p>Sue: <i>Does the princess like dancing?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that, according to Mary, the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",20], "MyController", {html: "<p>Sue: <i>Does the actress like the movie?</i><br>Mary: <i>She likes it.</i></p><p> Would you conclude from this that, according to Mary, the actress doesn't love the movie?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",20], "MyController", {html: "<p>Sue: <i>Does the manager like spaghetti?</i><br>Mary: <i>He likes it.</i></p><p> Would you conclude from this that, according to Mary, the manager doesn't love spaghetti?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",21], "MyController", {html: "<p>Sue: <i>Is the energy depleted?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the energy is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",21], "MyController", {html: "<p>Sue: <i>Is the battery depleted?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the battery is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",21], "MyController", {html: "<p>Sue: <i>Is the gas depleted?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the gas is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",21], "MyController", {html: "<p>Sue: <i>Is the energy low?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the energy is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",21], "MyController", {html: "<p>Sue: <i>Is the battery low?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the battery is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",21], "MyController", {html: "<p>Sue: <i>Is the gas low?</i><br>Mary: <i>It is low.</i></p><p> Would you conclude from this that, according to Mary, the gas is not depleted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",22], "MyController", {html: "<p>Sue: <i>Does the child have to eat an apple?</i><br>Mary: <i>She may eat an apple.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the child has to eat an apple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",22], "MyController", {html: "<p>Sue: <i>Does the boy have to watch television?</i><br>Mary: <i>He may watch television.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the boy has to watch television?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",22], "MyController", {html: "<p>Sue: <i>Does the dog have to sleep on the bed?</i><br>Mary: <i>It may sleep on the bed.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the dog has to sleep on the bed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",22], "MyController", {html: "<p>Sue: <i>May the child eat an apple?</i><br>Mary: <i>She may eat an apple.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the child has to eat an apple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",22], "MyController", {html: "<p>Sue: <i>May the boy watch television?</i><br>Mary: <i>He may watch television.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the boy has to watch television?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",22], "MyController", {html: "<p>Sue: <i>May the dog sleep on the bed?</i><br>Mary: <i>It may sleep on the bed.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the dog has to sleep on the bed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",23], "MyController", {html: "<p>Sue: <i>Is it the case that the lawyer will appear in person?</i><br>Mary: <i>She may appear in person.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the lawyer will appear in person?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",23], "MyController", {html: "<p>Sue: <i>Is it the case that the teacher will come?</i><br>Mary: <i>He may come.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the teacher will come?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",23], "MyController", {html: "<p>Sue: <i>Is it the case that the student will pass?</i><br>Mary: <i>He may pass.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the student will pass?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",23], "MyController", {html: "<p>Sue: <i>Is it the case that the lawyer may appear in person?</i><br>Mary: <i>She may appear in person.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the lawyer will appear in person?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",23], "MyController", {html: "<p>Sue: <i>Is it the case that the teacher may come?</i><br>Mary: <i>He may come.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the teacher will come?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",23], "MyController", {html: "<p>Sue: <i>Is it the case that the student may pass?</i><br>Mary: <i>He may pass.</i></p><p> Would you conclude from this that, according to Mary, it's not the case that the student will pass?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",24], "MyController", {html: "<p>Sue: <i>Was the party unforgettable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the party was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",24], "MyController", {html: "<p>Sue: <i>Was the view unforgettable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the view was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",24], "MyController", {html: "<p>Sue: <i>Was the movie unforgettable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the movie was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",24], "MyController", {html: "<p>Sue: <i>Was the party memorable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the party was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",24], "MyController", {html: "<p>Sue: <i>Was the view memorable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the view was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",24], "MyController", {html: "<p>Sue: <i>Was the movie memorable?</i><br>Mary: <i>It was memorable.</i></p><p> Would you conclude from this that, according to Mary, the movie was not unforgettable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",25], "MyController", {html: "<p>Sue: <i>Is the house ancient?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",25], "MyController", {html: "<p>Sue: <i>Is the mirror ancient?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the mirror is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",25], "MyController", {html: "<p>Sue: <i>Is the table ancient?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the table is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",25], "MyController", {html: "<p>Sue: <i>Is the house old?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",25], "MyController", {html: "<p>Sue: <i>Is the mirror old?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the mirror is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",25], "MyController", {html: "<p>Sue: <i>Is the table old?</i><br>Mary: <i>It is old.</i></p><p> Would you conclude from this that, according to Mary, the table is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",26], "MyController", {html: "<p>Sue: <i>Is the food delicious?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the food is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",26], "MyController", {html: "<p>Sue: <i>Is the wine delicious?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",26], "MyController", {html: "<p>Sue: <i>Is the dessert delicious?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the dessert is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",26], "MyController", {html: "<p>Sue: <i>Is the food palatable?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the food is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",26], "MyController", {html: "<p>Sue: <i>Is the wine palatable?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",26], "MyController", {html: "<p>Sue: <i>Is the dessert palatable?</i><br>Mary: <i>It is palatable.</i></p><p> Would you conclude from this that, according to Mary, the dessert is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",27], "MyController", {html: "<p>Sue: <i>Did the freshman win?</i><br>Mary: <i>She participated.</i></p><p> Would you conclude from this that, according to Mary, the freshman did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",27], "MyController", {html: "<p>Sue: <i>Did the runner win?</i><br>Mary: <i>She participated.</i></p><p> Would you conclude from this that, according to Mary, the runner did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",27], "MyController", {html: "<p>Sue: <i>Did the skier win?</i><br>Mary: <i>He participated.</i></p><p> Would you conclude from this that, according to Mary, the skier did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",27], "MyController", {html: "<p>Sue: <i>Did the freshman participate?</i><br>Mary: <i>She participated.</i></p><p> Would you conclude from this that, according to Mary, the freshman did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",27], "MyController", {html: "<p>Sue: <i>Did the runner participate?</i><br>Mary: <i>She participated.</i></p><p> Would you conclude from this that, according to Mary, the runner did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",27], "MyController", {html: "<p>Sue: <i>Did the skier participate?</i><br>Mary: <i>He participated.</i></p><p> Would you conclude from this that, according to Mary, the skier did not win?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//note that I don't use pronouns here
[["version1s",28], "MyController", {html: "<p>Sue: <i>Is happiness certain?</i><br>Mary: <i>Happiness is possible.</i></p><p> Would you conclude from this that, according to Mary, happiness is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",28], "MyController", {html: "<p>Sue: <i>Is failing certain?</i><br>Mary: <i>Failing is possible.</i></p><p> Would you conclude from this that, according to Mary, failing is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",28], "MyController", {html: "<p>Sue: <i>Is success certain?</i><br>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that, according to Mary, success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",28], "MyController", {html: "<p>Sue: <i>Is happiness possible?</i><br>Mary: <i>Happiness is possible.</i></p><p> Would you conclude from this that, according to Mary, happiness is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",28], "MyController", {html: "<p>Sue: <i>Is failing possible?</i><br>Mary: <i>Failing is possible.</i></p><p> Would you conclude from this that, according to Mary, failing is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",28], "MyController", {html: "<p>Sue: <i>Is success possible?</i><br>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that, according to Mary, success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",29], "MyController", {html: "<p>Sue: <i>Is the model beautiful?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the model is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",29], "MyController", {html: "<p>Sue: <i>Is the lady beautiful?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the lady is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",29], "MyController", {html: "<p>Sue: <i>Is the girl beautiful?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",29], "MyController", {html: "<p>Sue: <i>Is the model pretty?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the model is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",29], "MyController", {html: "<p>Sue: <i>Is the lady pretty?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the lady is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",29], "MyController", {html: "<p>Sue: <i>Is the girl pretty?</i><br>Mary: <i>She is pretty.</i></p><p> Would you conclude from this that, according to Mary, the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",30], "MyController", {html: "<p>Sue: <i>Is this plant extinct?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this plant is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",30], "MyController", {html: "<p>Sue: <i>Is this bird extinct?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this bird is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",30], "MyController", {html: "<p>Sue: <i>Is this fish extinct?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this fish is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",30], "MyController", {html: "<p>Sue: <i>Is this plant rare?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this plant is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",30], "MyController", {html: "<p>Sue: <i>Is this bird rare?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this bird is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",30], "MyController", {html: "<p>Sue: <i>Is this fish rare?</i><br>Mary: <i>It is rare.</i></p><p> Would you conclude from this that, according to Mary, this fish is not extinct?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",31], "MyController", {html: "<p>Sue: <i>Is this recording unavailable?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this recording is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",31], "MyController", {html: "<p>Sue: <i>Is this resource unavailable?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this resource is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",31], "MyController", {html: "<p>Sue: <i>Is this mineral unavailable?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this mineral is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",31], "MyController", {html: "<p>Sue: <i>Is this recording scarce?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this recording is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",31], "MyController", {html: "<p>Sue: <i>Is this resource scarce?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this resource is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",31], "MyController", {html: "<p>Sue: <i>Is this mineral scarce?</i><br>Mary: <i>It is scarce.</i></p><p> Would you conclude from this that, according to Mary, this mineral is not unavailable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",32], "MyController", {html: "<p>Sue: <i>Is the song ridiculous?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the song is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",32], "MyController", {html: "<p>Sue: <i>Is the joke ridiculous?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the joke is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",32], "MyController", {html: "<p>Sue: <i>Is the question ridiculous?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the question is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",32], "MyController", {html: "<p>Sue: <i>Is the song silly?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the song is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",32], "MyController", {html: "<p>Sue: <i>Is the joke silly?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the joke is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",32], "MyController", {html: "<p>Sue: <i>Is the question silly?</i><br>Mary: <i>It is silly.</i></p><p> Would you conclude from this that, according to Mary, the question is not ridiculous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",33], "MyController", {html: "<p>Sue: <i>Is the room tiny?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the room is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",33], "MyController", {html: "<p>Sue: <i>Is the car tiny?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the car is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",33], "MyController", {html: "<p>Sue: <i>Is the fish tiny?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",33], "MyController", {html: "<p>Sue: <i>Is the room small?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the room is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",33], "MyController", {html: "<p>Sue: <i>Is the car small?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the car is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",33], "MyController", {html: "<p>Sue: <i>Is the fish small?</i><br>Mary: <i>It is small.</i></p><p> Would you conclude from this that, according to Mary, the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",34], "MyController", {html: "<p>Sue: <i>Is the shirt tight?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",34], "MyController", {html: "<p>Sue: <i>Is the dress tight?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the dress is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",34], "MyController", {html: "<p>Sue: <i>Is the glove tight?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the glove is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",34], "MyController", {html: "<p>Sue: <i>Is the shirt snug?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",34], "MyController", {html: "<p>Sue: <i>Is the dress snug?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the dress is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",34], "MyController", {html: "<p>Sue: <i>Is the glove snug?</i><br>Mary: <i>It is snug.</i></p><p> Would you conclude from this that, according to Mary, the glove is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",35], "MyController", {html: "<p>Sue: <i>Did the bartender see all of the cars?</i><br>Mary: <i>He saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the bartender did not see all of the cars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",35], "MyController", {html: "<p>Sue: <i>Did the nurse see all of the signs?</i><br>Mary: <i>She saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the nurse did not see all of the signs?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",35], "MyController", {html: "<p>Sue: <i>Did the mathematician see all of the issues?</i><br>Mary: <i>He saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the mathematician did not see all of the issues?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",35], "MyController", {html: "<p>Sue: <i>Did the bartender see some of the cars?</i><br>Mary: <i>He saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the bartender did not see all of the cars?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",35], "MyController", {html: "<p>Sue: <i>Did the nurse see some of the signs?</i><br>Mary: <i>She saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the nurse did not see all of the signs?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",35], "MyController", {html: "<p>Sue: <i>Did the mathematician see some of the issues?</i><br>Mary: <i>He saw some of them.</i></p><p> Would you conclude from this that, according to Mary, the mathematician did not see all of the issues?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",36], "MyController", {html: "<p>Sue: <i>Is the assistant always angry?</i><br>Mary: <i>She is sometimes angry.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not always angry?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",36], "MyController", {html: "<p>Sue: <i>Is the director always late?</i><br>Mary: <i>He is sometimes late.</i></p><p> Would you conclude from this that, according to Mary, the director is not always late?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",36], "MyController", {html: "<p>Sue: <i>Is the doctor always irritable?</i><br>Mary: <i>She is sometimes irritable.</i></p><p> Would you conclude from this that, according to Mary, the doctor is not always irritable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",36], "MyController", {html: "<p>Sue: <i>Is the assistant sometimes angry?</i><br>Mary: <i>She is sometimes angry.</i></p><p> Would you conclude from this that, according to Mary, the assistant is not always angry?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",36], "MyController", {html: "<p>Sue: <i>Is the director sometimes late?</i><br>Mary: <i>He is sometimes late.</i></p><p> Would you conclude from this that, according to Mary, the director is not always late?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",36], "MyController", {html: "<p>Sue: <i>Is the doctor sometimes irritable?</i><br>Mary: <i>She is sometimes irritable.</i></p><p> Would you conclude from this that, according to Mary, the doctor is not always irritable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",37], "MyController", {html: "<p>Sue: <i>Did the athlete finish?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",37], "MyController", {html: "<p>Sue: <i>Did the dancer finish?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that, according to Mary, the dancer did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",37], "MyController", {html: "<p>Sue: <i>Did the runner finish?</i><br>Mary: <i>He started.</i></p><p> Would you conclude from this that, according to Mary, the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",37], "MyController", {html: "<p>Sue: <i>Did the athlete start?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",37], "MyController", {html: "<p>Sue: <i>Did the dancer start?</i><br>Mary: <i>She started.</i></p><p> Would you conclude from this that, according to Mary, the dancer did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",37], "MyController", {html: "<p>Sue: <i>Did the runner start?</i><br>Mary: <i>He started.</i></p><p> Would you conclude from this that, according to Mary, the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",38], "MyController", {html: "<p>Sue: <i>Is the quarterback exhausted?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that, according to Mary, the quarterback is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",38], "MyController", {html: "<p>Sue: <i>Is the runner exhausted?</i><br>Mary: <i>She is tired.</i></p><p> Would you conclude from this that, according to Mary, the runner is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",38], "MyController", {html: "<p>Sue: <i>Is the worker exhausted?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that, according to Mary, the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",38], "MyController", {html: "<p>Sue: <i>Is the quarterback tired?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that, according to Mary, the quarterback is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",38], "MyController", {html: "<p>Sue: <i>Is the runner tired?</i><br>Mary: <i>She is tired.</i></p><p> Would you conclude from this that, according to Mary, the runner is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",38], "MyController", {html: "<p>Sue: <i>Is the worker tired?</i><br>Mary: <i>He is tired.</i></p><p> Would you conclude from this that, according to Mary, the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",39], "MyController", {html: "<p>Sue: <i>Did the candidate succeed?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that, according to Mary, the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",39], "MyController", {html: "<p>Sue: <i>Did the athlete succeed?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",39], "MyController", {html: "<p>Sue: <i>Did the scientist succeed?</i><br>Mary: <i>She tried.</i></p><p> Would you conclude from this that, according to Mary, the scientist did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",39], "MyController", {html: "<p>Sue: <i>Did the candidate try?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that, according to Mary, the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",39], "MyController", {html: "<p>Sue: <i>Did the athlete try?</i><br>Mary: <i>He tried.</i></p><p> Would you conclude from this that, according to Mary, the athlete did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",39], "MyController", {html: "<p>Sue: <i>Did the scientist try?</i><br>Mary: <i>She tried.</i></p><p> Would you conclude from this that, according to Mary, the scientist did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",40], "MyController", {html: "<p>Sue: <i>Is the wallpaper hideous?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",40], "MyController", {html: "<p>Sue: <i>Is the sweater hideous?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the sweater is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",40], "MyController", {html: "<p>Sue: <i>Is the painting hideous?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the painting is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",40], "MyController", {html: "<p>Sue: <i>Is the wallpaper ugly?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",40], "MyController", {html: "<p>Sue: <i>Is the sweater ugly?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the sweater is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",40], "MyController", {html: "<p>Sue: <i>Is the painting ugly?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the painting is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",41], "MyController", {html: "<p>Sue: <i>Is the movie horrific?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the movie is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",41], "MyController", {html: "<p>Sue: <i>Is the picture horrific?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the picture is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",41], "MyController", {html: "<p>Sue: <i>Is the news horrific?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the news is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",41], "MyController", {html: "<p>Sue: <i>Is the movie unsettling?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the movie is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",41], "MyController", {html: "<p>Sue: <i>Is the picture unsettling?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the picture is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",41], "MyController", {html: "<p>Sue: <i>Is the news unsettling?</i><br>Mary: <i>It is unsettling.</i></p><p> Would you conclude from this that, according to Mary, the news is not horrific?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",42], "MyController", {html: "<p>Sue: <i>Is the weather hot?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",42], "MyController", {html: "<p>Sue: <i>Is the sand hot?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the sand is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",42], "MyController", {html: "<p>Sue: <i>Is the soup hot?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the soup is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",42], "MyController", {html: "<p>Sue: <i>Is the weather warm?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",42], "MyController", {html: "<p>Sue: <i>Is the sand warm?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the sand is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",42], "MyController", {html: "<p>Sue: <i>Is the soup warm?</i><br>Mary: <i>It is warm.</i></p><p> Would you conclude from this that, according to Mary, the soup is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["version1s",43], "MyController", {html: "<p>Sue: <i>Is the dog scared?</i><br>Mary: <i>It is wary.</i></p><p> Would you conclude from this that, according to Mary, the dog is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3s",43], "MyController", {html: "<p>Sue: <i>Is the victim scared?</i><br>Mary: <i>He is wary.</i></p><p> Would you conclude from this that, according to Mary, the victim is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2s",43], "MyController", {html: "<p>Sue: <i>Is the rabbit scared?</i><br>Mary: <i>It is wary.</i></p><p> Would you conclude from this that, according to Mary, the rabbit is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version1w",43], "MyController", {html: "<p>Sue: <i>Is the dog wary?</i><br>Mary: <i>It is wary.</i></p><p> Would you conclude from this that, according to Mary, the dog is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version3w",43], "MyController", {html: "<p>Sue: <i>Is the victim wary?</i><br>Mary: <i>He is wary.</i></p><p> Would you conclude from this that, according to Mary, the victim is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["version2w",43], "MyController", {html: "<p>Sue: <i>Is the rabbit wary?</i><br>Mary: <i>It is wary.</i></p><p> Would you conclude from this that, according to Mary, the rabbit is not scared?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],



//Filler items: 1,2,3,7 are catch trials
["filler1", "MyController", {html: "<p>Sue: <i>Is the table dirty?</i><br>Mary: <i>It is clean.</i></p><p> Would you conclude from this that, according to Mary, the table is not dirty?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler2", "MyController", {html: "<p>Sue: <i>Is the soldier harmless?</i><br>Mary: <i>He is dangerous.</i></p><p> Would you conclude from this that, according to Mary, the soldier is not harmless?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler3", "MyController", {html: "<p>Sue: <i>Is the man sober?</i><br>Mary: <i>He is drunk.</i></p><p> Would you conclude from this that, according to Mary, the man is not sober?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler4", "MyController", {html: "<p>Sue: <i>Is the neighbor rich?</i><br>Mary: <i>She is sleepy.</i></p><p> Would you conclude from this that, according to Mary, the neighbor is not rich?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler5", "MyController", {html: "<p>Sue: <i>Is the gymnast single?</i><br>Mary: <i>She is tall.</i></p><p> Would you conclude from this that, according to Mary, the gymnast is not single?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler6", "MyController", {html: "<p>Sue: <i>Is the doll old?</i><br>Mary: <i>It is ugly.</i></p><p> Would you conclude from this that, according to Mary, the doll is not old?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler7", "MyController", {html: "<p>Sue: <i>Is the street narrow?</i><br>Mary: <i>It is wide.</i></p><p> Would you conclude from this that, according to Mary, the street is not narrow?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}]// NOTE NO COMMA

];
