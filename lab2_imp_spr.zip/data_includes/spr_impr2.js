var shuffleSequence = seq("intro","Practice", "presep", sepWith("sep", rshuffle(startsWith("imp"), startsWith("f"))),"exit");

//var counterOverride = 3;
var ds = DashedSentence;
var q = Question;



var defaults = [
    Separator,{ignoreFailure: true},
    q,{hasCorrect: true, randomOrder: true},
    ds,{mode: "self-paced reading", display: "dashed"},
    "Message", {
        hideProgressBar: true
    }
   
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],    


["sep", Separator, { }],

["Practice", ds, {s: "This is just a practice sentence to get you used to the method of presentation."}, q, {q:"Was that sentence easy?", as: ["Yes","No"] }, Separator, { }],
                       
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all there is to it! Let's try some practice sentences more like the ones you'll be seeing in the experiment:"]
                           ]}],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Chris and Patt had been tirelessly rehearsing for their Broadway musical audition all week."],
                          
                          ]},
                    ds, { s:  "After so many rehearsals, Patt sang herself hoarse."} , "Question", {q: "What were Chris and Patt rehearsing for? ", as: ["An audition","An opera", "A recital"]}, Separator, { }],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Upon receiving a job offer from a company based in New york, Mandy was debating whether she was willing to relocate to such a big city."],
                          
                          ]},
                    ds, { s:  "Her friend Lucy told her that she had loved living in New York."} , "Question", {q: "Why is Mandy considering moving to New York?", as: ["Work","Family","Friends"]}, Separator, { }],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "In preparation for his trip to Myanmar, Preston went to the bookstore to buy a couple of travel guides."],
                          
                          ]},
                    ds, { s:  "Preston went back home with more guides than he would be able to read before his trip."} , "Question", {q: "Where is Preston travelling?", as: ["Myanmar","Laos", "Cambodia"]}, Separator, { }],
                               
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. REMEMBER: it will last approximately 30 minutes, and will require your full attention throughout that period. Thank you for your help!"]
                           ]}],
                           
["presep", Separator, { transfer: 3000, normalMessage: "Get your hands in position, and get ready to begin!" }],

[ [ "impr_a", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that approximately 10 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
[ [ "impr_b", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that approximately 100 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
[ [ "impr_c", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that approximately 1,000 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
[ [ "impr_d", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that exactly 10 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],
[ [ "impr_e", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that exactly 100 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],

[ [ "impr_f", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that exactly 1,000 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],

[ [ "impr_g", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 10 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],

[ [ "impr_h", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 100 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],

[ [ "impr_i", 1 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study."],
                          
                          ]},
                    ds, { s:  "The nurse replied that 1,000 patients were currently waitlisted."} , "Question", {q: " When did the conversation between the nurse and the doctor take place? ", as: ["Morning","Night", "Afternoon"]}],


[ [ "impr_a", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn approximately 200 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_b", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn approximately 2,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_c", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn approximately 20,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_d", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn exactly 200 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_e", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn exactly 2,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_f", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn exactly 20,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_g", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 200 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_h", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 2,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],

[ [ "impr_i", 2 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be."],
                          
                          ]},
                    ds, { s:  "His boss said that Peet would earn 20,000 dollars less per year."} , "Question", {q: "What was Peet worried about?", as: ["Salary reduction","Paying his taxes", "Health issues"]}],


[ [ "impr_a", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was approximately 30 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

[ [ "impr_b", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was approximately 300 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                                        
[ [ "impr_c", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was approximately 3,000 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                  

[ [ "impr_d", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was exactly 30 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                    
[ [ "impr_e", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was exactly 300 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                    

[ [ "impr_f", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was exactly 3,000 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                    

[ [ "impr_g", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 30 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                    
[ [ "impr_h", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 300 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],
                    
[ [ "impr_i", 3 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost."],
                          
                          ]},
                    ds, { s:  "Betsy answered that the toaster was 3,000 points after applying the discounts."} , "Question", {q: "What kind of card did Betsy use to earn points? ", as: ["Credit","Debit", "Frequent flyer"]}],

[ [ "impr_a", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling approximately 50 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_b", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling approximately 500 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_c", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling approximately 5,000 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_d", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling exactly 50 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_e", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling exactly 500 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_f", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling exactly 5,000 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_g", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling 50 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_h", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling 500 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],

[ [ "impr_i", 4 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling."],
                          
                          ]},
                    ds, { s: "The farmer replied that he was selling 5,000 gallons on a daily basis."} , "Question", {q: "What was Stephen inspecting?", as: ["A farm", "A factory", "A school"]}],


[ [ "impr_a", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had approximately 400 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_b", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had approximately 4,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_c", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had approximately 40,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_d", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had exactly 400 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_e", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had exactly 4,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_f", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had exactly 40,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_g", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had 400 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_h", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_i", 5 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter."],
                          
                          ]},
                    ds, { s: "Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."} , "Question", {q: "What’s Mary's position in her company?", as: ["PR manager", "Head of IT", "HR manager"]}],

[ [ "impr_a", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed approximately 400 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_b", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed approximately 4,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_c", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed approximately 40,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_d", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed exactly 400 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_e", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed exactly 4,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_f", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed exactly 40,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_g", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed 400 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_h", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed 4,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_i", 6 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed."],
                          
                          ]},
                    ds, { s: "The IRS representative said that Erika owed 40,000 dollars to the federal government."} , "Question", {q: "What government agency did Erika call?", as: ["IRS", "FBI", "CIA"]}],

[ [ "impr_a", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that approximately 900 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_b", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that approximately 9,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_c", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that approximately 90,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_d", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that exactly 900 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_e", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that exactly 9,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_f", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that exactly 90,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_g", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that 900 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_h", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that 9,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_i", 7 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated."],
                          
                          ]},
                    ds, { s: "His chief researcher told him that 90,000 people had submitted their answers."} , "Question", {q: "What was the poll about?", as: ["Presidential election", "Senate race", "Customer satisfaction"]}],

[ [ "impr_a", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by approximately 60 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_b", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by approximately 600 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_c", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by approximately 6,000 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_d", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by exactly 60 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_e", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by exactly 600 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_f", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by exactly 6,000 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_g", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by 60 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_h", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by 600 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_i", 8 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship."],
                          
                          ]},
                    ds, { s: "Abigayle said that she had won by 6,000 dollars the last time she played."} , "Question", {q: "Who asked Abigayle about her margin of victory?", as: ["Connor", "Julian", "Will"]}],

[ [ "impr_a", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that approximately 70 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
[ [ "impr_b", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that approximately 700 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
[ [ "impr_c", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that approximately 7,000 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
[ [ "impr_d", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that exactly 70 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
[ [ "impr_e", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that exactly 700 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
 [ [ "impr_f", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that exactly 7,000 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
 [ [ "impr_g", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that 70 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
 [ [ "impr_h", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that 700 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
 
[ [ "impr_i", 9 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct."],
                          
                          ]},
                    ds, { s: "The precinct captain said that 7,000 people had voted there that day."} , "Question", {q: "What was the event?", as: ["Caucus", "General election", "Primary"]}],
  
[ [ "impr_a", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had approximately 10 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_b", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had approximately 100 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_c", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had approximately 1,000 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_d", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had exactly 10 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_e", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had exactly 100 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_f", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had exactly 1,000 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_g", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had 10 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_h", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had 100 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_i", 10 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had."],
                          
                          ]},
                    ds, { s: "Carter said that his neighbor had 1,000 pounds at the time."} , "Question", {q: "What did Carter's neighbor sell? ", as: ["Cocaine", "LSD", "Heroin"]}], 
 
[ [ "impr_a", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew approximately 80 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_b", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew approximately 800 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_c", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew approximately 8,000 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_d", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew exactly 80 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_e", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew exactly 800 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_f", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew exactly 8,000 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_g", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew 80 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_h", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew 800 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_i", 11 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown."],
                          
                          ]},
                    ds, { s: "Emily said that the rocket flew 8,000 feet before falling back to the ground."} , "Question", {q: "What was the contest?", as: ["Model rockets", "Model airplanes", "Math Olympiad"]}],

[ [ "impr_a", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that approximately 900 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_b", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that approximately 9,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_c", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that approximately 90,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_d", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that exactly 900 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_e", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that exactly 9,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_f", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that exactly 90,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_g", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that 900 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_h", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that 9,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_i", 12 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost."],
                          
                          ]},
                    ds, { s: "The engineer said that 90,000 gallons had been spilled."} , "Question", {q: "What was spilled?", as: ["Oil", "Chemicals", "Apple juice"]}],
 
[ [ "impr_a", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained approximately 500 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_b", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained approximately 5,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_c", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained approximately 50,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_d", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained exactly 500 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_e", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained exactly 5,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
 [ [ "impr_f", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained exactly 50,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
 [ [ "impr_g", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained 500 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_h", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained 5,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_i", 13 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were."],
                          
                          ]},
                    ds, { s: "The professor answered that the files contained 50,000 rows not including headers."} , "Question", {q: "What was Erin’s final project on? ", as: ["Computational linguistics", "Computational chemistry", "Computational statistics"]}],
 
[ [ "impr_a", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that approximately 200 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
 
[ [ "impr_b", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that approximately 2,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
  
[ [ "impr_c", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that approximately 20,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
   
[ [ "impr_d", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that exactly 200 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
  
[ [ "impr_e", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that exactly 2,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
   
[ [ "impr_f", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that exactly 20,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
   
[ [ "impr_g", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that 200 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],

[ [ "impr_h", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that 2,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],
  
[ [ "impr_i", 14 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was."],
                          
                          ]},
                    ds, { s: "The scientists determined that 20,000 years was the age of the artifact."} , "Question", {q: "To whom did Noah take the artifact?", as: ["Paleontologists", "Obstetricians", "Dietitians"]}],

[ [ "impr_a", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the had plane travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled approximately 800 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_b", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled approximately 8,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_c", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled approximately 80,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_d", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled exactly 800 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_e", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled exactly 8,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_f", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled exactly 80,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_g", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled 800 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_h", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled 8,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_i", 15 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week."],
                          
                          ]},
                    ds, { s: "The engineer replied that the plane had travelled 80,000 miles with no major incidents."} , "Question", {q: "When did the conversation between the engineer and the pilot take place?", as: ["Before take off", "After landing", "During the flight"]}],

[ [ "impr_a", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that approximately 30 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_b", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that approximately 300 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_c", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that approximately 3,000 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_d", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that exactly 30 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_e", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that exactly 300 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_f", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that exactly 3,000 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_g", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that 30 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_h", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that 300 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_i", 16 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with."],
                          
                          ]},
                    ds, { s: "Her supervisor said that 3,000 degrees was the target temperature."} , "Question", {q: "Where does Julie work?", as: ["A lab", "IRS", "Wall Street"]}],

[ [ "impr_a", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had approximately 100 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_b", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had approximately 1,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],

[ [ "impr_c", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had approximately 10,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],

[ [ "impr_d", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had exactly 100 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_e", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had exactly 1,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_f", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had exactly 10,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_g", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had 100 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_h", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had 1,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_i", 17 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there."],
                          
                          ]},
                    ds, { s: "The veterinarian told her that they had 10,000 flamingos at the moment."} , "Question", {q: "Who was Sandy talking to?", as: ["A veterinarian", "A zookeeper", "A biologist"]}],
 
[ [ "impr_a", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed approximately 700 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                    
[ [ "impr_b", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed approximately 7,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                       
[ [ "impr_c", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed approximately 70,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                    
[ [ "impr_d", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed exactly 700 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                    
[ [ "impr_e", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed exactly 7,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                                        
[ [ "impr_f", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed exactly 70,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
                    
[ [ "impr_g", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed 700 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
 
[ [ "impr_h", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed 7,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],
 
[ [ "impr_i", 18 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed."],
                          
                          ]},
                    ds, { s: "The editor told him that they needed 70,000 copies by the end of the day."} , "Question", {q: "What kind of publication was the editor in charge of?", as: ["A newspaper", "A medical journal", "A magazine"]}],

[ [ "impr_a", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded approximately 700 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],
  
[ [ "impr_b", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded approximately 7,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_c", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded approximately 70,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_d", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded exactly 700 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_e", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded exactly 7,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_f", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded exactly 70,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_g", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded 700 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_h", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded 7,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_i", 19 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week."],
                          
                          ]},
                    ds, { s: "Andrea replied that the system had recorded 70,000 clicks all within the United States."} , "Question", {q: "In what department did Andrea work?", as: ["Data analysis", "Marketing", "Production"]}],

[ [ "impr_a", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up approximately 20 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],
 
[ [ "impr_b", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up approximately 200 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_c", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up approximately 2,000 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_d", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up exactly 20 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_e", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up exactly 200 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_f", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up exactly 2,000 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_g", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up 20 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_h", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up 200 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_i", 20 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold."],
                          
                          ]},
                    ds, { s: "Rachel responded that they needed to set up 2,000 chairs in the main room."} , "Question", {q: "What were Jordan and Rachel setting up for?", as: ["Concert", "Musical", "Play"]}],

[ [ "impr_a", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted approximately 30 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_b", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted approximately 300 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_c", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted approximately 3,000 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_d", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted exactly 30 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_e", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted exactly 300 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_f", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted exactly 3,000 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_g", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted 30 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_h", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted 300 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_i", 21 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have."],
                          
                          ]},
                    ds, { s: "Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."} , "Question", {q: "For what famous hotel chain was Clara making a floorplan?", as: ["Hilton", "Marriott", "Holiday Inn"]}],

[ [ "impr_a", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that approximately 80 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_b", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that approximately 800 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_c", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that approximately 8,000 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_d", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that exactly 80 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_e", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that exactly 800 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_f", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that exactly 8,000 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_g", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that 80 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_h", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that 800 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_i", 22 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening."],
                          
                          ]},
                    ds, { s: "The coordinator said that 8,000 Democrats would attend the event."} , "Question", {q: "Which candidate does Julian work for?", as: ["Bernie Sanders", "Jim Gilmore", "Lincoln Chafee"]}],

[ [ "impr_a", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired approximately 60 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_b", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired approximately 600 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_c", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired approximately 6,000 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_d", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired exactly 60 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_e", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired exactly 600 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_f", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired exactly 6,000 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_g", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired 60 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_h", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired 600 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_i", 23 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair."],
                          
                          ]},
                    ds, { s: "Peet said that he acquired 6,000 stamps at a very good price."} , "Question", {q: "Where did Peet buy his new stamps?", as: ["Stamp fair", "From a private collector", "Antique shop"]}],

[ [ "impr_a", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that approximately 90 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_b", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that approximately 900 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_c", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that approximately 9,000 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_d", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that exactly 90 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_e", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that exactly 900 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_f", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that exactly 9,000 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_g", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that 90 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_h", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that 900 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_i", 24 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost."],
                          
                          ]},
                    ds, { s: "The blood bank director said that 9,000 units had been contaminated."} , "Question", {q: "What caused the damage of the blood units?", as: ["A flood", "An earthquake", "A fire"]}],

[ [ "impr_a", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from approximately 60 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_b", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from approximately 600 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_c", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from approximately 6,000 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_d", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from exactly 60 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_e", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from exactly 600 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_f", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from exactly 6,000 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],
 
[ [ "impr_g", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from 60 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_h", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from 600 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_i", 25 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers."],
                          
                          ]},
                    ds, { s: "The manager said that information from 6,000 accounts had been stolen."} , "Question", {q: "Who had stolen from the company?", as: ["Hackers", "Terrorists", "Political activists"]}],

[ [ "impr_a", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that approximately 50 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_b", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that approximately 500 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_c", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that approximately 5,000 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_d", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that exactly 50 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_e", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that exactly 500 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_f", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that exactly 5,000 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_g", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that 50 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_h", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that 500 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_i", 26 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The Dean called her secretary to find out how many graduate students had received his email about the new grading policies."],
                          
                          ]},
                    ds, { s: "The secretary replied that 5,000 students had gotten the message."} , "Question", {q: "What was the email sent by the Dean's office about?", as: ["Grading policies", "Student fees", "Funding policies"]}],

[ [ "impr_a", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had approximately 40 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_b", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had approximately 400 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_c", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had approximately 4,000 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_d", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had exactly 40 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_e", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had exactly 400 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_f", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had exactly 4,000 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_g", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had 40 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_h", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had 400 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "impr_i", 27 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After learning that Pamela finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had during the last week."],
                          
                          ]},
                    ds, { s: "Pamela replied that her video had 4,000 views from several countries."} , "Question", {q: "What kind of video did Pamela upload to YouTube?", as: ["Music video", "Tutorial", "Cat video"]}],

[ [ "f_1", 28 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was."],
                          
                          ]},
                    ds, { s: "The map showed that the nearest lodge was still several miles away."} , "Question", {q: "What was several miles way?", as: ["Lodge", "Hostel", "Cabin"]}],
                    
[ [ "f_1", 29 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "While marathoning her favorite TV show, Avatar, Jhanelle checked the list to see exactly how many episodes were left."],
                          
                          ]},
                    ds, { s: "The list showed that she still had a few episodes left."} , "Question", {q: "What show was Jhanelle watching?", as: ["Avatar", "Breaking Bad", "Spongebob"]}],                    
                    
[ [ "f_1", 30 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the disappointing loss, Akash asked the basketball coach approximately how many turnovers he had committed."],
                          
                          ]},
                    ds, { s: "The coach said Akash had committed far too many turnovers."} , "Question", {q: "What was the couch's opinion about the amount of turnovers Akash committed?", as: ["Bad", "Good", "Indifferent"]}],

[ [ "f_1", 31 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Iz tested herself to see exactly how many airplane noises she could identify."],
                          
                          ]},
                    ds, { s: "She found that she could identify every airplane noise."} , "Question", {q: "What type of sound is Iz identifying?", as: ["Airplane noises", "Car horns", "Train whistles"]}],

[ [ "f_1", 32 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "The spectators were amazed by David's skill and asked him approximately how many knives he could juggle at once."],
                          
                          ]},
                    ds, { s: "David answered that he could juggle quite a few knives at one time."} , "Question", {q: "How many knives could David juggle at once?", as: ["Lots", "Few", "Not more than two"]}],

[ [ "f_1", 33 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Isabella was collecting flight statistics and asked the air traffic controller exactly how many planes would be flying through O'Hare that day."],
                          
                          ]},
                    ds, { s: "The air traffic controller replied that the airports would see an average number of flights that day."} , "Question", {q: "At what airport are statistics being collected?", as: ["O'Hare", "JFK", "Midway"]}],
 
[ [ "f_1", 34 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Bardia was bored and decided to count exactly how many tiles were on the floor of the lecture hall."],
                          
                          ]},
                    ds, { s: "He found that there were more tiles than he cared to count."} , "Question", {q: "Where was Bardia?", as: ["Lecture hall", "Kitchen", "Bathroom"]}],

[ [ "f_1", 35 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Kevin wanted to know exactly how many successful coups d'état there had been in American history."],
                          
                          ]},
                    ds, { s: "He learned that there had been none."} , "Question", {q: "How many coups d'état have there been in American history?", as: ["Zero", "One", "Two"]}],

[ [ "f_1", 36 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Pat went out knocking on doors while campaigning for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day."],
                          
                          ]},
                    ds, { s: "Pat answered that he had knocked on an enormous number of doors."} , "Question", {q: "Who is Pat campaigning for?", as: ["Jim Gilmore", "Lincoln Chafee", "Lawrence Lessig"]}],

[ [ "f_1", 37 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Brian decided that he would count approximately how many spoons there were in the South Campus dining hall."],
                          
                          ]},
                    ds, { s: "He counted many, many spoons."} , "Question", {q: "Which dining hall did Brian investigate?", as: ["South", "Bartlett", "Pierce"]}],
 
[ [ "f_1", 38 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Nancy, a salesperson, had to count up exactly how many pieces of cereal were in each box."],
                          
                          ]},
                    ds, { s: "Not surprisingly, she found that each box contained a lot of pieces of cereal."} , "Question", {q: "What is Nancy?", as: ["Salesperson", "Janitor", "Chef"]}],
    
[ [ "f_2", 39 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Dylan asked his boss how many people definitely would show up to the meeting."],
                          
                          ]},
                    ds, { s: "His boss said that exactly 20 people would come."} , "Question", {q: "What is the event?", as: ["Meeting", "Funeral", "Wedding"]}],

[ [ "f_2", 40 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Gerri asked the Goldman-Sachs executive nervously how many other candidates there were for the position."],
                          
                          ]},
                    ds, { s: "He told her that approximately 50 other candidates were being interviewed."} , "Question", {q: "What company has Gerri applied to?", as: ["Goldman Sachs", "JP Morgan", "US Bank"]}], 
 
[ [ "f_2", 41 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "A perplexed Jay wondered constantly how many of his classmates had failed the economics midterm."],
                          
                          ]},
                    ds, { s: "It turned out that exactly 20 of Jay's classmates had failed the exam."} , "Question", {q: "What subject was Jay studying?", as: ["Economics", "Chemistry", "Physics"]}],

[ [ "f_2", 42 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Nora wondered exasperatedly how many hours she would have to spend dancing that weekend."],
                          
                          ]},
                    ds, { s: "According to her schedule, she would dance for approximately 20 hours."} , "Question", {q: "What did Nora check?", as: ["Her schedule", "Her phone", "Her agenda"]}],
    
[ [ "f_2", 43 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "During the theology exam, Ryan racked his brain, asking himself frustratedly how many commandments there were."],
                          
                          ]},
                    ds, { s: "He then recalled that there were exactly 10 commandments."} , "Question", {q: "What subject is Ryan studying?", as: ["Theology", "History", "Arabic"]}],

[ [ "f_2", 44 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Curious acquaintances often wondered fervently how many languages Nina spoke."],
                          
                          ]},
                    ds, { s: "She revealed one day that she spoke exactly 10 languages."} , "Question", {q: "What is the polyglot's name?", as: ["Nina", "Bill", "Ted"]}],

[ [ "f_2", 45 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "On her visit to the alpaca farm, Shannon asked excitedly how many alpacas there were."],
                          
                          ]},
                    ds, { s: "She was informed that there were approximately 40 alpacas."} , "Question", {q: "What animal is Shannon seeing?", as: ["Alpacas", "Llamas", "Dromedaries"]}],

[ [ "f_2", 46 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating."],
                          
                          ]},
                    ds, { s: "She found that the average student procrastinates for approximately 20 hours per week."} , "Question", {q: "What did Angela study?", as: ["Procrastination", "Sleeping", "Eating"]}],

[ [ "f_2", 47 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elaina was lost and asked a pedestrian desperately how many blocks away the University of Chicago's campus was."],
                          
                          ]},
                    ds, { s: "The pedestrian said that the campus was approximately 10 blocks away."} , "Question", {q: "What campus is Elaina looking for?", as: ["University of Chicago", "Northwestern", "Harvard"]}],

[ [ "f_2", 48 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "After the accident, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop."],
                          
                          ]},
                    ds, { s: "The agent told him that it would cost exactly 500 dollars."} , "Question", {q: "What does Zach need repaired?", as: ["Laptop", "Refrigerator", "Car"]}],

[ [ "f_2", 49 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "William was interested in famous train heists and looked up curiously how many dollars Jesse James had stolen in his robbery."],
                          
                          ]},
                    ds, { s: "He learned that approximately 3,000 dollars had been taken."} , "Question", {q: "Who is William studying?", as: ["Jesse James", "Walter White", "Al Capone"]}],
 
[ [ "f_3", 50 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "James and Karnika asked the organizer how many people certainly would come to their wedding."],
                          
                          ]},
                    ds, { s: "The organizer replied that a large handful of people would come."} , "Question", {q: "How many people were invited to the wedding?", as: ["A lot", "Not a lot", "Ten"]}],

[ [ "f_3", 51 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Claire pondered carefully how many new strings she needed for her violin."],
                          
                          ]},
                    ds, { s: "She determined she needed several new strings."} , "Question", {q: "What does Claire play?", as: ["Violin", "Guitar", "Viola"]}],

[ [ "f_3", 52 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Remy asked his friends persistently how many of them would be participating in the scavenger hunt in the spring."],
                          
                          ]},
                    ds, { s: "He learned that few of his friends would participate."} , "Question", {q: "When does the scavenger hunt take place?", as: ["Spring", "Fall", "Winter"]}],
 
[ [ "f_3", 53 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday."],
                          
                          ]},
                    ds, { s: "They said they would be willing to make calls for a few hours."} , "Question", {q: "What kind of volunteer work were Rebecca's friends going to do?", as: ["Phone calls", "Tutoring", "Coaching"]}],
 
[ [ "f_3", 54 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "In the course of preparing for move-in, Louis asked the housing officials curiously how many new residents there would be that year."],
                          
                          ]},
                    ds, { s: "The officials told him there would be many new residents."} , "Question", {q: "Who asked this question?", as: ["Louis", "Dustin", "Helen"]}],
 
[ [ "f_3", 55 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Before leaving on her vacation, Julie asked her friends how many gallons of gas probably would be needed to get her to Pasadena."],
                          
                          ]},
                    ds, { s: "They told her that only a few gallons would be necessary."} , "Question", {q: "How many Gallons were necessary to make the trip?", as: ["A few", "A couple", "A full tank"]}], 

[ [ "f_3", 56 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Caleb went to the doughnut shop and asked the salesperson hungrily how many doughnuts there were left."],
                          
                          ]},
                    ds, { s: "The salesperson answered that there was a donut shortage and that they had only a few doughnuts left."} , "Question", {q: "What was the problem?", as: ["Doughnut shortage", "No doughnuts had not been delivered that day", "All doughnuts were sold out"]}],  
 
[ [ "f_3", 57 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Erin, an avid reader, wondered intently how many words were in the book 'War and Peace.'"],
                          
                          ]},
                    ds, { s: "She quickly discovered that it contained more words than she could count."} , "Question", {q: "For how long did Erin inspect the book?", as: ["Not for long", "She was not inspecting a book", "A year"]}],  
 
[ [ "f_3", 58 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Ulysses was in a bad mood and demanded to know immediately how many minutes his pizza would need to cook."],
                          
                          ]},
                    ds, { s: "The waiter responded that the food would be ready in a few minutes."} , "Question", {q: "When was the pizza going to be ready?", as: ["In a few minutes", "In an hour", "In an hour and a half"]}],  
                    
[ [ "f_3", 59 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Elaine asked her classmates nosily how many siblings they each had."],
                          
                          ]},
                    ds, { s: "She was informed that most of them had a few siblings."} , "Question", {q: "Whom did Elaine ask?", as: ["Classmates", "Neighbors", "Teachers"]}],  

[ [ "f_3", 60 ], "Message", {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "When a notification of delay came in, Frederick asked the gate attendant despondently how many hours his flight to Columbus would be delayed."],
                          
                          ]},
                    ds, { s: "The attendant reassured him that the delay was only a few minutes."} , "Question", {q: "How confident was the attendant about the length of the delay?", as: ["Very confident", "Not very confident", "Neutral"]}]

];