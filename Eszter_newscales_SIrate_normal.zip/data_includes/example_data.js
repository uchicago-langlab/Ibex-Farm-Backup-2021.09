define_ibex_controller({
name: "MyController",
jqueryWidget: {
_init: function () {
this.options.transfer = null; // Remove ’click to continue message’.
this.element.VBox({
options: this.options,
triggers: [1],
children: [
"Form", this.options,
"Question", this.options,
]
});
}
},
properties: { }
});


var shuffleSequence = seq("setcounter","screenshot","consent", "introfirst", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true,
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true
    },

    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: null
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
   ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],    
         ["introfirst", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Click here to continue."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Click here to continue."} ],
//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a sentence, and decide whether you can conclude something from that sentence."] 
],continueMessage:"Click here to start the experiment."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 
["practice", "MyController", {html: "<p>Mary: <i>The wrestler is strong.</i></p><p> Would you conclude from this that Mary thinks the wrestler is not weak?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["practice", "MyController", {html: "<p>Mary: <i>The spy memorized the plan.</i></p><p> Would you conclude from this that Mary thinks the spy did not discover the plan?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
[["screenshot",1], "MyController", {html: "<p>Mary: <i>The student is intelligent.</i></p><p> Would you conclude from this that Mary thinks the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//Experimental items
 
//["e1", "Question",       {q: "Mary: This student is intelligent. Would you conclude from this that, according to John, she is not brilliant?", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",1], "MyController",       {html: "<p>Mary: <i>Drinking is allowed.</i></p><p> Would you conclude from this that Mary thinks drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",1], "MyController",       {html: "<p>Mary: <i>Drinking is only allowed.</i></p><p> Would you conclude from this that Mary thinks drinking is not obligatory?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",2], "MyController",       {html: "<p>Mary: <i>The model is attractive.</i></p><p> Would you conclude from this that Mary thinks the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",2], "MyController",       {html: "<p>Mary: <i>The model is only attractive.</i></p><p> Would you conclude from this that Mary thinks the model is not stunning?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",3], "MyController",       {html: "<p>Mary: <i>John began the race.</i></p><p> Would you conclude from this that Mary thinks John did not complete the race?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",3], "MyController",       {html: "<p>Mary: <i>John only began the race.</i></p><p> Would you conclude from this that Mary thinks John did not complete the race?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",4], "MyController",       {html: "<p>Mary: <i>The teacher believes it is true.</i></p><p> Would you conclude from this that Mary thinks the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",4], "MyController",       {html: "<p>Mary: <i>The teacher only believes it is true.</i></p><p> Would you conclude from this that Mary thinks the teacher doesn't know it is true?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",5], "MyController",       {html: "<p>Mary: <i>The elephant is big.</i></p><p> Would you conclude from this that Mary thinks the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",5], "MyController",       {html: "<p>Mary: <i>The elephant is only big.</i></p><p> Would you conclude from this that Mary thinks the elephant is not enormous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",6], "MyController",       {html: "<p>Mary: <i>The weather is cool.</i></p><p> Would you conclude from this that Mary thinks the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",6], "MyController",       {html: "<p>Mary: <i>The weather is only cool.</i></p><p> Would you conclude from this that Mary thinks the weather is not cold?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",7], "MyController",       {html: "<p>Mary: <i>The machine damaged itself.</i></p><p> Would you conclude from this that Mary thinks the machine did not destroy itself?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",7], "MyController",       {html: "<p>Mary: <i>The machine only damaged itself.</i></p><p> Would you conclude from this that Mary thinks the machine did not destroy itself?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",8], "MyController",       {html: "<p>Mary: <i>The sky is dark.</i></p><p> Would you conclude from this that Mary thinks the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",8], "MyController",       {html: "<p>Mary: <i>The sky is only dark.</i></p><p> Would you conclude from this that Mary thinks the sky is not black?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",9], "MyController",       {html: "<p>Mary: <i>The task is difficult.</i></p><p> Would you conclude from this that Mary thinks the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",9], "MyController",       {html: "<p>Mary: <i>The task is only difficult.</i></p><p> Would you conclude from this that Mary thinks the task is not impossible?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",10], "MyController",       {html: "<p>Mary: <i>Zack's carpet was dirty.</i></p><p> Would you conclude from this that Mary thinks Zack's carpet was not filthy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",10], "MyController",       {html: "<p>Mary: <i>Zack's carpet was only dirty.</i></p><p> Would you conclude from this that Mary thinks Zack's carpet was not filthy?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",11], "MyController",       {html: "<p>Mary: <i>The doctor dislikes coffee.</i></p><p> Would you conclude from this that Mary thinks the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",11], "MyController",       {html: "<p>Mary: <i>The doctor only dislikes coffee.</i></p><p> Would you conclude from this that Mary thinks the doctor doesn't loathe coffee?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",12], "MyController", {html: "<p>Mary: <i>The sales will double. </i></p><p> Would you conclude from this that Mary thinks the sales will not triple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",12], "MyController", {html: "<p>Mary: <i>The sales will only double. </i></p><p> Would you conclude from this that Mary thinks the sales will not triple?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",13], "MyController", {html: "<p>Mary: <i>That candidate is equally skilled.</i></p><p> Would you conclude from this that Mary thinks the candidate is not more skilled?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",13], "MyController", {html: "<p>Mary: <i>That candidate is only equally skilled.</i></p><p> Would you conclude from this that Mary thinks the candidate is not more skilled?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",14], "MyController", {html: "<p>Mary: <i>The movie is funny.</i></p><p> Would you conclude from this that Mary thinks the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",14], "MyController", {html: "<p>Mary: <i>The movie is only funny.</i></p><p> Would you conclude from this that Mary thinks the movie is not hilarious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",15], "MyController", {html: "<p>Mary: <i>The movie is good.</i></p><p> Would you conclude from this that Mary thinks the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",15], "MyController", {html: "<p>Mary: <i>The movie is only good.</i></p><p> Would you conclude from this that Mary thinks the movie is not excellent?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",16], "MyController", {html: "<p>Mary: <i>The winner was happy.</i></p><p> Would you conclude from this that Mary thinks the winner was not ecstatic?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",16], "MyController", {html: "<p>Mary: <i>The winner was only happy.</i></p><p> Would you conclude from this that Mary thinks the winner was not ecstatic?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",17], "MyController", {html: "<p>Mary: <i>The problem is hard.</i></p><p> Would you conclude from this that Mary thinks the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",17], "MyController", {html: "<p>Mary: <i>The problem is only hard.</i></p><p> Would you conclude from this that Mary thinks the problem is not unsolvable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",18], "MyController", {html: "<p>Mary: <i>The toxin is harmful.</i></p><p> Would you conclude from this that Mary thinks the toxin is not deadly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",18], "MyController", {html: "<p>Mary: <i>The toxin is only harmful.</i></p><p> Would you conclude from this that Mary thinks the toxin is not deadly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",19], "MyController", {html: "<p>Mary: <i>There is water here.</i></p><p> Would you conclude from this that Mary thinks there isn't water everywhere?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",19], "MyController", {html: "<p>Mary: <i>There is water only here.</i></p><p> Would you conclude from this that Mary thinks there isn't water everywhere?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",20], "MyController", {html: "<p>Mary: <i>The boy is hungry.</i></p><p> Would you conclude from this that Mary thinks the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",20], "MyController", {html: "<p>Mary: <i>The boy is only hungry.</i></p><p> Would you conclude from this that Mary thinks the boy is not starving?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",21], "MyController", {html: "<p>Mary: <i>The student is intelligent.</i></p><p> Would you conclude from this that Mary thinks the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",21], "MyController", {html: "<p>Mary: <i>The student is only intelligent.</i></p><p> Would you conclude from this that Mary thinks the student is not brilliant?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",22], "MyController", {html: "<p>Mary: <i>Chris's opponent was intimidating.</i></p><p> Would you conclude from this that Mary thinks Chris's opponent was not terrifying?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",22], "MyController", {html: "<p>Mary: <i>Chris's opponent was only intimidating.</i></p><p> Would you conclude from this that Mary thinks Chris's opponent was not terrifying?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",23], "MyController", {html: "<p>Mary: <i>The coast was largely flooded.</i></p><p> Would you conclude from this that Mary thinks the coast was not totally flooded?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",23], "MyController", {html: "<p>Mary: <i>The coast was only largely flooded.</i></p><p> Would you conclude from this that Mary thinks the coast was not totally flooded?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",24], "MyController", {html: "<p>Mary: <i>The princess likes dancing.</i></p><p> Would you conclude from this that Mary thinks the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",24], "MyController", {html: "<p>Mary: <i>The princess only likes dancing.</i></p><p> Would you conclude from this that Mary thinks the princess doesn't love dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",25], "MyController", {html: "<p>Mary: <i>Bill's score matches Al's.</i></p><p> Would you conclude from this that Mary thinks Bill's score does not exceed Al's?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",25], "MyController", {html: "<p>Mary: <i>Bill's score only matches Al's.</i></p><p> Would you conclude from this that Mary thinks Bill's score does not exceed Al's?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",26], "MyController", {html: "<p>Mary: <i>Peter's answers were mostly wrong.</i></p><p> Would you conclude from this that Mary thinks Peter's answers were not entirely wrong?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",26], "MyController", {html: "<p>Mary: <i>Peter's answers were only mostly wrong.</i></p><p> Would you conclude from this that Mary thinks Peter's answers were not entirely wrong?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",27], "MyController", {html: "<p>Mary: <i>The house is old.</i></p><p> Would you conclude from this that Mary thinks the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",27], "MyController", {html: "<p>Mary: <i>The house is only old.</i></p><p> Would you conclude from this that Mary thinks the house is not ancient?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",28], "MyController", {html: "<p>Mary: <i>Mistakes happened once.</i></p><p> Would you conclude from this that Mary thinks mistakes did not happen twice?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",28], "MyController", {html: "<p>Mary: <i>Mistakes happened only once.</i></p><p> Would you conclude from this that Mary thinks mistakes did not happen twice?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

//figure out only!!!
//[["ESI",29], "MyController", {html: "<p>Mary: <i>Jimmy writes books or plays.</i></p><p> Would you conclude from this that Mary thinks Jimmy does not write books and plays?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
////[["Eonly",29], "MyController", {html: "<p>Mary: <i>Jimmy writes books or plays.</i></p><p> Would you conclude from this that Mary thinks Jimmy does not write books and plays?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",29], "MyController", {html: "<p>Mary: <i>Everyone saw Wonder Woman or Batman.</i></p><p> Would you conclude from this that Mary thinks it's not the case that everyone saw Wonder Woman and Batman?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",29], "MyController", {html: "<p>Mary: <i>Everyone saw only Wonder Woman or Batman.</i></p><p> Would you conclude from this that Mary thinks it's not the case that everyone saw Wonder Woman and Batman?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",30], "MyController", {html: "<p>Mary: <i>The teenager is overweight.</i></p><p> Would you conclude from this that Mary thinks the teenager is not obese?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",30], "MyController", {html: "<p>Mary: <i>The teenager is only overweight.</i></p><p> Would you conclude from this that Mary thinks the teenager is not obese?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",31], "MyController", {html: "<p>Mary: <i>The measure was supported overwhelmingly.</i></p><p> Would you conclude from this that Mary thinks the measure was not supported unanimously?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",31], "MyController", {html: "<p>Mary: <i>The measure was supported only overwhelmingly.</i></p><p> Would you conclude from this that Mary thinks the measure was not supported unanimously?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",32], "MyController", {html: "<p>Mary: <i>The wine is palatable.</i></p><p> Would you conclude from this that Mary thinks the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",32], "MyController", {html: "<p>Mary: <i>The wine is only palatable.</i></p><p> Would you conclude from this that Mary thinks the wine is not delicious?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",33], "MyController", {html: "<p>Mary: <i>The tank is partially full.</i></p><p> Would you conclude from this that Mary thinks the tank is not completely full?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",33], "MyController", {html: "<p>Mary: <i>The tank is only partially full.</i></p><p> Would you conclude from this that Mary thinks the tank is not completely full?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",34], "MyController", {html: "<p>Mary: <i>The club permits dancing.</i></p><p> Would you conclude from this that Mary thinks the club doesn't require dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",34], "MyController", {html: "<p>Mary: <i>The club only permits dancing.</i></p><p> Would you conclude from this that Mary thinks the club doesn't require dancing?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",35], "MyController", {html: "<p>Mary: <i>Ann's speech was polished.</i></p><p> Would you conclude from this that Mary thinks Ann's speech was not impeccable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",35], "MyController", {html: "<p>Mary: <i>Ann's speech was only polished.</i></p><p> Would you conclude from this that Mary thinks Ann's speech was not impeccable?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",36], "MyController", {html: "<p>Mary: <i>Success is possible.</i></p><p> Would you conclude from this that Mary thinks success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",36], "MyController", {html: "<p>Mary: <i>Success is only possible.</i></p><p> Would you conclude from this that Mary thinks success is not certain?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",37], "MyController", {html: "<p>Mary: <i>The girl is pretty.</i></p><p> Would you conclude from this that Mary thinks the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",37], "MyController", {html: "<p>Mary: <i>The girl is only pretty.</i></p><p> Would you conclude from this that Mary thinks the girl is not beautiful?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",38], "MyController", {html: "<p>Mary: <i>The residents are primarily Greek.</i></p><p> Would you conclude from this that Mary thinks the resident are not exclusively Greek?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",38], "MyController", {html: "<p>Mary: <i>The residents are only primarily Greek.</i></p><p> Would you conclude from this that Mary thinks the resident are not exclusively Greek?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",39], "MyController", {html: "<p>Mary: <i>A delay will probably occur.</i></p><p> Would you conclude from this that Mary thinks a delay won't necessarily occur?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",39], "MyController", {html: "<p>Mary: <i>A delay will only probably occur.</i></p><p> Would you conclude from this that Mary thinks a delay won't necessarily occur?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",40], "MyController", {html: "<p>Mary: <i>The city reduced waste.</i></p><p> Would you conclude from this that Mary thinks the city did not eliminate waste?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",40], "MyController", {html: "<p>Mary: <i>The city only reduced waste.</i></p><p> Would you conclude from this that Mary thinks the city did not eliminate waste?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",41], "MyController", {html: "<p>Mary: <i>Stu's daughter was scared.</i></p><p> Would you conclude from this that Mary thinks Stu's daughter was not petrified?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",41], "MyController", {html: "<p>Mary: <i>Stu's daughter was only scared.</i></p><p> Would you conclude from this that Mary thinks Stu's daughter was not petrified?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",42], "MyController", {html: "<p>Mary: <i>Kaye's illness was serious.</i></p><p> Would you conclude from this that Mary thinks Kaye's illness was not life-threatening?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",42], "MyController", {html: "<p>Mary: <i>Kaye's illness was only serious.</i></p><p> Would you conclude from this that Mary thinks Kaye's illness was not life-threatening?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",43], "MyController", {html: "<p>Mary: <i>The two paintings are similar.</i></p><p> Would you conclude from this that Mary thinks the two paintings are not identical?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",43], "MyController", {html: "<p>Mary: <i>The two paintings are only similar.</i></p><p> Would you conclude from this that Mary thinks the two paintings are not identical?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",44], "MyController", {html: "<p>Mary: <i>The train slowed.</i></p><p> Would you conclude from this that Mary thinks the train did not stop?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",44], "MyController", {html: "<p>Mary: <i>The train only slowed.</i></p><p> Would you conclude from this that Mary thinks the train did not stop?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",45], "MyController", {html: "<p>Mary: <i>The fish is small.</i></p><p> Would you conclude from this that Mary thinks the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",45], "MyController", {html: "<p>Mary: <i>The fish is only small.</i></p><p> Would you conclude from this that Mary thinks the fish is not tiny?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",46], "MyController", {html: "<p>Mary: <i>The shirt is snug.</i></p><p> Would you conclude from this that Mary thinks the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",46], "MyController", {html: "<p>Mary: <i>The shirt is only snug.</i></p><p> Would you conclude from this that Mary thinks the shirt is not tight?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

 [["ESI",47], "MyController", {html: "<p>Mary: <i>Cecilia trusts some politicians.</i></p><p> Would you conclude from this that Mary thinks Cecilia doesn't trust all politicians?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",47], "MyController", {html: "<p>Mary: <i>Cecilia trusts only some politicians.</i></p><p> Would you conclude from this that Mary thinks Cecilia doesn't trust all politicians?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",48], "MyController", {html: "<p>Mary: <i>The runner started.</i></p><p> Would you conclude from this that Mary thinks the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",48], "MyController", {html: "<p>Mary: <i>The runner only started.</i></p><p> Would you conclude from this that Mary thinks the runner did not finish?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",49], "MyController", {html: "<p>Mary: <i>The plant survived.</i></p><p> Would you conclude from this that Mary thinks the plant did not thrive?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",49], "MyController", {html: "<p>Mary: <i>The plant only survived.</i></p><p> Would you conclude from this that Mary thinks the plant did not thrive?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",50], "MyController", {html: "<p>Mary: <i>The worker is tired.</i></p><p> Would you conclude from this that Mary thinks the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",50], "MyController", {html: "<p>Mary: <i>The worker is only tired.</i></p><p> Would you conclude from this that Mary thinks the worker is not exhausted?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",51], "MyController", {html: "<p>Mary: <i>Joey's parents tolerate dating.</i></p><p> Would you conclude from this that Mary thinks the Joey's parents do not encourage dating?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",51], "MyController", {html: "<p>Mary: <i>Joey's parents only tolerate dating.</i></p><p> Would you conclude from this that Mary thinks the Joey's parents do not encourage dating?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",52], "MyController", {html: "<p>Mary: <i>The candidate tried.</i></p><p> Would you conclude from this that Mary thinks the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",52], "MyController", {html: "<p>Mary: <i>The candidate only tried.</i></p><p> Would you conclude from this that Mary thinks the candidate did not succeed?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",53], "MyController", {html: "<p>Mary: <i>The wallpaper is ugly.</i></p><p> Would you conclude from this that Mary thinks the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",53], "MyController", {html: "<p>Mary: <i>The wallpaper is only ugly.</i></p><p> Would you conclude from this that Mary thinks the wallpaper is not hideous?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",54], "MyController", {html: "<p>Mary: <i>Tom's interview was understandable.</i></p><p> Would you conclude from this that Mary thinks Tom's interview was not articulate?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",54], "MyController", {html: "<p>Mary: <i>Tom's interview was only understandable.</i></p><p> Would you conclude from this that Mary thinks Tom's interview was not articulate?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",55], "MyController", {html: "<p>Mary: <i>Tim's bathroom was unpleasant.</i></p><p> Would you conclude from this that Mary thinks Tim's bathroom is not disgusting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",55], "MyController", {html: "<p>Mary: <i>Tim's bathroom was only unpleasant.</i></p><p> Would you conclude from this that Mary thinks Tim's bathroom is not disgusting?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",56], "MyController", {html: "<p>Mary: <i>The lawyer is usually early.</i></p><p> Would you conclude from this that Mary thinks the lawyer is not always early?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",56], "MyController", {html: "<p>Mary: <i>The lawyer is only usually early.</i></p><p> Would you conclude from this that Mary thinks the lawyer is not always early?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",57], "MyController", {html: "<p>Mary: <i>Phoebe wants a car.</i></p><p> Would you conclude from this that Mary thinks Phoebe doesn't need a car?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",57], "MyController", {html: "<p>Mary: <i>Phoebe only wants a car.</i></p><p> Would you conclude from this that Mary thinks Phoebe doesn't need a car?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",58], "MyController", {html: "<p>Mary: <i>The weather is warm.</i></p><p> Would you conclude from this that Mary thinks the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",58], "MyController", {html: "<p>Mary: <i>The weather is only warm.</i></p><p> Would you conclude from this that Mary thinks the weather is not hot?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",59], "MyController", {html: "<p>Mary: <i>The rehearsal went well.</i></p><p> Would you conclude from this that Mary thinks the rehearsal didn't go superbly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",59], "MyController", {html: "<p>Mary: <i>The rehearsal only went well.</i></p><p> Would you conclude from this that Mary thinks the rehearsal didn't go superbly?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],

[["ESI",60], "MyController", {html: "<p>Mary: <i>The waiter is willing.</i></p><p> Would you conclude from this that Mary thinks the waiter is not eager?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
//[["Eonly",60], "MyController", {html: "<p>Mary: <i>The waiter is only willing.</i></p><p> Would you conclude from this that Mary thinks the waiter is not eager?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],


//Filler items NEED MORE???
["filler1", "MyController", {html: "<p>Mary: <i>The table is clean.</i></p><p> Would you conclude from this that Mary thinks the table is not dirty?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler2", "MyController", {html: "<p>Mary: <i>The soldier is dangerous.</i></p><p> Would you conclude from this that Mary thinks the soldier is not harmless?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler3", "MyController", {html: "<p>Mary: <i>The man is drunk.</i></p><p> Would you conclude from this that Mary thinks the man is not sober?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler4", "MyController", {html: "<p>Mary: <i>The neighbor is sleepy.</i></p><p> Would you conclude from this that Mary thinks the neighbor is not rich?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler5", "MyController", {html: "<p>Mary: <i>The gymnast is tall.</i></p><p> Would you conclude from this that Mary thinks the gymnast is not single?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler6", "MyController", {html: "<p>Mary: <i>The doll is ugly.</i></p><p> Would you conclude from this that Mary thinks the doll is not old?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}],
["filler7", "MyController", {html: "<p>Mary: <i>The street is wide.</i></p><p> Would you conclude from this that Mary thinks the street is not narrow?</p>", q:"", as: ["Yes.", "No."], hasCorrect: 0, randomOrder: false}]// NOTE NO COMMA

];
