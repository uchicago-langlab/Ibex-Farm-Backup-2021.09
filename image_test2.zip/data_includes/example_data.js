/*
--Toronto-Psycholinguistics-Experiments--

Template that gives examples of everything Ibex can do for experiments
*/

var shuffleSequence = seq(anyType);
var practiceItemTypes = ["practice"];
var centerItems = true;


var defaults = [
    
    "MyController", {
        randomOrder: true 
        //setting default order for pictures to be random 
        //you can check this is true by simply trying experiment multiple times
     },
    
    "MyGrid",{
        randomOrder: true,
        presentHorizontally: true
     },

    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [


    /*
    ===================
    INTRODUCTION
    Can include files for Questionnaires, consent forms etc...
    ===================
    */

    //name of controller
    ["intro",
      //type
      "Form",
      //obligatory option that includes a HTML file that is a questionnaire
      {html: { include: "example_intro.html" },
      //fields that need to have the right format when taking input from user
      validators: {
        //age has to be a number
        age: function (s) { if (s.match(/^\d+$/)) return true; else return "Bad value for \u2018age\u2019"; }
        }
    } ],



    /*
    ===================
    IMAGE
    Controllers that work with Images and Questions
    ===================
    */
    
    /*["testing", "MyGrid", {as: ["Hi", "Hello" ] , as2: ["bye", "farewell"]}],*/
    
    ["s2", "MyController", { s: "Do you see ___ in the below below pictures?", /*question you want to ask*/
                             as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
                                 ["A","http://www.premierecreative.com/wp-content/uploads/2014/11/1NumberOneInCircle.png"],
                                 ["B","http://modalpoint.com/wp-content/uploads/2015/08/Two-Mistakes.png"], 
                                 ["C","https://core4nutrition.com/sites/default/files/3NumberThreeInCircle.png"],                                 
                                 ["D","http://www.pushtechnology.com/wp-content/uploads/2013/06/4NumberFourInCircle.png"]]}]
    //[["Con", 1], "MyController", { s: "In this display, there is a bumpy square.", /*question you want to ask*/ /*Have added condition /group/ to the type*/
    //                         as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
    //                             ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"],
    //                             ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
    //                             ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                                 
    //                             ["D","http://lucian.uchicago.edu/blogs/lpl/files/2014/08/bumpy_redsquare1.jpg"]]}],
                                 
    //[["NCon", 1], "MyController", { s: "In this display, there is a bumpy square.", /*question you want to ask*/ /*Have added condition /group/ to the type*/
    //                         as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
    //                             ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_bluesquare4.jpg"],
    //                             ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/bumpy_greencircle4.jpg"], 
    //                             ["C","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/tall_yellowcylinder3.jpg"],                              
    //                             ["D","http://www.pushtechnology.com/wp-content/uploads/2013/06/4NumberFourInCircle.png"]]}],

    //[["Con", 2], "MyController", { s: "In this display, there is an open circle.", /*question you want to ask*/ /*Have added condition /group/ to the type*/
    //                         as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
    //                             ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle4.jpg"],
    //                             ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
    //                             ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],                                 
    //                             ["D","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/green_garabato.jpg"]]}], 

    //[["NCon", 2], "MyController", { s: "In this display, there is an open circle.", /*question you want to ask*/ /*Have added condition /group/ to the type*/
    //                         as: [ /*Images to show along with question, question default answers are set to "yes", "no", and "I don't know"*/
    //                                 ["A","http://lucian.uchicago.edu/blogs/lpl/files/2014/04/open_bluecircle4.jpg"],
    //                             ["B","http://lucian.uchicago.edu/blogs/lpl/files/2014/06/open_redtriangle4.jpg"], 
    //                             ["C","http://lucian.uchicago.edu/blogs/lpl/files/2015/07/yellow_cloud.jpg"],   
    //                             ["D","http://www.pushtechnology.com/wp-content/uploads/2013/06/4NumberFourInCircle.png"]]}]


];