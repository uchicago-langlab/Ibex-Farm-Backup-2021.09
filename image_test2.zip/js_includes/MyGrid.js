define_ibex_controller({
    name: "MyGrid",
    jqueryWidget: {
        _init: function () {
           // this.options.transfer = null; // Remove 'click to continue message'.         
            this.element.VBox({
                options: this.options,
                triggers: [2],
                children: [            
                                 //    timeout: null} //stimulus sentence option
                            "Question",  /*{//next controller, binary yes/no,    no options need to be passed
                                      q: null,
                                      presentAsScale: true,
                                      presentHorizontally: true },*/ this.options,
                            "Question2", /*{//next controller, binary yes/no,    no options need to be passed
                                      q: null,
                                      presentAsScale: true,
                                      presentHorizontally: true },*/ this.options,
                            "Form",  {html: 'Please construct a sentence: <input type="text" name="sentence" class = "obligatory">'},      
                ]
            });
        }
    },
    properties: {obligatory: ["as","as2"]}
});