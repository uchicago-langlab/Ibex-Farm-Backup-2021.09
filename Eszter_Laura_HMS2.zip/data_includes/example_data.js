var shuffleSequence = seq("setcounter","consent", "intro", sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("m"),startsWith("f")))), "brexit");
//var shuffleSequence = seq("suspend");
var practiceItemTypes = ["practice"];

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Kérjük, várjon a következő mondatra.",
        ignoreFailure: "true"
    },
    "DashedSentence", {
        mode: "self-paced reading",
        display: "in place"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Kattintson az egyik fentebbi számra, vagy használja a billentyűzetét.",
        leftComment: "(rossz válasz)", rightComment: "(jó válasz)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    // New in Ibex 0.3-beta-9. You can now add a '__SendResults__' controller in your shuffle
    // sequence to send results before the experiment has finished. This is NOT intended to allow
    // for incremental sending of results -- you should send results exactly once per experiment.
    // However, it does permit additional messages to be displayed to participants once the
    // experiment itself is over. If you are manually inserting a '__SendResults__' controller into
    // the shuffle sequence, you must set the 'manualSendResults' configuration variable to 'true', since
    // otherwise, results are automatically sent at the end of the experiment.
    //
    //["sr", "__SendResults__", { }],

    ["sep", "Separator", { }],
    ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Kattintson ide az eredmények elküldéséhez."} ],
    ["consent", "Form", {consentRequired: true, html: { include: "intro.html" }, validators: {},continueMessage:"Kattintson ide a folytatáshoz."} ],
     ["intro", "Form", {consentRequired: true, html: { include: "intro2.html" }, validators: {},continueMessage:"Kattintson ide a gyakorláshoz."} ],
    ["suspend", "Form", {consentRequired: true, html: { include: "suspend.html" }, validators: {}} ],

//    ["practiceover", "Message", {html: ["div",
//                          ["p", "This is the end of the practice."],
//                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read sentences and answer the questions that follow."] 
//],continueMessage:"Click here to continue."}],

 ["practiceover", "Message", {html: ["div",
                          ["p", "Vége a gyakorlásnak."],
                          ["p", "Most fog elkezdődni a valódi kísérlet, ahol ugyanaz lesz a feladata, mint eddig: egy párbeszédet fog látni, és azt a választ kell kiválasztania, amelyik az elfogadhatóbb/jobb az A által feltett kérdésre."] 
],continueMessage:"Kattintson ide a kísérlet elkezdéséhez."}],


  

    // New in Ibex 0.3-beta19. You can now determine the point in the experiment at which the counter
    // for latin square designs will be updated. (Previously, this was always updated upon completion
    // of the experiment.) To do this, insert the special '__SetCounter__' controller at the desired
    // point in your running order. If given no options, the counter is incremented by one. If given
    // an 'inc' option, the counter is incremented by the specified amount. If given a 'set' option,
    // the counter is set to the given number. (E.g., { set: 100 }, { inc: -1 })
    //
    ["setcounter", "__SetCounter__", { }],

    // NOTE: You could also use the 'Message' controller for the experiment intro (this provides a simple
    // consent checkbox).

//    ["intro", "Message", {html: ["div",
//                          ["p", "In this experiment, you are going to read each sentence as a series of word chunks. To do this, the experiment will only show one part of the sentence at a time. //Each sentence will start with a blank line, and you will have to press the spacebar to reveal the first word."],//
//                          ["p", "Keep pressing the spacebar to reveal each new word. When a word appears, it replaces the previous one you saw. Continue hitting the spacebar until you reach the end of the sentence."],
//                          ["p", "Please read at your normal speed, try to avoid going either too slow or too fast. Please read each sentence silently to yourself, do not read out loud."],
//                          ["p", "You will be asked a question after each sentence to test your comprehension. Click on the answer that you think is correct, then wait for the next sentence to start."],
//                          ["p", "Before the real experiment, you will complete two practice sentences that teach you the task."] 
//],continueMessage:"Click here for the practice."}],


//
// Three practice items:
//
 
["practice", "Question",       {q: "A: Úgy szeretem az állatokat! Láttad az elefántot az állatkertben?", as: ["B: Igen, láttam.", "B: Nem voltam moziban."], hasCorrect: 0, randomOrder: true}],
["practice", "Question",       {q: "A: Én magyar vagyok. Te honnan származol?", as: ["B: Nem igazán szeretem a csokitortát.", "B: Budapestről."], hasCorrect: 0, randomOrder: true}],
["practice", "Question",       {q: "A: Tegnap koncerten voltam. Te milyen fajta zenét szeretsz?", as: ["B: Ó, nagyon szeretem a zenét!", "B: Leginkább a rockot."], hasCorrect: 0, randomOrder: true}],

//
// 18 experimental sets for the multiple sluicing experiment.
// 6 conditions 
//
// Keys:
// m: experimental item for the Multiple sluicing experiment
// E: Ellipsis (sluicing); SF: Single Fronting; MF: Multiple Fronting
 
[["m.E",1], "Question",       {q: "A: Valaki, vagy valakik megcsókoltak valakit. Emlékszel, hogy ki kit?", as: ["B: Péter Marit.", "B: Péter Marit, Gábor Julit, András pedig Évát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",1], "Question",       {q: "A: Valaki, vagy valakik megcsókoltak valakit. Emlékszel, hogy ki csókolt meg kit?", as: ["B: Péter Marit.", "B: Péter Marit, Gábor Julit, András pedig Évát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",1], "Question",       {q: "A: Valaki, vagy valakik megcsókoltak valakit. Emlékszel, hogy ki kit csókolt meg?", as: ["B: Péter Marit.", "B: Péter Marit, Gábor Julit, András pedig Évát."], hasCorrect: 0, randomOrder: true}],


[["m.E",2], "Question",       {q: "A: Valaki, vagy valakik megütöttek valakit. Emlékszel, hogy ki kit?", as: ["B: János Zoltánt.", "B: János Zoltánt, Pali Gabit, Rudi pedig Lajost."], hasCorrect: 0, randomOrder: true}],
[["m.SF",2], "Question",       {q: "A: Valaki, vagy valakik megütöttek valakit. Emlékszel, hogy ki ütött meg kit?", as: ["B: János Zoltánt.", "B: János Zoltánt, Pali Gabit, Rudi pedig Lajost."], hasCorrect: 0, randomOrder: true}],
[["m.MF",2], "Question",       {q: "A: Valaki, vagy valakik megütöttek valakit. Emlékszel, hogy ki kit ütött meg?", as: ["B: János Zoltánt.", "B: János Zoltánt, Pali Gabit, Rudi pedig Lajost."], hasCorrect: 0, randomOrder: true}],


[["m.E",3], "Question",       {q: "A: Valaki, vagy valakik megijesztettek valakit. Emlékszel, hogy ki kit?", as: ["B: Emese Lujzát.", "B: Emese Lujzát, Peti Kristófot, Gábor pedig Mátét."], hasCorrect: 0, randomOrder: true}],
[["m.SF",3], "Question",       {q: "A: Valaki, vagy valakik megijesztettek valakit. Emlékszel, hogy ki ijesztett meg kit?", as: ["B: Emese Lujzát.", "B: Emese Lujzát, Peti Kristófot, Gábor pedig Mátét."], hasCorrect: 0, randomOrder: true}],
[["m.MF",3], "Question",       {q: "A: Valaki, vagy valakik megijesztettek valakit. Emlékszel, hogy ki kit ijesztett meg?", as: ["B: Emese Lujzát.", "B: Emese Lujzát, Peti Kristófot, Gábor pedig Mátét."], hasCorrect: 0, randomOrder: true}],


[["m.E",4], "Question",       {q: "A: Valaki, vagy valakik meghívtak valakit. Tudod, hogy ki kit?", as: ["B: Pisti Vilmost.", "B: Pisti Vilmost, Károly Orsit, Zsófi pedig Gyurit."], hasCorrect: 0, randomOrder: true}],
[["m.SF",4], "Question",       {q: "A: Valaki, vagy valakik meghívtak valakit. Tudod, hogy ki hívott meg kit?", as: ["B: Pisti Vilmost.", "B: Pisti Vilmost, Károly Orsit, Zsófi pedig Gyurit."], hasCorrect: 0, randomOrder: true}],
[["m.MF",4], "Question",       {q: "A: Valaki, vagy valakik meghívtak valakit. Tudod, hogy ki kit hívott meg?", as: ["B: Pisti Vilmost.", "B: Pisti Vilmost, Károly Orsit, Zsófi pedig Gyurit."], hasCorrect: 0, randomOrder: true}],


[["m.E",5], "Question",       {q: "A: Valaki, vagy valakik kinevettek valakit. Emlékszel, hogy ki kit?", as: ["B: Feri Krisztát.", "B: Feri Krisztát, Erika Annát, Balázs pedig Áront."], hasCorrect: 0, randomOrder: true}],
[["m.SF",5], "Question",       {q: "A: Valaki, vagy valakik kinevettek valakit. Emlékszel, hogy ki nevetett ki kit?", as: ["B: Feri Krisztát.", "B: Feri Krisztát, Erika Annát, Balázs pedig Áront."], hasCorrect: 0, randomOrder: true}],
[["m.MF",5], "Question",       {q: "A: Valaki, vagy valakik kinevettek valakit. Emlékszel, hogy ki kit nevetett ki?", as: ["B: Feri Krisztát.", "B: Feri Krisztát, Erika Annát, Balázs pedig Áront."], hasCorrect: 0, randomOrder: true}],


[["m.E",6], "Question",       {q: "A: Valaki, vagy valakik leszidtak valakit. Emlékszel, hogy ki kit?", as: ["B: Bence Mikit.", "B: Bence Mikit, Marcsi Gizit, Noémi pedig Barnabást."], hasCorrect: 0, randomOrder: true}],
[["m.SF",6], "Question",       {q: "A: Valaki, vagy valakik leszidtak valakit. Emlékszel, hogy ki szidott le kit?", as: ["B: Bence Mikit.", "B: Bence Mikit, Marcsi Gizit, Noémi pedig Barnabást."], hasCorrect: 0, randomOrder: true}],
[["m.MF",6], "Question",       {q: "A: Valaki, vagy valakik leszidtak valakit. Emlékszel, hogy ki kit szidott le?", as: ["B: Bence Mikit.", "B: Bence Mikit, Marcsi Gizit, Noémi pedig Barnabást."], hasCorrect: 0, randomOrder: true}],


[["m.E",7], "Question",       {q: "A: Valaki, vagy valakik felidegesítettek valakit. Emlékszel, hogy ki kit?", as: ["B: Jani Brigit.", "B: Jani Brigit, Kata Emőkét, Vilmos pedig Nikit."], hasCorrect: 0, randomOrder: true}],
[["m.SF",7], "Question",       {q: "A: Valaki, vagy valakik felidegesítettek valakit. Emlékszel, hogy ki idegesített fel kit?", as: ["B: Jani Brigit.", "B: Jani Brigit, Kata Emőkét, Vilmos pedig Nikit."], hasCorrect: 0, randomOrder: true}],
[["m.MF",7], "Question",       {q: "A: Valaki, vagy valakik felidegesítettek valakit. Emlékszel, hogy ki kit idegesített fel?", as: ["B: Jani Brigit.", "B: Jani Brigit, Kata Emőkét, Vilmos pedig Nikit."], hasCorrect: 0, randomOrder: true}],


[["m.E",8], "Question",       {q: "A: Valaki, vagy valakik átöleltek valakit. Emlékszel, hogy ki kit?", as: ["B: Erzsébet Szilvesztert.", "B: Erzsébet Szilvesztert, Sára Zsoltot, Dani pedig Tamarát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",8], "Question",       {q: "A: Valaki, vagy valakik átöleltek valakit. Emlékszel, hogy ki ölelt át kit?", as: ["B: Erzsébet Szilvesztert.", "B: Erzsébet Szilvesztert, Sára Zsoltot, Dani pedig Tamarát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",8], "Question",       {q: "A: Valaki, vagy valakik átöleltek valakit. Emlékszel, hogy ki kit ölelt át?", as: ["B: Erzsébet Szilvesztert.", "B: Erzsébet Szilvesztert, Sára Zsoltot, Dani pedig Tamarát."], hasCorrect: 0, randomOrder: true}],


[["m.E",9], "Question",       {q: "A: Valaki, vagy valakik átvertek valakit. Tudod, hogy ki kit?", as: ["B: Bence Esztert.", "B: Bence Esztert, Márk Lehelt, Lola pedig Marcsit."], hasCorrect: 0, randomOrder: true}],
[["m.SF",9], "Question",       {q: "A: Valaki, vagy valakik átvertek valakit. Tudod, hogy ki vert át kit?", as: ["B: Bence Esztert.", "B: Bence Esztert, Márk Lehelt, Lola pedig Marcsit."], hasCorrect: 0, randomOrder: true}],
[["m.MF",9], "Question",       {q: "A: Valaki, vagy valakik átvertek valakit. Tudod, hogy ki kit vert át?", as: ["B: Bence Esztert.", "B: Bence Esztert, Márk Lehelt, Lola pedig Marcsit."], hasCorrect: 0, randomOrder: true}],


[["m.E",10], "Question",       {q: "A: Valaki, vagy valakik meglöktek valakit. Tudod, hogy ki kit?", as: ["B: Magda Rékát.", "B: Magda Rékát, Ádám Boldizsárt, Előd pedig Attilát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",10], "Question",       {q: "A: Valaki, vagy valakik meglöktek valakit. Tudod, hogy ki lökött meg kit?", as: ["B: Magda Rékát.", "B: Magda Rékát, Ádám Boldizsárt, Előd pedig Attilát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",10], "Question",       {q: "A: Valaki, vagy valakik meglöktek valakit. Tudod, hogy ki kit lökött meg?", as: ["B: Magda Rékát.", "B: Magda Rékát, Ádám Boldizsárt, Előd pedig Attilát."], hasCorrect: 0, randomOrder: true}],


[["m.E",11], "Question",       {q: "A: Valaki, vagy valakik megkérdeztek valakit. Tudod, hogy ki kit?", as: ["B: Rebeka Juliannát.", "B: Rebeka Juliannát, Amanda Elemért, Elza pedig Ildikót."], hasCorrect: 0, randomOrder: true}],
[["m.SF",11], "Question",       {q: "A: Valaki, vagy valakik megkérdeztek valakit. Tudod, hogy ki kérdezett meg kit?", as: ["B: Rebeka Juliannát.", "B: Rebeka Juliannát, Amanda Elemért, Elza pedig Ildikót."], hasCorrect: 0, randomOrder: true}],
[["m.MF",11], "Question",       {q: "A: Valaki, vagy valakik megkérdeztek valakit. Tudod, hogy ki kit kérdezett meg?", as: ["B: Rebeka Juliannát.", "B: Rebeka Juliannát, Amanda Elemért, Elza pedig Ildikót."], hasCorrect: 0, randomOrder: true}],


[["m.E",12], "Question",       {q: "A: Valaki, vagy valakik lehallgattak valakit. Emlékszel, hogy ki kit?", as: ["B: Andrea Ilonát.", "B: Andrea Ilonát, Tünde Csillát, Csaba pedig Sándort."], hasCorrect: 0, randomOrder: true}],
[["m.SF",12], "Question",       {q: "A: Valaki, vagy valakik lehallgattak valakit. Emlékszel, hogy ki mutatott be kit?", as: ["B: Andrea Ilonát.", "B: Andrea Ilonát, Tünde Csillát, Csaba pedig Sándort."], hasCorrect: 0, randomOrder: true}],
[["m.MF",12], "Question",       {q: "A: Valaki, vagy valakik lehallgattak valakit. Emlékszel, hogy ki kit mutatott be?", as: ["B: Andrea Ilonát.", "B: Andrea Ilonát, Tünde Csillát, Csaba pedig Sándort."], hasCorrect: 0, randomOrder: true}],


[["m.E",13], "Question",       {q: "A: Valaki, vagy valakik elfelejtettek valakit. Tudod, hogy ki kit?", as: ["B: Tibor Veronikát.", "B: Tibor Veronikát, Valéria Imrét, Ottó pedig Ákost."], hasCorrect: 0, randomOrder: true}],
[["m.SF",13], "Question",       {q: "A: Valaki, vagy valakik elfelejtettek valakit. Tudod, hogy ki felejtett el kit?", as: ["B: Tibor Veronikát.", "B: Tibor Veronikát, Valéria Imrét, Ottó pedig Ákost."], hasCorrect: 0, randomOrder: true}],
[["m.MF",13], "Question",       {q: "A: Valaki, vagy valakik elfelejtettek valakit. Tudod, hogy ki kit felejtett el?", as: ["B: Tibor Veronikát.", "B: Tibor Veronikát, Valéria Imrét, Ottó pedig Ákost."], hasCorrect: 0, randomOrder: true}],


[["m.E",14], "Question",       {q: "A: Valaki, vagy valakik előléptettek valakit. Tudod, hogy ki kit?", as: ["B: Szabolcs Mártont.", "B: Szabolcs Mártont, Aranka Norbertet, Rozi pedig Edinát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",14], "Question",       {q: "A: Valaki, vagy valakik előléptettek valakit. Tudod, hogy ki léptetett elő kit?", as: ["B: Szabolcs Mártont.", "B: Szabolcs Mártont, Aranka Norbertet, Rozi pedig Edinát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",14], "Question",       {q: "A: Valaki, vagy valakik előléptettek valakit. Tudod, hogy ki kit léptetett elő?", as: ["B: Szabolcs Mártont.", "B: Szabolcs Mártont, Aranka Norbertet, Rozi pedig Edinát."], hasCorrect: 0, randomOrder: true}],


[["m.E",15], "Question",       {q: "A: Valaki, vagy valakik hazakísértek valakit. Tudod, hogy ki kit?", as: ["B: Viktor Zitát.", "B: Viktor Zitát, Mátyás Angélát, Erik pedig Melindát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",15], "Question",       {q: "A: Valaki, vagy valakik hazakísértek valakit. Tudod, hogy ki kísért haza kit?", as: ["B: Viktor Zitát.", "B: Viktor Zitát, Mátyás Angélát, Erik pedig Melindát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",15], "Question",       {q: "A: Valaki, vagy valakik hazakísértek valakit. Tudod, hogy ki kit kísért haza?", as: ["B: Viktor Zitát.", "B: Viktor Zitát, Mátyás Angélát, Erik pedig Melindát."], hasCorrect: 0, randomOrder: true}],


[["m.E",16], "Question",       {q: "A: Valaki, vagy valakik kihasználtak valakit. Tudod, hogy ki kit?", as: ["B: Gellért Félixet.", "B: Gellért Félixet, Lőrinc Alízt, Emma pedig BIankát."], hasCorrect: 0, randomOrder: true}],
[["m.SF",16], "Question",       {q: "A: Valaki, vagy valakik kihasználtak valakit. Tudod, hogy ki használt ki kit?", as: ["B: Gellért Félixet.", "B: Gellért Félixet, Lőrinc Alízt, Emma pedig BIankát."], hasCorrect: 0, randomOrder: true}],
[["m.MF",16], "Question",       {q: "A: Valaki, vagy valakik kihasználtak valakit. Tudod, hogy ki kit használt ki?", as: ["B: Gellért Félixet.", "B: Gellért Félixet, Lőrinc Alízt, Emma pedig BIankát."], hasCorrect: 0, randomOrder: true}],


[["m.E",17], "Question",       {q: "A: Valaki, vagy valakik letartóztattak valakit. Tudod, hogy ki kit?", as: ["B: Albert Rékát.", "B: Albert Rékát, Bence Esztert, Erzsi pedig Jánost."], hasCorrect: 0, randomOrder: true}],
[["m.SF",17], "Question",       {q: "A: Valaki, vagy valakik letartóztattak valakit. Tudod, hogy ki tartóztatott le kit?", as: ["B: Albert Rékát.", "B: Albert Rékát, Bence Esztert, Erzsi pedig Jánost."], hasCorrect: 0, randomOrder: true}],
[["m.MF",17], "Question",       {q: "A: Valaki, vagy valakik letartóztattak valakit. Tudod, hogy ki kit tartóztatott le?", as: ["B: Albert Rékát.", "B: Albert Rékát, Bence Esztert, Erzsi pedig Jánost."], hasCorrect: 0, randomOrder: true}],


[["m.E",18], "Question",       {q: "A: Valaki, vagy valakik lerajzoltak valakit. Emlékszel, hogy ki kit?", as: ["B: Krisztina Máriát.", "B: Krisztina Máriát, Gabi Noémit, Éva pedig Lajost."], hasCorrect: 0, randomOrder: true}],
[["m.SF",18], "Question",       {q: "A: Valaki, vagy valakik lerajzoltak valakit. Emlékszel, hogy ki rajzolt le kit?", as: ["B: Krisztina Máriát.", "B: Krisztina Máriát, Gabi Noémit, Éva pedig Lajost."], hasCorrect: 0, randomOrder: true}],
[["m.MF",18], "Question",       {q: "A: Valaki, vagy valakik lerajzoltak valakit. Emlékszel, hogy ki kit rajzolt le?", as: ["B: Krisztina Máriát.", "B: Krisztina Máriát, Gabi Noémit, Éva pedig Lajost."], hasCorrect: 0, randomOrder: true}],


//
/// 30 fillers
//
// Keys:
// f: fillers
// C: fillers with one (the first) correct answer; O: fillers with "or" questions; M: middle ground fillers
 
//10 Fillers with one Correct answer
[["f.C.1"], "Question", {q: "A: Péter vásárolt egy új esőkabátot. Tudod, hogy mennyibe került?", as: ["B: Igen, tizenötezer forintba.", "B: Igen, gyönyörű az új esőkabátja!"], hasCorrect: 0, randomOrder: true}],
[["f.C.2"], "Question", {q: "A: István vett egy ajándékot Julinak. Szeretném tudni, hogy pontosan hol vette.", as: ["B: Tudtommal a Westendben vette.", "B: Tudtommal tegnap vette."], hasCorrect: 0, randomOrder: true}],
[["f.C.3"], "Question", {q: "A: Valaki megtalálta a pénztárcámat. Találd ki, hogy hol!", as: ["B: Hmm, talán a buszmegállóban?", "B: Hmm, talán a fickó a buszmegállóban?"], hasCorrect: 0, randomOrder: true}],
[["f.C.4"], "Question", {q: "A: Mindenkitől kaptam egy virágot. Emlékszel, hogy ki hozta a rózsát?", as: ["B: Anna és Péter hozták.", "B: Anna és Péter nem hozták."], hasCorrect: 0, randomOrder: true}],
[["f.C.5"], "Question", {q: "A: Anna megbukott matekból. Szeretném tudni, hogy ez hogy történhetett.", as: ["B: Talán az az oka, hogy sosem írt leckét, és a dolgozatokra sem tanult.", "B: Talán az az oka, hogy nem szeretem a matekot, és nem tanultam a dolgozatokra."], hasCorrect: 0, randomOrder: true}],
[["f.C.6"], "Question", {q: "A: Valaki feldíszítette a karácsonyfát. Találd ki, hogy ki volt az!", as: ["B: Szerintem a Julcsi lehetett.", "B: Úgy szeretem a karácsonyfákat!"], hasCorrect: 0, randomOrder: true}],
[["f.C.7"], "Question", {q: "A: Sok mindent hozott a posta ma. Ki írt levelet Fanninak?", as: ["B: Dávid.", "B: Tegnap."], hasCorrect: 0, randomOrder: true}],
[["f.C.8"], "Question", {q: "A: Valaki kihívta ránk a rendőröket. Tudod, hogy ki lehetett?", as: ["B: A Kovácsék.", "B: Éjfél után."], hasCorrect: 0, randomOrder: true}],
[["f.C.9"], "Question", {q: "A: Mindenki sokat mosolygott ma az iskolában. Mi lehet az oka?", as: ["B: Elmaradt az első két óra.", "B: Anyukám múlt szombaton tortát sütött."], hasCorrect: 0, randomOrder: true}],
[["f.C.10"], "Question", {q: "A: Kemény vizsga volt ez a mai. Mindenki megbukott?", as: ["B: Nem, ketten átmentek.", "B: Igen, senki nem bukott meg."], hasCorrect: 0, randomOrder: true}],


//10 Fillers with "or" questions:

[["f.O.1"], "Question", {q: "A: Te jó ég, nincs több torta! Melyik lány, vagy melyik lányok ették meg?", as: ["B: Mari.", "B: Mari és Zsuzsi."], hasCorrect: 0, randomOrder: true}],
[["f.O.2"], "Question", {q: "A: Mindenki evett valamilyen gyümölcsöt. Ki, vagy kik ették meg a dinnyét?", as: ["B: Valika.", "B: Valika és Erik."], hasCorrect: 0, randomOrder: true}],
[["f.O.3"], "Question", {q: "A: Micsoda szín! Ki, vagy kik voltak azok, akik kifestették a szobát?", as: ["B: Benedek.", "B: Benedek és Krisztián."], hasCorrect: 0, randomOrder: true}],
[["f.O.4"], "Question", {q: "A: Karácsonykor sok bónuszt kiosztottak. Melyik menedzser, vagy menedzserek kaptak?", as: ["B: Ábel.", "B: Ábel és Mariann."], hasCorrect: 0, randomOrder: true}],
[["f.O.5"], "Question", {q: "A: Nem teljesítenek túl jól a diákok. Melyik diák, vagy melyik diákok buktak meg?", as: ["B: Zsuzsi.", "B: Zsuzsi és Pál."], hasCorrect: 0, randomOrder: true}],
[["f.O.6"], "Question", {q: "A: Nem jó az oviban magányosnak lenni. Kivel, vagy kikkel nem játszott senki?", as: ["B: Gyuri.", "B: Gyuri és Pali."], hasCorrect: 0, randomOrder: true}],
[["f.O.7"], "Question", {q: "A: Általános iskolában ritkán válogatósak a gyerekek. Ki, vagy kik nem szeretik semmilyen ebédet?", as: ["B: Kinga.", "B: Kinga és Tamara."], hasCorrect: 0, randomOrder: true}],
[["f.O.8"], "Question", {q: "A: Valaki meghívott a moziba. Te milyen filmeket szoktál nézni?", as: ["B: Vígjátékot.", "B: Vígjátékot és horrort."], hasCorrect: 0, randomOrder: true}],
[["f.O.9"], "Question", {q: "A: Sok minden lesz idén a Szigeten. Ki, vagy kik a kedvenc fellépőid?", as: ["B: Ed Sheeran.", "B: Ed Sheeran és Franz Ferdinand."], hasCorrect: 0, randomOrder: true}],
[["f.O.10"], "Question", {q: "A: A szüleim azt mondták láttak az utcán. Kivel, vagy kikkel voltál?", as: ["B: Anyukámmal.", "B: Anyukámmal és a nővéremmel."], hasCorrect: 0, randomOrder: true}],


//10 Middle ground fillers

[["f.M.1"], "Question", {q: "A: János találkozott egy lánnyal. Számodra egyértelmű, hogy kivel?", as: ["B: Nem, körte volt.", "B: Igen, egy körte és egy alma."], hasCorrect: 0, randomOrder: true}],
[["f.M.2"], "Question", {q: "A: Megettem egy hatalmas süteményt. Találd ki, hogy mekkorát!", as: ["B: Talán vaníliát.", "B: Talán vaníliát, vagy csokit."], hasCorrect: 0, randomOrder: true}],
[["f.M.3"], "Question", {q: "A: Megkérdeztél valamit valakitől. Szeretném tudni, hogy mit és kitől.", as: ["B: Maritól és Zoltántól kérdeztem valamit.", "B: Maritól kérdeztem meg, hogy hány óra van."], hasCorrect: 0, randomOrder: true}],
[["f.M.4"], "Question", {q: "A: Kata és Balázs felelősek valamiért. Számodra egyértelmű, hogy miért?", as: ["B: A desszertet kell hozniuk.", "B: Balázsnak kell hoznia a desszertet, Katának pedig a bort."], hasCorrect: 0, randomOrder: true}],
[["f.M.5"], "Question", {q: "A: Valakik megismerkedtek anyukáddal. Tudod, hogy mikor?", as: ["B: Zsófi ismerkedett meg vele.", "B: Zsófi ismerkedett meg vele, Mari pedig kedden."], hasCorrect: 0, randomOrder: true}],
[["f.M.6"], "Question", {q: "A: Minden gyerek ajándékot kapott karácsonykor. Tudod melyik gyerek kapott kisvonatot?", as: ["B: Pál és Zsuzsi kaptak kisvonatot.", "B: Pál volt az, aki kisvonatot és kirakóst kapott."], hasCorrect: 0, randomOrder: true}],
[["f.M.7"], "Question", {q: "A: Olyan sokat olvasol. Melyik könyveket nem olvastad el?", as: ["B: Nyolcból hármat elolvastam.", "B: Minden könyvet elolvastam."], hasCorrect: 0, randomOrder: true}],
[["f.M.8"], "Question", {q: "A: Tegnap este láttalak válaszolni. Vettél egy órát?", as: ["B: Egy kabátot vettem.", "B: Egy kabátot és egy órát vettem."], hasCorrect: 0, randomOrder: true}],
[["f.M.9"], "Question", {q: "A: I bought a theater ticket for almost everyone. Do you remember who I didn’t buy one for?", as: ["B: Mindenki kapott jegyet.", "B: Senki nem kapott jegyet."], hasCorrect: 0, randomOrder: true}],
[["f.M.10"], "Question", {q: "A: Your sister called yesterday. Do you want to know why?", as: ["B: Anyukám volt az, aki hívott.", "B: Én hívtam a nővéremet."], hasCorrect: 0, randomOrder: true}]// NOTE NO COMMA

];
