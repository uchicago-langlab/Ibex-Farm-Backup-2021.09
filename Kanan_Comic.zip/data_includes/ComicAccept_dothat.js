var shuffleSequence = seq("Intro", "setcounter", "Intro1", "practice", rshuffle(startsWith("q")), "Exit");

var practiceItemTypes = ["practice"];
var centerItems = true;

var defaults = [
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Unlikely)", 
        rightComment: "(Likely)"
    },
    "Form", {
        //"html" option is obligatory
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [

    
["setcounter", "__SetCounter__", { }],

/*This makes it so that Ibex moves to the next iteration of the Latin Square at whatever point in the sequence you put this item, rather than when the results are submitted. Keeps several people from getting the same list if they access the link at the same time.*/

["Intro", "Form", {consentRequired: true, html: {include: "Intro.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro1.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro2.html" }} ],
["Intro1", "Form", {consentRequired: true, html: {include: "Intro3.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],
    
    
/*Conditions ordered so that subjects see 3 unmod and 3 mod ratings. They see six different context/antecedent combos.

    Context, Antecedent, Rating
    a a neutral none unmod
    b e mod unmod unmod
    c i unmod mod unmod
    d k neutral unmod mod
    e o mod mod mod
    f p unmod none mod
    g b neutral unmod unmod
    h f mod mod unmod
    i g unmod none unmod
    j l neutral mod mod
    k m mod none mod
    l q unmod unmod mod
    m c neutral mod unmod
    n d mod none unmod
    o h unmod unmod unmod
    p j neutral none mod
    q n mod unmod mod
    r r unmod mod mod
*/


/*
[["q1a",1] or "practice", "PictureScale", {
html:'<h><b><center><font size="5"> Title</font></center></b></h> <p></p> <center><img src = "imglink.jpg" height="10%"</center>',
s: {html: '<center><p>Utterance 1</p> <p>Utterance 2</p> <p>Prompt</p><p>Meaning</p></center> '}}],
*/
  
  /*  Old syntax - cleaner, but can\'t format text or put title above strip
[["q1e", 1], "PictureScale", {
html:'<center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%" <center>', 
s:["center",
["p", "At the grocery store"],
["p", "Son: I want to buy candy bars!"],
["p", "Father: We can\'t."],
["p", "On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant:"],
["p", "We can\'t buy any candy bars today."],
]}],
    */

["practice", "PictureScale", {
html:'<h><b><center><font size="5"> Planning a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/example_1.jpg" height="35%"<center>',
s: {html: '<center><p><i>Party host: </i>Do you want to come?</p> <p><i>Host\'s friend: </i>I\'d love to!</p> <p>On a scale from 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the host\'s friend meant:</p><p>I\'ll be at the party.</p></center> '}}],  

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it seems likely that the host\'s friend meant they would be at the party, so you should have clicked on one of the buttons on the higher end of the scale (5-7)."],
["p", "Press any key to continue."]
]}],
    
["practice", "PictureScale", {
html:'<h><b><center><font size="5"> Planning a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/example_2.jpg" height="35%"</center>',
s: {html: '<center><p><i> Host:</i> Can you bring a dessert?</p> <p><i> Host\'s friend:</i> I make great brownies.</p> <p>On a scale from 1 to 7, where 1 is the most likely and 7 is the least likely, how likely do you think it is that the host\'s friend meant:</p><p>I can\'t bring a dessert.</p></center> '}}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "In this case, it doesn\'t seem very likely that the host\'s friend meant that they can\'t bring a dessert, so you should have clicked on one of the buttons on the lower end of the scale (1-3)."],
["p", "Press any key to continue."]
]}],

["practice", Message, {consentRequired: false, transfer: "keypress",
html: ["div",
["p", "The practice session is over. You are now ready to begin the task."],
["p", "Press any key to begin."]
]}],
    
    




[["q1a", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1b", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1c", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1d", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1e", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1f", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1g", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1h", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1i", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1j", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1k", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1l", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1m", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1n", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1o", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy any candy bars today.</p></center> '}}],

[["q1p", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1q", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],

[["q1r", 1], "PictureScale", {html:'<h><b><center><font size="5"> At the grocery store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen1_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Son: </i>I want to buy five candy bars!</p> <p><i> Father: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>We can\'t buy five candy bars today, but maybe we could get fewer.</p></center> '}}],










[["q2a", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2b", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2c", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2d", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2e", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2f", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2g", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2h", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2i", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2j", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2k", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2l", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2m", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2n", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2o", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take any candies.</p></center> '}}],

[["q2p", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2q", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],

[["q2r", 2], "PictureScale", {html:'<h><b><center><font size="5"> In an office</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen2_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing worker: </i>I\'m going to take four candies!</p> <p><i> Sitting worker: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the sitting worker meant: </p> <p>You can\'t take four candies, but maybe you can take fewer.</p></center> '}}],










[["q3a", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3b", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3c", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3d", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3e", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3f", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3g", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3h", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3i", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3j", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3k", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3l", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3m", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3n", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3o", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add any chili peppers.</p></center> '}}],

[["q3p", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3q", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],

[["q3r", 3], "PictureScale", {html:'<h><b><center><font size="5"> In a cooking class</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen3_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Student: </i>Now I\'m going to add four chili peppers.</p> <p><i> Instructor: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the instructor meant: </p> <p>You shouldn\'t add four chili peppers, but maybe fewer would be OK.</p></center> '}}],










[["q4a", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4b", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4c", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4d", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4e", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4f", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4g", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4h", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4i", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4j", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4k", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4l", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4m", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4n", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4o", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy any bracelet charms today.</p></center> '}}],

[["q4p", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4q", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],

[["q4r", 4], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen4_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Wife: </i>I want to get four charms for my bracelet.</p> <p><i> Husband: </i>You shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the husband meant: </p> <p>You shouldn\'t buy four bracelet charms today, but maybe fewer would be OK.</p></center> '}}],










[["q5a", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5b", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5c", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5d", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5e", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5f", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5g", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5h", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5i", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5j", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5k", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5l", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5m", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5n", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5o", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy any shirts today.</p></center> '}}],

[["q5p", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5q", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],

[["q5r", 5], "PictureScale", {html:'<h><b><center><font size="5"> In a clothing store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen5_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I think you should buy three shirts today.</p> <p><i> Customer: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I shouldn\'t buy three shirts today, but maybe fewer would be OK.</p></center> '}}],










[["q6a", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6b", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6c", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6d", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6e", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6f", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6g", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6h", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6i", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6j", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6k", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6l", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6m", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6n", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6o", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy any princess dresses today.</p></center> '}}],

[["q6p", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_neutral.jpg" height="10%"</center>', s: {html: '<center><p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6q", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_mod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],

[["q6r", 6], "PictureScale", {html:'<h><b><center><font size="5"> In a children\'s store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/scen6_unmod.jpg" height="10%"</center>', s: {html: '<center><p><i> Daughter: </i>I want to buy three princess dresses!</p> <p><i> Mother: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the mother meant: </p> <p>We can\'t buy three princess dresses today, but maybe we could get fewer.</p></center> '}}],










[["q7s", 7], "PictureScale", {html:'<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_1.jpg" height="10%"</center>', s: {html: '<center><p><i> Host: </i>Do you want another drink?</p> <p><i> Guest: </i>I really can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the guest meant: </p> <p>I can\'t have another drink of any kind.</p></center> '}}],

[["q7t", 7], "PictureScale", {html:'<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_1.jpg" height="10%"</center>', s: {html: '<center><p><i> Host: </i>Do you want another drink?</p> <p><i> Guest: </i>I really can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the guest meant: </p> <p>I can\'t have another cocktail, but maybe a beer would be OK.</p></center> '}}],










[["q8s", 8], "PictureScale", {html:'<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_2.jpg" height="10%"</center>', s: {html: '<center><p><i> Host: </i>Do you want a big piece of cake?</p> <p><i> Guest: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the guest meant: </p> <p>I shouldn\'t have any cake at all.</p></center> '}}],

[["q8t", 8], "PictureScale", {html:'<h><b><center><font size="5"> At a party</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_2.jpg" height="10%"</center>', s: {html: '<center><p><i> Host: </i>Do you want a big piece of cake?</p> <p><i> Guest: </i>I shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the guest meant: </p> <p>I shouldn\'t have a big piece of cake, but maybe a smaller piece would be OK.</p></center> '}}],










[["q9s", 9], "PictureScale", {html:'<h><b><center><font size="5"> At a car dealership</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_3.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I see you\'re looking at the fast car.</p> <p><i> Wife: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the wife meant: </p> <p>We can\'t buy a car at all today.</p></center> '}}],

[["q9t", 9], "PictureScale", {html:'<h><b><center><font size="5"> At a car dealership</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_3.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>I see you\'re looking at the fast car.</p> <p><i> Wife: </i>We can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the wife meant: </p> <p>We can\'t buy a fast car today, but we might be willing to buy a slower car.</p></center> '}}],










[["q10s", 10], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_4.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>Were you looking to buy a ring today?</p> <p><i> Customer: </i>I can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I can\'t buy a ring at all today.</p></center> '}}],

[["q10t", 10], "PictureScale", {html:'<h><b><center><font size="5"> In a jewelry store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_4.jpg" height="10%"</center>', s: {html: '<center><p><i> Salesperson: </i>Were you looking to buy a ring today?</p> <p><i> Customer: </i>I can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the customer meant: </p> <p>I can\'t buy an expensive ring today, but maybe I could buy a cheaper one.</p></center> '}}],










[["q11s", 11], "PictureScale", {html:'<h><b><center><font size="5"> In a liquor store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_5.jpg" height="10%"</center>', s: {html: '<center><p><i> Man: </i>Should we buy the expensive wine?</p> <p><i> Woman: </i>We shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the woman meant: </p> <p>We shouldn\'t buy any wine today.</p></center> '}}],

[["q11t", 11], "PictureScale", {html:'<h><b><center><font size="5"> In a liquor store</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_5.jpg" height="10%"</center>', s: {html: '<center><p><i> Man: </i>Should we buy the expensive wine?</p> <p><i> Woman: </i>We shouldn\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the woman meant: </p> <p>We shouldn\'t buy the expensive wine today, but maybe a cheaper wine would be OK.</p></center> '}}],










[["q12s", 12], "PictureScale", {html:'<h><b><center><font size="5"> At a buffet</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_6.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>Don\'t do that!</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>Don\'t take any of that.</p></center> '}}],

[["q12t", 12], "PictureScale", {html:'<h><b><center><font size="5"> At a buffet</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_6.jpg" height="10%"</center>', s: {html: '<center><p><i> Father: </i>Don\'t do that!</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the father meant: </p> <p>Don\'t take so much of that.</p></center> '}}],










[["q13s", 13], "PictureScale", {html:'<h><b><center><font size="5"> At a bake sale</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_7.jpg" height="10%"</center>', s: {html: '<center><p><i> Woman: </i>I\'m going to buy a whole pie.</p> <p><i> Man: </i>Don\'t do that!</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the man meant: </p> <p>Don\'t buy any pie at all.</p></center> '}}],

[["q13t", 13], "PictureScale", {html:'<h><b><center><font size="5"> At a bake sale</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_7.jpg" height="10%"</center>', s: {html: '<center><p><i> Woman: </i>I\'m going to buy a whole pie.</p> <p><i> Man: </i>Don\'t do that!</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the man meant: </p> <p>Don\'t buy a whole pie, but maybe a slice of pie would be OK.</p></center> '}}],










[["q14s", 14], "PictureScale", {html:'<h><b><center><font size="5"> Opening a lock</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_8.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing person: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the standing person meant: </p> <p>You can\'t open that lock at all.</p></center> '}}],

[["q14t", 14], "PictureScale", {html:'<h><b><center><font size="5"> Opening a lock</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_8.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing person: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the standing person meant: </p> <p>You can\'t open that lock with that key.</p></center> '}}],










[["q15s", 15], "PictureScale", {html:'<h><b><center><font size="5"> Turning a screw</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_9.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing person: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the standing person meant: </p> <p>You can\'t turn that screw at all.</p></center> '}}],

[["q15t", 15], "PictureScale", {html:'<h><b><center><font size="5"> Turning a screw</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_9.jpg" height="10%"</center>', s: {html: '<center><p><i> Standing person: </i>You can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the standing person meant: </p> <p>You can\'t turn that screw with that screwdriver.</p></center> '}}],










[["q16s", 16], "PictureScale", {html:'<h><b><center><font size="5"> Writing</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_10.jpg" height="10%"</center>', s: {html: '<center><p><i> Person on right: </i>Can you hand me the short pencil?</p> <p><i> Person on left: </i>I can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the person on the left meant: </p> <p>I can\'t hand you any pencil at all.</p></center> '}}],

[["q16t", 16], "PictureScale", {html:'<h><b><center><font size="5"> Writing</font></center></b></h> <p></p> <center><img src = "http://home.uchicago.edu/~jgeiger/QP2_Strips/filler_10.jpg" height="10%"</center>', s: {html: '<center><p><i> Person on right: </i>Can you hand me the short pencil?</p> <p><i> Person on left: </i>I can\'t do that.</p> <p> On a scale of 1 to 7, where 1 is the least likely and 7 is the most likely, how likely do you think it is that the person on the left meant: </p> <p>I can\'t hand you the short pencil, but maybe I can hand you a longer pencil.</p></center> '}}]
    
    
    
    




];
