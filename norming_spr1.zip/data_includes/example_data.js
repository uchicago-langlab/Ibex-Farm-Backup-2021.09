var shuffleSequence = seq("setcounter","Intro0", "Intro", "practice", "check1", "xep", rshuffle(startsWith("norm"), startsWith("f")), "Exit");
var practiceItemTypes = ["practice"];



var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        errorMessage: "Wrong. Please wait for the next sentence."
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Click boxes to answer.",
        leftComment: "(Highly Unlikely)", rightComment: "(Highly Likely)"
    },
    "Question", {
        hasCorrect: true
    },
    "Message", {
        hideProgressBar: true
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    }
];

var items = [
["setcounter", "__SetCounter__", { }],
["Intro0", "Form", {consentRequired: true, html: {include: "intro1_norm.html" }} ],  


["Intro", "Form", {consentRequired: true, html: {include: "intro_norm.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "intro2_norm.html" }} ],
["Intro", "Form", {consentRequired: true, html: {include: "intro4_norm.html" }} ],  
["check1", "Form", {consentRequired: true, html: {include: "intro3_norm.html" }} ],
["Exit", "Form", {consentRequired: false, html: {include: "Exit.html" }} ],


 ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Mike told Stacey that he felt like going out for dinner that night. Stacey replied that she had had a big lunch that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Stacey will go out to dinner with Mike?"}}],                          
  
  ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Not today, thanks'', it means that you think it is unlikely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."], 
                           ["p", "If you thought Mike should have interpreted Stacey's answer to mean ''Sure, but let's get something light like a salad'', it means that you think it is likely that Stacey will go get dinner with Mike that night. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                           ["p", "If on the other hand you were not sure how Myke should have interpreted Stacey's answer, you should have clicked on button 4."],
   
                           ["p", "Press any key to move on to the next example."]
                           ]}],                      
                          
 
   ["practice", "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Cecilia asked his boss if she could get a raise. Her boss replied that the company had just acquired expensive new equipment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Cecilia's boss will give her a raise?"}}],                          
    
                          
    ["practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sorry, we just spent a lot of money and we cannot afford to give you a raise right now'', it means that you think it's very unlikely that she will receive a raise. In that case, you should have clicked on one of the buttons in the lower portion of the scale (1-3)."],
                            
                           ["p", "If you think that Cecilia should have interpreted her boss' answer to mean ''Sure, we now have a lot of money to invest in the company'', it means that you think it's very likely that she will receive a raise. In that case, you should have clicked on one of the buttons in the higher end of the scale (5-7)."],
                            
                           ["p", "If on the other hand you were not sure how Cecilia should have interpreted her boss' answer, you should have clicked on button 4."],
                           ["p", "Press any key to move on to the next example."]
                           ]}],                                          
  

   ["xep", Separator, {transfer: 2000, normalMessage: "Now you are ready to begin!" }],
    
  
        [["norm_a",1], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study. The nurse replied that 10 patients were currently waitlisted."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 10 patients, no more and no fewer?"}}],                          
    
    [["norm_b",1], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study. The nurse replied that 100 patients were currently waitlisted."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 100 patients, no more and no fewer?"}}],
                              
    [["norm_c",1], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When the doctor arrived that morning she asked the nurse how many patients were waitlisted for the new clinical study. The nurse replied that 1,000 patients were currently waitlisted."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the nurse meant that there were exactly 1,000 patients, no more and no fewer?"}}],
                                    
   [["norm_a",2], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be. His boss said that Peet would earn 200 dollars less per year."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that the cuts were exactly 200 dollars, no more and no less?"}}],                          
      
    [["norm_b",2], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be. His boss said that Peet would earn 2,000 dollars less per year."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that the cuts were exactly 2,000 dollars, no more and no less?"}}], 
    
    [["norm_c",2], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that the agency would undergo major cuts, Peet worried that his annual income would decrease significantly. He decided to email his boss to find out what his salary reduction would be. His boss said that Peet would earn 20,000 dollars less per year."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet's boss meant that the cuts were exactly 20,000 dollars, no more and no less?"}}], 

[["norm_a",3], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost. Betsy answered that the toaster was 30 points after applying the discounts."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 30 points, no more and no fewer?"}}], 

[["norm_b",3], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost. Betsy answered that the toaster was 300 points after applying the discounts."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 300 points, no more and no fewer?"}}],                

[["norm_c",3], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Betsy bought a new toaster using her credit card points. Tom wondered whether he could do the same, so he asked Betsy how many points the toaster cost. Betsy answered that the toaster was 3,000 points after applying the discounts."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Betsy meant that the toaster was exactly 3,000 points, no more and no fewer?"}}],

[["norm_a",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling. The farmer replied that he was selling 50 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 50 gallons of milk, no more and no fewer?"}}], 

[["norm_b",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling. The farmer replied that he was selling 500 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 500 gallons of milk, no more and no fewer?"}}],
    
[["norm_c",4], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Stephen was inspecting one of the local farms in order to ensure that it was up to code. During the inspection, Stephen asked the owner how many gallons of milk the farm was currently selling. The farmer replied that he was selling 5,000 gallons on a daily basis."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farmer meant that he sold exactly 5,000 gallons of milk, no more and no fewer?"}}],

[["norm_a",5], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter. Jonathan said that they currently had 400 subscribers based both in Europe and the US."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 400, not more and not fewer?"}}], 
    
[["norm_b",5], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter. Jonathan said that they currently had 4,000 subscribers based both in Europe and the US."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 4,000, not more and not fewer?"}}],
    
[["norm_c",5], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "As the new PR manager of her technology company, Mary asked Jonathan, the previous PR manager, how many subscribers they had to their monthly newsletter. Jonathan said that they currently had 40,000 subscribers based both in Europe and the US."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jonathan meant that the number of subscribers was exactly 40,000, not more and not fewer?"}}],

[["norm_a",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed. The IRS representative said that Erika owed 400 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 400 dollars, not more and not fewer?"}}],
    
[["norm_b",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed. The IRS representative said that Erika owed 4,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 4,000 dollars, not more and not fewer?"}}], 
    
[["norm_c",6], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Due to a mistake in filing her taxes, Erika had to call the IRS to ask how much money she owed. The IRS representative said that Erika owed 40,000 dollars to the federal government."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the IRS representative meant that Erika had to pay exactly 40,000 dollars, not more and not fewer?"}}], 

[["norm_a",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated. His chief researcher told him that 900 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 900 people had participated, not more and not fewer?"}}],
    
[["norm_b",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated. His chief researcher told him that 9,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 9,000 people had participated, not more and not fewer?"}}],
  
[["norm_c",7], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ryan was directing a presidential poll and needed to know how many people had participated. His chief researcher told him that 90,000 people had submitted their answers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the Chief researcher meant that exactly 90,000 people had participated, not more and not fewer?"}}],
 
[["norm_a",8], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship. Abigayle said that she had won by 60 dollars the last time she played."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 60 dollars the last time she played, not more and not fewer? "}}],
    
[["norm_b",8], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship. Abigayle said that she had won by 600 dollars the last time she played."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 600 dollars the last time she played, not more and not fewer? "}}],
    
[["norm_c",8], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Connor met Abigayle, a retired Jeopardy champion, he asked how large her margin of victory had been in her final championship. Abigayle said that she had won by 6,000 dollars the last time she played."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Abigayle meant that she had won exactly 6,000 dollars the last time she played, not more and not fewer? "}}],

[["norm_a",9], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct. The precinct captain said that 70 people had voted there that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 70 people had voted that day at the precinct, not more and not fewer?"}}],
    
[["norm_b",9], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct. The precinct captain said that 700 people had voted there that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 700 people had voted that day at the precinct, not more and not fewer?"}}],         
    
[["norm_c",9], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When Elsa arrived to tabulate the votes, she asked the precinct captain how many people had cast votes in the caucus in that precinct. The precinct captain said that 7,000 people had voted there that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the precinct captain meant that exactly 7,000 people had voted that day at the precinct, not more and not fewer?"}}],           

[["norm_a",10], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had. Carter said that his neighbor had 10 pounds at the time."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 10 pounds of cocaine in his apartment, not more and not fewer?"}}],
    
[["norm_b",10], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had. Carter said that his neighbor had 100 pounds at the time."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 100 pounds of cocaine in his apartment, not more and not fewer?"}}],
    
[["norm_c",10], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The police, receiving a tip-off from Carter that his neighbor sold cocaine, were preparing to raid the home. They asked Carter how much cocaine his neighbor had. Carter said that his neighbor had 1,000 pounds at the time."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Carter meant that his neighbor had exactly 1,000 pounds of cocaine in his apartment, not more and not fewer?"}}],

[["norm_a",11], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown. Emily said that the rocket flew 80 feet before falling back to the ground."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 80 feet, not more and not fewer?"}}],
    
[["norm_b",11], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown. Emily said that the rocket flew 800 feet before falling back to the ground."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 800 feet, not more and not fewer?"}}],                            
    
[["norm_c",11], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Emily won the model rocket contest, soundly outdistancing all her competitors. Tom asked her how high her rocket had flown. Emily said that the rocket flew 8,000 feet before falling back to the ground."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Emily meant that her rocket had flown exactly 8,000 feet, not more and not fewer?"}}],

[["norm_a",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost. The engineer said that 900 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 900 gallons had been spilled, not more and not fewer?"}}],
    
[["norm_b",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost. The engineer said that 9,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 9,000 gallons had been spilled, not more and not fewer?"}}],                                  
    
[["norm_c",12], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The project manager, unnerved by the latest oil spill in the Gulf of Mexico, demanded that the engineer immediately report to him how many gallons of oil had been lost. The engineer said that 90,000 gallons had been spilled."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that exactly 90,000 gallons had been spilled, not more and not fewer?"}}],                               

[["norm_a",13], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were. The professor answered that the files contained 500 rows not including headers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 500 rows long, not more and not fewer?"}}],
                       
[["norm_b",13], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were. The professor answered that the files contained 5,000 rows not including headers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 5,000 rows long, not more and not fewer?"}}],
    
[["norm_c",13], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erin was ready to start working on her computational linguistics final project, so she asked her professor how long the input files that had been assigned for data processing were. The professor answered that the files contained 50,000 rows not including headers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the professor meant that the files for data processing were exactly 50,000 rows long, not more and not fewer?"}}],

[["norm_a",14], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was. The scientists determined that 200 years was the age of the artifact."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 200 years old, no more and no less? "}}],
    
[["norm_b",14], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was. The scientists determined that 2,000 years was the age of the artifact."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 2,000 years old, no more and no less? "}}],
     
[["norm_c",14], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Noah found a curious artifact in a cave and took it to some paleontologists to ask how old it was. The scientists determined that 20,000 years was the age of the artifact."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the archeologist meant that the artifact was exactly 20,000 years old, no more and no less? "}}],

[["norm_a",15], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week. The engineer replied that the plane had travelled 800 miles with no major incidents."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that the plane had travelled exactly 800 miles, not more and not less?"}}],
    
[["norm_b",15], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week. The engineer replied that the plane had travelled 8,000 miles with no major incidents."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that the plane had travelled exactly 8,000 miles, not more and not less?"}}],
                                                    
[["norm_c",15], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Before taking off, the pilot asked the engineer how many miles the plane had travelled in the last week. The engineer replied that the plane had travelled 80,000 miles with no major incidents."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the engineer meant that the plane had travelled exactly 80,000 miles, not more and not less?"}}],                                            
   
[["norm_a",16], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with. Her supervisor said that 30 degrees was the target temperature."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 30 degrees, no more and no less?"}}],
    
[["norm_b",16], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with. Her supervisor said that 300 degrees was the target temperature."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 300 degrees, no more and no less?"}}],
                                                                                                         
[["norm_c",16], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "On Julie's first day in the lab, she asked her supervisor how much she needed to heat the sample that she was experimenting with. Her supervisor said that 3,000 degrees was the target temperature."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie's teacher meant that the sample needed to be heated exactly 3,000 degrees, no more and no less?"}}],
                                                                                                         
[["norm_a",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there. The veterinarian told her that they had 100 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 100 flamingos, no more and no less?"}}],
    
[["norm_b",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there. The veterinarian told her that they had 1,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 1,000 flamingos, no more and no less?"}}],
    
[["norm_c",17], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While visiting the local reserve, Sandy asked the onsite veterinarian how many flamingos lived there. The veterinarian told her that they had 10,000 flamingos at the moment."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the veterinarian meant that the flamingo population was exactly 10,000 flamingos, no more and no less?"}}],
    
[["norm_a",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed. The editor told him that they needed 700 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 700 copies, no more and no less?"}}],
    
[["norm_b",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed. The editor told him that they needed 7,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 7,000 copies, no more and no less?"}}],
    
[["norm_c",18], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The printer called the newspaper's editor to ask how many copies needed to be printed. The editor told him that they needed 70,000 copies by the end of the day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the editor meant for the printer to print exactly 70,000 copies, no more and no less?"}}],

[["norm_a",19], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week. Andrea replied that the system had recorded 700 clicks all within the United States."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 700 clicks?"}}],
    
[["norm_b",19], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week. Andrea replied that the system had recorded 7,000 clicks all within the United States."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 7,000 clicks?"}}],
                            
[["norm_c",19], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Susan called Andrea at the Data Analysis department to ask exactly how many clicks their new website publicity banner had received in the last week. Andrea replied that the system had recorded 70,000 clicks all within the United States."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Andrea meant that the ad had gotten exactly 70,000 clicks?"}}],

[["norm_a",20], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold. Rachel responded that they needed to set up 20 chairs in the main room."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 20 chairs, no more and no less?"}}],
    
[["norm_b",20], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold. Rachel responded that they needed to set up 200 chairs in the main room."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 200 chairs, no more and no less?"}}],
                
[["norm_c",20], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While setting up for the concert that night, Jordan asked Rachel how many chairs they needed to unfold. Rachel responded that they needed to set up 2,000 chairs in the main room."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rachel meant that they would need to set up exactly 2,000 chairs, no more and no less?"}}],

[["norm_a",21], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have. Mr. Hilton said that he wanted 30 rooms all with exterior windows."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 30 rooms, no more and no less?"}}],
    
[["norm_b",21], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have. Mr. Hilton said that he wanted 300 rooms all with exterior windows."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 300 rooms, no more and no less?"}}],
      
[["norm_c",21], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While mapping out the floorplan for the new Hilton hotel, Clara asked Mr. Hilton how many rooms he wanted the new hotel to have. Mr. Hilton said that he wanted 3,000 rooms all with exterior windows."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Mr. Hilton meant that he wanted exactly 3,000 rooms, no more and no less?"}}],

[["norm_a",22], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening. The coordinator said that 80 Democrats would attend the event."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 80 Democrats would attend the event, no more and no less?"}}],
     
[["norm_b",22], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening. The coordinator said that 800 Democrats would attend the event."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 800 Democrats would attend the event, no more and no less?"}}],
                
[["norm_c",22], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Julian while organizing a fundraiser for Bernie Sanders' campaign, asked the campaign's chief outreach coordinator how many Democrats were expected that evening. The coordinator said that 8,000 Democrats would attend the event."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the coordinator meant that exactly 8,000 Democrats would attend the event, no more and no less?"}}],
    
[["norm_a",23], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair. Peet said that he acquired 60 stamps at a very good price."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 60 stamps, no more and no less?"}}],
    
[["norm_b",23], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair. Peet said that he acquired 600 stamps at a very good price."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 600 stamps, no more and no less?"}}],
                  
[["norm_c",23], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Rowan asked Peet how many stamps he added to his collection after attending the stamp fair. Peet said that he acquired 6,000 stamps at a very good price."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Peet meant that he had acquired exactly 6,000 stamps, no more and no less?"}}],
 
[["norm_a",24], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost. The blood bank director said that 90 units had been contaminated."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 90 units of blood had been contaminated in the flood, no more and no less? "}}],
     
[["norm_b",24], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost. The blood bank director said that 900 units had been contaminated."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 900 units of blood had been contaminated in the flood, no more and no less? "}}],
                            
[["norm_c",24], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the flood, the head of the hospital asked the blood bank director how many units of blood had been lost. The blood bank director said that 9,000 units had been contaminated."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the blood bank director meant that exactly 9,000 units of blood had been contaminated in the flood, no more and no less? "}}],
 
[["norm_a",25], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers. The manager said that information from 60 accounts had been stolen."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that the information from exactly 60 accounts had been stolen, no more and no less?"}}],
    
[["norm_b",25], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers. The manager said that information from 600 accounts had been stolen."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that the information from exactly 600 accounts had been stolen, no more and no less?"}}],
                            
[["norm_c",25], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that her company's website had been hacked, Joana called the IT department to ask the manager how many accounts had been accessed by the hackers. The manager said that information from 6,000 accounts had been stolen."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do think it is that the IT department manager meant that the information from exactly 6,000 accounts had been stolen, no more and no less?"}}],
    
[["norm_a",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean called his secretary to find out how many graduate students had received his email about the new grading policies. The secretary replied that 50 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 50 students had gotten the message, no more and no less? "}}],
     
[["norm_b",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean called his secretary to find out how many graduate students had received his email about the new grading policies. The secretary replied that 500 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 500 students had gotten the message, no more and no less? "}}],
                         
[["norm_c",26], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The Dean called his secretary to find out how many graduate students had received his email about the new grading policies. The secretary replied that 5,000 students had gotten the message."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the secretary meant that exactly 5,000 students had gotten the message, no more and no less? "}}],

[["norm_a",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that Pamela had finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had had in the last week. Pamela replied that her video had 40 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 40 views, no more and no less?"}}],
    
[["norm_b",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that Pamela had finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had had in the last week.Pamela replied that her video had 400 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 400 views, no more and no less?"}}],
                                 
[["norm_c",27], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After learning that Pamela had finally uploaded the video of her latest song to YouTube, Matt asked her how many views the video had had in the last week.Pamela replied that her video had 4,000 views from several countries."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pamela meant that her video had exactly 4,000 views, no more and no less?"}}],
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
[["f_1",28], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While driving through the mountains at night, Gertrude became exhausted, so she checked her map to see approximately how many miles away the nearest lodge was. The map showed that the nearest lodge was still several miles away."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the lodge is more than 10 miles away?"}}],                          
 
 [["f_1",29], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "While marathoning her favorite TV show, Avatar, Jhanelle checked the list to see exactly how many episodes were left. The list showed that she still had a few episodes left."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there are less than 5 episodes left?"}}],                          
    
 [["f_1",30], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the disappointing loss, Akash asked the basketball coach approximately how many turnovers he had committed. The coach said Akash had committed far too many turnovers."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Akash committed more turnovers than anyone else on the team?"}}],                          
    
 [["f_1", 31], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Iz tested herself to see exactly how many airplane noises she could identify. She found that she could identify every airplane noise."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were a lot of airplanes in the air that day?"}}],                          
    
 [["f_1", 32], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "The spectators were amazed by David's skill and asked him approximately how many knives he could juggle at once. David answered that he could juggle quite a few knives at one time."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that David exaggerated when he told the crowd the number of knives he could juggle to impress them?"}}],                          
    
 [["f_1", 33], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Isabella was collecting flight statistics and asked the air traffic controller exactly how many planes would be flying through O'Hare that day. The air traffic controller replied that the airports would see an average number of flights that day."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that exactly 2,500 airplanes will fly through O'Hare, no more and no less? "}}],                          
    
 [["f_1", 34], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Bardia was bored and decided to count exactly how many tiles were on the floor of the lecture hall. He found that there were more tiles than he cared to count."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were over 100 tiles on the floor of the lecture hall?"}}],                          
    
 [["f_1", 35], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Kevin wanted to know exactly how many successful coups d'�tat there had been in American history. He learned that there had been none."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Kevin thought that there was at least one coups d'�tat before he checked?"}}],                          
    
 [["f_1", 36], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Pat went out knocking on doors while campaigning for Jim Gilmore. The head organizer later asked him roughly how many doors he had knocked on that day. Pat answered that he had knocked on an enormous number of doors."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Pat knocked on exactly 50 doors, no more and no less?"}}],                          
    
 [["f_1", 37], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Brian decided that he would count approximately how many spoons there were in the South Campus dining hall. He counted many, many spoons."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were over 100 spoons in the dining hall?"}}],                          
    
 [["f_1", 38], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Nancy, a salesperson, had to count up exactly how many pieces of cereal were in each box. Not surprisingly, she found that each box contained a lot of pieces of cereal."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that each box contained the exact same amount of pieces?"}}],                          
    
 [["f_2", 39], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Dylan asked his boss how many people definitely would show up to the meeting. His boss said that exactly 20 people would come."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Dylan was expecting exactly 20 people to come to the meeting when he asked his boss, no more and no less?"}}],                          
    
 [["f_2", 40], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Gerri asked the Goldman-Sachs executive nervously how many other candidates there were for the position. He told her that approximately 50 other candidates were being interviewed."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Gerri was expecting exactly 50 other people were being interviewed for the position, no more and no less? "}}],                          
    
 [["f_2", 41], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "A perplexed Jay wondered constantly how many of his classmates had failed the economics midterm. It turned out that exactly 20 of Jay's classmates had failed the exam."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Jay expected more than 20 people to fail the exam?"}}],                          
    
 [["f_2", 42], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Nora wondered exasperatedly how many hours she would have to spend dancing that weekend. According to her schedule, she would dance for approximately 20 hours."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Nora was expecting to work more than 20 hours that weekend?"}}],                          
    
 [["f_2", 43], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "During the theology exam, Ryan racked his brain, asking himself frustratedly how many commandments there were. He then recalled that there were exactly 10 commandments."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Ryan recalled what those 10 commandments were?"}}],                          
    
 [["f_2", 44], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Curious acquaintances often wondered fervently how many languages Nina spoke. She revealed one day that she spoke exactly 10 languages."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Nina's acquaintances were surprised when she told them she spoke 10 languages? "}}],                          
    
 [["f_2", 45], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "On her visit to the alpaca farm, Shannon asked excitedly how many alpacas there were. She was informed that there were approximately 40 alpacas."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the farm contained exactly 40 alpacas, no more and no less?"}}],                          
    
 [["f_2", 46], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Angela decided that she would ascertain decisively how many hours on average a student spent procrastinating. She found that the average student procrastinates for approximately 20 hours per week."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Angela expected the average student to procrastinate more than 20 hours per week?"}}],                          
    
 [["f_2", 47], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Elaina was lost and asked a pedestrian desperately how many blocks away the University of Chicago's campus was. The pedestrian said that the campus was approximately 10 blocks away."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Elania expected campus to be more than 10 blocks away?"}}],                          
    
 [["f_2", 48], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "After the accident, Zach asked the customer service agent anxiously how many dollars it would cost to repair his laptop. The agent told him that it would cost exactly 500 dollars."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Zach expected the repairs to cost exactly 500 dollars, no more and no less?"}}],                          
    
 [["f_2", 49], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "William was interested in famous train heists and looked up curiously how many dollars Jesse James had stolen in his robbery. He learned that approximately 3,000 dollars had been taken."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that William expected the total amount of money taken by Jesse James to be around 3,000 dollars?"}}],                          
    
 [["f_3", 50], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "James and Karnika asked the organizer how many people certainly would come to their wedding. The organizer replied that a large handful of people would come."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that James and Karnika expected more people to come than what the organizer told them?"}}],                          
    
 [["f_3", 51], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Claire pondered carefully how many new strings she needed for her violin. She determined she needed several new strings."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Claire initially expected her violin to need more than 2 strings replaced?"}}],                          
    
 [["f_3", 52], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Remy asked his friends persistently how many of them would be participating in the scavenger hunt in the spring. He learned that few of his friends would participate."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that exactly 5 of Remy's friends would participate, no more and no less?"}}],                          
    
 [["f_3", 53], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Rebecca asked her friends gleefully how many hours they would be able to volunteer in the phone bank on Friday. They said they would be willing to make calls for a few hours."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Rebecca's friends volunteered in the phone bank on Friday for over 3 hours?"}}],                          
    
 [["f_3", 54], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "In the course of preparing for move-in, Louis asked the housing officials curiously how many new residents there would be that year. The officials told him there would be many new residents."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that there were at least over 10 new residents that year?"}}],                          
    
 [["f_3", 55], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Before leaving on her vacation, Julie asked her friends how many gallons of gas probably would be needed to get her to Pasadena. They told her that only a few gallons would be necessary."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Julie needed exactly 3 gallons of gas to get to Pasadena, no more and no less?"}}],                          
    
 [["f_3", 56], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Caleb went to the doughnut shop and asked the salesperson hungrily how many doughnuts there were left. The salesperson answered that there was a donut shortage and that they had only a few doughnuts left."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Caleb bought the rest of the doughnuts in the shop?"}}],                          
    
 [["f_3",57], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Erin, an avid reader, wondered intently how many words were in the book 'War and Peace.' She quickly discovered that it contained more words than she could count."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that Erin counted over 100 words before she stopped counting?"}}],                          
    
 [["f_3", 58], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Ulysses was in a bad mood and demanded to know immediately how many minutes his pizza would need to cook. The waiter responded that the food would be ready in a few minutes."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the pizza came in exactly 5 minutes, no more and no less?"}}],                          
    
 [["f_3", 59], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "Elaine asked her classmates nosily how many siblings they each had. She was informed that most of them had a few siblings."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the average student in Elaine's class had approximately 3 siblings?"}}],                          
    
 [["f_3", 60], "Message", {consentRequired: false, transfer: "keypress",
    html: ["div",
          ["p", "When a notification of delay came in, Frederick asked the gate attendant despondently how many hours his flight to Columbus would be delayed. The attendant reassured him that the delay was only a few minutes."],
          ]},
    "AcceptabilityJudgment", {s: {html:"How likely do you think it is that the plane came in less than an hour late?"}}]                          
       
];
