var shuffleSequence = seq("setcounter","consent", "intro1","intro2",
                      sepWith("sep", seq("practice","practiceover", rshuffle(startsWith("E"),startsWith("f")))), "brexit"  );

var completionMessage = "Thank you for your participation!"

var defaults = [
    "Separator", {
        transfer: 1000,
        normalMessage: "Please wait for the next sentence.",
        errorMessage: "Wrong. Please wait for the next sentence.",
        ignoreFailure: true,
        hideProgressBar: true
    },
    "DashedSentence", {
        hideProgressBar: true
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: false,
        as: ["Yes","No"],
        randomOrder: false
    },
    "Message", {
       hideProgressBar: true
    },
        "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "Vorm", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true
    },
    "Scale_New", {
        startValue: 0, 
        endValue: 100,
        hideProgressBar: true,
        scaleLabels: true,
        saveReactionTime: true,
        leftLabel: "(Not relevant)", rightLabel: "(Very relevant)"
    },
    "StaticSentence",{
        hideProgressBar: true
    },
    "StaticSentence2",{
        hideProgressBar: true
    },
    "SingleSlider",{
        children: ["StaticSentence","StaticSentence2","Scale_New"],
        triggers: [2],
        hideProgressBar: true
    }
];



var items = [

    ["sep", "Separator", { }],
    ["consent", "Form", {consentRequired: true, html: { include: "consent.html" }, validators: {},continueMessage:"Click here to continue."} ],
   ["brexit", "Form", {html: { include: "exit.html" },validators: {},continueMessage:"Click here to send the results."} ],

    ["intro1", "Form", {consentRequired: true, html: {include: "intro1.html"}}],
    
    ["intro2", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],

     ["practiceover", "Message", {html: ["div",
                          ["p", "This is the end of the practice."],
                          ["p", "Now the real experiment is going to start, where you'll have to do the same task as before: read a sentence, and answer the question that follows it, using a 0-100 scale."],
                          ["p", "Drag the bar to choose your response on the scale."] 
],continueMessage:"Click here to start the experiment."}],
 
  ["setcounter", "__SetCounter__", { }],
    
// items

["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The bus driver is furious.",
                                html: "On a 0-100 scale, how angry is the bus driver?"}],

["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The soldier is dangerous.",
                                html: "On a 0-100 scale, how harmless is the soldier?"}],

["practice", "SingleSlider", {s: "Drag the bar to choose your response!",
                                s2: "The wrestler is strong.",
                                html: "On a 0-100 scale, how strong is the wrestler?"}],

[["Eweak",1], "SingleSlider", {s: "",
                                s2: "Drinking is allowed.",
                                html: "On a 0-100 scale, how acceptable is drinking?"}],

    [["Estrong",1], "SingleSlider", {s: "",
                                s2: "Drinking is obligatory.",
                                html: "On a 0-100 scale, how acceptable is drinking?"}],
[["Eweak",2], "SingleSlider", {s: "", 
                                s2: "The model is attractive.", 
                                html: "On a 0-100 scale, how attractive is the model?"}],

    [["Estrong",2], "SingleSlider", {s: "",
                                s2: "The model is stunning.",
                                html: "On a 0-100 scale, how attractive is the model?"}],
    [["Eweak",3], "SingleSlider", {s: "",
                                s2: "John began the race.",
                                html: "On a 0-100 scale, how far along is John in the race?"}],

    [["Estrong",3], "SingleSlider", {s: "",
                                s2: "John completed the race.",
                                html: "On a 0-100 scale, how far along is John in the race?"}],

    [["Eweak",4], "SingleSlider",       {s: "",
                                s2: "The teacher believes it is true.",
                                html: "On a 0-100 scale, how sure is the teacher that it is true?"}], 
[["Estrong",4], "SingleSlider",       {s: "",
                                s2: "The teacher knows it is true.",
                                html: "On a 0-100 scale, how sure is the teacher that it is true?"}], 

[["Eweak",5], "SingleSlider",       {s: "",
                                s2: "The elephant is big.",
                                html: "On a 0-100 scale, how big is the elephant?"}], 
[["Estrong",5], "SingleSlider",       {s: "",
                                s2: "The elephant is enormous.",
                                html: "On a 0-100 scale, how big is the elephant?"}], 

[["Eweak",6], "SingleSlider",       {s: "",
                                s2: "The weather is cool.",
                                html: "On a 0-100 scale, how cool is the weather?"}], 
[["Estrong",6], "SingleSlider",       {s: "",
                                s2: "The weather is cold.",
                                html: "On a 0-100 scale, how cool is the weather?"}], 

[["Eweak",7], "SingleSlider",       {s: "",
                                s2: "The machine damaged itself.",
                                html: "On a 0-100 scale, how damaged is the machine?"}],
[["Estrong",7], "SingleSlider",       {s: "",
                                s2: "The machine destroyed itself.",
                                html: "On a 0-100 scale, how damaged is the machine?"}], 

[["Eweak",8], "SingleSlider",       {s: "",
                                s2: "The sky is dark.",
                                html: "On a 0-100 scale, how dark is the sky?"}],
[["Estrong",8], "SingleSlider",       {s: "",
                                s2: "The sky is black.",
                                html: "On a 0-100 scale, how dark is the sky?"}], 

[["Eweak",9], "SingleSlider",       {s: "",
                                s2: "The task is difficult.",
                                html: "On a 0-100 scale, how difficult is the task?"}], 
[["Estrong",9], "SingleSlider",       {s: "",
                                s2: "The task is impossible.",
                                html: "On a 0-100 scale, how difficult is the task?"}], 

[["Eweak",10], "SingleSlider",       {s: "",
                                s2: "Zack's carpet was dirty.",
                                html: "On a 0-100 scale, how dirty is Zack's carpet?"}],
[["Estrong",10], "SingleSlider",       {s: "",
                                s2: "Zack's carpet was filthy.",
                                html: "On a 0-100 scale, how dirty is Zack's carpet?"}],

[["Eweak",11], "SingleSlider",       {s: "",
                                s2: "The doctor dislikes coffee.",
                                html: "On a 0-100 scale, how much does the doctor dislike coffee?"}], 
[["Estrong",11], "SingleSlider",       {s: "",
                                s2: "The doctor loathes coffee.",
                                html: "On a 0-100 scale, how much does the doctor dislike coffee?"}], 

[["Eweak",12], "SingleSlider", {s: "",
                                s2: "The sales will double. ",
                                html: "On a 0-100 scale, how much will the sales increase?"}], 
[["Estrong",12], "SingleSlider", {s: "",
                                s2: "The sales will triple. ",
                                html: "On a 0-100 scale, how much will the sales increase?"}],

[["Eweak",13], "SingleSlider", {s: "",
                                s2: "That candidate is equally skilled.",
                                html: "On a 0-100 scale, how do the candidates' skills compare?"}],
[["Estrong",13], "SingleSlider", {s: "",
                                s2: "That candidate is more skilled.",
                                html: "On a 0-100 scale, how do the candidates' skills compare?"}],

[["Eweak",14], "SingleSlider", {s: "",
                                s2: "The movie is funny.",
                                html: "On a 0-100 scale, how funny is the movie?"}], 
[["Estrong",14], "SingleSlider", {s: "",
                                s2: "The movie is hilarious.",
                                html: "On a 0-100 scale, how funny is the movie?"}], 

[["Eweak",15], "SingleSlider", {s: "",
                                s2: "The movie is good.",
                                html: "On a 0-100 scale, how good is the movie?"}], 
[["Estrong",15], "SingleSlider", {s: "",
                                s2: "The movie is excellent.",
                                html: "On a 0-100 scale, how good is the movie?"}],

[["Eweak",16], "SingleSlider", {s: "",
                                s2: "The winner was happy.",
                                html: "On a 0-100 scale, how happy was the winner?"}],
[["Estrong",16], "SingleSlider", {s: "",
                                s2: "The winner was ecstatic.",
                                html: "On a 0-100 scale, how happy was the winner?"}], 

[["Eweak",17], "SingleSlider", {s: "",
                                s2: "The problem is hard.",
                                html: "On a 0-100 scale, how hard is the problem?"}], 
[["Estrong",17], "SingleSlider", {s: "",
                                s2: "The problem is unsolvable.",
                                html: "On a 0-100 scale, how hard is the problem?"}], 

[["Eweak",18], "SingleSlider", {s: "",
                                s2: "The toxin is harmful.",
                                html: "On a 0-100 scale, how harmful is the toxin?"}], 
[["Estrong",18], "SingleSlider", {s: "",
                                s2: "The toxin is deadly.",
                                html: "On a 0-100 scale, how harmful is the toxin?"}],

[["Eweak",19], "SingleSlider", {s: "",
                                s2: "There is water here.",
                                html: "On a 0-100 scale, how widespread is the water?"}], 
[["Estrong",19], "SingleSlider", {s: "",
                                s2: "There is water everywhere.",
                                html: "On a 0-100 scale, how widespread is the water?"}],

[["Eweak",20], "SingleSlider", {s: "",
                                s2: "The boy is hungry.",
                                html: "On a 0-100 scale, how hungry is the boy?"}], 
[["Estrong",20], "SingleSlider", {s: "",
                                s2: "The boy is starving.",
                                html: "On a 0-100 scale, how hungry is the boy?"}], 

[["Eweak",21], "SingleSlider", {s: "",
                                s2: "The student is intelligent.",
                                html: "On a 0-100 scale, how intelligent is the student?"}], 
[["Estrong",21], "SingleSlider", {s: "",
                                s2: "The student is briliant.",
                                html: "On a 0-100 scale, how intelligent is the student?"}], 

[["Eweak",22], "SingleSlider", {s: "",
                                s2: "Chris's opponent was intimidating.",
                                html: "On a 0-100 scale, how intimidating was Chris's opponent?"}],
[["Estrong",22], "SingleSlider", {s: "",
                                s2: "Chris's opponent was terrifying.",
                                html: "On a 0-100 scale, how intimidating was Chris's opponent?"}], 

[["Eweak",23], "SingleSlider", {s: "",
                                s2: "The coast was largely flooded.",
                                html: "On a 0-100 scale, how flooded was the coast?"}], 
[["Estrong",23], "SingleSlider", {s: "",
                                s2: "The coast was totally flooded.",
                                html: "On a 0-100 scale, how flooded was the coast?"}], 

[["Eweak",24], "SingleSlider", {s: "",
                                s2: "The princess likes dancing.",
                                html: "On a 0-100 scale, how much does the princess like dancing?"}],
[["Estrong",24], "SingleSlider", {s: "",
                                s2: "The princess loves dancing.",
                                html: "On a 0-100 scale, how much does the princess like dancing?"}], 

[["Eweak",25], "SingleSlider", {s: "",
                                s2: "Bill's score matches Al's.",
                                html: "On a 0-100 scale, how does Bill's score compare to Al's?"}], 
[["Estrong",25], "SingleSlider", {s: "",
                                s2: "Bill's score exceeds Al's.",
                                html: "On a 0-100 scale, how does Bill's score compare to Al's?"}], 

[["Eweak",26], "SingleSlider", {s: "",
                                s2: "Peter's answers were mostly wrong.",
                                html: "On a 0-100 scale, how wrong were Peter's answers?"}], 
[["Estrong",26], "SingleSlider", {s: "",
                                s2: "Peter's answers were entirely wrong.",
                                html: "On a 0-100 scale, how wrong were Peter's answers?"}], 

[["Eweak",27], "SingleSlider", {s: "",
                                s2: "The house is old.",
                                html: "On a 0-100 scale, how old is the house?"}], 
[["Estrong",27], "SingleSlider", {s: "",
                                s2: "The house is ancient.",
                                html: "On a 0-100 scale, how old is the house?"}], 

[["Eweak",28], "SingleSlider", {s: "",
                                s2: "Mistakes happened once.",
                                html: "On a 0-100 scale, how many times did mistakes happen?"}], 
[["Estrong",28], "SingleSlider", {s: "",
                                s2: "Mistakes happened twice.",
                                html: "On a 0-100 scale, how many times did mistakes happen?"}], 

[["Eweak",29], "SingleSlider", {s: "",
                                s2: "Jimmy writes books or plays.",
                                html: "On a 0-100 scale, how likely is it that Jimmy writes both books and plays?"}], 
[["Estrong",29], "SingleSlider", {s: "",
                                s2: "Jimmy writes books and plays.",
                                html: "On a 0-100 scale, how likely is it that Jimmy writes both books and plays?"}], 

[["Eweak",30], "SingleSlider", {s: "",
                                s2: "The teenager is overweight.",
                                html: "On a 0-100 scale, how overweight is the teenager?"}], 
[["Estrong",30], "SingleSlider", {s: "",
                                s2: "The teenager is obese.",
                                html: "On a 0-100 scale, how overweight is the teenager?"}],

[["Eweak",31], "SingleSlider", {s: "",
                                s2: "The measure was supported overwhelmingly.",
                                html: "On a 0-100 scale, how much was the measure supported?"}], 
[["Estrong",31], "SingleSlider", {s: "",
                                s2: "The measure was supported unanimously.",
                                html: "On a 0-100 scale, how much was the measure supported?"}], 

[["Eweak",32], "SingleSlider", {s: "",
                                s2: "The wine is palatable.",
                                html: "On a 0-100 scale, how palatable is the wine?"}], 
[["Estrong",32], "SingleSlider", {s: "",
                                s2: "The wine is delicious.",
                                html: "On a 0-100 scale, how palatable is the wine?"}], 

[["Eweak",33], "SingleSlider", {s: "",
                                s2: "The tank is partially full.",
                                html: "On a 0-100 scale, how full is the tank?"}], 
[["Estrong",33], "SingleSlider", {s: "",
                                s2: "The tank is completely full.",
                                html: "On a 0-100 scale, how full is the tank?"}], 

[["Eweak",34], "SingleSlider", {s: "",
                                s2: "The club permits dancing.",
                                html: "On a 0-100 scale, how obligatory is dancing in the club?"}],
[["Estrong",34], "SingleSlider", {s: "",
                                s2: "The club requires dancing.",
                                html: "On a 0-100 scale, how obligatory is dancing in the club?"}],

[["Eweak",35], "SingleSlider", {s: "",
                                s2: "Ann's speech was polished.",
                                html: "On a 0-100 scale, how polished was Anne's speech?"}], 
[["Estrong",35], "SingleSlider", {s: "",
                                s2: "Ann's speech was impeccable.",
                                html: "On a 0-100 scale, how polished was Anne's speech?"}], 

[["Eweak",36], "SingleSlider", {s: "",
                                s2: "Success is possible.",
                                html: "On a 0-100 scale, how likely is success?"}], 
[["Estrong",36], "SingleSlider", {s: "",
                                s2: "Success is certain.",
                                html: "On a 0-100 scale, how likely is success?"}],

[["Eweak",37], "SingleSlider", {s: "",
                                s2: "The girl is pretty.",
                                html: "On a 0-100 scale, how pretty is the girl?"}], 
[["Estrong",37], "SingleSlider", {s: "",
                                s2: "The girl is beautiful.",
                                html: "On a 0-100 scale, how pretty is the girl?"}], 

[["Eweak",38], "SingleSlider", {s: "",
                                s2: "The residents are primarily Greek.",
                                html: "On a 0-100 scale, how many of the residents are Greek?"}], 
[["Estrong",38], "SingleSlider", {s: "",
                                s2: "The residents are exclusively Greek.",
                                html: "On a 0-100 scale, how many of the residents are Greek?"}], 

[["Eweak",39], "SingleSlider", {s: "",
                                s2: "A delay will probably occur.",
                                html: "On a 0-100 scale, how likely is a delay to occur?"}], 
[["Estrong",39], "SingleSlider", {s: "",
                                s2: "A delay will necessarily occur.",
                                html: "On a 0-100 scale, how likely is a delay to occur?"}], 

[["Eweak",40], "SingleSlider", {s: "",
                                s2: "The city reduced waste.",
                                html: "On a 0-100 scale, how much did the city reduce waste?"}], 
[["Estrong",40], "SingleSlider", {s: "",
                                s2: "The city eliminated waste.",
                                html: "On a 0-100 scale, how much did the city reduce waste?"}], 

[["Eweak",41], "SingleSlider", {s: "",
                                s2: "Stu's daughter was scared.",
                                html: "On a 0-100 scale, how scared was Stu's daughter?"}],
[["Estrong",41], "SingleSlider", {s: "",
                                s2: "Stu's daughter was petrified.",
                                html: "On a 0-100 scale, how scared was Stu's daughter?"}], 

[["Eweak",42], "SingleSlider", {s: "",
                                s2: "Kaye's illness was serious.",
                                html: "On a 0-100 scale, how serious was Kaye's illness?"}], 
[["Estrong",42], "SingleSlider", {s: "",
                                s2: "Kaye's illness was life-threatening.",
                                html: "On a 0-100 scale, how serious was Kaye's illness?"}], 

[["Eweak",43], "SingleSlider", {s: "",
                                s2: "The two paintings are similar.",
                                html: "On a 0-100 scale, how similar are the two paintings?"}], 
[["Estrong",43], "SingleSlider", {s: "",
                                s2: "The two paintings are identical.",
                                html: "On a 0-100 scale, how similar are the two paintings?"}], 

[["Eweak",44], "SingleSlider", {s: "",
                                s2: "The train slowed.",
                                html: "On a 0-100 scale, how much did the train slow?"}], 
[["Estrong",44], "SingleSlider", {s: "",
                                s2: "The train stopped.",
                                html: "On a 0-100 scale, how much did the train slow?"}], 

[["Eweak",45], "SingleSlider", {s: "",
                                s2: "The fish is small.",
                                html: "On a 0-100 scale, how small is the fish?"}],
[["Estrong",45], "SingleSlider", {s: "",
                                s2: "The fish is tiny.",
                                html: "On a 0-100 scale, how small is the fish?"}], 

[["Eweak",46], "SingleSlider", {s: "",
                                s2: "The shirt is snug.",
                                html: "On a 0-100 scale, how snug is the shirt?"}], 
[["Estrong",46], "SingleSlider", {s: "",
                                s2: "The shirt is tight.",
                                html: "On a 0-100 scale, how snug is the shirt?"}], 

 [["Eweak",47], "SingleSlider", {s: "",
                                s2: "Cecilia trusts some politicians.",
                                html: "On a 0-100 scale, how many politicians does Cecilia trust?"}], 
[["Estrong",47], "SingleSlider", {s: "",
                                s2: "Cecilia trusts all politicians.",
                                html: "On a 0-100 scale, how many politicians does Cecilia trust?"}], 

[["Eweak",48], "SingleSlider", {s: "",
                                s2: "The runner started.",
                                html: "On a 0-100 scale, how far along is the runner?"}], 
[["Estrong",48], "SingleSlider", {s: "",
                                s2: "The runner finished.",
                                html: "On a 0-100 scale, how far along is the runner?"}], 

[["Eweak",49], "SingleSlider", {s: "",
                                s2: "The plant survived.",
                                html: "On a 0-100 scale, how well did the plant survive?"}], 
[["Estrong",49], "SingleSlider", {s: "",
                                s2: "The plant thrived.",
                                html: "On a 0-100 scale, how well did the plant survive?"}], 

[["Eweak",50], "SingleSlider", {s: "",
                                s2: "The worker is tired.",
                                html: "On a 0-100 scale, how tired is the worker?"}], 
[["Estrong",50], "SingleSlider", {s: "",
                                s2: "The worker is exhausted.",
                                html: "On a 0-100 scale, how tired is the worker?"}], 

[["Eweak",51], "SingleSlider", {s: "",
                                s2: "Joey's parents tolerate dating.",
                                html: "On a 0-100 scale, how much do Joey's parents like dating?"}], 
[["Estrong",51], "SingleSlider", {s: "",
                                s2: "Joey's parents encourage dating.",
                                html: "On a 0-100 scale, how much do Joey's parents like dating?"}], 

[["Eweak",52], "SingleSlider", {s: "",
                                s2: "The candidate tried.",
                                html: "On a 0-100 scale, how close is the candidate to success?"}], 
[["Estrong",52], "SingleSlider", {s: "",
                                s2: "The candidate succeeded.",
                                html: "On a 0-100 scale, how close is the candidate to success?"}], 

[["Eweak",53], "SingleSlider", {s: "",
                                s2: "The wallpaper is ugly.",
                                html: "On a 0-100 scale, how ugly is wallpaper?"}], 
[["Estrong",53], "SingleSlider", {s: "",
                                s2: "The wallpaper is hideous.",
                                html: "On a 0-100 scale, how ugly is wallpaper?"}], 

[["Eweak",54], "SingleSlider", {s: "",
                                s2: "Tom's interview was understandable.",
                                html: "On a 0-100 scale, how understandable was Tom's interview?"}],
[["Estrong",54], "SingleSlider", {s: "",
                                s2: "Tom's interview was articulate.",
                                html: "On a 0-100 scale, how understandable was Tom's interview?"}], 

[["Eweak",55], "SingleSlider", {s: "",
                                s2: "Tim's bathroom was unpleasant.",
                                html: "On a 0-100 scale, how unpleasant was Tim's bathroom?"}], 
[["Estrong",55], "SingleSlider", {s: "",
                                s2: "Tim's bathroom was disgusting.",
                                html: "On a 0-100 scale, how unpleasant was Tim's bathroom?"}], 

[["Eweak",56], "SingleSlider", {s: "",
                                s2: "The lawyer is usually early.",
                                html: "On a 0-100 scale, how often is the lawyer early?"}],
[["Estrong",56], "SingleSlider", {s: "",
                                s2: "The lawyer is always early.",
                                html: "On a 0-100 scale, how often is the lawyer early?"}], 

[["Eweak",57], "SingleSlider", {s: "",
                                s2: "Phoebe wants a car.",
                                html: "On a 0-100 scale, how necessary is a car for Phoebe?"}], 
[["Estrong",57], "SingleSlider", {s: "",
                                s2: "Phoebe needs a car.",
                                html: "On a 0-100 scale, how necessary is a car for Phoebe?"}], 

[["Eweak",58], "SingleSlider", {s: "",
                                s2: "The weather is warm.",
                                html: "On a 0-100 scale, how warm is the weather?"}], 
[["Estrong",58], "SingleSlider", {s: "",
                                s2: "The weather is hot.",
                                html: "On a 0-100 scale, how warm is the weather?"}], 

[["Eweak",59], "SingleSlider", {s: "",
                                s2: "The rehearsal went well.",
                                html: "On a 0-100 scale, how well did the rehearsal go?"}], 
[["Estrong",59], "SingleSlider", {s: "",
                                s2: "The rehearsal went superbly.",
                                html: "On a 0-100 scale, how well did the rehearsal go?"}], 

[["Eweak",60], "SingleSlider", {s: "",
                                s2: "The waiter is willing.",
                                html: "On a 0-100 scale, how willing is the waiter?"}], 
[["Estrong",60], "SingleSlider", {s: "",
                                s2: "The waiter is eager.",
                                html: "On a 0-100 scale, how willing is the waiter?"}], 

["filler1", "SingleSlider", {s: "",
                                s2: "The table is clean.",
                                html: "On a 0-100 scale, how dirty is the table?"}],
["filler2", "SingleSlider", {s: "",
                                s2: "The man is drunk.",
                                html: "On a 0-100 scale, how sober is the man?"}], 
["filler3", "SingleSlider", {s: "",
                                s2: "The neighbor is sleepy.",
                                html: "On a 0-100 scale, how alert is the neighbor?"}], 
["filler4", "SingleSlider", {s: "",
                                s2: "The gymnast is tall.",
                                html: "On a 0-100 scale, how short is the gymnast?"}],
["filler5", "SingleSlider", {s: "",
                                s2: "The street is wide.",
                                html: "On a 0-100 scale, how narrow is the street?"}]// NOTE NO COMMA


    
    ];
