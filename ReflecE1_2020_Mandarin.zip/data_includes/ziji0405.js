// ZIJI-EXP
// Implements independent, random assignment of participants to
// 1) Training condition
// Using strategy developed by Michael Wilson (UMass Amherst), 2017

// Determine training group
var x = Math.random();

if (x < 0.33) {
  var groupID = "ta";
} else if (x >= 0.33 & x < 0.66) {
  var groupID = "ziji";
} else {
  var groupID = "none";
}

trainID = "train-"+groupID
experimentalID = "exp-"+groupID
geiID = "gei-"+groupID

var shuffleSequence = seq("intro","practice", "presep", trainID, sepWith("sep", rshuffle(startsWith(experimentalID), startsWith(geiID))), "exit");
var practiceItemTypes = ["practice"];

var progressBarText = "您的进度是"
var completionMessage = "数据传送完毕。 非常感谢您的参与！"


var defaults = [
    "Separator", {
        transfer: 800,
        normalMessage: "",
        ignoreFailure:true
    },
    "DashedSentence", {
        mode: "self-paced reading"
    },
    "AcceptabilityJudgment", {
        as: ["1", "2", "3", "4", "5", "6", "7"],
        presentAsScale: true,
        instructions: "Use number keys or click boxes to answer.",
        leftComment: "(Bad)", rightComment: "(Good)"
    },
    "Question", {
        hasCorrect: 1,
        //randomOrder: ['f','j'],
        presentHorizontally: true
    },
    "Message", {
        hideProgressBar: true,
        continueMessage: ""
    },
    "Form", {
        hideProgressBar: true,
        continueOnReturn: true,
        saveReactionTime: true,
        continueMessage: "请按此键继续。"
    }
];

var items = [

["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ],

["sep", Separator, { }],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "下面您会做几个练习的例子。"],
                          ["p", "如果有些句子后面的问题难以判断， 您不需要考虑太多， 按照第一印象来回答就可以了。我们更希望知道您直觉的反应是是什么！"],
                          ["br",],
                          ["br",],
                          ["p", "请按下键继续"],
                          ]}],
                             
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "张京说服了王立不要辞职。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(您下面会看到一个问题。您需要根据您以上读到的这个句子来回答问题。)"],
                          ["p", "(如果您准备好了， 请按下键继续)"],
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "张京说服了谁不要辞职？",
                              as: ["张京",
                                   "王立"]}],
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "正确答案是 ‘王立’。 您答对了吗？"],
               
                          ["p", "请按下键继续"],
                          ]}],
                             
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "那个老教授培养的学生盗窃了教授的一个很重要的发现。"],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["br",],
                          ["p", "(您下面会看到一个问题。您需要根据您以上读到的这个句子来回答问题。)"],
                          ["p", "(如果您准备好了， 请按下键继续)"],
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "谁有一个重要发现？",
                              as: ["学生",
                                   "教授"]}],
                                 
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "正确答案是 ‘教授’。 您答对了吗？"],
               
                          ["p", "请按下键继续"],
                          ]}],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "您知道怎么做了吗？"],
                          ["p", "下面您会再看到几个例子。 您不会再收到任何提示。"],
                          ["br",],
                        //  ["p", "请按空格键继续"],
                          ]}],
    
                             
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王老师给班上的五个学生都推荐了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王老师一共推荐了几本书？",
                              as: ["五本",
                                   "一本"]}],
                                 
    
     ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "被记者称赞了的工程师发明的新产品创造出的价值救活了这个企业。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "什么被记者称赞了？",
                              as: ["工程师",
                                   "工程师的新产品"]}],
    
    
    ["practice", "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "练习结束。下面进入正式实验。请按下键键继续。"],
                          ]}],
    
   
    ["presep", Separator, { transfer: 1500, normalMessage: "请准备好， 我们要开始了。请等待。。。" }],

// Ta-training items
    
[ [ "train-ta", 1 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王娟知道李娜经常批评她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王娟知道李娜经常批评谁？",
                              as: ["王娟",
                                   "李娜"]}],
                                   
[ [ "train-ta", 2 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "罗珊觉得陈倩伤害了她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "罗珊觉得陈倩伤害了谁？",
                              as: ["罗珊",
                                   "陈倩"]}],
                                   
[ [ "train-ta", 3 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王红很失望林燕欺骗了她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王红很失望林燕欺骗了谁？",
                              as: ["王红",
                                   "林燕"]}],
                                   
[ [ "train-ta", 4 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马芳希望罗虹能保护她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马芳希望罗虹能保护谁？",
                              as: ["马芳",
                                   "罗虹"]}],
                                   
[ [ "train-ta", 5 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "胡菲说徐霞误导了她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "胡菲说徐霞误导了谁？",
                              as: ["胡菲",
                                   "徐霞"]}],
                                   
[ [ "train-ta", 6 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高辉希望罗强能养活他。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高辉希望罗强能养活谁？",
                              as: ["高辉",
                                   "罗强"]}],
                                   
[ [ "train-ta", 7 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈豪觉得许锋能捧红他。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈豪觉得许锋能捧红谁？",
                              as: ["沈豪",
                                   "许锋"]}],
                                   
[ [ "train-ta", 8 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘濠说李磊不重视他。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘濠说李磊不重视谁？",
                              as: ["刘濠",
                                   "李磊"]}],

[ [ "train-ta", 9 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "黄硕发现吴坤讨厌他。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "黄硕发现吴坤讨厌谁？",
                              as: ["黄硕",
                                   "吴坤"]}],
                                   
[ [ "train-ta", 10 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "徐俊害怕林威会累垮他。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "徐俊害怕林威会累垮谁？",
                              as: ["徐俊",
                                   "林威"]}],

// Ziji-training items
    
[ [ "train-ziji", 11 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王娟知道李娜经常批评她自己"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王娟知道李娜经常批评谁？",
                              as: ["王娟",
                                   "李娜"]}],
                                   
[ [ "train-ziji", 12 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "罗珊觉得陈倩伤害了她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "罗珊觉得陈倩伤害了谁？",
                              as: ["罗珊",
                                   "陈倩"]}],
                                   
[ [ "train-ziji", 13 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王红很失望林燕欺骗了她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王红很失望林燕欺骗了谁？",
                              as: ["王红",
                                   "林燕"]}],
                                   
[ [ "train-ziji", 14 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马芳希望罗虹能保护她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马芳希望罗虹能保护谁？",
                              as: ["马芳",
                                   "罗虹"]}],
                                   
[ [ "train-ziji", 15 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "胡菲说徐霞误导了她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "胡菲说徐霞误导了谁？",
                              as: ["胡菲",
                                   "徐霞"]}],
                                   
[ [ "train-ziji", 16 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高辉希望罗强能养活他自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高辉希望罗强能养活谁？",
                              as: ["高辉",
                                   "罗强"]}],
                                   
[ [ "train-ziji", 17 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈豪觉得许锋能捧红他自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈豪觉得许锋能捧红谁？",
                              as: ["沈豪",
                                   "许锋"]}],
                                   
[ [ "train-ziji", 18 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘濠说李磊不重视他自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘濠说李磊不重视谁？",
                              as: ["刘濠",
                                   "李磊"]}],
[ [ "train-ziji", 19 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "黄硕发现吴坤讨厌他自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "黄硕发现吴坤讨厌谁？",
                              as: ["黄硕",
                                   "吴坤"]}],
                                   
[ [ "train-ziji", 20 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "徐俊害怕林威会累垮他自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "徐俊害怕林威会累垮谁？",
                              as: ["徐俊",
                                   "林威"]}],
                                   
// None-training items
    
[ [ "train-none", 21 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王娟知道李娜经常批评学生。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王娟知道李娜经常批评谁？",
                              as: ["王娟",
                                   "学生"]}],
                                   
[ [ "train-none", 22 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "罗珊觉得陈倩伤害了朋友。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "罗珊觉得陈倩伤害了谁？",
                              as: ["罗珊",
                                   "朋友"]}],
                                   
[ [ "train-none", 23 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王红很失望林燕欺骗了老师。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王红很失望林燕欺骗了谁？",
                              as: ["王红",
                                   "老师"]}],
                                   
[ [ "train-none", 24 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马芳希望罗虹能保护病人们。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马芳希望罗虹能保护谁？",
                              as: ["马芳",
                                   "病人"]}],
                                   
[ [ "train-none", 25 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "胡菲说徐霞误导了记者。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "胡菲说徐霞误导了谁？",
                              as: ["胡菲",
                                   "记者"]}],
                                   
[ [ "train-none", 26 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高辉希望罗强能养活那个孤儿。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高辉希望罗强能养活谁？",
                              as: ["罗强",
                                   "一个孤儿"]}],
                                   
[ [ "train-none", 27 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈豪觉得许锋能捧红那个新人。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈豪觉得许锋能捧红谁？",
                              as: ["许锋",
                                   "一个新人"]}],
                                   
[ [ "train-none", 28 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘濠说李磊不重视新队友。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘濠说李磊不重视谁？",
                              as: ["李磊",
                                   "新队友"]}],
[ [ "train-none", 29 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "黄硕发现吴坤讨厌那个新老师。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "黄硕发现吴坤讨厌谁？",
                              as: ["吴坤",
                                   "新老师"]}],
                                   
[ [ "train-none", 30 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "徐俊害怕林威会累垮那个新助手。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "徐俊害怕林威会累垮谁？",
                              as: ["林威",
                                   "助手"]}],
                                   
// Experimental items below here                                   

[ [ "exp-ta-group-ziji", 31 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变自己."],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "冯莲"]}],                                   


[ [ "exp-ta-group-alt", 31 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变她。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "冯莲"]}],

[ [ "exp-ziji-group-ziji", 51 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变自己."],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "冯莲"]}],                                   

[ [ "exp-ziji-group-alt", 51 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变她自己。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "冯莲"]}],

[ [ "exp-none-group-ziji", 71 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变自己."],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "冯莲"]}],                                   


[ [ "exp-none-group-alt", 71 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "宋敏听说冯莲想改变那个运动员。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "宋敏听说冯莲想改变谁？",
                              as: ["宋敏",
                                   "一个运动员"]}],


[ [ "exp-ta-group-ziji", 32 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "何丽"]}],
                                   
[ [ "exp-ta-group-alt", 32 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了她。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "何丽"]}],
 
                                   
[ [ "exp-ziji-group-ziji", 52 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "何丽"]}],
                                   
[ [ "exp-ziji-group-alt", 52 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了她自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "何丽"]}],

[ [ "exp-none-group-ziji", 72 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "何丽"]}],
                                   
[ [ "exp-none-group-alt", 72 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "高梅担心何丽低估了对手。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "高梅担心何丽低估了谁？",
                              as: ["高梅",
                                   "对手"]}],


[ [ "exp-ta-group-ziji", 33 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "黄霞"]}],
                                   
[ [ "exp-ta-group-alt", 33 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "黄霞"]}],                             

[ [ "exp-ziji-group-ziji", 53 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "黄霞"]}],
                                   
[ [ "exp-ziji-group-alt", 53 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "黄霞"]}],                             


[ [ "exp-none-group-ziji", 73 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "黄霞"]}],
                                   
[ [ "exp-none-group-alt", 73 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周芳知道黄霞暴露了其他卧底。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周芳知道黄霞暴露了谁？",
                              as: ["周芳",
                                   "其他卧底"]}],                             



[ [ "exp-ta-group-ziji", 34 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "不符合."]}],
                                   
[ [ "exp-ta-group-alt", 34 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "刘敏"]}],

[ [ "exp-ziji-group-ziji", 54 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "不符合."]}],
                                   
[ [ "exp-ziji-group-alt", 54 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "刘敏"]}],

[ [ "exp-none-group-ziji", 74 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "不符合."]}],
                                   
[ [ "exp-none-group-alt", 74 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "吕萍希望刘敏多鼓励新同事。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "吕萍希望刘敏多鼓励谁？",
                              as: ["吕萍",
                                   "新同事"]}],
  

[ [ "exp-ta-group-ziji", 35 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "朱婷"]}],
                                   
[ [ "exp-ta-group-alt", 35 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待她。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "朱婷"]}],


[ [ "exp-ziji-group-ziji", 55 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "朱婷"]}],
                                   
[ [ "exp-ziji-group-alt", 55 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待她自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "朱婷"]}],


[ [ "exp-none-group-ziji", 75 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "朱婷"]}],
                                   
[ [ "exp-none-group-alt", 75 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "杨芳期待朱婷能善待那个老人。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "杨芳期待朱婷能善待谁？",
                              as: ["杨芳",
                                   "老人"]}],


[ [ "exp-ta-group-ziji", 36 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["王刚",
                                   "张军"]}],
                                   
[ [ "exp-ta-group-alt", 36 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定他。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["王刚",
                                   "张军"]}],

[ [ "exp-ziji-group-ziji", 56 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["王刚",
                                   "张军"]}],
                                   
[ [ "exp-ziji-group-alt", 56 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定他自己。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["王刚",
                                   "张军"]}],

[ [ "exp-none-group-ziji", 76 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["王刚",
                                   "张军"]}],
                                   
[ [ "exp-none-group-alt", 76 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王刚希望张军不要否定新老板。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王刚希望张军不要否定谁？",
                              as: ["张军",
                                   "新老板"]}],

                                   
[ [ "exp-ta-group-ziji", 37 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["周健",
                                   "李强"]}],
                                   
[ [ "exp-ta-group-alt", 37 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估他。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["周健",
                                   "李强"]}],

[ [ "exp-ziji-group-ziji", 57 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["周健",
                                   "李强"]}],
                                   
[ [ "exp-ziji-group-alt", 57 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估他自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["周健",
                                   "李强"]}],

[ [ "exp-none-group-ziji", 77 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["周健",
                                   "李强"]}],
                                   
[ [ "exp-none-group-alt", 77 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "周健盼望李强能仔细评估每个学生。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "周健盼望李强能仔细评估谁？",
                              as: ["李强",
                                   "每个学生"]}],


[ [ "exp-ta-group-ziji", 38 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["马山",
                                   "田军"]}],
                                   
[ [ "exp-ta-group-alt", 38 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低他。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["马山",
                                   "田军"]}],

[ [ "exp-ziji-group-ziji", 58 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["马山",
                                   "田军"]}],
                                   
[ [ "exp-ziji-group-alt", 58 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低他自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["马山",
                                   "田军"]}],

[ [ "exp-none-group-ziji", 78 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["马山",
                                   "田军"]}],
                                   
[ [ "exp-none-group-alt", 78 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "马山告诉田军不要贬低年轻人。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "马山告诉田军不要贬低谁？",
                              as: ["田军",
                                   "年轻人"]}],

                                   
[ [ "exp-ta-group-ziji", 39 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["孙强",
                                   "赵勇"]}],
                                   
[ [ "exp-ta-group-alt", 39 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了他。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["孙强",
                                   "赵勇"]}],

[ [ "exp-ziji-group-ziji", 59 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["孙强",
                                   "赵勇"]}],
                                   
[ [ "exp-ziji-group-alt", 59 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了他自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["孙强",
                                   "赵勇"]}],

[ [ "exp-none-group-ziji", 79 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["孙强",
                                   "赵勇"]}],
                                   
[ [ "exp-none-group-alt", 79 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙强听说赵勇积极推荐了一个年轻职员。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙强听说赵勇积极推荐了谁？",
                              as: ["赵勇",
                                   "一个年轻职员"]}],

    
[ [ "exp-ta-group-ziji", 40 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["刘刚",
                                   "谢伟"]}],
                                   
[ [ "exp-ta-group-alt", 40 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了他。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["刘刚",
                                   "谢伟"]}],


    
[ [ "exp-ziji-group-ziji", 60 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["刘刚",
                                   "谢伟"]}],
                                   
[ [ "exp-ziji-group-alt", 60 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了他自己。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["刘刚",
                                   "谢伟"]}],

    
[ [ "exp-none-group-ziji", 80 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了自己。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["刘刚",
                                   "谢伟"]}],
                                   
[ [ "exp-none-group-alt", 80 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘刚知道谢伟高估了那个新领导。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘刚知道谢伟高估了谁？",
                              as: ["谢伟",
                                   "新领导"]}],
                                   
[ [ "gei-ta-group-ziji", 41 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给自己设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "孔蓉"]}],
                                   
[ [ "gei-ta-group-alt", 41 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给她设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "孔蓉"]}],     

[ [ "gei-ziji-group-ziji", 61 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给自己设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "孔蓉"]}],
                                   
[ [ "gei-ziji-group-alt", 61 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给她自己设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "孔蓉"]}],     

[ [ "gei-none-group-ziji", 81 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给自己设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "孔蓉"]}],
                                   
[ [ "gei-none-group-alt", 81 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "夏彤发现孔蓉给邻居设计了一套房子。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "夏彤发现孔蓉给谁设计了一套房子？",
                              as: ["夏彤",
                                   "邻居"]}],     
   
   
[ [ "gei-ta-group-ziji", 42 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给自己写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "庄璇"]}],
                                   
[ [ "gei-ta-group-alt", 42 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给她写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "庄璇"]}],

   
[ [ "gei-ziji-group-ziji", 62 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给自己写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "庄璇"]}],
                                   
[ [ "gei-ziji-group-alt", 62 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给她自己写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "庄璇"]}],

   
[ [ "gei-none-group-ziji", 82 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给自己写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "庄璇"]}],
                                   
[ [ "gei-none-group-alt", 82 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "卫玲被告知庄璇给医生们写了一本书。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "卫玲被告知庄璇给谁写了一本书？",
                              as: ["卫玲",
                                   "医生"]}],


                                   
[ [ "gei-ta-group-ziji", 43 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给自己送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "田蕊."]}],
                                   
[ [ "gei-ta-group-alt", 43 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给她送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "田蕊"]}],

[ [ "gei-ziji-group-ziji", 63 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给自己送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "田蕊."]}],
                                   
[ [ "gei-ziji-group-alt", 63 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给她自己送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "田蕊"]}],

[ [ "gei-none-group-ziji", 83 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给自己送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "田蕊."]}],
                                   
[ [ "gei-none-group-alt", 83 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "赵菡说田蕊给新娘送了一份礼物。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "赵菡说田蕊给谁送了一份礼物？",
                              as: ["赵菡",
                                   "新娘"]}],

                                   
[ [ "gei-ta-group-ziji", 44 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给自己买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "陆珊"]}],
                                   
[ [ "gei-ta-group-alt", 44 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给她买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "陆珊"]}],

                                   
[ [ "gei-ziji-group-ziji", 64 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给自己买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "陆珊"]}],
                                   
[ [ "gei-ziji-group-alt", 64 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给她自己买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "陆珊"]}],

[ [ "gei-none-group-ziji", 84 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给自己买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "陆珊"]}],
                                   
[ [ "gei-none-group-alt", 84 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "沈蔓发现陆珊给女儿买了一份保险。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "沈蔓发现陆珊给谁买了一份保险？",
                              as: ["沈蔓",
                                   "女儿"]}],                                   
[ [ "gei-ta-group-ziji", 45 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给自己安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "宋倩"]}],
                                   
[ [ "gei-ta-group-alt", 45 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给她安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "宋倩"]}],

[ [ "gei-ziji-group-ziji", 65 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给自己安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "宋倩"]}],
                                   
[ [ "gei-ziji-group-alt", 65 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给她自己安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "宋倩"]}],

[ [ "gei-none-group-ziji", 85 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给自己安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "宋倩"]}],
                                   
[ [ "gei-none-group-alt", 85 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "刘兰听说宋倩给下属安排了很多工作。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "刘兰听说宋倩给谁安排了很多工作？",
                              as: ["刘兰",
                                   "下属"]}],    
[ [ "gei-ta-group-ziji", 46 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给自己报了一个补习班。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["王贵",
                                   "马良"]}],
                                   
[ [ "gei-ta-group-alt", 46 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给他报了一个补习班。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["王贵",
                                   "马良"]}],

[ [ "gei-ziji-group-ziji", 66 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给自己报了一个补习班。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["王贵",
                                   "马良"]}],
                                   
[ [ "gei-ziji-group-alt", 66 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给他自己报了一个补习班。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["王贵",
                                   "马良"]}],

[ [ "gei-none-group-ziji", 86 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给自己报了一个补习班。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["王贵",
                                   "马良"]}],
                                   
[ [ "gei-none-group-alt", 86 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王贵知道马良给儿子报了一个补习班。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王贵知道马良给谁报了一个补习班？",
                              as: ["马良",
                                   "儿子"]}],
                                   
[ [ "gei-ta-group-ziji", 47 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给自己创造了一个机会。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["孙刚",
                                   "李富"]}],
                                   
[ [ "gei-ta-group-alt", 47 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给他创造了一个机会。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["孙刚",
                                   "李富"]}],

                                   
[ [ "gei-ziji-group-ziji", 67 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给自己创造了一个机会。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["孙刚",
                                   "李富"]}],
                                   
[ [ "gei-ziji-group-alt", 67 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给他自己创造了一个机会。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["孙刚",
                                   "李富"]}],

                                   
[ [ "gei-none-group-ziji", 87 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给自己创造了一个机会。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["孙刚",
                                   "李富"]}],
                                   
[ [ "gei-none-group-alt", 87 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "孙刚很确定李富给竞争对手创造了一个机会。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "孙刚很确定李富给谁创造了一个机会？",
                              as: ["李富",
                                   "竞争对手"]}],
    
[ [ "gei-ta-group-ziji", 48 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给自己投了一票。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑大壮给谁投了一票？",
                              as: ["邓磊",
                                   "郑大壮"]}],
                                   
[ [ "gei-ta-group-alt", 48 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给他投了一票。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑壮给谁投了一票？",
                              as: ["邓磊",
                                   "郑大壮"]}],

[ [ "gei-ziji-group-ziji", 68 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给自己投了一票。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑大壮给谁投了一票？",
                              as: ["邓磊",
                                   "郑大壮"]}],
                                   
[ [ "gei-ziji-group-alt", 68 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给他自己投了一票。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑壮给谁投了一票？",
                              as: ["邓磊",
                                   "郑大壮"]}],

[ [ "gei-none-group-ziji", 88 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给自己投了一票。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑大壮给谁投了一票？",
                              as: ["邓磊",
                                   "郑大壮"]}],
                                   
[ [ "gei-none-group-alt", 88 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "邓磊打听到郑大壮给那个冷门候选人投了一票。"],
                          
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "邓磊打听到郑大壮给谁投了一票？",
                              as: ["郑大壮",
                                   "冷门候选人"]}],                                   
                                   
[ [ "gei-ta-group-ziji", 49 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给自己施加了太多压力。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["王庆",
                                   "唐威"]}],
                                   
[ [ "gei-ta-group-alt", 49 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给他施加了太多压力。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["王庆",
                                   "唐威"]}],                           

[ [ "gei-ziji-group-ziji", 69 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给自己施加了太多压力。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["王庆",
                                   "唐威"]}],
                                   
[ [ "gei-ziji-group-alt", 69 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给他自己施加了太多压力。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["王庆",
                                   "唐威"]}],

[ [ "gei-none-group-ziji", 89 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给自己施加了太多压力。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["王庆",
                                   "唐威"]}],
                                   
[ [ "gei-none-group-alt", 89 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "王庆觉得唐威给律师施加了太多压力。"],
                        
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "王庆觉得唐威给谁施加了太多压力？",
                              as: ["唐威",
                                   "律师"]}],

[ [ "gei-ta-group-ziji", 50 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给自己制订一个计划。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["顾军",
                                   "谢峰"]}],
                                   
[ [ "gei-ta-group-alt", 50 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给他制订一个计划。"],
                         
                          ]},
                "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["顾军",
                                   "谢峰"]}],

                                   
[ [ "gei-ziji-group-ziji", 70 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给自己制订一个计划。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["顾军",
                                   "谢峰"]}],
                                   
[ [ "gei-ziji-group-alt", 70 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给他自己制订一个计划。"],
                         
                          ]},
                "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["顾军",
                                   "谢峰"]}],


[ [ "gei-none-group-ziji", 90 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给自己制订一个计划。"],
                         
                          ]},
                 "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["顾军",
                                   "谢峰"]}],
                                   
[ [ "gei-none-group-alt", 90 ], "Message", {consentRequired: false, transfer: "click",
                    html: ["div",
                          ["p", "顾军希望谢峰给旅行团制订一个计划。"],
                         
                          ]},
                "Question", {hasCorrect: true, randomOrder: true,
                              q: "顾军希望谢峰给谁制订一个计划？",
                              as: ["谢峰",
                                   "旅行团"]}]

                                   

];
