var shuffleSequence = seq("intro","Practice", "presep", sepWith("sep", rshuffle(startsWith("Cheesecake"), "f")), "exit");
//variable declarations
var counterOverride = 3;
var ds = DashedSentence;
var q = Question;
var items = [];


var defaults = [
    Separator,{ignoreFailure: true},
    q,{hasCorrect: true, randomOrder: ["f","j"], presentHorizontally: true},
    ds,{mode: "self-paced reading", display: "dashed"}
];

//this array contains the intro and exit html references
var introArray = [
["intro", "Form", {consentRequired: true, html: {include: "intro.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro1.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro2.html" }} ],
["intro", "Form", {consentRequired: true, html: {include: "intro3.html" }} ],
["exit", "Form", {consentRequired: false, html: {include: "exit.html" }} ]
];

//this array holds one of the separators
var separator1Array = [
["sep", Separator, { }]
];

//this array holds the practice sentences
var practiceArray = [
["Practice", ds, {s: ["This is", "just a practice sentence", "to get you used", "to the method", "of presentation."]}, q, {q:"Was that sentence easy?", as: ["Yes","No"] }, Separator, { }],
["Practice", ds, {s: ["This is", "another practice sentence", "which is longer", "and a little more complicated", "than the one", "you just read."]}, q, {q:"Did you read that at a normal pace?",as: ["Yes","No"]  }],
                           
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all there is to it! Let's try some practice sentences more like the ones you'll be seeing in the experiment:"]
                           ]}],
                           
["Practice", ds, {s: ["Elias","told Martha","that the attractive lifeguard","on the pier","who is dating","Tracy's sister","saved","a little boy","from being","swept out to sea","by a rip-tide yesterday."]}, q,{q: "Who did the lifeguard save?", as: ["the little boy","Tracy's sister"], hasCorrect: 0}],

["Practice", Message, {consentRequired: false, transfer: "keypress",
                    html: ["div",
                          ["p", "Some sentences, like the one you just read, are fairly long and complex. How did you do on the comprehension question? You should have responded that the lifeguard saved the little boy."],
                          ["p", "Try your hand at these next few sentences. Don't overthink your response: go with your gut feeling or intuition!"]
                          ]}],
    

["Practice", ds, {s: ["The pop star", "sang", "herself hoarse","at the concert", "last night."]}, q, {q: "When was the concert?", as: ["last night","last year"]}, Separator, { }],
["Practice", ds, {s: ["The tall nurse", "swore", "that the elderly widow", "had never mistreated", "hospital staff."]}, q, {q:"Was the widow elderly?", as: ["Yes","No"]}, Separator, { }],
["Practice", ds, {s: ["The plumber", "working in the bathroom","cursed himself", "for forgetting", "his wrench."]}, q, {q: "Where was the plumber working?", as: ["the bathroom","the kitchen"]}],
                           
["Practice", Message, {consentRequired: false, transfer: "keypress",
                     html: ["div",
                           ["p", "That's all the practice! When you're ready to begin the experiment, press any button to move ahead. REMEMBER: it will last approximately 15 minutes, and will require your full attention throughout that period. Thank you for your help!"]
                           ]}],];

//this array contains the other separator                           
var separatorArray = [
["presep", Separator, { transfer: 3000, normalMessage: "Get your hands in position, and get ready to begin!" }],
];


/*this array contains cheesecake sentences, in a simplified format. each cheesecake sentence is fed to the method cheesecakeDecoder, which parses it
into a format the Ibex program will accept.
the simplified format is as follows:
[ the_sentence's_group_number , ["a", "list of", "words that", "form", "the sentence", "with commas between chunks", "and quotes around each word"] , "a single question surrounded by quotes" , ["answers to the questions, in quotes", "there can be more then one"] ], 
*/
var cheesecakeArray = [

//### GROUP 20 SIMPLIFIED SENTENCES###

[20, "After class,#the students#thought about#the older brother#of#the little girl#who#prepared himself#for college#by#studying hard.","Who studied hard?",[ "the older brother", "the little girl" ]],
[20, "The students#thought about#the older brother#of#the little girl#after class#who#prepared himself#for college#by#studying hard.", "Who studied hard?", ["the older brother", "the little girl" ]],
[20, "After class,#the students#thought about#the older brother#of#the little girl#who#prepared herself#for college#by#studying hard.", "Who studied hard?", [ "the little girl", "the older brother" ]],
[20, "The students#thought about#the older brother#of#the little girl#after class#who#prepared herself#for college#by#studying hard.", "Who studied hard?", [ "the little girl", "the older brother" ]],

];

//this array holds filler sentences
var fillerArray = [
[ "Immediately after#being#caught#and placed#in cold storage,#the fish#were#doubtlessly#frozen#on#the boat.","Where were the fish placed?",[ "in cold storage", "in the cargo hold" ]],
["Due to#extreme and rapid#changes#in temperature,#the logs#were#definitely#split#into#several pieces.", "How were the logs split?", ["into several pieces", "in two" ] ],
["Prior to#the magnificent#and decadent#feast,#forty chocolate layer cakes#were#supposedly#baked#for#an hour.","How many cakes were baked?",[ "forty", "twenty" ]],
];

function sentenceChunker(sentString)
{
    var finalSentArray = [];
    var prevHashPos = 0;
    
    for(var i = 0;i < sentString.length;i++)
    {
        if (sentString.charAt(i) === "#")
        {
            finalSentArray.push(sentString.substring(prevHashPos, i));
            prevHashPos = i+1;
        }
    }
    finalSentArray.push(sentString.substring(prevHashPos, sentString.length));
    return finalSentArray;
}

function cheesecakeDecoder(cakeArray)
{
    //array to store cheesecakes before appending to items array
    var tempArrayOfCheesecakes = [];
    var letters = ["a","b","c","d"];
    var counter = 0;
    for (var i = 0; i < cakeArray.length; i++)
    {
        //if the cheesecake is of the old format, leave alone and add to temp array
        if (typeof(cakeArray[i][0][0]) === "string")
        {
            tempArrayOfCheesecakes.push(cakeArray[i]);
        }
        //else, decode the cheesecake
        else
        {
            if(counter > 3){counter = 0};
            
            //store item to be turned to cheesecake
            var toDecode = cakeArray[i];
            //final cheesecake format
            var finalCheesecake = [ ["Cheesecake"+"-"+letters[counter], toDecode[0] ],ds,{ s: sentenceChunker(toDecode[1]) },"Question",{ q: toDecode[2], as: toDecode[3] } ];
            //add now complete cheesecake to temp list
            tempArrayOfCheesecakes.push(finalCheesecake);
            counter += 1;
        }
    }
    //add all cheesecakes to items array using concatenation    
    items = items.concat(tempArrayOfCheesecakes);
}
    
function fillerDecoder(fillerArray)
{
    //array to store filler sentences before appending to items array
    var tempArrayOfFillers = [];
    for (var i = 0; i < fillerArray.length; i++)
    {
        if (fillerArray[i][0] === "f")
            {
                tempArrayOfFillers.push(fillerArray[i]);
            }
        else
        {
            //store item to be turned to a filler sentence
            var toDecode = fillerArray[i];
            //final filler sentence format
            var finalFillerSent = [ "f",ds,{ s: sentenceChunker(toDecode[0]) },"Question",{ q: toDecode[1], as: toDecode[2], } ];
            //add now complete filler sentence to temp list
            tempArrayOfFillers.push(finalFillerSent);
        }
    }
    //add all filler sentences to items array using concatenation
    items = items.concat(tempArrayOfFillers);
}    

items = items.concat(introArray);
items = items.concat(separator1Array);
items = items.concat(practiceArray);
items = items.concat(separatorArray);
cheesecakeDecoder(cheesecakeArray);
fillerDecoder(fillerArray);